// SysInfoDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SysInfo.h"
#include "SysInfoDlg.h"

#ifdef _DEBUG
	#define new DEBUG_NEW
	#undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

#define REG_KEY_MSINFO_PATH1		_T("Software\\Microsoft\\Shared Tools\\MSInfo")
#define REG_KEY_MSINFO_PATH2		_T("Software\\Microsoft\\Shared Tools Location")
#define REG_VAL_MSINFO_PATH1		_T("Path")
#define REG_VAL_MSINFO_PATH2		_T("MSInfo")
#define MSINFO_EXE_NAME				_T("\\MSInfo32.exe")

#include <atlbase.h> // Required for the CRegKey

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	CHyperLink		m_wndlnkCopyright;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	DDX_Control(pDX, IDC_STATIC_LNKCOPYRIGHT, m_wndlnkCopyright);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSysInfoDlg dialog

CSysInfoDlg::CSysInfoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSysInfoDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSysInfoDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSysInfoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSysInfoDlg)
	DDX_Control(pDX, IDC_STATIC_SYSINFO, m_wndLinkSysInfo);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSysInfoDlg, CDialog)
	//{{AFX_MSG_MAP(CSysInfoDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSysInfoDlg message handlers

BOOL CSysInfoDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	CString strSysInfo;	
	if(GetSysInfoPath(strSysInfo))
		m_wndLinkSysInfo.SetURL(strSysInfo);
	else
		m_wndLinkSysInfo.EnableWindow(FALSE);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CSysInfoDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSysInfoDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSysInfoDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CSysInfoDlg::OnOK() 
{	
	if((UINT)::ShellExecute(GetSafeHwnd(), _T("open"), 
		_T("MsInfo32.exe"), NULL, NULL, SW_SHOWNORMAL) <= HINSTANCE_ERROR)
	{
		CString strSysInfo;
		if(GetSysInfoPath(strSysInfo))
		{	
			HINSTANCE hRet = ::ShellExecute(GetSafeHwnd(), _T("open"), strSysInfo, 
							   NULL, NULL, SW_SHOWNORMAL);
			if((UINT)hRet <= HINSTANCE_ERROR)
				AfxMessageBox(_T("Error executing \"MsInfo32.exe\" !"));
		}
		else
		{
			AfxMessageBox(_T("Cannot locate \"MsInfo32.exe\" !"));
		}
	}
	
}

BOOL CSysInfoDlg::GetSysInfoPath(CString& strPath)
{		
		// Empty the string buffer and initialize variables.		
		CRegKey	cReg;
		strPath.Empty();		
				
		// Try to find "msfinfo32.exe" at the first location:
		
		if (cReg.Open(HKEY_LOCAL_MACHINE, REG_KEY_MSINFO_PATH1) == ERROR_SUCCESS)
		{
			DWORD		dwSize = _MAX_DIR;
			LONG		nRet = -1;

			nRet = cReg.QueryValue(strPath.GetBuffer(dwSize), 
					REG_VAL_MSINFO_PATH1, &dwSize);			
			
			strPath.ReleaseBuffer();
			strPath.FreeExtra();

			// If first attemp fails then try to find "msfinfo32.exe" 
			// at the second location:

			if (nRet != ERROR_SUCCESS)
			{
				if (cReg.Open(HKEY_LOCAL_MACHINE, 
					REG_KEY_MSINFO_PATH2) == ERROR_SUCCESS)
				{
					nRet = cReg.QueryValue(strPath.GetBuffer(dwSize), 
						   REG_VAL_MSINFO_PATH2, &dwSize);					
					
					strPath.ReleaseBuffer();
					strPath.FreeExtra();	
					
					// The second location does not contain the full
					// path (exe name is missing), complete it:

					if (nRet == ERROR_SUCCESS)					
						strPath += MSINFO_EXE_NAME;
				}
			}
			cReg.Close();	
		}
		
		// Check for valid file path:
		BOOL bRet = FALSE;
		if (!strPath.IsEmpty())
		{
			CFileFind	cFinder;
			bRet = cFinder.FindFile(strPath);
			cFinder.Close(); 
		}
		return bRet;
}

BOOL CAboutDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();	
	m_wndlnkCopyright.SetURL(_T("mailto:armenh@cit.am?subject=SysInfo&body="));	
	return TRUE;
}
