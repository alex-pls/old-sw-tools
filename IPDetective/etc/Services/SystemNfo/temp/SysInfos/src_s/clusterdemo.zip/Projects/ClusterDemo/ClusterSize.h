/////////////////////////////////////////////////////////////////////////////
// CClusterSize 
// ------------
// This class can be used to find the cluster size on any Windows95 or 98 
// computers.  I have not been able to test it under Windows NT, but my guess
// is that it wouldn't work, or wouldn't be applicable.  
//
// Author:	Daniel Hirsch
//			danielh@comports.com
//							
// You may use this code freely, but please keep my name and email address
// with it.  I also request that if you do use it, send me some email and 
// tell me so.  I spent quite a while figuring this out, so I would love
// to hear if anybody appreciates my work.  
/////////////////////////////////////////////////////////////////////////////



// ClusterSize.h: interface for the CClusterSize class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CLUSTERSIZE_H__72CA86D0_4120_11D2_9CD7_00609736C6B2__INCLUDED_)
#define AFX_CLUSTERSIZE_H__72CA86D0_4120_11D2_9CD7_00609736C6B2__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CClusterSize  
{
public:
	bool SetDrive(CString strDrive);	// sets the current drive 
	CClusterSize();	// two step constructor
	CClusterSize(CString strDrive);	// one step contsructor
	virtual ~CClusterSize();
	DWORD GetClusterSize();

	CString GetDrive()			{ return m_strDrive; }

protected:
	CString m_strDrive;		// The path of the drive to get the cluster size of
							/* should be in the form of C:\ */
};

//////////////////////
// Definitions for getting cluster size in OSR2
//////////////////////
#define VWIN32_DIOC_DOS_DRIVEINFO 6

// holds the register values before and after the call to get the cluster size	
typedef struct _DIOC_REGISTERS 
{
	DWORD reg_EBX;
	DWORD reg_EDX;
	DWORD reg_ECX;
	DWORD reg_EAX;
	DWORD reg_EDI;
	DWORD reg_ESI;
	DWORD reg_Flags;
} DIOC_REGISTERS, *PDIOC_REGISTERS;

#pragma pack(1)
// the structure returned by VWIN32_DIOC_DOS_DRIVEINFO
typedef struct _ExtGetDskFreSpcStruc
{
	WORD ExtFree_Size;
	WORD ExtFree_Level;
	DWORD ExtFree_SectorsPerCluster;
	DWORD ExtFree_BytesPerSector;
	DWORD ExtFree_AvailableClusters;
	DWORD ExtFree_TotalClusters;
	DWORD ExtFree_AvailablePhysSectors;
	DWORD ExtFree_TotalPhysSectors;
	DWORD ExtFree_AvailableAllocationUnits;
	DWORD ExtFree_TotalAllocationUnits;
	DWORD ExtFree_Rsvd[2];
} ExtGetDskFreSpcStruc, *pExtGetDskFreSpcStruc;
#pragma pack()

#endif // !defined(AFX_CLUSTERSIZE_H__72CA86D0_4120_11D2_9CD7_00609736C6B2__INCLUDED_)
