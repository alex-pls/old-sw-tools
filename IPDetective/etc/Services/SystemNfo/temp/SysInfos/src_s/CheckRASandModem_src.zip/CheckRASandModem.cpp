#include <afxwin.h>
#include <atlbase.h>

//Operating System Information Checker

class OsVersionChecker
{
	CString GetSystemVersion()
	{
		CString szSysInfo;
	   OSVERSIONINFOEX osvi;
	   BOOL bOsVersionInfoEx;

	   ZeroMemory(&osvi, sizeof(OSVERSIONINFOEX));
	   osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEX);

	   if( !(bOsVersionInfoEx = GetVersionEx ((OSVERSIONINFO *) &osvi)) )
	   {
		  osvi.dwOSVersionInfoSize = sizeof (OSVERSIONINFO);
		  if (! GetVersionEx ( (OSVERSIONINFO *) &osvi) ) 
			 return szSysInfo;
	   }

	   switch (osvi.dwPlatformId)
	   {
		  case VER_PLATFORM_WIN32_NT:

			 if ( osvi.dwMajorVersion <= 4 )
				szSysInfo="Microsoft Windows NT";

			 if ( osvi.dwMajorVersion == 5 && osvi.dwMinorVersion == 0 )
				szSysInfo="Microsoft Windows 2000";

			 if ( osvi.dwMajorVersion == 5 && osvi.dwMinorVersion == 1 )
				szSysInfo="Microsoft Windows XP";

    
			 break;

		  case VER_PLATFORM_WIN32_WINDOWS:

			 if (osvi.dwMajorVersion == 4 && osvi.dwMinorVersion == 0)
			 {
				 szSysInfo = "Microsoft Windows 95";
			  } 

			 if (osvi.dwMajorVersion == 4 && osvi.dwMinorVersion == 10)
			 {
				 szSysInfo += "Microsoft Windows 98";
			 } 

			 if (osvi.dwMajorVersion == 4 && osvi.dwMinorVersion == 90)
			 {
				 szSysInfo = "Microsoft Windows Me";
			 } 
			 break;

		  case VER_PLATFORM_WIN32s:
			 szSysInfo = "Microsoft Win32s";
			 break;
	   }
	   return szSysInfo; 
	}

public:
	BOOL IsOS(CString szOsName)
	{
		
		
		if(szOsName == "NT")
		{
			if( GetSystemVersion() == "Microsoft Windows NT")
				return TRUE;
		}
		else if(szOsName == "XP")
		{
			if( GetSystemVersion() == "Microsoft Windows 2000")
				return TRUE;
		}
		else if(szOsName == "2000")
		{
			if( GetSystemVersion() == "Microsoft Windows XP")
				return TRUE;
		}
		else if(szOsName == "95")
		{
			if( GetSystemVersion() == "Microsoft Windows 95")
				return TRUE;
		}
		else if(szOsName == "98")
		{
			if( GetSystemVersion() == "Microsoft Windows 98")
				return TRUE;
		}
		else if(szOsName == "ME")
		{
			if( GetSystemVersion() == "Microsoft Windows Me")
				return TRUE;
		}
		
		return FALSE;
	}
};

//Modem Checker

class CModemCheck
{
	CRegKey m_CRegKey;
	OsVersionChecker m_OSVersionCheck;
public:
	BOOL IsModemInstalled();
	void StartModemInstallation();
};

BOOL CModemCheck::IsModemInstalled()
{
	DWORD dwCount = 0;

	if( m_OSVersionCheck.IsOS("NT") || m_OSVersionCheck.IsOS("2000") || m_OSVersionCheck.IsOS("XP") )
	{
		if(m_CRegKey.Open( HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\Class\\{4D36E96D-E325-11CE-BFC1-08002BE10318}" ) == ERROR_SUCCESS)
		{
			if( RegQueryInfoKey(m_CRegKey.m_hKey,NULL,NULL,NULL,&dwCount,NULL,NULL,NULL,NULL,NULL,NULL,NULL) == ERROR_SUCCESS )
			{
				m_CRegKey.Close();
				if( dwCount >= 1)
					return TRUE;
			}
			else
			{
				m_CRegKey.Close();
			}
		}
	}
	else 
	{
		if(m_CRegKey.Open( HKEY_LOCAL_MACHINE,"System\\CurrentControlSet\\Services\\Class\\Modem" ) ==ERROR_SUCCESS)
		{
			if( RegQueryInfoKey(m_CRegKey.m_hKey,NULL,NULL,NULL,&dwCount,NULL,NULL,NULL,NULL,NULL,NULL,NULL) == ERROR_SUCCESS )
			{
				m_CRegKey.Close();
				if( dwCount >= 1)
					return TRUE;
			}
			else
			{
				m_CRegKey.Close();
			}
		}
	}
	return FALSE;
}

void CModemCheck::StartModemInstallation()
{
	WinExec("rundll32.exe shell32.dll,Control_RunDLL Modem.cpl,,add",1);
}

//Dial-up Networking(DUN), Remote Access Service(RAS) Checker.

class CRASCheck
{
	CRegKey m_CRegKey;
	OsVersionChecker m_OSVersionCheck;
public:
	BOOL IsRASInstalled();
	void StartRASInstallation();
};

BOOL CRASCheck::IsRASInstalled()
{
	DWORD dwLen;
	if( m_OSVersionCheck.IsOS("NT") || m_OSVersionCheck.IsOS("2000") || m_OSVersionCheck.IsOS("XP") ) 
	{
		if(m_CRegKey.Open(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Services\\RemoteAccess") == ERROR_SUCCESS)
		{
			m_CRegKey.Close();
			return TRUE;
		}
	}
	else if(m_OSVersionCheck.IsOS("ME"))
	{
		if( m_CRegKey.Open( HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Setup\\OptionalComponents\\RNA\\" ) == ERROR_SUCCESS)
		{
			CString szTemp;
			if(m_CRegKey.QueryValue(NULL,"Installed",&dwLen)==ERROR_SUCCESS)
			{
				if(m_CRegKey.QueryValue(szTemp.GetBuffer(dwLen),"Installed",&dwLen)==ERROR_SUCCESS)
				{
					szTemp.ReleaseBuffer();
					m_CRegKey.Close();

					szTemp.TrimLeft();
					szTemp.TrimRight();

					if(szTemp.IsEmpty())
					{
						MessageBox(0,"Sorry! Unable to detect whether Dial-up Networking is already installed or not.","Dial-up Networking Checker",MB_ICONERROR);
						PostQuitMessage(0);
					}
					
					if(szTemp.CompareNoCase("1")==0)
						return TRUE;
				}
			}
		}
	}
	else  
	{
		if(m_CRegKey.Open(HKEY_LOCAL_MACHINE,"System\\CurrentControlSet\\Services\\RemoteAccess\\NetworkProvider") == ERROR_SUCCESS)
		{
			m_CRegKey.Close();
			return TRUE;
		}
	}

	return FALSE;
}

void CRASCheck::StartRASInstallation()
{
	if( m_OSVersionCheck.IsOS("NT") || m_OSVersionCheck.IsOS("2000") || m_OSVersionCheck.IsOS("XP") )
	{
		WinExec("rasphone.exe",1);
	}
	else
	{
		WinExec("rundll.exe setupx.dll,InstallHinfSection rna 0 rna.inf",1);
	}
}

class CRASModemCheckApp:public CWinApp
{
	CModemCheck m_CModemCheck;
	CRASCheck m_CRASCheck;

	
public :
	BOOL InitInstance()
	{
		if( !m_CModemCheck.IsModemInstalled() )
		{
			m_CModemCheck.StartModemInstallation();
		}
		else
			MessageBox(NULL,"Modem is already Installed in your system.","Modem Checker",MB_OK|MB_ICONINFORMATION);

		if( ! m_CRASCheck.IsRASInstalled() )
		{
			m_CRASCheck.StartRASInstallation();
		}
		else
			MessageBox(NULL,"Dial-up Networking is already Installed in your system.","DUN, RAS Checker",MB_OK|MB_ICONINFORMATION);

		return TRUE;
	}
}m_appObj;
