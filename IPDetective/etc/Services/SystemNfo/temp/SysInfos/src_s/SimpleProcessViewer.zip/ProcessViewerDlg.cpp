/*----------------------------------------------------------*/
//  INCLUDE SECTION
/*----------------------------------------------------------*/
#include "stdafx.h"
#include "ProcessViewer.h"
#include "ProcessViewerDlg.h"
#include "Tlhelp32.h"
#include <Winbase.h>
/*----------------------------------------------------------*/

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


//Message for Tray Notification
#define WM_TRAY_NOTIFY WM_USER+5




CProcessViewerDlg::CProcessViewerDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CProcessViewerDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CProcessViewerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST1, m_list);
}


BEGIN_MESSAGE_MAP(CProcessViewerDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_COMMAND(ID_VIEW_REFRESH, OnViewRefresh)
	ON_WM_CONTEXTMENU()
	ON_WM_TIMER()
	ON_WM_CTLCOLOR()
	ON_MESSAGE(WM_TRAY_NOTIFY, OnTrayNotify)
	ON_COMMAND(ID_VIEW_EXIT, OnViewExit)
END_MESSAGE_MAP()


BOOL CProcessViewerDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetTimer(1,3000,NULL);

	
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon


	//Insert Columns into ListControl
	m_list.InsertColumn(0,"Process Name");
	m_list.InsertColumn(1,"PID");
	m_list.InsertColumn(2,"Number Of Threads");
	m_list.InsertColumn(3,"Parent PID");
	m_list.InsertColumn(4,"Priority");

	
	//set the back and fore colors
	m_list.SetBkColor (RGB(0,0,0));
	m_list.SetTextBkColor (RGB(0,0,0));
	m_list.SetTextColor (RGB(0,255,0));

	
	//show the processes
	ShowProcessData();	
	
	return TRUE;  
}

void CProcessViewerDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
	
	}
	else if(nID==SC_MINIMIZE )
	{
		
		//If window is minimized show an icon in the system tray
		data.cbSize =sizeof(NOTIFYICONDATA);
		data.hIcon = AfxGetApp()->LoadIcon (IDI_ICON1);
		data.hWnd =this->m_hWnd ;
		strcpy(data.szTip ,"A very Simple process viewer");
		data.uFlags = NIF_ICON | NIF_MESSAGE| NIF_TIP ;
		data.uID =0;
		data.uCallbackMessage = WM_TRAY_NOTIFY;
		Shell_NotifyIcon ( NIM_ADD ,&data);
		ShowWindow(SW_HIDE);
		return;
		
	}
	CDialog::OnSysCommand(nID, lParam);
}


void CProcessViewerDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); 
		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CProcessViewerDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}


void CProcessViewerDlg::ShowProcessData()
{
	
	//Clear the list
	m_list.DeleteAllItems ();

	//set column widths
	m_list.SetColumnWidth(0,100);
	m_list.SetColumnWidth(1,100);
	m_list.SetColumnWidth(2,100);
	m_list.SetColumnWidth(3,100);
	m_list.SetColumnWidth(4,100);
	
	//Get the snapshot of the system
	hSnapShot=CreateToolhelp32Snapshot (TH32CS_SNAPALL,NULL);


	PROCESSENTRY32 pEntry;
	pEntry.dwSize =sizeof(pEntry);
	
	//Buffer for Process Info
	char szProcessInfo[255];
	
	//Get first process
	Process32First (hSnapShot,&pEntry);
	
	//Iterate thru all processes
	while(1)
	{
	  BOOL hRes=Process32Next (hSnapShot,&pEntry);

	  if(hRes==FALSE)
		  break;

	  sprintf(szProcessInfo,"%d",pEntry.th32ProcessID );
	  m_list.InsertItem(0,pEntry.szExeFile);


	  m_list.SetItemText(0,0,pEntry.szExeFile);
	  m_list.SetItemText(0,1,szProcessInfo);

	  sprintf(szProcessInfo,"%d",pEntry.cntThreads );
	  m_list.SetItemText(0,2,szProcessInfo);

	  sprintf(szProcessInfo,"%d",pEntry.th32ParentProcessID);
	  m_list.SetItemText(0,3,szProcessInfo);

	  sprintf(szProcessInfo,"%d",pEntry.pcPriClassBase );
	  m_list.SetItemText(0,4,szProcessInfo);
	}
	
}


void CProcessViewerDlg::OnViewRefresh() 
{
	ShowProcessData();	
}



void CProcessViewerDlg::OnContextMenu(CWnd* pWnd, CPoint point) 
{
	CMenu menu;
	menu.LoadMenu (IDR_PROCESSMENU);
	CMenu *pMenu=menu.GetSubMenu (0);
	
	int CurSel=m_list.GetNextItem (-1,LVNI_SELECTED);
	char pid[255];
	m_list.GetItemText (CurSel,1,pid,255);
	int ipid=atoi(pid);
	hProcess=::OpenProcess (PROCESS_ALL_ACCESS,FALSE ,ipid);
	DWORD dwClass=GetPriorityClass (hProcess);
	
	if(dwClass==NORMAL_PRIORITY_CLASS)
			pMenu->CheckMenuRadioItem (ID_LOW,ID_HIGH,ID_NORMAL,MF_BYCOMMAND);
	else if(dwClass==HIGH_PRIORITY_CLASS)
			pMenu->CheckMenuRadioItem (ID_LOW,ID_HIGH,ID_HIGH,MF_BYCOMMAND);
	else if(dwClass==IDLE_PRIORITY_CLASS)
			pMenu->CheckMenuRadioItem (ID_LOW,ID_HIGH,ID_LOW,MF_BYCOMMAND);
	
	pMenu->TrackPopupMenu (TPM_LEFTALIGN    ,point.x,point.y,pWnd);
}


void CProcessViewerDlg::OnTimer(UINT nIDEvent) 
{
	ShowProcessData();
	CDialog::OnTimer(nIDEvent);
}

HBRUSH CProcessViewerDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	
	if(nCtlColor==CTLCOLOR_DLG)
		return CreateSolidBrush (RGB(255,255,255));

	return hbr;
}

void CProcessViewerDlg::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CDialog::OnShowWindow(bShow, nStatus);
}

LRESULT CProcessViewerDlg::OnTrayNotify(WPARAM wParam, LPARAM lParam)
{
   if (lParam == WM_LBUTTONUP)
	{
		Shell_NotifyIcon (NIM_DELETE, &data);
		ShowWindow(SW_SHOW);
	} 
	if (lParam == WM_RBUTTONDOWN)
	{
		CMenu menu;
		VERIFY(menu.LoadMenu(IDR_MENU1));
		CMenu* pPopup = menu.GetSubMenu(0);
		ASSERT(pPopup != NULL); 
		CRect screen;
		GetDesktopWindow()->GetWindowRect(screen);
		pPopup->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON,
							   screen.right,
							   screen.bottom,
							   AfxGetMainWnd());
	} 
	return LRESULT(0);
}

void CProcessViewerDlg::OnViewExit() 
{
	KillTimer(1);
	EndDialog (0);
}


void CProcessViewerDlg::OnOK() 
{
	KillTimer(1);
	CDialog::OnOK();
}
