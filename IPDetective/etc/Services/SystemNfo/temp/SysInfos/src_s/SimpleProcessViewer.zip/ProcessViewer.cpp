// ProcessViewer.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "ProcessViewer.h"
#include "ProcessViewerDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


BEGIN_MESSAGE_MAP(CProcessViewerApp, CWinApp)
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()


CProcessViewerApp::CProcessViewerApp()
{
	
}


CProcessViewerApp theApp;


BOOL CProcessViewerApp::InitInstance()
{
	AfxEnableControlContainer();

	
#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	CProcessViewerDlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
		
	}
	else if (nResponse == IDCANCEL)
	{
		
	}
	return FALSE;
}
