// Disclaimer and Copyright Information
// Pardesi Services LLC.  Copyright (c) 2001
//						  All rights reserved.
// PSKeyboardInformation.h : Declaration of the PSKeyboardInformation
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////

// Revision History:
//	4/16/2001	Initial Creation
//


#ifndef __PSKEYBOARDINFORMATION_H_
#define __PSKEYBOARDINFORMATION_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// PSKeyboardInformation
class ATL_NO_VTABLE PSKeyboardInformation : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<PSKeyboardInformation, &CLSID_PSKeyboardInformation>,
	public ISupportErrorInfo,
	public IDispatchImpl<IPSKeyboardInformation, &IID_IPSKeyboardInformation, &LIBID_SYSTEMKEYBOARDLib>
{
public:
	PSKeyboardInformation()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_PSKEYBOARDINFORMATION)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(PSKeyboardInformation)
	COM_INTERFACE_ENTRY(IPSKeyboardInformation)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IPSKeyboardInformation
public:
	STDMETHOD(get_LightIndicators)(/*[out, retval]*/ short *pVal);
	STDMETHOD(get_FunctionKeys)(/*[out, retval]*/ short *pVal);
	STDMETHOD(get_Type)(/*[out, retval]*/ BSTR *pVal);
private:
	short m_nLightIndicators;
	short m_nFunctionKeys;
	CComBSTR m_bstrType;
};

#endif //__PSKEYBOARDINFORMATION_H_
