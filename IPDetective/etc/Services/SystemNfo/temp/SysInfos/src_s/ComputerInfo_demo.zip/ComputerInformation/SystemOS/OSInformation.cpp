// Disclaimer and Copyright Information
// OSInformation.cpp : Implementation of COSInformation
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////

// Revision History
//	3/8/2001	Added support for Windows Whistler Detection
//

#include "stdafx.h"
#include "SystemOS.h"
#include "OSInformation.h"

#ifndef VER_SUITE_PERSONAL
	#define VER_SUITE_PERSONAL	0x00000200
#endif

/////////////////////////////////////////////////////////////////////////////
// COSInformation

STDMETHODIMP COSInformation::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IOSInformation
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (::InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP COSInformation::get_BuildNumber(long *pVal)
{
	HRESULT hRes = S_OK;
	if ((hRes = GetInformation ()) != S_OK) {
		return hRes;
	}

	*pVal = m_sBuildNumber;

	return S_OK;
}

STDMETHODIMP COSInformation::get_IsWin95(BOOL *pVal)
{
	HRESULT hRes = S_OK;
	if ((hRes = GetInformation ()) != S_OK) {
		return hRes;
	}

	*pVal = m_bIsWin95;

	return S_OK;
}

STDMETHODIMP COSInformation::get_Platform(BSTR *pVal)
{
	HRESULT hRes = S_OK;
	if ((hRes = GetInformation ()) != S_OK) {
		return hRes;
	}

	*pVal = m_bstrPlatform.Copy ();

	return S_OK;
}

STDMETHODIMP COSInformation::get_MinorVersion(BSTR *pVal)
{
	HRESULT hRes = S_OK;
	if ((hRes = GetInformation ()) != S_OK) {
		return hRes;
	}

	*pVal = m_bstrMinorVersion.Copy ();

	return S_OK;
}

STDMETHODIMP COSInformation::get_ServicePack(BSTR *pVal)
{
	HRESULT hRes = S_OK;
	if ((hRes = GetInformation ()) != S_OK) {
		return hRes;
	}

	*pVal = m_bstrServicePack.Copy ();

	return S_OK;
}

STDMETHODIMP COSInformation::GetOSInformation(long *plBuildNumber,
											  BSTR *pbstrPlatform,
											  BSTR *pbstrSuites,
											  BSTR *pbstrMinorVersion,
											  BSTR *pbstrServicePack)
{
	HRESULT hRes = S_OK;
	if ((hRes = GetInformation ()) != S_OK)
	{
		return hRes;
	}

	*plBuildNumber = m_sBuildNumber;
	*pbstrPlatform = m_bstrPlatform.Copy ();
	*pbstrMinorVersion = m_bstrMinorVersion.Copy ();
	*pbstrServicePack = m_bstrServicePack.Copy ();

	return S_OK;
}

HRESULT
COSInformation::GetInformation ()
{
	int stat = 0;
	UINT resourceID = 0;
	TCHAR data [64];
	DWORD dataSize, dwError;
	OSVERSIONINFOEX  versionInfo;
	HKEY hKey;
	LONG result;
	LPTSTR lpErrDesc = NULL;
	BOOL bOsVersionInfoEx = FALSE;
	CComBSTR bstrTemp;

	// If we already have generated the information, then there is no need to do it again.
	if (m_bInfoGenerated)
	{
		return S_OK;
	}
	
	// Try calling GetVersionEx using the OSVERSIONINFOEX structure,
	// If that fails, try using the OSVERSIONINFO structure.
	::ZeroMemory(&versionInfo, sizeof(OSVERSIONINFOEX));
	versionInfo.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEX);

	if( !(bOsVersionInfoEx = ::GetVersionEx ((OSVERSIONINFO *) &versionInfo)) )
	{
		// If OSVERSIONINFOEX doesn't work, try OSVERSIONINFO.
		versionInfo.dwOSVersionInfoSize = sizeof (OSVERSIONINFO);
		if (!::GetVersionEx ( (OSVERSIONINFO *) &versionInfo) ) 
		{
			dwError = GetLastError ();
			MakeErrorDesc (dwError, lpErrDesc);
			return Error (lpErrDesc, IID_IOSInformation, E_FAIL);
		}
   }

	// If NT ,then check if its server or workstation.
	char szBuffer[128];

	if (versionInfo.dwPlatformId == VER_PLATFORM_WIN32_NT)
	{
		// If OSVERSIONEX has been used, then we will try to extract
		// the info from that structure.
		if (bOsVersionInfoEx)
		{
			// Load the platform type information.
			switch (versionInfo.wProductType)
			{
				case VER_NT_WORKSTATION:
					resourceID = IDS_WIN2K_PROF;
					if (versionInfo.dwMinorVersion > 0)
					{
						resourceID = IDS_WHISTLER_PROF;
					}
					break;
				case VER_NT_DOMAIN_CONTROLLER:
					resourceID = IDS_WIN2K_DOMAIN_CONTROLLER;
					break;
				case VER_NT_SERVER:
					resourceID = IDS_WIN2K_SERVER;
					if (versionInfo.dwMinorVersion > 0)
					{
						resourceID = IDS_WHISTLER_SERVER;
					}
					break;
			}

			m_bstrPlatform.LoadString (resourceID);

			// Load the suites installed.
			if (versionInfo.wSuiteMask & VER_SUITE_DATACENTER)
			{
				m_bstrSuites.LoadString (IDS_SUITE_DATACENTER);
			}
			if (versionInfo.wSuiteMask & VER_SUITE_ENTERPRISE)
			{
				bstrTemp.LoadString (IDS_SUITE_ENTERPRISE);
				m_bstrSuites.Append (_T (";"));
				m_bstrSuites.Append (bstrTemp);
			}
			if (versionInfo.wSuiteMask & VER_SUITE_BACKOFFICE)
			{
				bstrTemp.LoadString (IDS_SUITE_BACKOFFICE);
				m_bstrSuites.Append (_T (";"));
				m_bstrSuites.Append (bstrTemp);
			}
			if (versionInfo.wSuiteMask & VER_SUITE_SMALLBUSINESS)
			{
				bstrTemp.LoadString (IDS_SUITE_SMALLBUSINESS);
				m_bstrSuites.Append (_T (";"));
				m_bstrSuites.Append (bstrTemp);
			}
			if (versionInfo.wSuiteMask & VER_SUITE_SMALLBUSINESS_RESTRICTED)
			{
				bstrTemp.LoadString (IDS_SUITE_SMALLBUSINESS_RESTRICTED);
				m_bstrSuites.Append (_T (";"));
				m_bstrSuites.Append (bstrTemp);
			}
			if (versionInfo.wSuiteMask & VER_SUITE_TERMINAL)
			{
				bstrTemp.LoadString (IDS_SUITE_TERMINAL);
				m_bstrSuites.Append (_T (";"));
				m_bstrSuites.Append (bstrTemp);
			}
			if (versionInfo.wSuiteMask & VER_SUITE_PERSONAL)
			{
				bstrTemp.LoadString (IDS_SUITE_PERSONAL);
				m_bstrSuites.Append (_T (";"));
				m_bstrSuites.Append (bstrTemp);
			}
		}
		else
		{

			// there is no direct way of telling from ODVERSIONINFO thats is it 
			// workstation or server version.
			// There we need to check in the registry.
			if (versionInfo.dwMajorVersion <= 4)
			{
				m_bstrPlatform.LoadString (IDS_WINDOWS_NT);
			}
			else if (versionInfo.dwMajorVersion == 5 &&
					 versionInfo.dwMinorVersion == 0)
			{
				m_bstrPlatform.LoadString (IDS_WINDOWS_2000);
			}
			else if (versionInfo.dwMajorVersion == 5 &&
					 versionInfo.dwMinorVersion > 0)
			{
				m_bstrPlatform.LoadString (IDS_WINDOWS_WHISTLER);
			}

			dataSize = sizeof (data);
			result = ::RegOpenKeyEx (HKEY_LOCAL_MACHINE,
									"System\\CurrentControlSet\\Control\\ProductOptions",
									0, KEY_QUERY_VALUE, &hKey);

			// If there is error in opening the registry key, return
			if (result != ERROR_SUCCESS)
			{
				dwError = ::GetLastError ();
				MakeErrorDesc (dwError, lpErrDesc);
				return Error (lpErrDesc, IID_IOSInformation, E_FAIL);
			}

			result = ::RegQueryValueEx (hKey, _T("ProductType"), NULL, NULL, (LPBYTE) data,
										&dataSize);

			// Make sure to close the reg key
			RegCloseKey (hKey);

			if (result != ERROR_SUCCESS)
			{
				dwError = GetLastError ();
				MakeErrorDesc (dwError, lpErrDesc);
				return Error (lpErrDesc, IID_IOSInformation, E_FAIL);
			}

			// Check what string has been returned
			if (lstrcmpi (data, "WinNT") == 0)
			{
				resourceID = IDS_NT_WORKSTATION;
			}
			else if (lstrcmpi (data, "ServerNT") == 0)
			{
				resourceID = IDS_NT_SERVER;
			}
			else
			{
				resourceID = IDS_NT_DOMAIN_CONTROLLER;
			}
			
			bstrTemp.LoadString (resourceID);
			m_bstrPlatform.Append (_T ("-"));
			m_bstrPlatform.Append (bstrTemp);
		}

		// Check the version number
		switch (versionInfo.dwMajorVersion)
		{
			case 3:
				resourceID = IDS_NT_351;
				break;
			case 4:
				resourceID = IDS_NT_40;
				break;
			case 5:
				resourceID = IDS_NT_50;
				if (versionInfo.dwMinorVersion > 0)
				{
					resourceID = IDS_NT_51;
				}
				break;
		}

		m_bstrMinorVersion.LoadString (resourceID);
		// Get the build number.
		m_sBuildNumber = versionInfo.dwBuildNumber;
	}
	else if (versionInfo.dwPlatformId == VER_PLATFORM_WIN32_WINDOWS)
	{
		resourceID = IDS_WINDOWS_95;
		m_bIsWin95 = TRUE;

		// Windows 98 test
		if ((versionInfo.dwMajorVersion > 4) || ((versionInfo.dwMajorVersion == 4) &&
			(versionInfo.dwMinorVersion > 0)))
		{
			// NKK-- 2/7/2001
			// Code added for WinME detection.
			if (versionInfo.dwMinorVersion < 90)
			{
				resourceID = IDS_WINDOWS_98;
			}
			else
			{
				resourceID = IDS_WINDOWS_ME;
			}
		}

		if (LoadString (_Module.GetResourceInstance(), resourceID, szBuffer, 
						sizeof (szBuffer)))
		{
			m_bstrPlatform = szBuffer;
		}
			
		// For win95, build number is low order word
		m_sBuildNumber = (DWORD)(LOBYTE(LOWORD(versionInfo.dwBuildNumber)));
	}
	else if (versionInfo.dwPlatformId == VER_PLATFORM_WIN32s)
	{
		if (LoadString (_Module.GetResourceInstance(), IDS_WINDOWS_32S, szBuffer, 
						sizeof (szBuffer)))
		{
			m_bstrPlatform = szBuffer;
		}
		else
		{
			if (LoadString (_Module.GetResourceInstance(), IDS_WINDOWS_31, szBuffer, 
				sizeof (szBuffer)))
			{
				m_bstrPlatform = szBuffer;
			}
		}
	}

	// Get service pack information.
	m_bstrServicePack = versionInfo.szCSDVersion;
	m_bInfoGenerated = true;
	return S_OK;
}

void
COSInformation::MakeErrorDesc (DWORD errCode, LPVOID lpErrorDesc)
{
	::FormatMessage (FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | 
					 FORMAT_MESSAGE_IGNORE_INSERTS, NULL,
					 errCode,
					 MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
					 (LPTSTR) &lpErrorDesc,
					 0,
					 NULL);
}
