// PnPDevicesInfo.cpp : Implementation of CPnPDevicesInfo
#include "stdafx.h"

#include "SystemPnPDevices.h"
#include "PnPDevicesInfo.h"
#include "PnPDevices.h"
#include "PnPDevice.h"
#include "PnPDeviceDriver.h"
#include "PnPDeviceDrivers.h"

/////////////////////////////////////////////////////////////////////////////
// CPnPDevicesInfo

STDMETHODIMP CPnPDevicesInfo::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IPnPDevicesInfo
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (::InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CPnPDevicesInfo::GetPnpDevices(IPnPDevices** pDevices)
{
	HRESULT hr = S_OK;
	ATLASSERT (NULL != pDevices);
	if (NULL == pDevices)
	{
		return E_POINTER;
	}

	if (SUCCEEDED (this->InitInfo ()))
	{
		hr = m_pDevices->QueryInterface (IID_IPnPDevices,
										 reinterpret_cast<void **>(pDevices));
	}

	return hr;
}

HRESULT CPnPDevicesInfo::InitInfo(void)
{
	HRESULT hr = S_OK;
	if (true == m_bInfoInitialized)
	{
		return S_OK;
	}

	HDEVINFO hDevInfo = NULL;
	SP_DEVINFO_DATA DeviceInfoData;
	DWORD dwIdx = 0;

	// First create device information set that contains all devices of a
	// specified class on a local or remote computer.
	hDevInfo = SetupDiGetClassDevs (
									NULL,
									NULL,					// Enumerator
									NULL,					// Parent window handle
									DIGCF_PRESENT | DIGCF_ALLCLASSES	// Flags to use
									);
	if (INVALID_HANDLE_VALUE == hDevInfo)
	{
		return E_FAIL;
	}
	
	// Enumerate through all devices in the set.
	CComObject<CPnPDevices> *pDevices = NULL;
	hr = CComObject<CPnPDevices>::CreateInstance (&pDevices);
	if (FAILED (hr))
	{
		return hr;
	}

	hr = pDevices->QueryInterface (IID_IPnPDevices, reinterpret_cast<void **>(&m_pDevices));
	if (FAILED (hr))
	{
		return hr;
	}

	// *********************** Use of DDK *************************
	// SetupDiEnumDeviceInfo function has been documented in DDK
	// ************************************************************

	// SetupDiEnumDeviceInfo returns a context structure for a device information
	// element of a device information set. Each call returns information about
	// one device; the function can be called repeatedly to get information about
	// several devices.
	DeviceInfoData.cbSize = sizeof(SP_DEVINFO_DATA);
	while (SetupDiEnumDeviceInfo (hDevInfo, dwIdx, &DeviceInfoData))
	{
		dwIdx++;
		std::string strInfo;
		CComObject<CPnPDevice> *pDevice = NULL;
		CComObject<CPnPDeviceDrivers> *pDrivers = NULL;

		hr = CComObject<CPnPDevice>::CreateInstance (&pDevice);
		if (FAILED (hr))
		{
			return hr;
		}

		// Get device type.
		hr = GetDeviceRegistryInfo (hDevInfo, &DeviceInfoData, SPDRP_DEVTYPE, strInfo);
		if (SUCCEEDED (hr))
		{
			pDevice->m_bstrDeviceType = strInfo.c_str ();
		}
		hr = GetDeviceRegistryInfo (hDevInfo, &DeviceInfoData, SPDRP_ADDRESS, strInfo);
		hr = GetDeviceRegistryInfo (hDevInfo, &DeviceInfoData, SPDRP_BUSNUMBER, strInfo);
		hr = GetDeviceRegistryInfo (hDevInfo, &DeviceInfoData, SPDRP_BUSTYPEGUID, strInfo);
		hr = GetDeviceRegistryInfo (hDevInfo, &DeviceInfoData, SPDRP_CAPABILITIES, strInfo);
		hr = GetDeviceRegistryInfo (hDevInfo, &DeviceInfoData, SPDRP_CHARACTERISTICS, strInfo);
		hr = GetDeviceRegistryInfo (hDevInfo, &DeviceInfoData, SPDRP_CLASS, strInfo);
		hr = GetDeviceRegistryInfo (hDevInfo, &DeviceInfoData, SPDRP_CLASSGUID, strInfo);
		if (SUCCEEDED (hr))
		{
			pDevice->m_bstrClassGUID = strInfo.c_str ();
		}
		hr = GetDeviceRegistryInfo (hDevInfo, &DeviceInfoData, SPDRP_COMPATIBLEIDS, strInfo);
		hr = GetDeviceRegistryInfo (hDevInfo, &DeviceInfoData, SPDRP_CONFIGFLAGS, strInfo);
		hr = GetDeviceRegistryInfo (hDevInfo, &DeviceInfoData, SPDRP_DEVICEDESC, strInfo);
		if (SUCCEEDED (hr))
		{
			pDevice->m_bstrDescription = strInfo.c_str ();
		}
		hr = GetDeviceRegistryInfo (hDevInfo, &DeviceInfoData, SPDRP_DRIVER, strInfo);
		if (SUCCEEDED (hr))
		{
			pDevice->m_bstrDriver = strInfo.c_str ();
			hr = CComObject<CPnPDeviceDrivers>::CreateInstance (&pDrivers);
			if (SUCCEEDED (hr))
			{
				hr = this->GetDeviceDriverInfo (hDevInfo, &DeviceInfoData, pDrivers);
				if (SUCCEEDED (hr))
				{
					pDrivers->QueryInterface (IID_IPnPDeviceDrivers,
											  reinterpret_cast<void **>(&pDevice->m_pDrivers));
				}
			}
		}
		hr = GetDeviceRegistryInfo (hDevInfo, &DeviceInfoData, SPDRP_ENUMERATOR_NAME, strInfo);
		hr = GetDeviceRegistryInfo (hDevInfo, &DeviceInfoData, SPDRP_EXCLUSIVE, strInfo);
		hr = GetDeviceRegistryInfo (hDevInfo, &DeviceInfoData, SPDRP_FRIENDLYNAME, strInfo);
		if (SUCCEEDED (hr))
		{
			pDevice->m_bstrFriendlyName = strInfo.c_str ();
		}
		hr = GetDeviceRegistryInfo (hDevInfo, &DeviceInfoData, SPDRP_HARDWAREID, strInfo);
		if (SUCCEEDED (hr))
		{
			pDevice->m_bstrHWId = strInfo.c_str ();
		}
		hr = GetDeviceRegistryInfo (hDevInfo, &DeviceInfoData, SPDRP_LEGACYBUSTYPE, strInfo);
		hr = GetDeviceRegistryInfo (hDevInfo, &DeviceInfoData, SPDRP_LOCATION_INFORMATION, strInfo);
		hr = GetDeviceRegistryInfo (hDevInfo, &DeviceInfoData, SPDRP_LOWERFILTERS, strInfo);
		hr = GetDeviceRegistryInfo (hDevInfo, &DeviceInfoData, SPDRP_MFG, strInfo);
		if (SUCCEEDED (hr))
		{
			pDevice->m_bstrMfg = strInfo.c_str ();
		}
		hr = GetDeviceRegistryInfo (hDevInfo, &DeviceInfoData, SPDRP_PHYSICAL_DEVICE_OBJECT_NAME, strInfo);
		hr = GetDeviceRegistryInfo (hDevInfo, &DeviceInfoData, SPDRP_SECURITY, strInfo);
		hr = GetDeviceRegistryInfo (hDevInfo, &DeviceInfoData, SPDRP_SERVICE, strInfo);
		hr = GetDeviceRegistryInfo (hDevInfo, &DeviceInfoData, SPDRP_UI_NUMBER, strInfo);
		hr = GetDeviceRegistryInfo (hDevInfo, &DeviceInfoData, SPDRP_UI_NUMBER_DESC_FORMAT, strInfo);
		hr = GetDeviceRegistryInfo (hDevInfo, &DeviceInfoData, SPDRP_UPPERFILTERS, strInfo);

		(reinterpret_cast<IPnPDevices*>(m_pDevices))->Add (pDevice);
	}

	return S_OK;
}

HRESULT CPnPDevicesInfo::GetDeviceRegistryInfo (IN HDEVINFO  hDevInfo,
												IN PSP_DEVINFO_DATA  DeviceInfoData,
												IN DWORD  Property,
												OUT std::string &strInfo)
{
	strInfo.erase (strInfo.begin (), strInfo.end ());
	DWORD dwData;
	LPTSTR buffer = NULL;
	DWORD buffersize = 0;

	// 
	// Call function with null to begin with, 
	// then use the returned buffer size 
	// to Alloc the buffer. Keep calling until
	// success or an unknown failure.
	// 
	while (!SetupDiGetDeviceRegistryProperty (
											  hDevInfo,
											  DeviceInfoData,
											  Property,
											  &dwData,
											  (PBYTE)buffer,
											  buffersize,
											  &buffersize
											  )
											  )
	{
		if (::GetLastError() == ERROR_INSUFFICIENT_BUFFER)
		{
			// Change the buffer size.
			if (NULL != buffer)
			{
				::LocalFree(buffer);
			}
			buffer = (LPTSTR)(::LocalAlloc(LPTR,buffersize));
		}
		else
		{
			return E_FAIL;
		}
	}

	strInfo = buffer;
	
	if (NULL != buffer)
	{
		::LocalFree(buffer);
	}

	buffer = NULL;
	return S_OK;
}

HRESULT CPnPDevicesInfo::GetDeviceDriverInfo (IN HDEVINFO  DeviceInfoSet,
											  IN PSP_DEVINFO_DATA  DeviceInfoData,
											  IN IPnPDeviceDrivers *pDrivers)
{
	HRESULT hr = S_OK;
	SP_DRVINFO_DATA DriverInfoData;
	DriverInfoData.cbSize = sizeof (SP_DRVINFO_DATA);
	
	BOOLEAN bRet = SetupDiBuildDriverInfoList (DeviceInfoSet, DeviceInfoData, SPDIT_COMPATDRIVER);
	if (FALSE == bRet)
	{
		return E_FAIL;
	}
	DWORD dwIdx = 0;
	// Build the list of drivers for this device.
	while (SetupDiEnumDriverInfo (DeviceInfoSet, DeviceInfoData,
								  SPDIT_COMPATDRIVER, dwIdx, &DriverInfoData))
	{
		dwIdx++;
		if (ERROR_NO_MORE_ITEMS != ::GetLastError ())
		{
			CComObject<CPnPDeviceDriver> *pDriver = NULL;
			hr = CComObject<CPnPDeviceDriver>::CreateInstance (&pDriver);
			if (FAILED (hr))
			{
				continue;
			}
			if (DriverInfoData.DriverType == SPDIT_CLASSDRIVER)
			{
				pDriver->m_bstrType = L"Class Driver";
			}
			else
			{
				pDriver->m_bstrType = L"Compatible Driver";
			}

			pDriver->m_bstrDescription = DriverInfoData.Description;
			pDriver->m_bstrMfg = DriverInfoData.MfgName;
			pDriver->m_bstrProvider = DriverInfoData.ProviderName;
			pDriver->m_lVersion = DriverInfoData.DriverVersion;
			
			FILETIME ftLocal;
			SYSTEMTIME stTime;
			TCHAR szDate[MAX_PATH];
			// Convert the last-write time to local time.
			if (FileTimeToLocalFileTime(&DriverInfoData.DriverDate, &ftLocal))
			{
				// Convert the local file time from UTC to system time.
				FileTimeToSystemTime(&ftLocal, &stTime);

				// Build a string showing the date and time.
				wsprintf(szDate, "%02d/%02d/%d  %02d:%02d",
						 stTime.wDay, stTime.wMonth, stTime.wYear,
						 stTime.wHour, stTime.wMinute);

				pDriver->m_bstrDate = szDate;

			}

			pDrivers->Add (pDriver);
		}
	}

	return S_OK;
}
