// MultiMediaDevice.h : Declaration of the CMultiMediaDevice

#pragma once
#include "resource.h"       // main symbols



// CMultiMediaDevice

class ATL_NO_VTABLE CMultiMediaDevice : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CMultiMediaDevice, &CLSID_MultiMediaDevice>,
	public ISupportErrorInfo,
	public IDispatchImpl<IMultiMediaDevice, &IID_IMultiMediaDevice, &LIBID_SYSTEMMULTIMEDIALib, /*wMajor =*/ 1, /*wMinor =*/ 0>
{
public:
	CMultiMediaDevice()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_MULTIMEDIADEVICE)


BEGIN_COM_MAP(CMultiMediaDevice)
	COM_INTERFACE_ENTRY(IMultiMediaDevice)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}
	
	void FinalRelease() 
	{
	}

public:

};

OBJECT_ENTRY_AUTO(__uuidof(MultiMediaDevice), CMultiMediaDevice)
