// MainPropSheet.cpp : implementation file
//

#include "stdafx.h"
#include "SystemInformation.h"
#include "MainPropSheet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainPropSheet

IMPLEMENT_DYNAMIC(CMainPropSheet, CPropertySheet)

CMainPropSheet::CMainPropSheet(UINT nIDCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(nIDCaption, pParentWnd, iSelectPage)
{
}

CMainPropSheet::CMainPropSheet(LPCTSTR pszCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(pszCaption, pParentWnd, iSelectPage)
{
}

CMainPropSheet::~CMainPropSheet()
{
}


BEGIN_MESSAGE_MAP(CMainPropSheet, CPropertySheet)
	//{{AFX_MSG_MAP(CMainPropSheet)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMainPropSheet message handlers
