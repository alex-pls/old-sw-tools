// Disclaimer and Copyright Information
// MultiMediaInformation.h : Declaration of the CMultiMediaInformation
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////

#ifndef __MULTIMEDIAINFORMATION_H_
#define __MULTIMEDIAINFORMATION_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CMultiMediaInformation
class ATL_NO_VTABLE CMultiMediaInformation : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CMultiMediaInformation, &CLSID_MultiMediaInformation>,
	public ISupportErrorInfo,
	public IDispatchImpl<IMultiMediaInformation, &IID_IMultiMediaInformation, &LIBID_SYSTEMMULTIMEDIALib>
{
public:
	CMultiMediaInformation()
	{
		m_bInformationObtained = false;
		m_bIsPresent = FALSE;
		m_bHasVolCtrl = FALSE;
		m_bHasSeparateLRVolCtrl = FALSE;
		m_bstrCompanyName = _T ("");
		m_bstrProductName = _T ("");
	}

DECLARE_REGISTRY_RESOURCEID(IDR_MULTIMEDIAINFORMATION)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CMultiMediaInformation)
	COM_INTERFACE_ENTRY(IMultiMediaInformation)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IMultiMediaInformation
public:
	STDMETHOD(GetMultiMediaInformation)(/*[out]*/ VARIANT_BOOL *pbIsInstalled,
		/*[out]*/ VARIANT_BOOL *pbHasVolCtrl, /*[out]*/ VARIANT_BOOL *pbHasSeparateLRVolCtrl,
		/*[out]*/ BSTR *pbstrProductName, /*[out]*/ BSTR *pbstrCompanyName);
	STDMETHOD(get_HasSeparateLRVolControl)(/*[out, retval]*/ VARIANT_BOOL *pVal);
	STDMETHOD(get_HasVolumeControl)(/*[out, retval]*/ VARIANT_BOOL *pVal);
	STDMETHOD(get_ProductName)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(get_CompanyName)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(get_IsPresent)(/*[out, retval]*/ VARIANT_BOOL *pVal);

private:
	bool m_bInformationObtained;

	VARIANT_BOOL m_bIsPresent;
	VARIANT_BOOL m_bHasVolCtrl;
	VARIANT_BOOL m_bHasSeparateLRVolCtrl;
	CComBSTR m_bstrCompanyName;
	CComBSTR m_bstrProductName;

	HRESULT GetInformation ();
	CComBSTR GetAudioDevCompanyName (WORD wCompany) const;
};

#endif //__MULTIMEDIAINFORMATION_H_
