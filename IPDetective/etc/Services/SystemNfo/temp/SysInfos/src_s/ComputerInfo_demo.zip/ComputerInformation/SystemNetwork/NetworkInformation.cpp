// NetworkInformation.cpp : Implementation of CNetworkInformation
#include "stdafx.h"
#include "SystemNetwork.h"
#include "NetworkInformation.h"

/////////////////////////////////////////////////////////////////////////////
// CNetworkInformation

STDMETHODIMP CNetworkInformation::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_INetworkInformation
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (::InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

HRESULT CNetworkInformation::FinalConstruct()
{
	m_pSocketUtil = new CSocketUtil ();
	ATLASSERT (NULL != m_pSocketUtil);
	if (NULL == m_pSocketUtil)
	{
		return E_FAIL;
	}
	return S_OK;
}

void CNetworkInformation::FinalRelease()
{
	if (NULL != m_pSocketUtil)
	{
		delete m_pSocketUtil;
	}
	m_pSocketUtil = NULL;
}

HRESULT CNetworkInformation::GetInformation(void)
{
	// If we already have generated the information, then there is no need to do it again.
	if (m_bInfoGenerated)
	{
		return S_OK;
	}

	// Initialize Socket DLL.
	m_pSocketUtil->Startup ();

	// Get IP Address.
	string strAddr;
	m_pSocketUtil->GetIPAddress ("", strAddr);
	m_bstrIPAddress = strAddr.c_str ();

	m_pSocketUtil->GetIPInterfaces ();

	// Cleanup the socket resources.
	m_pSocketUtil->ShutDown ();

	m_bInfoGenerated = true;
	return HRESULT();
}

STDMETHODIMP CNetworkInformation::GetNetworkInfo(void)
{
	HRESULT hRes = S_OK;
	if ((hRes = this->GetInformation ()) != S_OK)
	{
		return hRes;
	}

	return hRes;
}
