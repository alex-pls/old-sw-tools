// Disclaimer and Copyright Information
// MouseInformation.h : 
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////

#ifndef __MOUSEINFORMATION_H_
#define __MOUSEINFORMATION_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CMouseInformation
class ATL_NO_VTABLE CMouseInformation : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CMouseInformation, &CLSID_MouseInformation>,
	public ISupportErrorInfo,
	public IDispatchImpl<IMouseInformation, &IID_IMouseInformation, &LIBID_SYSTEMMOUSELib>
{
public:
	CMouseInformation()
	{
		m_bInformationObtained = false;
		m_bIsInstalled = FALSE;
		m_bAreButtonsSwapped = FALSE;
		m_lSpeed = 0;
	}

DECLARE_REGISTRY_RESOURCEID(IDR_MOUSEINFORMATION)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CMouseInformation)
	COM_INTERFACE_ENTRY(IMouseInformation)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IMouseInformation
public:
	STDMETHOD(GetMouseInformation)(/*[out]*/ VARIANT_BOOL *pbInstalled,
		/*[out]*/ VARIANT_BOOL *pbButtonsSwapped, /*[out]*/ long *plSpeed);
	STDMETHOD(get_Speed)(/*[out, retval]*/ long *pVal);
	STDMETHOD(get_AreButtonsSwapped)(/*[out, retval]*/ VARIANT_BOOL *pVal);
	STDMETHOD(get_IsInstalled)(/*[out, retval]*/ VARIANT_BOOL *pVal);

	VARIANT_BOOL m_bIsInstalled;
	VARIANT_BOOL m_bAreButtonsSwapped;
	long m_lSpeed;

private:
	bool m_bInformationObtained;
	HRESULT GetInformation ();
};

#endif //__MOUSEINFORMATION_H_
