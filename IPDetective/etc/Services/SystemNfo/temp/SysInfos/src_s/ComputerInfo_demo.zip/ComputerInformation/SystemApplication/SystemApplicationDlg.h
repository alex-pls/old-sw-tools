// Disclaimer and Copyright Information
// SystemApplicationDlg.h : 
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_SYSTEMAPPLICATIONDLG_H__D955455A_CE91_11D2_8C81_000000000000__INCLUDED_)
#define AFX_SYSTEMAPPLICATIONDLG_H__D955455A_CE91_11D2_8C81_000000000000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "DialogStatusBar.h"
#include "OSInfoPage.h"
#include "MiscInfoPage.h"
#include "MouseInfoPage.h"
#include "MemoryInfoPage.h"
#include "CPUInfoPage.h"
#include "HDiskInfoPage.h"
#include "StorageInfoPage.h"
#include "MultiMediaInfoPage.h"
#include "ProtectedFilesPage.h"
//#include "HWDevicesInfoPage.h"
//#include "NetworkInfoPage.h"
#include "LocaleInfoPage.h"
//#include "PnPDevicesPage.h"
#include "KeyBoardInfoPage.h"

class CSystemApplicationDlgAutoProxy;

/////////////////////////////////////////////////////////////////////////////
// CSystemApplicationDlg dialog

class CSystemApplicationDlg : public CDialog
{
	DECLARE_DYNAMIC(CSystemApplicationDlg);
	friend class CSystemApplicationDlgAutoProxy;

// Construction
public:
	CSystemApplicationDlg(CWnd* pParent = NULL);	// standard constructor
	virtual ~CSystemApplicationDlg();

// Dialog Data
	//{{AFX_DATA(CSystemApplicationDlg)
	enum { IDD = IDD_SYSTEMAPPLICATION_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSystemApplicationDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

	static VOID CALLBACK TimerProc(HWND hwnd, UINT uMsg, UINT uIDEvent,
		DWORD dwTime);

// Implementation
protected:
	CSystemApplicationDlgAutoProxy *m_pAutoProxy;
	HICON				m_hIcon;
	UINT				m_nIDTimer;
	CDialogStatusBar	m_wndStatusBar;
	CFont				m_StatusBarFont;
	CFile				m_fOutputFile;
	ISystemInformation	*m_pSystemInfo;

	CPropertySheet		m_PropSheet;
	OSInfoPage			m_OSInfoPage;
	MiscInfoPage		m_MiscInfoPage;
	MouseInfoPage		m_MouseInfoPage;
	MemoryInfoPage		m_MemoryInfoPage;
	CPUInfoPage			m_CPUInfoPage;
	HDiskInfoPage		m_HDiskInfoPage;
	StorageInfoPage		m_StorageInfoPage;
	MultiMediaInfoPage	m_MMediaInfoPage;
	ProtectedFilesPage	m_ProtectedFilesPage;
//	HWDevicesInfoPage	m_HWDevicesPage;
//	NetworkInfoPage		m_NetworkInfoPage;
	LocaleInfoPage		m_LocaleInfoPage;
//	PnPDevicesPage		m_PnPDevicesPage;
	KeyBoardInfoPage	m_KeyBoardInfoPage;

	BOOL CanExit();

	// Generated message map functions
	//{{AFX_MSG(CSystemApplicationDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnDestroy();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnClose();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnUpdateTimeIndicator(CCmdUI* pCmdUI);
	afx_msg void OnAppAbout();
	afx_msg void OnAppOptions();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	bool m_bIsOutputFileOpen;
	void CreateInterfacePointer ();
	bool CreateStatusBarFont ();
	bool OpenOutputFile ();
public:
	void OnHelp(void);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SYSTEMAPPLICATIONDLG_H__D955455A_CE91_11D2_8C81_000000000000__INCLUDED_)
