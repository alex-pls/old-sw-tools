// PnPDeviceDriver.cpp : Implementation of CPnPDeviceDriver

#include "stdafx.h"
#include "SystemPnPDevices.h"
#include "PnPDeviceDriver.h"


// CPnPDeviceDriver

STDMETHODIMP CPnPDeviceDriver::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IPnPDeviceDriver
	};

	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (::InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CPnPDeviceDriver::get_Type(BSTR* pVal)
{
	ATLASSERT (NULL != pVal);
	if (NULL == pVal)
	{
		return E_POINTER;
	}
	
	*pVal = m_bstrType.Copy ();
	return S_OK;
}

STDMETHODIMP CPnPDeviceDriver::get_Description(BSTR* pVal)
{
	ATLASSERT (NULL != pVal);
	if (NULL == pVal)
	{
		return E_POINTER;
	}

	*pVal = m_bstrDescription.Copy ();
	return S_OK;
}

STDMETHODIMP CPnPDeviceDriver::get_Manufacturer(BSTR* pVal)
{
	ATLASSERT (NULL != pVal);
	if (NULL == pVal)
	{
		return E_POINTER;
	}

	*pVal = m_bstrMfg.Copy ();
	return S_OK;
}

STDMETHODIMP CPnPDeviceDriver::get_Provider(BSTR* pVal)
{
	ATLASSERT (NULL != pVal);
	if (NULL == pVal)
	{
		return E_POINTER;
	}

	*pVal = m_bstrProvider.Copy ();
	return S_OK;
}

STDMETHODIMP CPnPDeviceDriver::get_Date(BSTR* pVal)
{
	ATLASSERT (NULL != pVal);
	if (NULL == pVal)
	{
		return E_POINTER;
	}

	*pVal = m_bstrDate.Copy ();
	return S_OK;
}

STDMETHODIMP CPnPDeviceDriver::get_Version(long* pVal)
{
	ATLASSERT (NULL != pVal);
	if (NULL == pVal)
	{
		return E_POINTER;
	}

	*pVal = m_lVersion;
	return S_OK;
}
