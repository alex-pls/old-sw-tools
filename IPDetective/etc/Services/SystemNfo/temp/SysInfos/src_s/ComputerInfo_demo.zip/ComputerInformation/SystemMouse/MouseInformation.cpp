// Disclaimer and Copyright Information
// MouseInformation.cpp
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SystemMouse.h"
#include "MouseInformation.h"

/////////////////////////////////////////////////////////////////////////////
// CMouseInformation

STDMETHODIMP CMouseInformation::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IMouseInformation
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (::InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CMouseInformation::get_IsInstalled(VARIANT_BOOL *pVal)
{
	HRESULT hRes = S_OK;
	if ((hRes = GetInformation ()) != S_OK)
	{
		return hRes;
	}

	*pVal = m_bIsInstalled;

	return S_OK;
}

STDMETHODIMP CMouseInformation::get_AreButtonsSwapped(VARIANT_BOOL *pVal)
{
	HRESULT hRes = S_OK;
	if ((hRes = GetInformation ()) != S_OK)
	{
		return hRes;
	}

	*pVal = m_bAreButtonsSwapped;

	return S_OK;
}

STDMETHODIMP CMouseInformation::get_Speed(long *pVal)
{
	HRESULT hRes = S_OK;
	if ((hRes = GetInformation ()) != S_OK)
	{
		return hRes;
	}

	*pVal = m_lSpeed;

	return S_OK;
}

STDMETHODIMP CMouseInformation::GetMouseInformation(VARIANT_BOOL *pbInstalled,
	VARIANT_BOOL *pbButtonsSwapped, long *plSpeed)
{
	HRESULT hRes = S_OK;
	if ((hRes = GetInformation ()) != S_OK)
	{
		return hRes;
	}

	*pbInstalled = m_bIsInstalled;
	*pbButtonsSwapped = m_bAreButtonsSwapped;
	*plSpeed = m_lSpeed;

	return S_OK;
}

HRESULT CMouseInformation::GetInformation ()
{
	HRESULT hRes = S_OK;
	int mouseInfo[3];	// We need an array (size 3) of int for mouse information
	BOOL stat;

	if (m_bInformationObtained)
	{
		return S_OK;
	}

	// Check if mouse is present or not.
	if ((stat = ::GetSystemMetrics (SM_MOUSEPRESENT)) == 0)
	{
		hRes = E_FAIL;
	}

	if (SUCCEEDED (hRes))
	{
		m_bIsInstalled = TRUE;

		// Check if buttons are swapped
		stat = ::GetSystemMetrics (SM_SWAPBUTTON);
		m_bAreButtonsSwapped = ((stat != 0) ? TRUE : FALSE);
		
		// Get mouse speed
		::SystemParametersInfo (SPI_GETMOUSE, NULL, mouseInfo, NULL);

		// mouseInfo [0] & mouseInfo [1], give twp threshold values for mouse
		// mpuseInfo [2] gives the mouse speed.
		m_lSpeed = mouseInfo[2];
		m_bInformationObtained = true;
	}
	else 
	{
		m_bIsInstalled = FALSE;
		m_bAreButtonsSwapped = m_bIsInstalled;
		m_lSpeed = 0;
		m_bInformationObtained = false;
	}
	
	return hRes;
}
