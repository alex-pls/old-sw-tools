// Disclaimer and Copyright Information
// HDiskInfoPage.cpp : Implementation file
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SystemApplication.h"
#include "HDiskInfoPage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// HDiskInfoPage property page

IMPLEMENT_DYNCREATE(HDiskInfoPage, CPropertyPage)

HDiskInfoPage::HDiskInfoPage() : CPropertyPage(HDiskInfoPage::IDD)
{
	//{{AFX_DATA_INIT(HDiskInfoPage)
	m_pbstrDriveLetterArr = NULL;
	m_pbBootableArr = NULL;
	m_pbstrTypeArr = NULL;
	m_plPartitionNumberArr = NULL;
	m_plLengthArr = NULL;
	m_plHiddenSectorsArr = NULL;
	//}}AFX_DATA_INIT
}

HDiskInfoPage::~HDiskInfoPage()
{
	if (m_pbstrDriveLetterArr != NULL) {
		SafeArrayDestroy (m_pbstrDriveLetterArr);
		m_pbstrDriveLetterArr = NULL;
	}

	if (m_pbBootableArr != NULL) {
		SafeArrayDestroy (m_pbBootableArr);
		m_pbBootableArr = NULL;
	}

	if (m_pbstrTypeArr != NULL) {
		SafeArrayDestroy (m_pbstrTypeArr);
		m_pbstrTypeArr = NULL;
	}

	if (m_plPartitionNumberArr != NULL) {
		SafeArrayDestroy (m_plPartitionNumberArr);
		m_plPartitionNumberArr = NULL;
	}

	if (m_plLengthArr != NULL) {
		SafeArrayDestroy (m_plLengthArr);
		m_plLengthArr = NULL;
	}

	if (m_plHiddenSectorsArr != NULL) {
		SafeArrayDestroy (m_plHiddenSectorsArr);
		m_plHiddenSectorsArr = NULL;
	}
}

void HDiskInfoPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(HDiskInfoPage)
	DDX_Control(pDX, IDC_HDISK_INFO_LIST, m_ListCtrl);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(HDiskInfoPage, CPropertyPage)
	//{{AFX_MSG_MAP(HDiskInfoPage)
	ON_WM_VSCROLL()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// HDiskInfoPage message handlers

BOOL HDiskInfoPage::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	if (FAILED (GetInformation ())) {
		AfxMessageBox (_T ("Application Failed To Get Hardisk Information From Interface Pointer"),
			MB_ICONSTOP);
		return TRUE;
	}

	SetListData();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

HRESULT HDiskInfoPage::GetInformation ()
{
	VARIANT bstrDriveLetterArr;
	VARIANT bBootableArr;
	VARIANT bstrTypeArr;
	VARIANT lPartitionNumberArr;
	VARIANT lLengthArr;
	VARIANT lHiddenSectorsArr;

	if (FAILED (m_pSystemInfo->GetHDiskInformation (&m_lNumberOfPartitions, &bstrDriveLetterArr,
		&bBootableArr, &bstrTypeArr, &lPartitionNumberArr, &lLengthArr, &lHiddenSectorsArr))) {
		return E_FAIL;
	}

	if (!(bstrDriveLetterArr.vt & VT_BSTR)) {
		return DISP_E_TYPEMISMATCH;
	}

	if (!(bstrDriveLetterArr.vt & VT_ARRAY)) {
		return DISP_E_TYPEMISMATCH;
	}

	if (bstrDriveLetterArr.vt & VT_BYREF) {
		m_pbstrDriveLetterArr = * (bstrDriveLetterArr.pparray);
	}
	else {
		m_pbstrDriveLetterArr = bstrDriveLetterArr.parray;
	}

	if (!(bstrTypeArr.vt & VT_BSTR)) {
		return DISP_E_TYPEMISMATCH;
	}

	if (!(bstrTypeArr.vt & VT_ARRAY)) {
		return DISP_E_TYPEMISMATCH;
	}

	if (bstrDriveLetterArr.vt & VT_BYREF) {
		m_pbstrTypeArr = * (bstrTypeArr.pparray);
	}
	else {
		m_pbstrTypeArr = bstrTypeArr.parray;
	}

	if (!(bBootableArr.vt & VT_BOOL)) {
		return DISP_E_TYPEMISMATCH;
	}

	if (!(bBootableArr.vt & VT_ARRAY)) {
		return DISP_E_TYPEMISMATCH;
	}

	if (bBootableArr.vt & VT_BYREF) {
		m_pbBootableArr = * (bBootableArr.pparray);
	}
	else {
		m_pbBootableArr = bBootableArr.parray;
	}

	if (!(lPartitionNumberArr.vt & VT_I4)) {
		return DISP_E_TYPEMISMATCH;
	}

	if (!(lPartitionNumberArr.vt & VT_ARRAY)) {
		return DISP_E_TYPEMISMATCH;
	}

	if (bBootableArr.vt & VT_BYREF) {
		m_plPartitionNumberArr = * (lPartitionNumberArr.pparray);
	}
	else {
		m_plPartitionNumberArr = lPartitionNumberArr.parray;
	}

	if (!(lLengthArr.vt & VT_R8)) {
		return DISP_E_TYPEMISMATCH;
	}

	if (!(lLengthArr.vt & VT_ARRAY)) {
		return DISP_E_TYPEMISMATCH;
	}

	if (bBootableArr.vt & VT_BYREF) {
		m_plLengthArr = * (lLengthArr.pparray);
	}
	else {
		m_plLengthArr = lLengthArr.parray;
	}

	if (!(lHiddenSectorsArr.vt & VT_I4)) {
		return DISP_E_TYPEMISMATCH;
	}

	if (!(lHiddenSectorsArr.vt & VT_ARRAY)) {
		return DISP_E_TYPEMISMATCH;
	}

	if (bBootableArr.vt & VT_BYREF) {
		m_plHiddenSectorsArr = * (lHiddenSectorsArr.pparray);
	}
	else {
		m_plHiddenSectorsArr = lHiddenSectorsArr.parray;
	}

	return S_OK;
}

void HDiskInfoPage::SetListData()
{

	CString tmpStr;
	BSTR tmpBstr;
	VARIANT_BOOL bBootable;
	int i = 0;
	long lLBound, lUBound ;
	long tmpNum;
	double length = 0.;
	LV_ITEM item;
	LV_COLUMN col1, col2, col3, col4, col5, col6;

	col1.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	col1.fmt = LVCFMT_LEFT;
	col1.iSubItem = 0;
	col1.cx = 40;
	col1.pszText = _T ("Drive");

	col2.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	col2.fmt = LVCFMT_LEFT;
	col2.iSubItem = 1;
	col2.cx = 50;
	col2.pszText = _T ("Number");

	col3.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	col3.fmt = LVCFMT_LEFT;
	col3.iSubItem = 2;
	col3.cx = 55;
	col3.pszText = _T ("Bootable");

	col4.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	col4.fmt = LVCFMT_LEFT;
	col4.iSubItem = 3;
	col4.cx = 155;
	col4.pszText = _T ("Type");

	col5.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	col5.fmt = LVCFMT_LEFT;
	col5.iSubItem = 4;
	col5.cx = 85;
	col5.pszText = _T ("Length");

	col6.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	col6.fmt = LVCFMT_LEFT;
	col6.iSubItem = 5;
	col6.cx = 95;
	col6.pszText = _T ("Hidden Sectors");

	m_ListCtrl.InsertColumn (0, &col1);
	m_ListCtrl.InsertColumn (1, &col2);
	m_ListCtrl.InsertColumn (2, &col3);
	m_ListCtrl.InsertColumn (3, &col4);
	m_ListCtrl.InsertColumn (4, &col5);
	m_ListCtrl.InsertColumn (5, &col6);

	// Get the uprrer and lower bound of arrays. And assume it will be same for all arrays.

	::SafeArrayGetLBound (m_pbstrDriveLetterArr, 1, &lLBound);
	::SafeArrayGetUBound (m_pbstrDriveLetterArr, 1, &lUBound);

	for (i = lLBound; i <= lUBound; i++) {
		item.mask = LVIF_TEXT;
		item.iItem = i;
		item.iSubItem = 0;
		item.pszText = _T (" ");
		m_ListCtrl.InsertItem (&item);

		::SafeArrayGetElement (m_pbstrDriveLetterArr, (long *) &i, &tmpBstr);
		m_ListCtrl.SetItemText (i, 0, CString (tmpBstr));

		::SafeArrayGetElement (m_pbBootableArr, (long *) &i, &bBootable);
		tmpStr = (bBootable) ? _T ("YES") : _T ("NO");
		m_ListCtrl.SetItemText (i, 2, tmpStr);

		::SafeArrayGetElement (m_plPartitionNumberArr, (long *) &i, &tmpNum);
		tmpStr.Format ("%d", tmpNum);
		m_ListCtrl.SetItemText (i, 1, tmpStr);

		::SafeArrayGetElement (m_pbstrTypeArr, (long *) &i, &tmpBstr);
		m_ListCtrl.SetItemText (i, 3, CString (tmpBstr));

		::SafeArrayGetElement (m_plLengthArr, (long *) &i, &length);
		tmpStr.Format ("%12.0lf", length);
		tmpStr.TrimLeft ();
		m_ListCtrl.SetItemText (i, 4, tmpStr);

		::SafeArrayGetElement (m_plHiddenSectorsArr, (long *) &i, &tmpNum);
		tmpStr.Format ("%d", tmpNum);
		m_ListCtrl.SetItemText (i, 5, tmpStr);
	}
}

void HDiskInfoPage::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	// TODO: Add your message handler code here and/or call default
	
	CPropertyPage::OnVScroll(nSBCode, nPos, pScrollBar);
}
