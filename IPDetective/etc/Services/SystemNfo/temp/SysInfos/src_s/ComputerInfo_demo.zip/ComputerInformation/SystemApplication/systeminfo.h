// Machine generated IDispatch wrapper class(es) created with ClassWizard
/////////////////////////////////////////////////////////////////////////////
// ISystemInformation wrapper class

class ISystemInformation : public COleDispatchDriver
{
public:
	ISystemInformation() {}		// Calls COleDispatchDriver default constructor
	ISystemInformation(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	ISystemInformation(const ISystemInformation& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

// Attributes
public:

// Operations
public:
	void GetOSInformation(BSTR* pbstrPlatform, BSTR* pbstrMinorVersion, BSTR* pbstrServicePack, long* plBuildNumber);
	void GetMouseInformation(BOOL* pbInstalled, BOOL* pbButtonsSwapped, long* plSpeed);
	void GetCPUInformation(BSTR* pbstrVendor, BSTR* pbstrType, BSTR* pbstrArchitecture, BSTR* pbstrLevel, BSTR* pbstrRevision, long* plNumberOfProcessors, long* plSpeed, long* plPageSize, long* plMask);
	void GetHDiskInformation(long* plNumberOfPartitions, VARIANT* pbstrDriveLetterArr, VARIANT* pbBootableArr, VARIANT* pbstrTypeArr, VARIANT* plPartitionNumberArr, VARIANT* plLengthArr, VARIANT* plHiddenSectorsArr);
	void GetMemoryInformation(long* plRAMInstalled, long* plAvailableMemory, long* plVirtualMemory, long* plMemoryLoad);
	void GetStorageMediaInformation(long* plNumberOfDrives, VARIANT* pbReadyArr, VARIANT* pbstrDriveLetterArr, VARIANT* pbstrLabelArr, VARIANT* pbSupportLongNameArr, VARIANT* pbstrFileSystemArr, VARIANT* pbstrMediaTypeArr, 
		VARIANT* plTotalSpaceArr, VARIANT* plFreeSpaceUserArr, VARIANT* plFreeSpaceTotalArr);
	void GetMultiMediaInformation(BOOL* pbIsInstalled, BOOL* pbHasVolCtrl, BOOL* pbHasSeparateLRVolCtrl, BSTR* pbstrProductName, BSTR* pbstrCompanyName);
	void GetComputerName(BSTR* pbstrComputerName);
	void GetUserName_(BSTR* pbstrUserName);
	void GelLocalLanguage(BSTR* pbstrLocalLanguage);
};
