#pragma once


// NetworkInfoPage dialog

class NetworkInfoPage : public CPropertyPage
{
	DECLARE_DYNAMIC(NetworkInfoPage)

public:
	NetworkInfoPage();
	virtual ~NetworkInfoPage();

// Dialog Data
	enum { IDD = IDD_NETWORK_INFO_PAGE };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
private:
	ISystemInformation*m_pSystemInfo;
	CFile*m_pOutputFile;
public:
	BOOL OnInitDialog(void);
	void SetSystemInfo(ISystemInformation* pSystemInfo, CFile* pFile)
	{
		ASSERT (pSystemInfo != NULL);
		m_pSystemInfo = pSystemInfo;
		m_pOutputFile = pFile;
	}
private:
	HRESULT GetInformation(void);
};
