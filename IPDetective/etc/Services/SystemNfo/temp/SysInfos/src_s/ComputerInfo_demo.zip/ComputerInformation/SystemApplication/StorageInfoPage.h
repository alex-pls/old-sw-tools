// Disclaimer and Copyright Information
// StorageInfoPage.h : 
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////
//
#if !defined(AFX_STORAGEINFOPAGE_H__12C0D781_CF3F_11D2_8C83_000000000000__INCLUDED_)
#define AFX_STORAGEINFOPAGE_H__12C0D781_CF3F_11D2_8C83_000000000000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class StorageInfoPage : public CPropertyPage
{
	DECLARE_DYNCREATE(StorageInfoPage)

// Construction
public:
	StorageInfoPage();
	~StorageInfoPage();
	inline void SetSystemInfo (ISystemInformation *pSystemInfo = NULL, CFile *pFile = NULL);

// Dialog Data
	//{{AFX_DATA(StorageInfoPage)
	enum { IDD = IDD_STORAGE_INFO_PAGE };
	CListCtrl	m_ListCtrl;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(StorageInfoPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(StorageInfoPage)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	HRESULT GetInformation ();
	void SetListData ();
	CFile *m_pOutputFile;
	ISystemInformation *m_pSystemInfo;

	long m_lNumberOfDrives;
	SAFEARRAY *m_pbReadyArr;
	SAFEARRAY *m_pbstrDriveLetterArr;
	SAFEARRAY *m_pbstrLabelArr;
	SAFEARRAY *m_pbSupportLongNameArr;
	SAFEARRAY *m_pbstrFileSystemArr;
	SAFEARRAY *m_pbstrMediaTypeArr;
	SAFEARRAY *m_plTotalSpaceArr;
	SAFEARRAY *m_plFreeSpaceUserArr;
	SAFEARRAY *m_plFreeSpaceTotalArr;
};

inline void
StorageInfoPage::SetSystemInfo (ISystemInformation *pSystemInfo, CFile *pFile)
{
	ASSERT (pSystemInfo != NULL);
	m_pSystemInfo = pSystemInfo;
	m_pOutputFile = pFile;
}
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STORAGEINFOPAGE_H__12C0D781_CF3F_11D2_8C83_000000000000__INCLUDED_)
