// Disclaimer and Copyright Information
// LocaleInfoPage.cpp : Implementation file
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////

// Revision History:
//	2/10/2001	Initial Creation.
//

#include "stdafx.h"
#include "SystemApplication.h"
#include "LocaleInfoPage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// LocaleInfoPage property page

IMPLEMENT_DYNCREATE(LocaleInfoPage, CPropertyPage)

LocaleInfoPage::LocaleInfoPage() : CPropertyPage(LocaleInfoPage::IDD)
, m_pOutputFile(NULL)
{
	//{{AFX_DATA_INIT(LocaleInfoPage)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_sCodePage = 0;
	m_sOEMCodePage = 0;
	m_bstrCalendarType = NULL;
	m_bstrDateFormat = NULL;
	m_bstrLanguage= NULL;
	m_bstrCountry= NULL;
	m_sCountryCode = 0;
	m_bstrTimeFormat= NULL;
	m_bstrCurrency= NULL;
	m_bstrTimeFormatSpecifier= NULL;
}

LocaleInfoPage::~LocaleInfoPage()
{
	::SysFreeString (m_bstrCalendarType);
	::SysFreeString (m_bstrDateFormat);
	::SysFreeString (m_bstrLanguage);
	::SysFreeString (m_bstrCountry);
	::SysFreeString (m_bstrTimeFormat);
	::SysFreeString (m_bstrCurrency);
	::SysFreeString (m_bstrTimeFormatSpecifier);
}

void LocaleInfoPage::DoDataExchange(CDataExchange* pDX)
{
	DDX_Control(pDX, IDC_LOCALE_INFO_LIST, m_wndLocaleList);
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(LocaleInfoPage)
	// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP

}


BEGIN_MESSAGE_MAP(LocaleInfoPage, CPropertyPage)
	//{{AFX_MSG_MAP(LocaleInfoPage)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// LocaleInfoPage message handlers

BOOL LocaleInfoPage::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	// TimeZone information needs to be obtained from new interface.
	HRESULT hr = S_OK;
	ISystemInformation2 *pSysInfo2 = NULL;
	hr = m_pSystemInfo->QueryInterface (IID_ISystemInformation2,
										reinterpret_cast<void **>(&pSysInfo2));
	if (SUCCEEDED (hr))
	{
		hr = pSysInfo2->GetLocaleInformation (&m_sCodePage, &m_sOEMCodePage, &m_bstrCalendarType,
											  &m_bstrDateFormat, &m_bstrLanguage, &m_bstrCountry,
											  &m_sCountryCode, &m_bstrTimeFormat, &m_bstrCurrency,
											  &m_bstrTimeFormatSpecifier);
		pSysInfo2->Release ();
		pSysInfo2 = NULL;
		if (FAILED (hr))
		{
			return TRUE;
		}
	}
	SetListData();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void LocaleInfoPage::SetListData(void)
{
	CString tmpStr = _T ("");
	LV_ITEM item;
	LV_COLUMN leftCol, rightCol;

	leftCol.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	leftCol.fmt = LVCFMT_LEFT;
	leftCol.iSubItem = 0;
	leftCol.cx = 130;
	leftCol.pszText = _T ("Variable");

	rightCol.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	rightCol.fmt = LVCFMT_LEFT;
	rightCol.iSubItem = 1;
	rightCol.cx = 225;
	rightCol.pszText = _T ("Value");

	m_wndLocaleList.InsertColumn (0, &leftCol);
	m_wndLocaleList.InsertColumn (1, &rightCol);

	item.mask = LVIF_TEXT;
	item.iItem = 0;
	item.iSubItem = 0;
	item.pszText = _T ("Code Page");
	m_wndLocaleList.InsertItem (&item);
	tmpStr.Format (_T ("%d"), m_sCodePage);
	m_wndLocaleList.SetItemText (0, 1, tmpStr);

	item.iItem = 1;
	item.pszText = _T ("OEM Code Page");
	m_wndLocaleList.InsertItem (&item);
	tmpStr.Format (_T ("%d"), m_sOEMCodePage);
	m_wndLocaleList.SetItemText (1, 1, tmpStr);

	item.iItem = 2;
	item.pszText = _T ("Country");
	m_wndLocaleList.InsertItem (&item);
	tmpStr = m_bstrCountry;
	m_wndLocaleList.SetItemText (2, 1, tmpStr);

	item.iItem = 3;
	item.pszText = _T ("Language");
	m_wndLocaleList.InsertItem (&item);
	tmpStr = m_bstrLanguage;
	m_wndLocaleList.SetItemText (3, 1, tmpStr);

	item.iItem = 4;
	item.pszText = _T ("Currency");
	m_wndLocaleList.InsertItem (&item);
	tmpStr = m_bstrCurrency;
	m_wndLocaleList.SetItemText (4, 1, tmpStr);

	item.iItem = 5;
	item.pszText = _T ("Country Code");
	m_wndLocaleList.InsertItem (&item);
	tmpStr.Format (_T ("%d"), m_sCountryCode);
	m_wndLocaleList.SetItemText (5, 1, tmpStr);

	item.iItem = 6;
	item.pszText = _T ("Calendar Type");
	m_wndLocaleList.InsertItem (&item);
	tmpStr = m_bstrCalendarType;
	m_wndLocaleList.SetItemText (6, 1, tmpStr);

	item.iItem = 7;
	item.pszText = _T ("Date Format");
	m_wndLocaleList.InsertItem (&item);
	tmpStr = m_bstrDateFormat;
	m_wndLocaleList.SetItemText (7, 1, tmpStr);

	item.iItem = 8;
	item.pszText = _T ("Time Format");
	m_wndLocaleList.InsertItem (&item);
	tmpStr = m_bstrTimeFormat;
	m_wndLocaleList.SetItemText (8, 1, tmpStr);

	item.iItem = 9;
	item.pszText = _T ("Time Format Specifier");
	m_wndLocaleList.InsertItem (&item);
	tmpStr = m_bstrTimeFormatSpecifier;
	m_wndLocaleList.SetItemText (9, 1, tmpStr);
}
