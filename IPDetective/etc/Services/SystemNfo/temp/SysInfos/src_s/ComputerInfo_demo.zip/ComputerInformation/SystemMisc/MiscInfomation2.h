// MiscInfomation2.h : Declaration of the CMiscInfomation2

#pragma once
#include "resource.h"       // main symbols



// CMiscInfomation2

class ATL_NO_VTABLE CMiscInfomation2 : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CMiscInfomation2, &CLSID_MiscInfomation>,
	public ISupportErrorInfo,
	public IDispatchImpl<IMiscInfomation2, &IID_IMiscInfomation2, &LIBID_SYSTEMMISCLib, /*wMajor =*/ 1, /*wMinor =*/ 0>
{
public:
	CMiscInfomation2()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_MISCINFOMATION2)


BEGIN_COM_MAP(CMiscInfomation2)
	COM_INTERFACE_ENTRY(IMiscInfomation2)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}
	
	void FinalRelease() 
	{
	}

public:

};

OBJECT_ENTRY_AUTO(__uuidof(MiscInfomation2), CMiscInfomation2)
