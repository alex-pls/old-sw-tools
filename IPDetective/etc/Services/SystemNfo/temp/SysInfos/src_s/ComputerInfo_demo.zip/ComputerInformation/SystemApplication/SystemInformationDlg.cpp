// SystemInformationDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SystemInformation.h"
#include "SystemInformationDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
//	ID_INDICATOR_CAPS,
//	ID_INDICATOR_NUM,
//	ID_INDICATOR_SCRL,
	ID_INDICATOR_TIME,
};

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSystemInformationDlg dialog

CSystemInformationDlg::CSystemInformationDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSystemInformationDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSystemInformationDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSystemInformationDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSystemInformationDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSystemInformationDlg, CDialog)
	//{{AFX_MSG_MAP(CSystemInformationDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_DESTROY()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_UPDATE_COMMAND_UI(ID_INDICATOR_TIME, OnUpdateTimeIndicator)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSystemInformationDlg message handlers

BOOL CSystemInformationDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Create the status bar.
	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	// Make a sunken or recessed border around the first pane
	m_wndStatusBar.SetPaneInfo(0, m_wndStatusBar.GetItemID(0),
		SBPS_STRETCH, NULL );

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	GetSystemInformation();

	// Create all the proprty pages.

	try {
		m_pOSInfoPage = new COSInfoPage (m_SystemInfo.GetOSInfo ());
		m_pCPUInfoPage = new CCpuInfoPage (m_SystemInfo.GetCPUInfo ());
		m_pMemInfoPage = new CMemoryInfoPage(m_SystemInfo.GetMemoryInfo ());
		m_pMouseInfoPage = new CMouseInfoPage (m_SystemInfo.GetMouseInfo ());
		m_pHDiskInfoPage = new CHDiskInfoPage (m_SystemInfo.GetHDiskInfo ());
		m_pStorageInfoPage = new CStorageInfoPage (m_SystemInfo.GetStorageInfo ());
		m_pMiscInfoPage = new CMiscInfoPage (m_SystemInfo.GetMiscInfo ());
	}
	catch (CMemoryException *e) {
		e->ReportError ();
		e->Delete ();
		return TRUE;
	}

	// Add each page to property sheet.

	m_PropSheet.AddPage (m_pCPUInfoPage);
	m_PropSheet.AddPage (m_pOSInfoPage);
	m_PropSheet.AddPage (m_pMemInfoPage);
	m_PropSheet.AddPage (m_pMouseInfoPage);
	m_PropSheet.AddPage (m_pHDiskInfoPage);
	m_PropSheet.AddPage (m_pStorageInfoPage);
	m_PropSheet.AddPage (m_pMiscInfoPage);

	// Now create the property sheet.

	m_PropSheet.Create (this, WS_CHILD | WS_VISIBLE, 0);
	m_PropSheet.ModifyStyleEx (0, WS_EX_CONTROLPARENT);
	m_PropSheet.ModifyStyle (0, WS_TABSTOP);

	CRect rcSheet;

	GetDlgItem (IDC_PICTURE_STATIC)->GetWindowRect (&rcSheet);
	ScreenToClient (&rcSheet);
	m_PropSheet.SetWindowPos (NULL, rcSheet.left - 7, rcSheet.top - 7, 0, 0,
		SWP_NOZORDER | SWP_NOSIZE | SWP_NOACTIVATE);
	
	// Instead of using single row of tabs, use stacked row.

	m_PropSheet.EnableStackedTabs (TRUE);

	RepositionBars(AFX_IDW_CONTROLBAR_FIRST, AFX_IDW_CONTROLBAR_LAST, 0);

	m_nIDTimer = ::SetTimer(NULL, 0, 1000, TimerProc);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CSystemInformationDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

void CSystemInformationDlg::OnDestroy()
{
	WinHelp(0L, HELP_QUIT);

	CDialog::OnDestroy();

	// Cleanup the page pointers.
	if (m_pOSInfoPage != NULL) {
		delete m_pOSInfoPage;
	}

	if (m_pCPUInfoPage != NULL) {
		delete m_pCPUInfoPage;
	}
		
	if (m_pMemInfoPage != NULL) {
		delete m_pMemInfoPage;
	}
		
	if (m_pMouseInfoPage != NULL) {
		delete m_pMouseInfoPage;
	}
		
	if (m_pHDiskInfoPage != NULL) {
		delete m_pHDiskInfoPage;
	}
		
	if (m_pStorageInfoPage != NULL) {
		delete m_pStorageInfoPage;
	}
	
	if (m_pMiscInfoPage != NULL) {
		delete m_pMiscInfoPage;
	}

}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSystemInformationDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSystemInformationDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CSystemInformationDlg::GetSystemInformation()
{
	m_SystemInfo.GetInfo ();
}

void CSystemInformationDlg::OnUpdateTimeIndicator(CCmdUI* pCmdUI)
{
	CTime t = CTime::GetCurrentTime();
	char szTime[6];
    int nHour = t.GetHour();
	int nMinute = t.GetMinute();
    // Base Hours on 12 instead of 24
	if (nHour > 12) {
		nHour = nHour - 12;
	}
	wsprintf(szTime, "%i:%02i", nHour, nMinute);
	// Now set the text of the pane.
	m_wndStatusBar.SetPaneText(m_wndStatusBar.CommandToIndex(ID_INDICATOR_TIME),
               LPCSTR(szTime));

	pCmdUI->Enable();
}

VOID CALLBACK CSystemInformationDlg::TimerProc(HWND hwnd, UINT uMsg, UINT uIDEvent,
											  DWORD dwTime)
{
		 CSystemInformationDlg *pMainWnd = (CSystemInformationDlg *)AfxGetApp()->m_pMainWnd;
         ASSERT(uIDEvent == pMainWnd->m_nIDTimer);
         CCmdUI cui;
         cui.m_nID = ID_INDICATOR_TIME;
         cui.m_nIndex = 4;
         cui.m_pMenu = NULL;
         cui.m_pOther = &pMainWnd->m_wndStatusBar;
         pMainWnd->OnUpdateTimeIndicator(&cui);
}
  
