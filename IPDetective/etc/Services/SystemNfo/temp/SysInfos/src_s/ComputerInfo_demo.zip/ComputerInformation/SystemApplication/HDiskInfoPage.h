// Disclaimer and Copyright Information
// HDiskInfoPage.h : 
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////
//
#if !defined(AFX_HDISKINFOPAGE_H__FBA6EBC6_CEA5_11D2_8C82_000000000000__INCLUDED_)
#define AFX_HDISKINFOPAGE_H__FBA6EBC6_CEA5_11D2_8C82_000000000000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class HDiskInfoPage : public CPropertyPage
{
	DECLARE_DYNCREATE(HDiskInfoPage)

// Construction
public:
	HDiskInfoPage();
	~HDiskInfoPage();
	inline void SetSystemInfo (ISystemInformation *pSystemInfo = NULL, CFile *pFile = NULL);

// Dialog Data
	//{{AFX_DATA(HDiskInfoPage)
	enum { IDD = IDD_HDISK_INFO_PAGE };
	CListCtrl	m_ListCtrl;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(HDiskInfoPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(HDiskInfoPage)
	virtual BOOL OnInitDialog();
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	HRESULT GetInformation ();
	void SetListData ();
	CFile *m_pOutputFile;
	ISystemInformation *m_pSystemInfo;

	long		m_lNumberOfPartitions;
	SAFEARRAY	*m_pbstrDriveLetterArr;
	SAFEARRAY	*m_pbBootableArr;
	SAFEARRAY	*m_pbstrTypeArr;
	SAFEARRAY	*m_plPartitionNumberArr;
	SAFEARRAY	*m_plLengthArr;
	SAFEARRAY	*m_plHiddenSectorsArr;
};

inline void
HDiskInfoPage::SetSystemInfo (ISystemInformation *pSystemInfo, CFile *pFile)
{
	ASSERT (pSystemInfo != NULL);
	m_pSystemInfo = pSystemInfo;
	m_pOutputFile = pFile;
}
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HDISKINFOPAGE_H__FBA6EBC6_CEA5_11D2_8C82_000000000000__INCLUDED_)
