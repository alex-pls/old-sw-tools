// Disclaimer and Copyright Information
// SystemInformation.h : Declaration of the CSystemInformation
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////

// Revision History:
//	2/1/2001	Initial Creation
//	2/7/2001	Added new method from IMiscInformation2 interface
//

#ifndef __SYSTEMINFORMATION_H_
#define __SYSTEMINFORMATION_H_

#include "resource.h"       // main symbols

#ifdef DEBUG
	#import "..\Bin\Debug\SystemOS.dll" raw_interfaces_only, raw_native_types, no_namespace, named_guids
	#import "..\Bin\Debug\SystemMouse.dll" raw_interfaces_only, raw_native_types, no_namespace, named_guids
	#import "..\Bin\Debug\SystemMemory.dll" raw_interfaces_only, raw_native_types, no_namespace, named_guids
	#import "..\Bin\Debug\SystemHDisk.dll" raw_interfaces_only, raw_native_types, no_namespace, named_guids
	#import "..\Bin\Debug\SystemStorage.dll" raw_interfaces_only, raw_native_types, no_namespace, named_guids
	#import "..\Bin\Debug\SystemMultiMedia.dll" raw_interfaces_only, raw_native_types, no_namespace, named_guids
	#import "..\Bin\Debug\SystemCPU.dll" raw_interfaces_only, raw_native_types, no_namespace, named_guids
	#import "..\Bin\Debug\SystemMisc.dll" raw_interfaces_only, raw_native_types, no_namespace, named_guids
	#import "..\Bin\Debug\SystemProtectFiles.dll" raw_interfaces_only, raw_native_types, no_namespace, named_guids
//	#import "..\Bin\Debug\SystemDevices.dll" raw_interfaces_only, raw_native_types, no_namespace, named_guids
	#import "..\Bin\Debug\SystemNetwork.dll" raw_interfaces_only, raw_native_types, no_namespace, named_guids
	#import "..\Bin\Debug\SystemModem.dll" raw_interfaces_only, raw_native_types, no_namespace, named_guids
	#import "..\Bin\Debug\SystemLocale.dll" raw_interfaces_only, raw_native_types, no_namespace, named_guids
	#import "..\Bin\Debug\SystemPnPDevices.dll" raw_interfaces_only, raw_native_types, no_namespace, named_guids
	#import "..\Bin\Debug\SystemKeyboard.dll" raw_interfaces_only, raw_native_types, no_namespace, named_guids
#else
	#import "..\Bin\Release\SystemOS.dll" raw_interfaces_only, raw_native_types, no_namespace, named_guids
	#import "..\Bin\Release\SystemMouse.dll" raw_interfaces_only, raw_native_types, no_namespace, named_guids
	#import "..\Bin\Release\SystemMemory.dll" raw_interfaces_only, raw_native_types, no_namespace, named_guids
	#import "..\Bin\Release\SystemHDisk.dll" raw_interfaces_only, raw_native_types, no_namespace, named_guids
	#import "..\Bin\Release\SystemStorage.dll" raw_interfaces_only, raw_native_types, no_namespace, named_guids
	#import "..\Bin\Release\SystemMultiMedia.dll" raw_interfaces_only, raw_native_types, no_namespace, named_guids
	#import "..\Bin\Release\SystemCPU.dll" raw_interfaces_only, raw_native_types, no_namespace, named_guids
	#import "..\Bin\Release\SystemMisc.dll" raw_interfaces_only, raw_native_types, no_namespace, named_guids
	#import "..\Bin\Release\SystemProtectFiles.dll" raw_interfaces_only, raw_native_types, no_namespace, named_guids
//	#import "..\Bin\Release\SystemDevices.dll" raw_interfaces_only, raw_native_types, no_namespace, named_guids
	#import "..\Bin\Release\SystemNetwork.dll" raw_interfaces_only, raw_native_types, no_namespace, named_guids
	#import "..\Bin\Release\SystemModem.dll" raw_interfaces_only, raw_native_types, no_namespace, named_guids
	#import "..\Bin\Release\SystemLocale.dll" raw_interfaces_only, raw_native_types, no_namespace, named_guids
	#import "..\Bin\Release\SystemPnPDevices.dll" raw_interfaces_only, raw_native_types, no_namespace, named_guids
	#import "..\Bin\Release\SystemKeyboard.dll" raw_interfaces_only, raw_native_types, no_namespace, named_guids
#endif

/////////////////////////////////////////////////////////////////////////////
// CSystemInformation
class ATL_NO_VTABLE CSystemInformation : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CSystemInformation, &CLSID_SystemInformation>,
	public ISupportErrorInfo,
	public IDispatchImpl<ISystemInformation, &IID_ISystemInformation, &LIBID_SYSTEMINFOLib>,
	public IDispatchImpl<ISystemInformation2, &IID_ISystemInformation2, &LIBID_SYSTEMINFOLib>,
	public IDispatchImpl<ISystemInformation3, &IID_ISystemInformation3, &LIBID_SYSTEMINFOLib>,
	public IDispatchImpl<ISystemInformation4, &IID_ISystemInformation4, &LIBID_SYSTEMINFOLib>
{
public:
	CSystemInformation();
	HRESULT FinalConstruct ();
	void FinalRelease ();

DECLARE_REGISTRY_RESOURCEID(IDR_SYSTEMINFORMATION)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CSystemInformation)
	COM_INTERFACE_ENTRY(ISystemInformation)
	COM_INTERFACE_ENTRY2(IDispatch, ISystemInformation)
	COM_INTERFACE_ENTRY(ISystemInformation2)
	COM_INTERFACE_ENTRY(ISystemInformation3)
	COM_INTERFACE_ENTRY(ISystemInformation4)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// ISystemInformation
public:
	STDMETHOD(GetProtectedFilesInfo)(/*[out]*/long *plNumOfFiles, /*[out]*/ VARIANT *pbstrFileNameArr);
	STDMETHOD(GetLocalLanguage)(/*[out]*/ BSTR *pbstrLocalLanguage);
	STDMETHOD(GetSystemUserName)(/*[out]*/ BSTR *pbstrUserName);
	STDMETHOD(GetSystemName)(/*[out]*/ BSTR *pbstrComputerName);
	STDMETHOD(GetMultiMediaInformation)(/*[out]*/ VARIANT_BOOL *pbIsInstalled,
		/*[out]*/ VARIANT_BOOL *pbHasVolCtrl, /*[out]*/ VARIANT_BOOL *pbHasSeparateLRVolCtrl,
		/*[out]*/ BSTR *pbstrProductName, /*[out]*/ BSTR *pbstrCompanyName);
	STDMETHOD(GetStorageMediaInformation)(/*[out]*/ long *plNumberOfDrives,
		/*[out]*/ VARIANT *pbReadyArr,  /*[out]*/ VARIANT *pbstrDriveLetterArr,
		/*[out]*/ VARIANT *pbstrLabelArr, /*[out]*/ VARIANT *pbSupportLongNameArr,
		/*[out]*/ VARIANT *pbstrFileSystemArr, /*[out]*/ VARIANT *pbstrMediaTypeArr,
		/*[out]*/ VARIANT *plTotalSpaceArr, /*[out]*/ VARIANT *plFreeSpaceUserArr,
		/*[out]*/ VARIANT *plFreeSpaceTotalArr);
	STDMETHOD(GetMemoryInformation)(/*[out]*/ long *plRAMInstalled,
		/*[out]*/ long *plAvailableMemory, /*[out]*/ long *plVirtualMemory,
		/*[out]*/ long *plMemoryLoad);
	STDMETHOD(GetHDiskInformation)(/*[out]*/ long *plNumberOfPartitions,
		/*[out]*/ VARIANT *pbstrDriveLetterArr, /*[out]*/ VARIANT *pbBootableArr,
		/*[out]*/ VARIANT *pbstrTypeArr, /*[out]*/ VARIANT *plPartitionNumberArr,
		/*[out]*/ VARIANT *plLengthArr, /*[out]*/ VARIANT *plHiddenSectorsArr);
	STDMETHOD(GetCPUInformation)(/*[out]*/ BSTR *pbstrVendor, /*[out]*/ BSTR *pbstrType,
		/*[out]*/ BSTR *pbstrArchitecture, /*[out]*/ BSTR *pbstrLevel,
		/*[out]*/ BSTR *pbstrRevision, /*[out]*/ long *plNumberOfProcessors,
		/*[out]*/ long *plSpeed, /*[out]*/ long *plPageSize, /*[out]*/ long *plMask);
	STDMETHOD(GetMouseInformation)(/*[out]*/ VARIANT_BOOL *pbInstalled,
		/*[out]*/ VARIANT_BOOL *pbButtonsSwapped, /*[out]*/ long *plSpeed);
	STDMETHOD(GetOSInformation)(/*[out]*/ BSTR *pbstrPlatform, /*[out]*/ BSTR *pbstrSuites,
		/*[out]*/ BSTR *pbstrMinorVersion, /*[out]*/ BSTR *pbstrServicePack,
		/*[out]*/ long *plBuildNumber);
	STDMETHODIMP GetHWDevicesInfo(void);

	// ISystemInformation2 methods.
	STDMETHODIMP GetTimeZone (BSTR *pbstrTimeZone);
	STDMETHODIMP GetNetworkInfo (void);
	STDMETHODIMP GetModemInfo (void);
	STDMETHODIMP GetLocaleInformation ( /*[out]*/ short* CodePage,
										/*[out]*/ short *OEMCodePage, /*[out]*/ BSTR* CalendarType,
										/*[out]*/ BSTR* DateFormat, /*[out]*/ BSTR* Language,
										/*[out]*/ BSTR* Country, /*[out]*/ short* CountryCode,
										/*[out]*/ BSTR* TimeFormat, /*[out]*/ BSTR* Currency,
										/*[out]*/ BSTR* TimeFormatSpecifier);

	// ISystemInformation3 methods.
	STDMETHODIMP GetPnPDevices ( /*[out]*/ IUnknown** pDevices);

	// ISystemInformation4 methods.
	STDMETHODIMP GetKeyboardInfo ( /*[out]*/ BSTR* pbstrKeyboardType,
								   /*[out]*/ short* pnFnKeys);

	IOSInformation				*m_pOSInfo;
	IMouseInformation			*m_pMouseInfo;
	IMemoryInformation			*m_pMemoryInfo;
	IHDiskInformation			*m_pHDiskInfo;
	IStorageMediaInformation	*m_pStorageInfo;
	IMultiMediaInformation		*m_pMultiMediaInfo;
	ICPUInformation				*m_pCPUInfo;
	IMiscInformation			*m_pMiscInfo;
	IProtectedFilesInfo			*m_pProtectFileInfo;
//	IHWDevices					*m_pHWDevices;
//	INetworkInformation			*m_pNetworkInfo;
//	IModemInformation			*m_pModemInfo;
	ILocaleInformation			*m_pLocaleInfo;
	IPnPDevicesInfo				*m_pPnPDevices;
	IPSKeyboardInformation		*m_pKeyboardInfo;
};

#endif //__SYSTEMINFORMATION_H_
