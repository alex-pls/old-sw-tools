// Disclaimer and Copyright Information
// LocaleInfoPage.h : Header file
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////
//

// Revision History:
//	2/10/2001	Initial Creation
//

#if !defined(AFX_LOCALEINFOPAGE_H__7F0CEA3C_6B38_4F8C_968A_A4AEE4110BB4__INCLUDED_)
#define AFX_LOCALEINFOPAGE_H__7F0CEA3C_6B38_4F8C_968A_A4AEE4110BB4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// LocaleInfoPage dialog

class LocaleInfoPage : public CPropertyPage
{
	DECLARE_DYNCREATE(LocaleInfoPage)

// Construction
public:
	LocaleInfoPage();
	~LocaleInfoPage();

// Dialog Data
	//{{AFX_DATA(LocaleInfoPage)
	enum { IDD = IDD_LOCALE_INFO_PAGE };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(LocaleInfoPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(LocaleInfoPage)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

public:

	void SetSystemInfo(ISystemInformation* pSystemInfo, CFile* pOutputFile)
	{
		ASSERT (pSystemInfo != NULL);
		m_pSystemInfo = pSystemInfo;
		m_pOutputFile = pOutputFile;
	}
private:
	ISystemInformation *m_pSystemInfo;
	CFile*m_pOutputFile;
	short m_sCodePage;
	short m_sOEMCodePage;
	BSTR  m_bstrCalendarType;
	BSTR  m_bstrDateFormat;
	BSTR  m_bstrLanguage;
	BSTR  m_bstrCountry;
	short m_sCountryCode;
	BSTR  m_bstrTimeFormat;
	BSTR  m_bstrCurrency;
	BSTR  m_bstrTimeFormatSpecifier;

	void SetListData(void);
public:
	CListCtrl m_wndLocaleList;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LOCALEINFOPAGE_H__7F0CEA3C_6B38_4F8C_968A_A4AEE4110BB4__INCLUDED_)
