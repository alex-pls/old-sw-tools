// Disclaimer and Copyright Information
// MiscInfoPage.cpp : Implementation file
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SystemApplication.h"
#include "MiscInfoPage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// MiscInfoPage property page

IMPLEMENT_DYNCREATE(MiscInfoPage, CPropertyPage)

MiscInfoPage::MiscInfoPage() : CPropertyPage(MiscInfoPage::IDD)
{
	//{{AFX_DATA_INIT(MiscInfoPage)
	m_bstrComputerName = NULL;
	m_bstrUserName = NULL;
	m_bstrLocalLanguage = NULL;
	m_bstrTimeZone = NULL;
	//}}AFX_DATA_INIT
}

MiscInfoPage::~MiscInfoPage()
{
	::SysFreeString (m_bstrComputerName);
	::SysFreeString (m_bstrUserName);
	::SysFreeString (m_bstrLocalLanguage);
	::SysFreeString (m_bstrTimeZone);
}

void MiscInfoPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(MiscInfoPage)
	DDX_Control(pDX, IDC_MISC_INFO_LIST, m_ListCtrl);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(MiscInfoPage, CPropertyPage)
	//{{AFX_MSG_MAP(MiscInfoPage)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// MiscInfoPage message handlers

BOOL MiscInfoPage::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	if (FAILED (m_pSystemInfo->GetSystemName (&m_bstrComputerName)))
	{
		return TRUE;
	}

	if (FAILED (m_pSystemInfo->GetSystemUserName (&m_bstrUserName)))
	{
		return TRUE;
	}

	if (FAILED (m_pSystemInfo->GetLocalLanguage (&m_bstrLocalLanguage)))
	{
		return TRUE;
	}

	// TimeZone information needs to be obtained from new interface.
	HRESULT hr = S_OK;
	ISystemInformation2 *pSysInfo2 = NULL;
	hr = m_pSystemInfo->QueryInterface (IID_ISystemInformation2,
										reinterpret_cast<void **>(&pSysInfo2));
	if (SUCCEEDED (hr))
	{
		hr = pSysInfo2->GetTimeZone (&m_bstrTimeZone);
		pSysInfo2->Release ();
		pSysInfo2 = NULL;
		if (FAILED (hr))
		{
			return TRUE;
		}
	}
	SetListData();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void MiscInfoPage::SetListData()
{
	CString tmpStr = _T ("");
	LV_ITEM item;
	LV_COLUMN leftCol, rightCol;

	leftCol.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	leftCol.fmt = LVCFMT_LEFT;
	leftCol.iSubItem = 0;
	leftCol.cx = 130;
	leftCol.pszText = _T ("Variable");

	rightCol.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	rightCol.fmt = LVCFMT_LEFT;
	rightCol.iSubItem = 1;
	rightCol.cx = 225;
	rightCol.pszText = _T ("Value");

	m_ListCtrl.InsertColumn (0, &leftCol);
	m_ListCtrl.InsertColumn (1, &rightCol);

	item.mask = LVIF_TEXT;
	item.iItem = 0;
	item.iSubItem = 0;
	item.pszText = _T ("Computer Name");
	m_ListCtrl.InsertItem (&item);
	tmpStr = m_bstrComputerName;
	m_ListCtrl.SetItemText (0, 1, tmpStr);

	item.iItem = 1;
	item.pszText = _T ("User Name");
	m_ListCtrl.InsertItem (&item);
	tmpStr = m_bstrUserName;
	m_ListCtrl.SetItemText (1, 1, tmpStr);

	item.iItem = 2;
	item.pszText = _T ("Local Language");
	m_ListCtrl.InsertItem (&item);
	tmpStr = m_bstrLocalLanguage;
	m_ListCtrl.SetItemText (2, 1, tmpStr);

	item.iItem = 3;
	item.pszText = _T ("Time Zone");
	m_ListCtrl.InsertItem (&item);
	tmpStr = m_bstrTimeZone;
	m_ListCtrl.SetItemText (3, 1, tmpStr);
}
