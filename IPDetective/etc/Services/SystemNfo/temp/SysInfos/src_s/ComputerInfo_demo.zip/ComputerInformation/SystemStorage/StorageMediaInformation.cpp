// Disclaimer and Copyright Information
// StorageMediaInformation.cpp : Implementation of CStorageMediaInformation
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include <stdio.h>
#include "SystemStorage.h"
#include "StorageMediaInformation.h"

/////////////////////////////////////////////////////////////////////////////
// CStorageMediaInformation

/******************************************************************************
 *	Function:
 *
 *	Parameters:
 *
 *	Returns:
 *
 *	Desscription:
 *
 *****************************************************************************/
STDMETHODIMP CStorageMediaInformation::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IStorageMediaInformation
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (::InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

/******************************************************************************
 *	Function:
 *
 *	Parameters:
 *
 *	Returns:
 *
 *	Desscription:
 *
 *****************************************************************************/
STDMETHODIMP CStorageMediaInformation::get_NumberOfDrives(long *pVal)
{
	HRESULT hRes = E_FAIL;

	if ((hRes = GetInformation ()) != S_OK)
	{
		return hRes;
	}

	*pVal = m_NumberOfDrives;

	return hRes;
}

/******************************************************************************
 *	Function:
 *
 *	Parameters:
 *
 *	Returns:
 *
 *	Desscription:
 *
 *****************************************************************************/
STDMETHODIMP CStorageMediaInformation::GetStorageMediaInformation(long *plNumberOfDrives,
	VARIANT *pbReadyArr, VARIANT *pbstrDriveLetterArr, VARIANT *pbstrLabelArr,
	VARIANT *pbSupportLongNameArr,	VARIANT *pbstrFileSystemArr, VARIANT *pbstrMediaTypeArr,
	VARIANT *plTotalSpaceArr, VARIANT *plFreeSpaceUserArr, VARIANT *plFreeSpaceTotalArr)
{
	HRESULT hRes = E_FAIL;

	if ((hRes = GetInformation ()) != S_OK)
	{
		return hRes;
	}

	*plNumberOfDrives = m_NumberOfDrives;
	
	VariantInit (pbReadyArr);
	VariantInit (pbSupportLongNameArr);
	VariantInit (pbstrDriveLetterArr);
	VariantInit (pbstrLabelArr);
	VariantInit (pbstrMediaTypeArr);
	VariantInit (pbstrFileSystemArr);
	VariantInit (plTotalSpaceArr);
	VariantInit (plFreeSpaceUserArr);
	VariantInit (plFreeSpaceTotalArr);

	
	V_VT (pbReadyArr) = VT_ARRAY | VT_BOOL;
	V_ARRAY (pbReadyArr) = m_pbDriveReady;

	V_VT (pbSupportLongNameArr) = VT_ARRAY | VT_BOOL;
	V_ARRAY (pbSupportLongNameArr) = m_pbSupportLongName;

	V_VT (pbstrDriveLetterArr) = VT_ARRAY | VT_BSTR;
	V_ARRAY (pbstrDriveLetterArr) = m_pbstrDriveLetter;

	V_VT (pbstrLabelArr) = VT_ARRAY | VT_BSTR;
	V_ARRAY (pbstrLabelArr) = m_pbstrDriveLabel;

	V_VT (pbstrMediaTypeArr) = VT_ARRAY | VT_BSTR;
	V_ARRAY (pbstrMediaTypeArr) = m_pbstrMediaType;

	V_VT (pbstrFileSystemArr) = VT_ARRAY | VT_BSTR;
	V_ARRAY (pbstrFileSystemArr) = m_pbstrFileSystem;

	V_VT (plTotalSpaceArr) = VT_ARRAY | VT_R8;
	V_ARRAY (plTotalSpaceArr) = m_plTotalSpace;

	V_VT (plFreeSpaceUserArr) = VT_ARRAY | VT_R8;
	V_ARRAY (plFreeSpaceUserArr) = m_plFreeSpaceUser;

	V_VT (plFreeSpaceTotalArr) = VT_ARRAY | VT_R8;
	V_ARRAY (plFreeSpaceTotalArr) = m_plFreeSpaceTotal;

	return S_OK;
}

/******************************************************************************
 *	Function:
 *
 *	Parameters:
 *
 *	Returns:
 *
 *	Desscription:
 *
 *****************************************************************************/
HRESULT CStorageMediaInformation::GetInformation ()
{
	UINT i, nIndex;
	UINT nDrives, nDriveType[32];
	ULARGE_INTEGER uFreeBytesAvailable, uTotalNumberOfBytes;
	ULARGE_INTEGER uTotalNumberOfFreeBytes;
	double tmpNum = 0;
	HRESULT hRes = S_OK;
	HANDLE hDevice = NULL;
	BOOL fResult, bReady, bSupportLongName;
	DWORD dwError;
	DWORD dwSerialNumber, dwMaxNameLength;
	DWORD dwFileSystemFlags;
	char szCurrentDrive[MAX_PATH];
	char szName[80];
	char lpMultiByteStr[128];
	TCHAR szLabel[128];
	TCHAR szFileSysName[128];

	DWORD dwLogicalDrives;

	if (m_bInformationObtained)
	{
		return S_OK;
	}

	CComBSTR bstrDriveLetter;
	CComBSTR bstrLabel;
	CComBSTR bstrFileSystem;
	
	SAFEARRAY *pSafeArray = NULL;
	SAFEARRAYBOUND arrayBound[1];

	arrayBound[0].lLbound = 0;
	arrayBound[0].cElements = 32;

	pSafeArray = ::SafeArrayCreate (VT_BSTR, 1, arrayBound);

	// Get the all the logical drives. Function will return a bit mask of the logical
	// drives. Bits are set if the corresponding drives are available. Bit 0 represents
	// drive A, bit 2 is drive B and so on.
	dwLogicalDrives = ::GetLogicalDrives ();

	m_NumberOfDrives = nIndex = 0;

	for (nDrives = 0; nDrives < 32; nDrives ++)
	{
		if (dwLogicalDrives && (1 << nDrives))
		{
			wsprintf (szCurrentDrive, "%c", nDrives + 'A');
			strcpy (szName, szCurrentDrive);
			strcat (szCurrentDrive, _T (":\\"));
			
			// Get the drive type.
			nDriveType[nIndex] = ::GetDriveType (szCurrentDrive);

			if (nDriveType[nIndex] == 1)
			{
				ATLTRACE (_T ("Drive %s doesn't exist!\n"), szCurrentDrive);
				continue;
			}

			bstrDriveLetter = szName;
			::SafeArrayPutElement (pSafeArray, (long *) &nIndex, bstrDriveLetter.Copy ());
			m_NumberOfDrives++;
			nIndex++;
		}
	}

	// Create the SafeArrays.

	if (FAILED (this->InitializeSafeArrays ()))
	{
		return E_FAIL;
	}

	for (i = 0; i < nIndex; i++)
	{
		::SafeArrayGetElement (pSafeArray, (long *) &i, &bstrDriveLetter);

		::WideCharToMultiByte (CP_ACP, 0, bstrDriveLetter, -1, lpMultiByteStr,
							   sizeof (lpMultiByteStr), NULL, NULL);

		sprintf(szCurrentDrive,"%s", lpMultiByteStr);
		strcat (szCurrentDrive, _T (":\\"));

		::SafeArrayPutElement (m_pbstrDriveLetter, (long *) &i, bstrDriveLetter.Copy ());
		::SafeArrayPutElement (m_pbstrMediaType, (long *) &i,
			                   GetMediaType (nDriveType[i]).Copy ());

		// Get the disk space information.

		fResult = ::GetDiskFreeSpaceEx (szCurrentDrive, &uFreeBytesAvailable,
										&uTotalNumberOfBytes, &uTotalNumberOfFreeBytes);

		bReady = TRUE;

		if (!fResult)
		{
			dwError = ::GetLastError ();
			// If the drive is not ready the, simply give this information and
			// bump the counter.
			if (dwError == ERROR_NOT_READY)
			{
				bReady = FALSE;
				::SafeArrayPutElement (m_pbDriveReady, (long *) &i, &bReady);
				continue;
			}
		}

		::SafeArrayPutElement (m_pbDriveReady, (long *) &i, &bReady);
		
		tmpNum = (double)(__int64)uTotalNumberOfBytes.QuadPart;
		::SafeArrayPutElement (m_plTotalSpace, (long *) &i, &tmpNum);
		
		tmpNum = (double)(__int64)uFreeBytesAvailable.QuadPart;
		::SafeArrayPutElement (m_plFreeSpaceUser, (long *) &i, &tmpNum);

		tmpNum = (double)(__int64)uTotalNumberOfFreeBytes.QuadPart;
		::SafeArrayPutElement (m_plFreeSpaceTotal, (long *) &i, &tmpNum);
		
		// Get the volume information for drive.
		
		::GetVolumeInformation (szCurrentDrive, szLabel, MAX_PATH - 1,
								&dwSerialNumber,
								&dwMaxNameLength,
								&dwFileSystemFlags,
								szFileSysName,
								MAX_PATH - 1);
		
		bSupportLongName = (dwMaxNameLength == 255) ? TRUE : FALSE;
		
		::SafeArrayPutElement (m_pbSupportLongName, (long *) &i, &bSupportLongName);
		bstrFileSystem = szFileSysName;
		::SafeArrayPutElement (m_pbstrFileSystem, (long *) &i, bstrFileSystem.Copy ());
		bstrLabel = szLabel;
		::SafeArrayPutElement (m_pbstrDriveLabel, (long *) &i, bstrLabel.Copy ());
	}

	m_bInformationObtained = true;

	return hRes;
}

/******************************************************************************
 *	Function:
 *
 *	Parameters:
 *
 *	Returns:
 *
 *	Desscription:
 *
 *****************************************************************************/
CComBSTR CStorageMediaInformation::GetMediaType (DWORD dwType) const
{
	CComBSTR bstrType;

	switch (dwType)
	{
		case DRIVE_UNKNOWN:
			bstrType = _T ("Unknown");
			break;
		case DRIVE_NO_ROOT_DIR:
			bstrType = _T ("No Root Directory");
			break;
		case DRIVE_REMOVABLE:
			bstrType = _T ("Floppy/Removable");
			break;
		case DRIVE_FIXED:
			bstrType = _T ("Hard Disk");
			break;
		case DRIVE_REMOTE:
			bstrType = _T ("Network Drive");
			break;
		case DRIVE_CDROM:
			bstrType = _T ("CD-ROM Drive");
			break;
		case DRIVE_RAMDISK:
			bstrType = _T ("RAM Disk");
			break;
	}

	return bstrType;
}

/******************************************************************************
 *	Function:
 *
 *	Parameters:
 *
 *	Returns:
 *
 *	Desscription:
 *
 *****************************************************************************/
HRESULT CStorageMediaInformation::InitializeSafeArrays ()
{
	SAFEARRAYBOUND arrayBound[1];

	if (m_NumberOfDrives <= 0)
	{
		return E_FAIL;
	}

	arrayBound[0].lLbound = 0;
	arrayBound[0].cElements = m_NumberOfDrives;

	m_pbDriveReady = SafeArrayCreate (VT_BOOL, 1, arrayBound);
	m_pbstrDriveLetter = SafeArrayCreate (VT_BSTR, 1, arrayBound);
	m_pbSupportLongName = SafeArrayCreate (VT_BOOL, 1, arrayBound);
	m_pbstrDriveLabel = SafeArrayCreate (VT_BSTR, 1, arrayBound);
	m_pbstrMediaType = SafeArrayCreate (VT_BSTR, 1, arrayBound);
	m_pbstrFileSystem = SafeArrayCreate (VT_BSTR, 1, arrayBound);
	m_plTotalSpace = SafeArrayCreate (VT_R8, 1, arrayBound);
	m_plFreeSpaceUser = SafeArrayCreate (VT_R8, 1, arrayBound);
	m_plFreeSpaceTotal = SafeArrayCreate (VT_R8, 1, arrayBound);

	return S_OK;
}
