// MiscInformation2.cpp : Implementation of CMiscInformation2

#include "stdafx.h"
#include "SystemMisc.h"
#include "MiscInformation2.h"


// CMiscInformation2

STDMETHODIMP CMiscInformation2::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IMiscInformation2
	};

	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CMiscInformation2::get_TimeZone(BSTR* pVal)
{
	// TODO: Add your implementation code here

	return S_OK;
}
