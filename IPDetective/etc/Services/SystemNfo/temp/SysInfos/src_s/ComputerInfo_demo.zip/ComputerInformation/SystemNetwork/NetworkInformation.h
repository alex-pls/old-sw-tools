// NetworkInformation.h : Declaration of the CNetworkInformation

#ifndef __NETWORKINFORMATION_H_
#define __NETWORKINFORMATION_H_

#include "resource.h"       // main symbols
#include "SocketUtil.h"

/////////////////////////////////////////////////////////////////////////////
// CNetworkInformation
class ATL_NO_VTABLE CNetworkInformation : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CNetworkInformation, &CLSID_NetworkInformation>,
	public ISupportErrorInfo,
	public IDispatchImpl<INetworkInformation, &IID_INetworkInformation, &LIBID_SYSTEMNETWORKLib>
{
public:
	CNetworkInformation()
		: m_pSocketUtil(NULL)
		, m_bInfoGenerated(false)
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_NETWORKINFORMATION)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CNetworkInformation)
	COM_INTERFACE_ENTRY(INetworkInformation)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// INetworkInformation
	HRESULT FinalConstruct();
	void FinalRelease() ;

public:
private:
	HRESULT GetInformation(void);
public:
	STDMETHODIMP GetNetworkInfo(void);
protected:
	CSocketUtil* m_pSocketUtil;
	bool m_bInfoGenerated;
	CComBSTR m_bstrIPAddress;
};

#endif //__NETWORKINFORMATION_H_
