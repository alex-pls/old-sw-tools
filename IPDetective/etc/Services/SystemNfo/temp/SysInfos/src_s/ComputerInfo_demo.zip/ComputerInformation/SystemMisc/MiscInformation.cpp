// Disclaimer and Copyright Information
// MiscInformation.cpp
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SystemMisc.h"
#include "MiscInformation.h"

/////////////////////////////////////////////////////////////////////////////
// CMiscInformation

STDMETHODIMP CMiscInformation::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IMiscInformation
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (::InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CMiscInformation::get_SystemName(BSTR *pVal)
{
	HRESULT hRes = S_OK;
	if ((hRes = GetInformation ()) != S_OK) {
		return hRes;
	}

	*pVal = m_bstrComputerName.Copy ();

	return S_OK;
}

STDMETHODIMP CMiscInformation::get_SystemUserName(BSTR *pVal)
{
	HRESULT hRes = S_OK;
	if ((hRes = GetInformation ()) != S_OK) {
		return hRes;
	}

	*pVal = m_bstrUserName.Copy ();
	return S_OK;
}

STDMETHODIMP CMiscInformation::get_Language(BSTR *pVal)
{
	HRESULT hRes = S_OK;
	if ((hRes = GetInformation ()) != S_OK) {
		return hRes;
	}

	*pVal = m_bstrLocalLanguage.Copy ();
	return S_OK;
}

STDMETHODIMP CMiscInformation::get_TimeZone(BSTR* pVal)
{
	HRESULT hRes = S_OK;
	if ((hRes = GetInformation ()) != S_OK) {
		return hRes;
	}

	*pVal = m_bstrTimeZone.Copy ();
	return S_OK;
}

HRESULT CMiscInformation::GetInformation ()
{
	HRESULT hRes = S_OK;
	BOOL fResult;
	DWORD dwSize, dwError, dwReturnedSize;
	LANGID langId;
	char szBuffer[MAX_COMPUTERNAME_LENGTH + 1];
	char szLanguage[MAX_PATH];

	if (m_bInformationObtained)
	{
		return S_OK;
	}

	dwSize = MAX_COMPUTERNAME_LENGTH + 1;
	fResult = ::GetComputerName (szBuffer, &dwSize);
	if (!fResult)
	{
		dwError = ::GetLastError ();
		m_bstrComputerName = _T ("");
	}
	else
	{
		m_bstrComputerName = szBuffer;
	}

	fResult = ::GetUserName (szBuffer, &dwSize);
	if (!fResult)
	{
		dwError = GetLastError ();
		m_bstrUserName = _T ("");
	}
	else
	{
		m_bstrUserName = szBuffer;
	}

	// Get the ID of the language identifier.
	langId = ::GetSystemDefaultLangID ();

	// Get the string for the language identifier.
	dwSize = MAX_PATH;
	dwReturnedSize = VerLanguageName (langId, szLanguage, dwSize);
	if (dwReturnedSize <= dwSize)
	{
		m_bstrLocalLanguage = szLanguage;
	}

	// Get time zone information.
	TIME_ZONE_INFORMATION info;
	dwError = ::GetTimeZoneInformation (&info);
	if (TIME_ZONE_ID_INVALID != dwError)
	{
		m_bstrTimeZone = ::SysAllocString (info.StandardName);
	}

	m_bInformationObtained = true;
	return hRes;
}