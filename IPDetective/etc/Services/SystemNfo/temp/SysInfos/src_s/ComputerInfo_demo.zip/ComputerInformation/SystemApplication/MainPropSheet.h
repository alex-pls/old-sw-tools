#if !defined(AFX_MAINPROPSHEET_H__A7364AE3_B2D8_11D2_8C49_000000000000__INCLUDED_)
#define AFX_MAINPROPSHEET_H__A7364AE3_B2D8_11D2_8C49_000000000000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MainPropSheet.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMainPropSheet

class CMainPropSheet : public CPropertySheet
{
	DECLARE_DYNAMIC(CMainPropSheet)

// Construction
public:
	CMainPropSheet(UINT nIDCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);
	CMainPropSheet(LPCTSTR pszCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainPropSheet)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMainPropSheet();

	// Generated message map functions
protected:
	//{{AFX_MSG(CMainPropSheet)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINPROPSHEET_H__A7364AE3_B2D8_11D2_8C49_000000000000__INCLUDED_)
