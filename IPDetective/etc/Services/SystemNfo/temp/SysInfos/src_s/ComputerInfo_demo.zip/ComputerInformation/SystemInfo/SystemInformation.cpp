// Disclaimer and Copyright Information
// SystemInformation.cpp : Implementation of CSystemInformation
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////

// Revision History:
//	2/1/2001	Initial Creation
//	2/7/2001	Added new method from IMiscInformation2 interface
//	2/10/2001	Added Locale Info interface
//

#include "stdafx.h"
#include "SystemInfo.h"
#include "SystemInformation.h"

/////////////////////////////////////////////////////////////////////////////
// CSystemInformation

CSystemInformation::CSystemInformation ()
{
	m_pOSInfo = NULL;
	m_pMouseInfo = NULL;
	m_pMemoryInfo = NULL;
	m_pHDiskInfo = NULL;
	m_pStorageInfo = NULL;
	m_pMultiMediaInfo = NULL;
	m_pCPUInfo = NULL;
	m_pMiscInfo = NULL;
	m_pLocaleInfo = NULL;
//	m_pHWDevices = NULL;
//	m_pNetworkInfo = NULL;
//	m_pModemInfo = NULL;
	m_pPnPDevices = NULL;
	m_pKeyboardInfo = NULL;
}

HRESULT
CSystemInformation::FinalConstruct ()
{
	HRESULT hr;

	hr = CoCreateInstance (CLSID_OSInformation, 0, CLSCTX_INPROC_SERVER,
		IID_IOSInformation,	reinterpret_cast<void **>(&m_pOSInfo));
	if (FAILED (hr)) {
		return E_NOINTERFACE;
	}

	hr = CoCreateInstance (CLSID_MouseInformation, 0, CLSCTX_INPROC_SERVER,
		IID_IMouseInformation, reinterpret_cast<void **>(&m_pMouseInfo));
	if (FAILED (hr)) {
		return E_NOINTERFACE;
	}

	hr = CoCreateInstance (CLSID_MemoryInformation, 0, CLSCTX_INPROC_SERVER,
		IID_IMemoryInformation, reinterpret_cast<void **>(&m_pMemoryInfo));
	if (FAILED (hr)) {
		return E_NOINTERFACE;
	}

	hr = CoCreateInstance (CLSID_HDiskInformation, 0, CLSCTX_INPROC_SERVER,
		IID_IHDiskInformation, reinterpret_cast<void **>(&m_pHDiskInfo));
	if (FAILED (hr)) {
		return E_NOINTERFACE;
	}

	hr = CoCreateInstance (CLSID_StorageMediaInformation, 0, CLSCTX_INPROC_SERVER,
		IID_IStorageMediaInformation, reinterpret_cast<void **>(&m_pStorageInfo));
	if (FAILED (hr)) {
		return E_NOINTERFACE;
	}

	hr = CoCreateInstance (CLSID_MultiMediaInformation, 0, CLSCTX_INPROC_SERVER,
		IID_IMultiMediaInformation, reinterpret_cast<void **>(&m_pMultiMediaInfo));
	if (FAILED (hr)) {
		return E_NOINTERFACE;
	}

	hr = CoCreateInstance (CLSID_CPUInformation, 0, CLSCTX_INPROC_SERVER,
		IID_ICPUInformation, reinterpret_cast<void **>(&m_pCPUInfo));
	if (FAILED (hr)) {
		return E_NOINTERFACE;
	};

	hr = CoCreateInstance (CLSID_MiscInformation, 0, CLSCTX_INPROC_SERVER,
		IID_IMiscInformation, reinterpret_cast<void **>(&m_pMiscInfo));
	if (FAILED (hr)) {
		return E_NOINTERFACE;
	};

	hr = CoCreateInstance (CLSID_ProtectedFilesInfo, 0, CLSCTX_INPROC_SERVER,
		IID_IProtectedFilesInfo, reinterpret_cast<void **>(&m_pProtectFileInfo));
	if (FAILED (hr)) {
		return E_NOINTERFACE;
	};
/*
	hr = CoCreateInstance (CLSID_HWDevices, 0, CLSCTX_INPROC_SERVER,
		IID_IHWDevices, reinterpret_cast<void **>(&m_pHWDevices));
	if (FAILED (hr))
	{
		return E_NOINTERFACE;
	}

	hr = ::CoCreateInstance (CLSID_NetworkInformation,
							 0,
							 CLSCTX_SERVER,
							 IID_INetworkInformation,
							 reinterpret_cast<void **>(&m_pNetworkInfo));
	if (FAILED (hr))
	{
		return E_NOINTERFACE;
	};

	hr = ::CoCreateInstance (CLSID_ModemInformation,
							 0,
							 CLSCTX_SERVER,
							 IID_IModemInformation,
							 reinterpret_cast<void **>(&m_pModemInfo));
	if (FAILED (hr))
	{
		return E_NOINTERFACE;
	};
*/
	hr = ::CoCreateInstance (CLSID_LocaleInformation,
							 0,
							 CLSCTX_SERVER,
							 IID_ILocaleInformation,
							 reinterpret_cast<void **>(&m_pLocaleInfo));
	if (FAILED (hr))
	{
		return E_NOINTERFACE;
	};

	hr = ::CoCreateInstance (CLSID_PnPDevicesInfo,
							 0,
							 CLSCTX_SERVER,
							 IID_IPnPDevicesInfo,
							 reinterpret_cast<void **>(&m_pPnPDevices));
	if (FAILED (hr))
	{
		return E_NOINTERFACE;
	};

	hr = ::CoCreateInstance (CLSID_PSKeyboardInformation,
							 0,
							 CLSCTX_SERVER,
							 IID_IPSKeyboardInformation,
							 reinterpret_cast<void **>(&m_pKeyboardInfo));
	if (FAILED (hr))
	{
		return E_NOINTERFACE;
	};

	return S_OK;
}

void
CSystemInformation::FinalRelease ()
{
	if (m_pOSInfo != NULL)
	{
		m_pOSInfo->Release ();
	}
	m_pOSInfo = NULL;

	if (m_pMouseInfo != NULL)
	{
		m_pMouseInfo->Release ();
	}
	m_pMouseInfo = NULL;

	if (m_pMemoryInfo != NULL)
	{
		m_pMemoryInfo->Release ();
	}
	m_pMemoryInfo = NULL;

	if (m_pHDiskInfo != NULL)
	{
		m_pHDiskInfo->Release ();
	}
	m_pHDiskInfo = NULL;

	if (m_pStorageInfo != NULL)
	{
		m_pStorageInfo->Release ();
	}
	m_pStorageInfo = NULL;

	if (m_pMultiMediaInfo != NULL)
	{
		m_pMultiMediaInfo->Release ();
	}
	m_pMultiMediaInfo = NULL;

	if (m_pCPUInfo != NULL)
	{
		m_pCPUInfo->Release ();
	}
	m_pCPUInfo = NULL;

	if (m_pMiscInfo != NULL)
	{
		m_pMiscInfo->Release ();
	}
	m_pMiscInfo = NULL;

	if (m_pMiscInfo != NULL)
	{
		m_pProtectFileInfo->Release ();
	}
	m_pProtectFileInfo = NULL;
/*
	if (m_pHWDevices != NULL)
	{
		m_pHWDevices->Release ();
	}
	m_pHWDevices = NULL;

	if (NULL != m_pNetworkInfo)
	{
		m_pNetworkInfo->Release ();
	}
	m_pNetworkInfo = NULL;

	if (NULL != m_pModemInfo)
	{
		m_pModemInfo->Release ();
	}
	m_pModemInfo = NULL;
*/
	if (NULL != m_pLocaleInfo)
	{
		m_pLocaleInfo->Release ();
	}
	m_pLocaleInfo = NULL;

	if (NULL != m_pPnPDevices)
	{
		m_pPnPDevices->Release ();
	}
	m_pPnPDevices = NULL;

	if (NULL != m_pKeyboardInfo)
	{
		m_pKeyboardInfo->Release ();
	}
	m_pKeyboardInfo = NULL;
}

STDMETHODIMP CSystemInformation::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_ISystemInformation
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (::InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CSystemInformation::GetOSInformation(BSTR *pbstrPlatform,
												  BSTR *pbstrSuites,
												  BSTR *pbstrMinorVersion, 
												  BSTR *pbstrServicePack,
												  long *plBuildNumber)
{
	HRESULT hr = E_FAIL;
	hr = m_pOSInfo->GetOSInformation (plBuildNumber, pbstrPlatform,
									  pbstrSuites, pbstrMinorVersion,
									  pbstrServicePack);
	if (FAILED (hr))
	{
		return E_FAIL;
	}
	return S_OK;
}

STDMETHODIMP CSystemInformation::GetMouseInformation(VARIANT_BOOL *pbInstalled, VARIANT_BOOL *pbButtonsSwapped,
													 long *plSpeed)
{
	HRESULT hr = E_FAIL;
	hr = m_pMouseInfo->GetMouseInformation (pbInstalled, pbButtonsSwapped, plSpeed);
	if (FAILED (hr))
	{
		return E_FAIL;
	}
	return S_OK;
}

STDMETHODIMP CSystemInformation::GetCPUInformation(BSTR *pbstrVendor, BSTR *pbstrType,
	BSTR *pbstrArchitecture, BSTR *pbstrLevel, BSTR *pbstrRevision, long *plNumberOfProcessors,
	long *plSpeed, long *plPageSize, long *plMask)
{
	HRESULT hr = E_FAIL;

	hr = m_pCPUInfo->GetCPUInformation (pbstrVendor, pbstrType, pbstrArchitecture, pbstrLevel,
		pbstrRevision, plNumberOfProcessors, plSpeed, plPageSize, plMask);
	if (FAILED (hr))
	{
		return E_FAIL;
	}

	return S_OK;
}

STDMETHODIMP CSystemInformation::GetHDiskInformation(long *plNumberOfPartitions,
	VARIANT *pbstrDriveLetterArr, VARIANT *pbBootableArr, VARIANT *pbstrTypeArr,
	VARIANT *plPartitionNumberArr, VARIANT *plLengthArr, VARIANT *plHiddenSectorsArr)
{
	HRESULT hr = E_FAIL;

	hr = m_pHDiskInfo->GetHDiskInformation(plNumberOfPartitions, pbstrDriveLetterArr,
		pbBootableArr, pbstrTypeArr, plPartitionNumberArr, plLengthArr, plHiddenSectorsArr);
	if (FAILED (hr)) {
		return E_FAIL;
	}

	return S_OK;
}

STDMETHODIMP CSystemInformation::GetMemoryInformation(long *plRAMInstalled,
	long *plAvailableMemory, long *plVirtualMemory, long *plMemoryLoad)
{
	HRESULT hr = E_FAIL;

	hr = m_pMemoryInfo->GetMemoryInformation (plRAMInstalled, plAvailableMemory, plVirtualMemory, plMemoryLoad);
	if (FAILED (hr)) {
		return E_FAIL;
	}

	return S_OK;
}

STDMETHODIMP CSystemInformation::GetStorageMediaInformation(long *plNumberOfDrives,
	VARIANT *pbReadyArr, VARIANT *pbstrDriveLetterArr, VARIANT *pbstrLabelArr,
	VARIANT *pbSupportLongNameArr, VARIANT *pbstrFileSystemArr, VARIANT *pbstrMediaTypeArr,
	VARIANT *plTotalSpaceArr, VARIANT *plFreeSpaceUserArr, VARIANT *plFreeSpaceTotalArr)
{
	HRESULT hr = E_FAIL;

	hr = m_pStorageInfo->GetStorageMediaInformation (plNumberOfDrives, pbReadyArr, pbstrDriveLetterArr,
		pbstrLabelArr, pbSupportLongNameArr, pbstrFileSystemArr, pbstrMediaTypeArr,
		plTotalSpaceArr, plFreeSpaceUserArr, plFreeSpaceTotalArr);
	if (FAILED (hr)) {
		return E_FAIL;
	}

	return S_OK;
}

STDMETHODIMP CSystemInformation::GetMultiMediaInformation(VARIANT_BOOL *pbIsInstalled,
	VARIANT_BOOL *pbHasVolCtrl, VARIANT_BOOL *pbHasSeparateLRVolCtrl, BSTR *pbstrProductName,
	BSTR *pbstrCompanyName)
{
	HRESULT hr = E_FAIL;

	hr = m_pMultiMediaInfo->GetMultiMediaInformation (pbIsInstalled, pbHasVolCtrl,
		pbHasSeparateLRVolCtrl, pbstrProductName, pbstrCompanyName);
	if (FAILED (hr)) {
		return E_FAIL;
	}

	return S_OK;
}

STDMETHODIMP CSystemInformation::GetSystemName(BSTR *pbstrComputerName)
{
	HRESULT hr = E_FAIL;

	hr = m_pMiscInfo->get_SystemName(pbstrComputerName);
	if (FAILED (hr)) {
		return E_FAIL;
	}

	return S_OK;
}

STDMETHODIMP CSystemInformation::GetSystemUserName(BSTR *pbstrUserName)
{
	HRESULT hr = E_FAIL;

	hr = m_pMiscInfo->get_SystemUserName(pbstrUserName);
	if (FAILED (hr)) {
		return E_FAIL;
	}

	return S_OK;
}

STDMETHODIMP CSystemInformation::GetLocalLanguage(BSTR *pbstrLocalLanguage)
{
	HRESULT hr = E_FAIL;

	hr = m_pMiscInfo->get_Language (pbstrLocalLanguage);
	if (FAILED (hr)) {
		return E_FAIL;
	}

	return S_OK;
}

STDMETHODIMP CSystemInformation::GetProtectedFilesInfo(long *plNumOfFiles, VARIANT *pbstrFileNameArr)
{
	HRESULT hr = E_FAIL;

//	hr = m_pProtectFileInfo->get_NumberOfProtectedFiles (plNumOfFiles);
	hr = m_pProtectFileInfo->GetProtectedFilesInfo (plNumOfFiles, pbstrFileNameArr);
	if (FAILED (hr)) {
		return E_FAIL;
	}

	return S_OK;
}

STDMETHODIMP CSystemInformation::GetHWDevicesInfo(void)
{
	HRESULT hr = E_FAIL;
	// For the time being implementation has been disabled.
/*
	hr = m_pHWDevices->GetHWDevicesInfo ();
	if (FAILED (hr))
	{
		return E_FAIL;
	}
*/
	return hr;
}

STDMETHODIMP CSystemInformation::GetTimeZone (BSTR *pbstrTimeZone)
{
	HRESULT hr = E_FAIL;
	IMiscInformation2 *pMiscInfo2 = NULL;

	// Get the new interface object.
	hr = m_pMiscInfo->QueryInterface (IID_IMiscInformation2,
									  reinterpret_cast<void **>(&pMiscInfo2));
	if (SUCCEEDED (hr))
	{
		hr = pMiscInfo2->get_TimeZone (pbstrTimeZone);
		pMiscInfo2->Release ();
		pMiscInfo2 = NULL;
	}

	return hr;
}

STDMETHODIMP CSystemInformation::GetNetworkInfo (void)
{
	HRESULT hr = S_OK;

//	hr = m_pNetworkInfo->GetNetworkInfo ();
	return hr;
}

STDMETHODIMP CSystemInformation::GetModemInfo (void)
{
	HRESULT hr = S_OK;
	return hr;
}

STDMETHODIMP CSystemInformation::GetLocaleInformation ( /*[out]*/ short* pCodePage,
														/*[out]*/ short *pOEMCodePage,
														/*[out]*/ BSTR* pCalendarType,
														/*[out]*/ BSTR* pDateFormat,
														/*[out]*/ BSTR* pLanguage,
														/*[out]*/ BSTR* pCountry,
														/*[out]*/ short* pCountryCode,
														/*[out]*/ BSTR* pTimeFormat,
														/*[out]*/ BSTR* pCurrency,
														/*[out]*/ BSTR* pTimeFormatSpecifier)
{
	HRESULT hr = S_OK;

	hr = m_pLocaleInfo->get_CodePage (pCodePage);
	hr = m_pLocaleInfo->get_OEMCodePage (pOEMCodePage);
	hr = m_pLocaleInfo->get_CalendarType (pCalendarType);
	hr = m_pLocaleInfo->get_DateFormat (pDateFormat);
	hr = m_pLocaleInfo->get_Language (pLanguage);
	hr = m_pLocaleInfo->get_Country (pCountry);
	hr = m_pLocaleInfo->get_CountryCode (pCountryCode);
	hr = m_pLocaleInfo->get_TimeFormat (pTimeFormat);
	hr = m_pLocaleInfo->get_Currency (pCurrency);
	hr = m_pLocaleInfo->get_TimeFormatSpecifier (pTimeFormatSpecifier);

	return hr;
}

STDMETHODIMP CSystemInformation::GetPnPDevices (IUnknown **pDevices)
{
	HRESULT hr = S_OK;
	ATLASSERT (NULL != pDevices);
	if (NULL == pDevices)
	{
		return E_POINTER;
	}
	
	IPnPDevices *pPnPDevices = NULL;
	hr = m_pPnPDevices->GetPnpDevices (&pPnPDevices);
	if (SUCCEEDED (hr))
	{
		hr = pPnPDevices->QueryInterface (IID_IUnknown, reinterpret_cast<void **>(pDevices));
	}

	return hr;
}

STDMETHODIMP CSystemInformation::GetKeyboardInfo (BSTR* pbstrKeyboardType, short* pnFnKeys)
{
	HRESULT hr = S_OK;
	ATLASSERT (NULL != pbstrKeyboardType);
	if (NULL == pbstrKeyboardType)
	{
		return E_POINTER;
	}

	ATLASSERT (NULL != pnFnKeys);
	if (NULL == pnFnKeys)
	{
		return E_POINTER;
	}

	hr = this->m_pKeyboardInfo->get_Type (pbstrKeyboardType);
	ATLASSERT (SUCCEEDED (hr));
	if (FAILED (hr))
	{
		return hr;
	}

	hr = this->m_pKeyboardInfo->get_FunctionKeys (pnFnKeys);
	ATLASSERT (SUCCEEDED (hr));
	return hr;
}
