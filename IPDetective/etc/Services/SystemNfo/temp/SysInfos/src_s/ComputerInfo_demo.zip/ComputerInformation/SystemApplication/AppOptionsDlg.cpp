// Disclaimer and Copyright Information
// AppOptionsDlg.cpp : Implementation file
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////

//	Revision History:
//	2/12/2001	Initial Creation
//

#include "stdafx.h"
#include "SystemApplication.h"
#include "AppOptionsDlg.h"


// CAppOptionsDlg dialog

IMPLEMENT_DYNAMIC(CAppOptionsDlg, CDialog)
CAppOptionsDlg::CAppOptionsDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CAppOptionsDlg::IDD, pParent)
	, m_dwOptionsMask(0)
{
}

CAppOptionsDlg::~CAppOptionsDlg()
{
}

void CAppOptionsDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CAppOptionsDlg, CDialog)
END_MESSAGE_MAP()


// CAppOptionsDlg message handlers
