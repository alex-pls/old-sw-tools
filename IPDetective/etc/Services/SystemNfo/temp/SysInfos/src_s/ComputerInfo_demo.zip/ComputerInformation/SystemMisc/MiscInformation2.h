// MiscInformation2.h : Declaration of the CMiscInformation2

#pragma once
#include "resource.h"       // main symbols



// CMiscInformation2

class ATL_NO_VTABLE CMiscInformation2 : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CMiscInformation2, &CLSID_MiscInformation>,
	public ISupportErrorInfo,
	public IDispatchImpl<IMiscInformation2, &IID_IMiscInformation2, &LIBID_SYSTEMMISCLib, /*wMajor =*/ 1, /*wMinor =*/ 0>
{
public:
	CMiscInformation2()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_MISCINFORMATION2)


BEGIN_COM_MAP(CMiscInformation2)
	COM_INTERFACE_ENTRY(IMiscInformation2)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}
	
	void FinalRelease() 
	{
	}

public:

	STDMETHODIMP get_TimeZone(BSTR* pVal);
};
