//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SystemApplication.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDS_ABOUTBOX                    101
#define IDD_SYSTEMAPPLICATION_DIALOG    102
#define IDD_HWDEVICESINFOPAGE           103
#define ID_INDICATOR_TIME               104
#define IDD_NETWORK_INFO_PAGE1          105
#define IDR_MAINFRAME                   128
#define IDD_MOUSE_PROP_PAGE             129
#define IDD_MEMORY_INFO_PAGE            130
#define IDD_CPU_INFO_PAGE               131
#define IDD_HDISK_INFO_PAGE             132
#define IDD_SAFE_FILES_PAGE             133
#define IDD_MISC_INFO_PAGE              134
#define IDI_ICON1                       134
#define IDI_APP_ICON                    134
#define IDD_NETWORK_INFO_PAGE           135
#define IDD_LOCALE_INFO_PAGE            136
#define IDR_OPTIONS_MENU                137
#define IDD_OS_INFO_PAGE                138
#define ID_SYS_ABOUTSYSTEMAPPLICATION   138
#define IDD_STORAGE_INFO_PAGE           139
#define ID_SYS_OPTIONS                  139
#define IDD_MULTIMEDIA_PROP_PAGE        140
#define IDD_OPTIONS_DIALOG              141
#define IDD_PNPDEVICES_PAGE             142
#define IDD_DEVICEINFO_DIALOG           143
#define IDD_KEYBOARD_INFO_PAGE          144
#define IDC_PICTURE_STATIC              1000
#define IDC_SAFE_FILES_LIST             1000
#define IDC_LIST1                       1001
#define IDC_HWDEVICES_INFO_LIST         1001
#define IDC_NETWORK_INFO_LIST           1001
#define IDC_LOCALE_INFO_LIST            1001
#define IDC_PNP_DEVICES_LIST            1001
#define IDC_KEYBOARD_INFO_LIST          1001
#define IDC_OS_CHECK                    1002
#define IDC_CPU_CHECK                   1003
#define IDC_MOUSE_INFO_LIST             1004
#define IDC_MEMORY_CHECK                1004
#define IDC_CPU_INFO_LIST               1005
#define IDC_HDISK_CHECK                 1005
#define IDC_HDISK_INFO_LIST             1006
#define IDC_STORAGE_CHECK               1006
#define IDC_MEMORY_INFO_LIST            1007
#define IDC_LOCALE_CHECK                1007
#define IDC_MISC_INFO_LIST              1008
#define IDC_MISC_CHECK                  1008
#define IDC_MMEDIA_CHECK                1009
#define IDC_OS_INFO_LIST                1010
#define IDC_PROTECTFILES_CHECK          1010
#define IDC_STORAGE_INFO_LIST           1011
#define IDC_NETWORK_CHECK1              1011
#define IDC_NETWORK_CHECK               1011
#define IDC_MODEM_CHECK                 1012
#define IDC_SYSBIOS_CHECK               1013
#define IDC_VIDEOBIOS_CHECK             1014
#define IDC_DESC_EDIT                   1016
#define IDC_VENDOR_EDIT                 1017
#define IDC_CLASSGUID_EDIT              1018
#define IDC_DEVICETYPE_EDIT             1019
#define IDC_SERIAL_NUMBER_EDIT          1020
#define IDC_DRIVERS_LIST                1021
#define IDC_DRIVER_DETAILS_RICHEDIT     1022

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        144
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1024
#define _APS_NEXT_SYMED_VALUE           106
#endif
#endif
