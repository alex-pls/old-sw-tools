// Disclaimer and Copyright Information
// MemoryInfoPage.cpp : Implementation file
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SystemApplication.h"
#include "MemoryInfoPage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// MemoryInfoPage property page

IMPLEMENT_DYNCREATE(MemoryInfoPage, CPropertyPage)

MemoryInfoPage::MemoryInfoPage() : CPropertyPage(MemoryInfoPage::IDD)
{
	//{{AFX_DATA_INIT(MemoryInfoPage)
	m_lRAMInstalled = 0;
	m_lAvailableMemory = 0;
	m_lVirtualMemory = 0;
	m_lLoad = 0;
	//}}AFX_DATA_INIT
}

MemoryInfoPage::~MemoryInfoPage()
{
}

void MemoryInfoPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(MemoryInfoPage)
	DDX_Control(pDX, IDC_MEMORY_INFO_LIST, m_ListCtrl);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(MemoryInfoPage, CPropertyPage)
	//{{AFX_MSG_MAP(MemoryInfoPage)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// MemoryInfoPage message handlers

BOOL MemoryInfoPage::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	if (FAILED (m_pSystemInfo->GetMemoryInformation (&m_lRAMInstalled, &m_lAvailableMemory,
		&m_lVirtualMemory, &m_lLoad))) {
		return TRUE;
	}

	SetListData();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void MemoryInfoPage::SetListData()
{
	CString tmpStr;
	double var;
	LV_ITEM item;
	LV_COLUMN leftCol, rightCol;

	leftCol.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	leftCol.fmt = LVCFMT_LEFT;
	leftCol.iSubItem = 0;
	leftCol.cx = 130;
	leftCol.pszText = _T ("Parameter");

	rightCol.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	rightCol.fmt = LVCFMT_LEFT;
	rightCol.iSubItem = 1;
	rightCol.cx = 225;
	rightCol.pszText = _T ("Value");

	m_ListCtrl.InsertColumn (0, &leftCol);
	m_ListCtrl.InsertColumn (1, &rightCol);

	item.mask = LVIF_TEXT;
	item.iItem = 0;
	item.iSubItem = 0;
	item.pszText = _T ("Memory Load");
	m_ListCtrl.InsertItem (&item);

	tmpStr.Format ("%d", m_lLoad);
	m_ListCtrl.SetItemText (0, 1, tmpStr);

	item.iItem = 1;
	item.pszText = _T ("RAM Installed");
	m_ListCtrl.InsertItem (&item);

	var = m_lRAMInstalled / (1024 * 1024);
	// There is some memory which is reserved by system and is not available. Its around
	// 0.5 - 0.6 MB. so we can approximate our calculations by adding 1 MB to calculated
	// value.
	var ++;
	tmpStr.Format ("%7.0lf", var);
	tmpStr.TrimLeft ();
	tmpStr = _T ("~") + tmpStr + _T (" MB");
	m_ListCtrl.SetItemText (1, 1, tmpStr);

	item.iItem = 2;
	item.pszText = _T ("Memory Available");
	m_ListCtrl.InsertItem (&item);

	var = m_lAvailableMemory / (1024 * 1024);
	tmpStr.Format ("%7.0lf", var);
	tmpStr.TrimLeft ();
	tmpStr = _T ("~") + tmpStr + _T (" MB");
	m_ListCtrl.SetItemText (2, 1, tmpStr);

	item.iItem = 3;
	item.pszText = _T ("Total Virtual Memory");
	m_ListCtrl.InsertItem (&item);

	var = m_lVirtualMemory / (1024 * 1024);
	tmpStr.Format ("%7.0lf", var);
	tmpStr.TrimLeft ();
	tmpStr = _T ("~") + tmpStr + _T (" MB");
	m_ListCtrl.SetItemText (3, 1, tmpStr);
}
