// PnPDevicesInfo.h : Declaration of the CPnPDevicesInfo

#ifndef __PNPDEVICESINFO_H_
#define __PNPDEVICESINFO_H_

#include "resource.h"       // main symbols
#include <list>
#include <atlbase.h>
#include "SetupApi.h"

/////////////////////////////////////////////////////////////////////////////
// CPnPDevicesInfo
class ATL_NO_VTABLE CPnPDevicesInfo : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CPnPDevicesInfo, &CLSID_PnPDevicesInfo>,
	public ISupportErrorInfo,
	public IDispatchImpl<IPnPDevicesInfo, &IID_IPnPDevicesInfo, &LIBID_SYSTEMPNPDEVICESLib>
{
public:
	CPnPDevicesInfo()
		: m_bInfoInitialized(false)
	{
		
	}

DECLARE_REGISTRY_RESOURCEID(IDR_PNPDEVICESINFO)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CPnPDevicesInfo)
	COM_INTERFACE_ENTRY(IPnPDevicesInfo)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

	HRESULT FinalConstruct()
	{
		m_pDevices = NULL;
		return S_OK;
	}
	
	void FinalRelease() 
	{
		if (NULL != m_pDevices)
		{
			m_pDevices->Release ();
		}
		m_pDevices = NULL;
	}

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IPnPDevicesInfo
public:

	STDMETHODIMP GetPnpDevices(IPnPDevices** pDevices);
protected:
	HRESULT InitInfo(void);
	bool m_bInfoInitialized;
	IUnknown *m_pDevices;

private:
	HRESULT GetDeviceRegistryInfo (IN HDEVINFO  DeviceInfoSet,
								   IN PSP_DEVINFO_DATA  DeviceInfoData,
								   IN DWORD  Property,
								   OUT std::string &strInfo);

	HRESULT GetDeviceDriverInfo (IN HDEVINFO  DeviceInfoSet,
								 IN PSP_DEVINFO_DATA  DeviceInfoData,
								 IN IPnPDeviceDrivers *pDrivers);

	friend class CPnPDevice;
	friend class CPnPDeviceDriver;
};

#endif //__PNPDEVICESINFO_H_
