// Disclaimer and Copyright Information
// HDiskInformation.h : Declaration of the CHDiskInformation
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////

#ifndef __HDISKINFORMATION_H_
#define __HDISKINFORMATION_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CHDiskInformation
class ATL_NO_VTABLE CHDiskInformation : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CHDiskInformation, &CLSID_HDiskInformation>,
	public ISupportErrorInfo,
	public IDispatchImpl<IHDiskInformation, &IID_IHDiskInformation, &LIBID_SYSTEMHDISKLib>
{
public:
	CHDiskInformation()
	{
		m_bInformationObtained = false;
		m_NumberOfPartitions= 0;
		m_pBootable = NULL;
		m_pPartitionLetter = NULL;
		m_pPartitionType = NULL;
		m_pPartitionNumber = NULL;
		m_pPartitionLength = NULL;
		m_pHiddenSectors = NULL;
	}

DECLARE_REGISTRY_RESOURCEID(IDR_HDISKINFORMATION)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CHDiskInformation)
	COM_INTERFACE_ENTRY(IHDiskInformation)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IHDiskInformation
public:
	STDMETHOD(GetHDiskInformation)(/*[out]*/ long *plNumberOfPartitions,
		/*[out]*/ VARIANT *pbstrDriveLetterArr, /*[out]*/ VARIANT *pbBootableArr,
		/*[out]*/ VARIANT *pbstrTypeArr, /*[out]*/ VARIANT *plPartitionNumberArr,
		/*[out]*/ VARIANT *plLengthArr, /*[out]*/ VARIANT *plHiddenSectorsArr);
	STDMETHOD(get_HiddenSectors)(/*[out, retval]*/ VARIANT *pVal);
	STDMETHOD(get_PartitionLength)(/*[out, retval]*/ VARIANT *pVal);
	STDMETHOD(get_PartitionNumber)(/*[out, retval]*/ VARIANT *pVal);
	STDMETHOD(get_PartitionType)(/*[out, retval]*/ VARIANT *pVal);
	STDMETHOD(get_Letter)(/*[out, retval]*/ VARIANT *pVal);
	STDMETHOD(get_Bootable)(/*[out, retval]*/ VARIANT *pVal);
	STDMETHOD(get_NumberOfPartitions)(/*[out, retval]*/ long *pVal);

private:
	bool m_bInformationObtained;

	long m_NumberOfPartitions;
	SAFEARRAY *m_pBootable;
	SAFEARRAY *m_pPartitionLetter;
	SAFEARRAY *m_pPartitionType;
	SAFEARRAY *m_pPartitionNumber;
	SAFEARRAY *m_pPartitionLength;
	SAFEARRAY *m_pHiddenSectors;

	HRESULT GetInformation ();
	HRESULT InitializeSafeArrays ();
	CComBSTR GetPartitionType (DWORD dwType) const;
};

#endif //__HDISKINFORMATION_H_
