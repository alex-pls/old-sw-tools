//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SystemOS.rc
//
#define IDS_PROJNAME                    100
#define IDR_OSINFORMATION               101
#define IDS_WINDOWS_NT                  101
#define IDS_WINDOWS_95                  102
#define IDS_WINDOWS_98                  103
#define IDS_NT_WORKSTATION              104
#define IDS_NT_SERVER                   105
#define IDS_NT_DOMAIN_CONTROLLER        106
#define IDS_NT_40                       107
#define IDS_NT_50                       108
#define IDS_NT_351                      109
#define IDS_WINDOWS_32S                 110
#define IDS_WINDOWS_31                  111
#define IDS_ERR_GETVERSION              112
#define IDS_WINDOWS_2000                113
#define IDS_WIN2K_PROF                  114
#define IDS_WIN2K_SERVER                115
#define IDS_WIN2K_ADV_SERVER            116
#define IDS_WIN2K_DATA_CENETER          117
#define IDS_NT_SP6                      118
#define IDS_WIN2K_DOMAIN_CONTROLLER     119
#define IDS_SUITE_BACKOFFICE            120
#define IDS_SUITE_DATACENTER            121
#define IDS_SUITE_ENTERPRISE            122
#define IDS_SUITE_SMALL_BUSS_SERVER     123
#define IDS_SUITE_SMALLBUSINESS         123
#define IDS_SUITE_SMALLBUSINESS_RESTRICTED 124
#define IDS_SUITE_TERMINAL              125
#define IDS_SUITE_PERSONAL              126
#define IDS_WINDOWS_ME                  127
#define IDS_WINDOWS_WHISTLER            128
#define IDS_WINDOWS_XP                  129
#define IDS_NT_51                       130
#define IDS_WHISTLER_PROF               131
#define IDS_WHISTLER_SERVER             132

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
