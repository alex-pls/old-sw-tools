// Disclaimer and Copyright Information
// OSInformation.h : Declaration of the COSInformation 
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////

#ifndef __OSINFORMATION_H_
#define __OSINFORMATION_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// COSInformation
class ATL_NO_VTABLE COSInformation : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<COSInformation, &CLSID_OSInformation>,
	public ISupportErrorInfo,
	public IDispatchImpl<IOSInformation, &IID_IOSInformation, &LIBID_SYSTEMOSLib>
{
public:
	COSInformation()
	{
		m_bInfoGenerated = false;
		m_bIsWin95 = FALSE;
		m_sBuildNumber = 0;
		m_bstrPlatform = _T ("");
		m_bstrSuites = _T ("");
		m_bstrMinorVersion = _T ("");
		m_bstrServicePack = _T ("");
	}

DECLARE_REGISTRY_RESOURCEID(IDR_OSINFORMATION)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(COSInformation)
	COM_INTERFACE_ENTRY(IOSInformation)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IOSInformation
public:
	STDMETHOD(GetOSInformation)(/*[out]*/long *plBuildNumber,
								/*[out]*/ BSTR *pbstrPlateform,
								/*[out]*/ BSTR *pbstrSuites,
								/*[out]*/ BSTR *pbstrMinorVersion,
								/*[out]*/ BSTR *pbstrServicePack);
	STDMETHOD(get_ServicePack)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(get_MinorVersion)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(get_Platform)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(get_IsWin95)(/*[out, retval]*/ BOOL *pVal);
	STDMETHOD(get_BuildNumber)(/*[out, retval]*/ long *pVal);

	BOOL m_bIsWin95;
	long m_sBuildNumber;
	CComBSTR m_bstrPlatform;
	CComBSTR m_bstrSuites;
	CComBSTR m_bstrMinorVersion;
	CComBSTR m_bstrServicePack;

private:
	bool m_bInfoGenerated;
	HRESULT GetInformation ();
	void MakeErrorDesc (DWORD errCode, LPVOID errorDesc);
};

#endif //__OSINFORMATION_H_
