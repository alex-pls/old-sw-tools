// Disclaimer and Copyright Information
// LocaleInformation.h : Declaration of the CLocaleInformation
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////

// Revision History:
//	2/10/2001	Initial Creation
//

#ifndef __LOCALEINFORMATION_H_
#define __LOCALEINFORMATION_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CLocaleInformation
class ATL_NO_VTABLE CLocaleInformation : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CLocaleInformation, &CLSID_LocaleInformation>,
	public ISupportErrorInfo,
	public IDispatchImpl<ILocaleInformation, &IID_ILocaleInformation, &LIBID_SYSTEMLOCALELib>
{
public:
	CLocaleInformation()
		: m_bInfoGenerated(false)
		, m_sCodePage(0)
		, m_sOEMCodePage(0)
		, m_sCountryCode(0)
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_LOCALEINFORMATION)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CLocaleInformation)
	COM_INTERFACE_ENTRY(ILocaleInformation)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// ILocaleInformation
private:
	HRESULT GetInformation(void);
protected:
	bool m_bInfoGenerated;
public:
	STDMETHODIMP get_CodePage(short* pVal);
	STDMETHODIMP get_CalendarType(BSTR* pVal);
	STDMETHODIMP get_OEMCodePage(short* pVal);
	STDMETHODIMP get_Language(BSTR* pVal);
	STDMETHODIMP get_DateFormat(BSTR* pVal);
	STDMETHODIMP get_Country(BSTR* pVal);
	STDMETHODIMP get_CountryCode(short* pVal);
	STDMETHODIMP get_TimeFormat(BSTR* pVal);
	STDMETHODIMP get_Currency(BSTR* pVal);
	STDMETHODIMP get_TimeFormatSpecifier(BSTR* pVal);
private:
	short m_sCodePage;
	CComBSTR m_bstrCalendarType;
	CComBSTR m_bstrDateFormat;
	short m_sOEMCodePage;
	CComBSTR m_bstrLanguage;
	CComBSTR m_bstrCountry;
	short m_sCountryCode;
	CComBSTR m_bstrTimeFormat;
	CComBSTR m_bstrCurrency;
	CComBSTR m_bstrTimeFormatSpecifier;
};

#endif //__LOCALEINFORMATION_H_
