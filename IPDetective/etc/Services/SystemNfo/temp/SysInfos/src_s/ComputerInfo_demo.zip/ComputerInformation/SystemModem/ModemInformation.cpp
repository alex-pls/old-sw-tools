// ModemInformation.cpp : Implementation of CModemInformation
#include "stdafx.h"
#include "SystemModem.h"
#include "ModemInformation.h"

/////////////////////////////////////////////////////////////////////////////
// CModemInformation

STDMETHODIMP CModemInformation::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IModemInformation
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (::InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

HRESULT CModemInformation::GetInformation(void)
{
	return HRESULT();
}
