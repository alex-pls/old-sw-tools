// Disclaimer and Copyright Information
// OSInfoPage.cpp : Implementation file
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SystemApplication.h"
#include "OSInfoPage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// OSInfoPage property page

IMPLEMENT_DYNCREATE(OSInfoPage, CPropertyPage)

OSInfoPage::OSInfoPage() : CPropertyPage(OSInfoPage::IDD)
{
	//{{AFX_DATA_INIT(OSInfoPage)
	m_bstrPlatform = NULL;
	m_bstrSuites = NULL;
	m_bstrMinorVersion = NULL;
	m_bstrServicePack = NULL;
	m_lBuildNumber = 0;
	//}}AFX_DATA_INIT
}

OSInfoPage::~OSInfoPage()
{
	::SysFreeString (m_bstrPlatform);
	::SysFreeString (m_bstrMinorVersion);
	::SysFreeString (m_bstrServicePack);
	::SysFreeString (m_bstrSuites);
}

void OSInfoPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(OSInfoPage)
	DDX_Control(pDX, IDC_OS_INFO_LIST, m_ListCtrl);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(OSInfoPage, CPropertyPage)
	//{{AFX_MSG_MAP(OSInfoPage)
	ON_NOTIFY(NM_DBLCLK, IDC_OS_INFO_LIST, OnDblclkOsInfoList)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// OSInfoPage message handlers

BOOL OSInfoPage::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();

	if (FAILED (m_pSystemInfo->GetOSInformation (&m_bstrPlatform, &m_bstrSuites, &m_bstrMinorVersion,
		&m_bstrServicePack,&m_lBuildNumber))) {
		return FALSE;
	}
	
	SetListData();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void OSInfoPage::SetListData()
{
	CString tmpStr;
	LV_ITEM item;
	LV_COLUMN leftCol, rightCol;

	leftCol.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	leftCol.fmt = LVCFMT_LEFT;
	leftCol.iSubItem = 0;
	leftCol.cx = 130;
	leftCol.pszText = _T ("Parameter");

	rightCol.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	rightCol.fmt = LVCFMT_LEFT;
	rightCol.iSubItem = 1;
	rightCol.cx = 225;
	rightCol.pszText = _T ("Value");

	m_ListCtrl.InsertColumn (0, &leftCol);
	m_ListCtrl.InsertColumn (1, &rightCol);

	item.mask = LVIF_TEXT;
	item.iItem = 0;
	item.iSubItem = 0;
	item.pszText = _T ("Operating System");
	m_ListCtrl.InsertItem (&item);
	tmpStr = m_bstrPlatform;
	m_ListCtrl.SetItemText (0, 1, tmpStr);

	item.iItem = 1;
	item.pszText = _T ("Minor Version");
	m_ListCtrl.InsertItem (&item);
	tmpStr = m_bstrMinorVersion;
	m_ListCtrl.SetItemText (1, 1, tmpStr);

	item.iItem = 2;
	item.pszText = _T ("Service Pack");
	m_ListCtrl.InsertItem (&item);
	tmpStr = m_bstrServicePack;
	m_ListCtrl.SetItemText (2, 1, tmpStr);

	item.iItem = 3;
	item.pszText = _T ("Build Number");
	m_ListCtrl.InsertItem (&item);

	tmpStr.Format ("%d", m_lBuildNumber);
	m_ListCtrl.SetItemText (3, 1, tmpStr);
}

void OSInfoPage::OnDblclkOsInfoList(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
		
	*pResult = 0;
}
