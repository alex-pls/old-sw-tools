
#pragma warning( disable: 4049 )  /* more than 64k source lines */

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 6.00.0338 */
/* at Tue Apr 17 11:46:01 2001
 */
/* Compiler settings for SystemPnPDevices.idl:
    Oicf, W1, Zp8, env=Win32 (32b run)
    protocol : dce , ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __SystemPnPDevices_h__
#define __SystemPnPDevices_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

/* Forward Declarations */ 

#ifndef __IPnPDevice_FWD_DEFINED__
#define __IPnPDevice_FWD_DEFINED__
typedef interface IPnPDevice IPnPDevice;
#endif 	/* __IPnPDevice_FWD_DEFINED__ */


#ifndef __IPnPDevices_FWD_DEFINED__
#define __IPnPDevices_FWD_DEFINED__
typedef interface IPnPDevices IPnPDevices;
#endif 	/* __IPnPDevices_FWD_DEFINED__ */


#ifndef __IPnPDevicesInfo_FWD_DEFINED__
#define __IPnPDevicesInfo_FWD_DEFINED__
typedef interface IPnPDevicesInfo IPnPDevicesInfo;
#endif 	/* __IPnPDevicesInfo_FWD_DEFINED__ */


#ifndef __IPnPDeviceDriver_FWD_DEFINED__
#define __IPnPDeviceDriver_FWD_DEFINED__
typedef interface IPnPDeviceDriver IPnPDeviceDriver;
#endif 	/* __IPnPDeviceDriver_FWD_DEFINED__ */


#ifndef __IPnPDeviceDrivers_FWD_DEFINED__
#define __IPnPDeviceDrivers_FWD_DEFINED__
typedef interface IPnPDeviceDrivers IPnPDeviceDrivers;
#endif 	/* __IPnPDeviceDrivers_FWD_DEFINED__ */


#ifndef __IPnPDevice_FWD_DEFINED__
#define __IPnPDevice_FWD_DEFINED__
typedef interface IPnPDevice IPnPDevice;
#endif 	/* __IPnPDevice_FWD_DEFINED__ */


#ifndef __IPnPDevices_FWD_DEFINED__
#define __IPnPDevices_FWD_DEFINED__
typedef interface IPnPDevices IPnPDevices;
#endif 	/* __IPnPDevices_FWD_DEFINED__ */


#ifndef __IPnPDeviceDriver_FWD_DEFINED__
#define __IPnPDeviceDriver_FWD_DEFINED__
typedef interface IPnPDeviceDriver IPnPDeviceDriver;
#endif 	/* __IPnPDeviceDriver_FWD_DEFINED__ */


#ifndef __IPnPDeviceDrivers_FWD_DEFINED__
#define __IPnPDeviceDrivers_FWD_DEFINED__
typedef interface IPnPDeviceDrivers IPnPDeviceDrivers;
#endif 	/* __IPnPDeviceDrivers_FWD_DEFINED__ */


#ifndef __PnPDevicesInfo_FWD_DEFINED__
#define __PnPDevicesInfo_FWD_DEFINED__

#ifdef __cplusplus
typedef class PnPDevicesInfo PnPDevicesInfo;
#else
typedef struct PnPDevicesInfo PnPDevicesInfo;
#endif /* __cplusplus */

#endif 	/* __PnPDevicesInfo_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

#ifdef __cplusplus
extern "C"{
#endif 

void * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void * ); 

/* interface __MIDL_itf_SystemPnPDevices_0000 */
/* [local] */ 




extern RPC_IF_HANDLE __MIDL_itf_SystemPnPDevices_0000_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_SystemPnPDevices_0000_v0_0_s_ifspec;

#ifndef __IPnPDevice_INTERFACE_DEFINED__
#define __IPnPDevice_INTERFACE_DEFINED__

/* interface IPnPDevice */
/* [unique][helpstring][nonextensible][dual][uuid][object] */ 


EXTERN_C const IID IID_IPnPDevice;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("6AB72C82-E881-432A-B32F-B828C32E38A0")
    IPnPDevice : public IDispatch
    {
    public:
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Description( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_HardwareID( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ClassGUID( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Driver( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Manufacturer( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_FriendlyName( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_DeviceType( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_VendorID( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ProductID( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ProductRevision( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_SerialNumber( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_DeviceDrivers( 
            /* [retval][out] */ IPnPDeviceDrivers **pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IPnPDeviceVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IPnPDevice * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IPnPDevice * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IPnPDevice * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IPnPDevice * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IPnPDevice * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IPnPDevice * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IPnPDevice * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Description )( 
            IPnPDevice * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_HardwareID )( 
            IPnPDevice * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_ClassGUID )( 
            IPnPDevice * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Driver )( 
            IPnPDevice * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Manufacturer )( 
            IPnPDevice * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_FriendlyName )( 
            IPnPDevice * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_DeviceType )( 
            IPnPDevice * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_VendorID )( 
            IPnPDevice * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_ProductID )( 
            IPnPDevice * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_ProductRevision )( 
            IPnPDevice * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_SerialNumber )( 
            IPnPDevice * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_DeviceDrivers )( 
            IPnPDevice * This,
            /* [retval][out] */ IPnPDeviceDrivers **pVal);
        
        END_INTERFACE
    } IPnPDeviceVtbl;

    interface IPnPDevice
    {
        CONST_VTBL struct IPnPDeviceVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IPnPDevice_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IPnPDevice_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IPnPDevice_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IPnPDevice_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IPnPDevice_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IPnPDevice_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IPnPDevice_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IPnPDevice_get_Description(This,pVal)	\
    (This)->lpVtbl -> get_Description(This,pVal)

#define IPnPDevice_get_HardwareID(This,pVal)	\
    (This)->lpVtbl -> get_HardwareID(This,pVal)

#define IPnPDevice_get_ClassGUID(This,pVal)	\
    (This)->lpVtbl -> get_ClassGUID(This,pVal)

#define IPnPDevice_get_Driver(This,pVal)	\
    (This)->lpVtbl -> get_Driver(This,pVal)

#define IPnPDevice_get_Manufacturer(This,pVal)	\
    (This)->lpVtbl -> get_Manufacturer(This,pVal)

#define IPnPDevice_get_FriendlyName(This,pVal)	\
    (This)->lpVtbl -> get_FriendlyName(This,pVal)

#define IPnPDevice_get_DeviceType(This,pVal)	\
    (This)->lpVtbl -> get_DeviceType(This,pVal)

#define IPnPDevice_get_VendorID(This,pVal)	\
    (This)->lpVtbl -> get_VendorID(This,pVal)

#define IPnPDevice_get_ProductID(This,pVal)	\
    (This)->lpVtbl -> get_ProductID(This,pVal)

#define IPnPDevice_get_ProductRevision(This,pVal)	\
    (This)->lpVtbl -> get_ProductRevision(This,pVal)

#define IPnPDevice_get_SerialNumber(This,pVal)	\
    (This)->lpVtbl -> get_SerialNumber(This,pVal)

#define IPnPDevice_get_DeviceDrivers(This,pVal)	\
    (This)->lpVtbl -> get_DeviceDrivers(This,pVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IPnPDevice_get_Description_Proxy( 
    IPnPDevice * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IPnPDevice_get_Description_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IPnPDevice_get_HardwareID_Proxy( 
    IPnPDevice * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IPnPDevice_get_HardwareID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IPnPDevice_get_ClassGUID_Proxy( 
    IPnPDevice * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IPnPDevice_get_ClassGUID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IPnPDevice_get_Driver_Proxy( 
    IPnPDevice * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IPnPDevice_get_Driver_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IPnPDevice_get_Manufacturer_Proxy( 
    IPnPDevice * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IPnPDevice_get_Manufacturer_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IPnPDevice_get_FriendlyName_Proxy( 
    IPnPDevice * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IPnPDevice_get_FriendlyName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IPnPDevice_get_DeviceType_Proxy( 
    IPnPDevice * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IPnPDevice_get_DeviceType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IPnPDevice_get_VendorID_Proxy( 
    IPnPDevice * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IPnPDevice_get_VendorID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IPnPDevice_get_ProductID_Proxy( 
    IPnPDevice * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IPnPDevice_get_ProductID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IPnPDevice_get_ProductRevision_Proxy( 
    IPnPDevice * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IPnPDevice_get_ProductRevision_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IPnPDevice_get_SerialNumber_Proxy( 
    IPnPDevice * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IPnPDevice_get_SerialNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IPnPDevice_get_DeviceDrivers_Proxy( 
    IPnPDevice * This,
    /* [retval][out] */ IPnPDeviceDrivers **pVal);


void __RPC_STUB IPnPDevice_get_DeviceDrivers_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IPnPDevice_INTERFACE_DEFINED__ */


#ifndef __IPnPDevices_INTERFACE_DEFINED__
#define __IPnPDevices_INTERFACE_DEFINED__

/* interface IPnPDevices */
/* [unique][helpstring][nonextensible][oleautomation][uuid][object] */ 


EXTERN_C const IID IID_IPnPDevices;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("E1B4025C-DCB0-4C42-9057-B06744C6D1BC")
    IPnPDevices : public IUnknown
    {
    public:
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_Item( 
            /* [in] */ long ItemIndex,
            /* [retval][out] */ IPnPDevice **pVal) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get__NewEnum( 
            /* [retval][out] */ IUnknown **pVal) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_Count( 
            /* [retval][out] */ LONG *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Add( 
            /* [in] */ IPnPDevice *Device) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Clear( void) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IPnPDevicesVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IPnPDevices * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IPnPDevices * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IPnPDevices * This);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Item )( 
            IPnPDevices * This,
            /* [in] */ long ItemIndex,
            /* [retval][out] */ IPnPDevice **pVal);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get__NewEnum )( 
            IPnPDevices * This,
            /* [retval][out] */ IUnknown **pVal);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Count )( 
            IPnPDevices * This,
            /* [retval][out] */ LONG *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Add )( 
            IPnPDevices * This,
            /* [in] */ IPnPDevice *Device);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Clear )( 
            IPnPDevices * This);
        
        END_INTERFACE
    } IPnPDevicesVtbl;

    interface IPnPDevices
    {
        CONST_VTBL struct IPnPDevicesVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IPnPDevices_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IPnPDevices_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IPnPDevices_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IPnPDevices_get_Item(This,ItemIndex,pVal)	\
    (This)->lpVtbl -> get_Item(This,ItemIndex,pVal)

#define IPnPDevices_get__NewEnum(This,pVal)	\
    (This)->lpVtbl -> get__NewEnum(This,pVal)

#define IPnPDevices_get_Count(This,pVal)	\
    (This)->lpVtbl -> get_Count(This,pVal)

#define IPnPDevices_Add(This,Device)	\
    (This)->lpVtbl -> Add(This,Device)

#define IPnPDevices_Clear(This)	\
    (This)->lpVtbl -> Clear(This)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IPnPDevices_get_Item_Proxy( 
    IPnPDevices * This,
    /* [in] */ long ItemIndex,
    /* [retval][out] */ IPnPDevice **pVal);


void __RPC_STUB IPnPDevices_get_Item_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IPnPDevices_get__NewEnum_Proxy( 
    IPnPDevices * This,
    /* [retval][out] */ IUnknown **pVal);


void __RPC_STUB IPnPDevices_get__NewEnum_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IPnPDevices_get_Count_Proxy( 
    IPnPDevices * This,
    /* [retval][out] */ LONG *pVal);


void __RPC_STUB IPnPDevices_get_Count_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPnPDevices_Add_Proxy( 
    IPnPDevices * This,
    /* [in] */ IPnPDevice *Device);


void __RPC_STUB IPnPDevices_Add_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPnPDevices_Clear_Proxy( 
    IPnPDevices * This);


void __RPC_STUB IPnPDevices_Clear_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IPnPDevices_INTERFACE_DEFINED__ */


#ifndef __IPnPDevicesInfo_INTERFACE_DEFINED__
#define __IPnPDevicesInfo_INTERFACE_DEFINED__

/* interface IPnPDevicesInfo */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IPnPDevicesInfo;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("1B203F52-A865-4792-91C3-18AF456DB836")
    IPnPDevicesInfo : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetPnpDevices( 
            /* [out] */ IPnPDevices **pDevices) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IPnPDevicesInfoVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IPnPDevicesInfo * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IPnPDevicesInfo * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IPnPDevicesInfo * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IPnPDevicesInfo * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IPnPDevicesInfo * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IPnPDevicesInfo * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IPnPDevicesInfo * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetPnpDevices )( 
            IPnPDevicesInfo * This,
            /* [out] */ IPnPDevices **pDevices);
        
        END_INTERFACE
    } IPnPDevicesInfoVtbl;

    interface IPnPDevicesInfo
    {
        CONST_VTBL struct IPnPDevicesInfoVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IPnPDevicesInfo_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IPnPDevicesInfo_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IPnPDevicesInfo_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IPnPDevicesInfo_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IPnPDevicesInfo_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IPnPDevicesInfo_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IPnPDevicesInfo_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IPnPDevicesInfo_GetPnpDevices(This,pDevices)	\
    (This)->lpVtbl -> GetPnpDevices(This,pDevices)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPnPDevicesInfo_GetPnpDevices_Proxy( 
    IPnPDevicesInfo * This,
    /* [out] */ IPnPDevices **pDevices);


void __RPC_STUB IPnPDevicesInfo_GetPnpDevices_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IPnPDevicesInfo_INTERFACE_DEFINED__ */


#ifndef __IPnPDeviceDriver_INTERFACE_DEFINED__
#define __IPnPDeviceDriver_INTERFACE_DEFINED__

/* interface IPnPDeviceDriver */
/* [unique][helpstring][nonextensible][dual][uuid][object] */ 


EXTERN_C const IID IID_IPnPDeviceDriver;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("B7A2CDEE-A28C-4B61-8A2B-69B27EDBC59E")
    IPnPDeviceDriver : public IDispatch
    {
    public:
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Type( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Description( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Manufacturer( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Provider( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Date( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Version( 
            /* [retval][out] */ long *pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IPnPDeviceDriverVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IPnPDeviceDriver * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IPnPDeviceDriver * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IPnPDeviceDriver * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IPnPDeviceDriver * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IPnPDeviceDriver * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IPnPDeviceDriver * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IPnPDeviceDriver * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Type )( 
            IPnPDeviceDriver * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Description )( 
            IPnPDeviceDriver * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Manufacturer )( 
            IPnPDeviceDriver * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Provider )( 
            IPnPDeviceDriver * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Date )( 
            IPnPDeviceDriver * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Version )( 
            IPnPDeviceDriver * This,
            /* [retval][out] */ long *pVal);
        
        END_INTERFACE
    } IPnPDeviceDriverVtbl;

    interface IPnPDeviceDriver
    {
        CONST_VTBL struct IPnPDeviceDriverVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IPnPDeviceDriver_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IPnPDeviceDriver_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IPnPDeviceDriver_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IPnPDeviceDriver_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IPnPDeviceDriver_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IPnPDeviceDriver_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IPnPDeviceDriver_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IPnPDeviceDriver_get_Type(This,pVal)	\
    (This)->lpVtbl -> get_Type(This,pVal)

#define IPnPDeviceDriver_get_Description(This,pVal)	\
    (This)->lpVtbl -> get_Description(This,pVal)

#define IPnPDeviceDriver_get_Manufacturer(This,pVal)	\
    (This)->lpVtbl -> get_Manufacturer(This,pVal)

#define IPnPDeviceDriver_get_Provider(This,pVal)	\
    (This)->lpVtbl -> get_Provider(This,pVal)

#define IPnPDeviceDriver_get_Date(This,pVal)	\
    (This)->lpVtbl -> get_Date(This,pVal)

#define IPnPDeviceDriver_get_Version(This,pVal)	\
    (This)->lpVtbl -> get_Version(This,pVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IPnPDeviceDriver_get_Type_Proxy( 
    IPnPDeviceDriver * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IPnPDeviceDriver_get_Type_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IPnPDeviceDriver_get_Description_Proxy( 
    IPnPDeviceDriver * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IPnPDeviceDriver_get_Description_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IPnPDeviceDriver_get_Manufacturer_Proxy( 
    IPnPDeviceDriver * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IPnPDeviceDriver_get_Manufacturer_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IPnPDeviceDriver_get_Provider_Proxy( 
    IPnPDeviceDriver * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IPnPDeviceDriver_get_Provider_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IPnPDeviceDriver_get_Date_Proxy( 
    IPnPDeviceDriver * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IPnPDeviceDriver_get_Date_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IPnPDeviceDriver_get_Version_Proxy( 
    IPnPDeviceDriver * This,
    /* [retval][out] */ long *pVal);


void __RPC_STUB IPnPDeviceDriver_get_Version_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IPnPDeviceDriver_INTERFACE_DEFINED__ */


#ifndef __IPnPDeviceDrivers_INTERFACE_DEFINED__
#define __IPnPDeviceDrivers_INTERFACE_DEFINED__

/* interface IPnPDeviceDrivers */
/* [unique][helpstring][nonextensible][dual][uuid][object] */ 


EXTERN_C const IID IID_IPnPDeviceDrivers;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("13E58B92-463D-4533-B73C-3A3568D186C9")
    IPnPDeviceDrivers : public IDispatch
    {
    public:
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_Item( 
            /* [in] */ long ItemIndex,
            /* [retval][out] */ IPnPDeviceDriver **pVal) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get__NewEnum( 
            /* [retval][out] */ IUnknown **pVal) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_Count( 
            /* [retval][out] */ LONG *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Add( 
            /* [in] */ IPnPDeviceDriver *Device) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Clear( void) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IPnPDeviceDriversVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IPnPDeviceDrivers * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IPnPDeviceDrivers * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IPnPDeviceDrivers * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IPnPDeviceDrivers * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IPnPDeviceDrivers * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IPnPDeviceDrivers * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IPnPDeviceDrivers * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Item )( 
            IPnPDeviceDrivers * This,
            /* [in] */ long ItemIndex,
            /* [retval][out] */ IPnPDeviceDriver **pVal);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get__NewEnum )( 
            IPnPDeviceDrivers * This,
            /* [retval][out] */ IUnknown **pVal);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Count )( 
            IPnPDeviceDrivers * This,
            /* [retval][out] */ LONG *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Add )( 
            IPnPDeviceDrivers * This,
            /* [in] */ IPnPDeviceDriver *Device);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Clear )( 
            IPnPDeviceDrivers * This);
        
        END_INTERFACE
    } IPnPDeviceDriversVtbl;

    interface IPnPDeviceDrivers
    {
        CONST_VTBL struct IPnPDeviceDriversVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IPnPDeviceDrivers_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IPnPDeviceDrivers_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IPnPDeviceDrivers_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IPnPDeviceDrivers_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IPnPDeviceDrivers_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IPnPDeviceDrivers_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IPnPDeviceDrivers_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IPnPDeviceDrivers_get_Item(This,ItemIndex,pVal)	\
    (This)->lpVtbl -> get_Item(This,ItemIndex,pVal)

#define IPnPDeviceDrivers_get__NewEnum(This,pVal)	\
    (This)->lpVtbl -> get__NewEnum(This,pVal)

#define IPnPDeviceDrivers_get_Count(This,pVal)	\
    (This)->lpVtbl -> get_Count(This,pVal)

#define IPnPDeviceDrivers_Add(This,Device)	\
    (This)->lpVtbl -> Add(This,Device)

#define IPnPDeviceDrivers_Clear(This)	\
    (This)->lpVtbl -> Clear(This)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IPnPDeviceDrivers_get_Item_Proxy( 
    IPnPDeviceDrivers * This,
    /* [in] */ long ItemIndex,
    /* [retval][out] */ IPnPDeviceDriver **pVal);


void __RPC_STUB IPnPDeviceDrivers_get_Item_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IPnPDeviceDrivers_get__NewEnum_Proxy( 
    IPnPDeviceDrivers * This,
    /* [retval][out] */ IUnknown **pVal);


void __RPC_STUB IPnPDeviceDrivers_get__NewEnum_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IPnPDeviceDrivers_get_Count_Proxy( 
    IPnPDeviceDrivers * This,
    /* [retval][out] */ LONG *pVal);


void __RPC_STUB IPnPDeviceDrivers_get_Count_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPnPDeviceDrivers_Add_Proxy( 
    IPnPDeviceDrivers * This,
    /* [in] */ IPnPDeviceDriver *Device);


void __RPC_STUB IPnPDeviceDrivers_Add_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPnPDeviceDrivers_Clear_Proxy( 
    IPnPDeviceDrivers * This);


void __RPC_STUB IPnPDeviceDrivers_Clear_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IPnPDeviceDrivers_INTERFACE_DEFINED__ */



#ifndef __SYSTEMPNPDEVICESLib_LIBRARY_DEFINED__
#define __SYSTEMPNPDEVICESLib_LIBRARY_DEFINED__

/* library SYSTEMPNPDEVICESLib */
/* [helpstring][version][uuid] */ 






EXTERN_C const IID LIBID_SYSTEMPNPDEVICESLib;

EXTERN_C const CLSID CLSID_PnPDevicesInfo;

#ifdef __cplusplus

class DECLSPEC_UUID("0F9C4A57-BEDB-4F99-ACBB-0FD030F5EAD9")
PnPDevicesInfo;
#endif
#endif /* __SYSTEMPNPDEVICESLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long *, unsigned long            , BSTR * ); 
unsigned char * __RPC_USER  BSTR_UserMarshal(  unsigned long *, unsigned char *, BSTR * ); 
unsigned char * __RPC_USER  BSTR_UserUnmarshal(unsigned long *, unsigned char *, BSTR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long *, BSTR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


