// Disclaimer and Copyright Information
// StorageInfoPage.cpp : Implementation file
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SystemApplication.h"
#include "StorageInfoPage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// StorageInfoPage property page

IMPLEMENT_DYNCREATE(StorageInfoPage, CPropertyPage)

StorageInfoPage::StorageInfoPage() : CPropertyPage(StorageInfoPage::IDD)
{
	//{{AFX_DATA_INIT(StorageInfoPage)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

StorageInfoPage::~StorageInfoPage()
{
}

void StorageInfoPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(StorageInfoPage)
	DDX_Control(pDX, IDC_STORAGE_INFO_LIST, m_ListCtrl);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(StorageInfoPage, CPropertyPage)
	//{{AFX_MSG_MAP(StorageInfoPage)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// StorageInfoPage message handlers

BOOL StorageInfoPage::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	if (FAILED (GetInformation ())) {
		return TRUE;
	}

	SetListData();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

HRESULT StorageInfoPage::GetInformation ()
{
	VARIANT bstrDriveLetterArr;
	VARIANT bReadyArr;
	VARIANT bstrLabelArr;
	VARIANT bSupportLongNameArr;
	VARIANT bstrFileSystemArr;
	VARIANT bstrMediaTypeArr;
	VARIANT lTotalSpaceArr;
	VARIANT lFreeSpaceUserArr;
	VARIANT lFreeSpaceTotalArr;


	if (FAILED (m_pSystemInfo->GetStorageMediaInformation (&m_lNumberOfDrives, &bReadyArr,
		&bstrDriveLetterArr, &bstrLabelArr, &bSupportLongNameArr, &bstrFileSystemArr,
		&bstrMediaTypeArr, &lTotalSpaceArr, &lFreeSpaceUserArr, &lFreeSpaceTotalArr))) {
		return E_FAIL;
	}

	if (!(bstrDriveLetterArr.vt & VT_BSTR)) {
		return DISP_E_TYPEMISMATCH;
	}

	if (!(bstrDriveLetterArr.vt & VT_ARRAY)) {
		return DISP_E_TYPEMISMATCH;
	}

	if (bstrDriveLetterArr.vt & VT_BYREF) {
		m_pbstrDriveLetterArr = * (bstrDriveLetterArr.pparray);
	}
	else {
		m_pbstrDriveLetterArr = bstrDriveLetterArr.parray;
	}

	if (!(bstrLabelArr.vt & VT_BSTR)) {
		return DISP_E_TYPEMISMATCH;
	}

	if (!(bstrLabelArr.vt & VT_ARRAY)) {
		return DISP_E_TYPEMISMATCH;
	}

	if (bstrLabelArr.vt & VT_BYREF) {
		m_pbstrLabelArr = * (bstrLabelArr.pparray);
	}
	else {
		m_pbstrLabelArr = bstrLabelArr.parray;
	}

	if (!(bstrMediaTypeArr.vt & VT_BSTR)) {
		return DISP_E_TYPEMISMATCH;
	}

	if (!(bstrMediaTypeArr.vt & VT_ARRAY)) {
		return DISP_E_TYPEMISMATCH;
	}

	if (bstrMediaTypeArr.vt & VT_BYREF) {
		m_pbstrMediaTypeArr = * (bstrMediaTypeArr.pparray);
	}
	else {
		m_pbstrMediaTypeArr = bstrMediaTypeArr.parray;
	}

	if (!(bstrFileSystemArr.vt & VT_BSTR)) {
		return DISP_E_TYPEMISMATCH;
	}

	if (!(bstrFileSystemArr.vt & VT_ARRAY)) {
		return DISP_E_TYPEMISMATCH;
	}

	if (bstrFileSystemArr.vt & VT_BYREF) {
		m_pbstrFileSystemArr = * (bstrFileSystemArr.pparray);
	}
	else {
		m_pbstrFileSystemArr = bstrFileSystemArr.parray;
	}

	if (!(bReadyArr.vt & VT_BOOL)) {
		return DISP_E_TYPEMISMATCH;
	}

	if (!(bReadyArr.vt & VT_ARRAY)) {
		return DISP_E_TYPEMISMATCH;
	}

	if (bReadyArr.vt & VT_BYREF) {
		m_pbReadyArr = * (bReadyArr.pparray);
	}
	else {
		m_pbReadyArr = bReadyArr.parray;
	}

	if (!(bSupportLongNameArr.vt & VT_BOOL)) {
		return DISP_E_TYPEMISMATCH;
	}

	if (!(bSupportLongNameArr.vt & VT_ARRAY)) {
		return DISP_E_TYPEMISMATCH;
	}

	if (bSupportLongNameArr.vt & VT_BYREF) {
		m_pbSupportLongNameArr = * (bSupportLongNameArr.pparray);
	}
	else {
		m_pbSupportLongNameArr = bSupportLongNameArr.parray;
	}

	if (!(lTotalSpaceArr.vt & VT_R8)) {
		return DISP_E_TYPEMISMATCH;
	}

	if (!(lTotalSpaceArr.vt & VT_ARRAY)) {
		return DISP_E_TYPEMISMATCH;
	}

	if (lTotalSpaceArr.vt & VT_BYREF) {
		m_plTotalSpaceArr = * (lTotalSpaceArr.pparray);
	}
	else {
		m_plTotalSpaceArr = lTotalSpaceArr.parray;
	}

	if (!(lFreeSpaceUserArr.vt & VT_R8)) {
		return DISP_E_TYPEMISMATCH;
	}

	if (!(lFreeSpaceUserArr.vt & VT_ARRAY)) {
		return DISP_E_TYPEMISMATCH;
	}

	if (lFreeSpaceUserArr.vt & VT_BYREF) {
		m_plFreeSpaceUserArr = * (lFreeSpaceUserArr.pparray);
	}
	else {
		m_plFreeSpaceUserArr = lFreeSpaceUserArr.parray;
	}

	if (!(lFreeSpaceTotalArr.vt & VT_R8)) {
		return DISP_E_TYPEMISMATCH;
	}

	if (!(lFreeSpaceTotalArr.vt & VT_ARRAY)) {
		return DISP_E_TYPEMISMATCH;
	}

	if (lFreeSpaceTotalArr.vt & VT_BYREF) {
		m_plFreeSpaceTotalArr = * (lFreeSpaceTotalArr.pparray);
	}
	else {
		m_plFreeSpaceTotalArr = lFreeSpaceTotalArr.parray;
	}

	return S_OK;
}

void StorageInfoPage::SetListData()
{
	CString tmpStr;
	double var;
	double space;
	VARIANT_BOOL bStatus;
	BSTR tmpBstr;
	long lLBound, lUBound ;
	int i = 0;
	LV_ITEM item;
	LV_COLUMN col1, col3, col4, col5, col6, col7, col8, col9, col2;

	col1.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	col1.fmt = LVCFMT_LEFT;
	col1.iSubItem = 0;
	col1.cx = 40;
	col1.pszText = _T ("Drive");

	col2.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	col2.fmt = LVCFMT_LEFT;
	col2.iSubItem = 1;
	col2.cx = 65;
	col2.pszText = _T ("Ready");

	col3.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	col3.fmt = LVCFMT_LEFT;
	col3.iSubItem = 2;
	col3.cx = 65;
	col3.pszText = _T ("Label");

	col4.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	col4.fmt = LVCFMT_LEFT;
	col4.iSubItem = 3;
	col4.cx = 70;
	col4.pszText = _T ("File System");

	col5.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	col5.fmt = LVCFMT_LEFT;
	col5.iSubItem = 4;
	col5.cx = 75;
	col5.pszText = _T ("Long Names");

	col6.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	col6.fmt = LVCFMT_LEFT;
	col6.iSubItem = 5;
	col6.cx = 70;
	col6.pszText = _T ("Type");

	col7.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	col7.fmt = LVCFMT_LEFT;
	col7.iSubItem = 6;
	col7.cx = 85;
	col7.pszText = _T ("Total Space");

	col8.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	col8.fmt = LVCFMT_LEFT;
	col8.iSubItem = 7;
	col8.cx = 85;
	col8.pszText = _T ("Free Space (U)");

	col9.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	col9.fmt = LVCFMT_LEFT;
	col9.iSubItem = 8;
	col9.cx = 85;
	col9.pszText = _T ("Free Space (T)");

	m_ListCtrl.InsertColumn (0, &col1);
	m_ListCtrl.InsertColumn (1, &col2);
	m_ListCtrl.InsertColumn (2, &col3);
	m_ListCtrl.InsertColumn (3, &col4);
	m_ListCtrl.InsertColumn (4, &col5);
	m_ListCtrl.InsertColumn (5, &col6);
	m_ListCtrl.InsertColumn (6, &col7);
	m_ListCtrl.InsertColumn (7, &col8);
	m_ListCtrl.InsertColumn (8, &col9);

	// Get the uprrer and lower bound of arrays. And assume it will be same for all arrays.

	SafeArrayGetLBound (m_pbstrDriveLetterArr, 1, &lLBound);
	SafeArrayGetUBound (m_pbstrDriveLetterArr, 1, &lUBound);

	for (i = lLBound; i <= lUBound; i++) {
		item.mask = LVIF_TEXT;
		item.iItem = i;
		item.iSubItem = 0;
		item.pszText = _T (" ");
		m_ListCtrl.InsertItem (&item);

		SafeArrayGetElement (m_pbstrDriveLetterArr, (long *) &i, &tmpBstr);
		m_ListCtrl.SetItemText (i, 0, CString (tmpBstr));

		SafeArrayGetElement (m_pbReadyArr, (long *) &i, &bStatus);
		tmpStr = (bStatus) ? _T ("YES") : _T ("NO");
		m_ListCtrl.SetItemText (i, 1, tmpStr);

		// If drive is not ready, then no need to show rest of the information.
		if (!bStatus) {
			continue;
		}

		SafeArrayGetElement (m_pbstrLabelArr, (long *) &i, &tmpBstr);
		m_ListCtrl.SetItemText (i, 2, CString (tmpBstr));

		SafeArrayGetElement (m_pbstrFileSystemArr, (long *) &i, &tmpBstr);
		m_ListCtrl.SetItemText (i, 3, CString (tmpBstr));

		SafeArrayGetElement (m_pbSupportLongNameArr, (long *) &i, &bStatus);
		tmpStr = (bStatus) ? _T ("YES") : _T ("NO");
		m_ListCtrl.SetItemText (i, 4, tmpStr);

		SafeArrayGetElement (m_pbstrMediaTypeArr, (long *) &i, &tmpBstr);
		m_ListCtrl.SetItemText (i, 5, CString (tmpBstr));

		SafeArrayGetElement (m_plTotalSpaceArr, (long *) &i, &space);
		var =  space / (1024 * 1024);

		if (var / 1000 < 0.5) {
			tmpStr.Format ("%7.2lf", var);
			tmpStr += _T (" MB");
		}
		else {
			var /= 1000;
			tmpStr.Format ("%5.2lf", var);
			tmpStr += _T (" GB");
		}

		tmpStr.TrimLeft ();
		m_ListCtrl.SetItemText (i, 6, tmpStr);

		SafeArrayGetElement (m_plFreeSpaceUserArr, (long *) &i, &space);
		var =  space / (1024 * 1024);

		if (var / 1000 < 0.5) {
			tmpStr.Format ("%7.2lf", var);
			tmpStr += _T (" MB");
		}
		else {
			var /= 1000;
			tmpStr.Format ("%5.2lf", var);
			tmpStr += _T (" GB");
		}

		tmpStr.TrimLeft ();
		m_ListCtrl.SetItemText (i, 7, tmpStr);

		SafeArrayGetElement (m_plFreeSpaceTotalArr, (long *) &i, &space);
		var =  space / (1024 * 1024);

		if (var / 1000 < 0.5) {
			tmpStr.Format ("%7.2lf", var);
			tmpStr += _T (" MB");
		}
		else {
			var /= 1000;
			tmpStr.Format ("%5.2lf", var);
			tmpStr += _T (" GB");
		}

		tmpStr.TrimLeft ();
		m_ListCtrl.SetItemText (i, 8, tmpStr);

	}
}