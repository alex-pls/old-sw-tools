// PnPDevices.h : Declaration of the CPnPDevices

#pragma once
#include "resource.h"       // main symbols
#include <vector>
#include <atlbase.h>

// CPnPDevices

class ATL_NO_VTABLE CPnPDevices : 
	public CComObjectRootEx<CComSingleThreadModel>,
//	public CComCoClass<CPnPDevices, &CLSID_PnPDevices>,
	public ISupportErrorInfo,
	public IPnPDevices
{
public:
	CPnPDevices()
	{
	}

//DECLARE_REGISTRY_RESOURCEID(IDR_PNPDEVICES)


BEGIN_COM_MAP(CPnPDevices)
	COM_INTERFACE_ENTRY(IPnPDevices)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		m_List.clear ();
		return S_OK;
	}
	
	void FinalRelease() 
	{
	}

public:

	STDMETHODIMP get_Item(long lItemIndex, IPnPDevice** pVal);
	STDMETHODIMP get__NewEnum(IUnknown** pVal);
	STDMETHODIMP get_Count(LONG* pVal);

private:
	std::vector<CAdapt < CComVariant > > m_List;
public:
	STDMETHODIMP Add(IPnPDevice *pDevice);
	STDMETHODIMP Clear(void);
};

//OBJECT_ENTRY_AUTO(__uuidof(PnPDevices), CPnPDevices)
