#if !defined(AFX_PNPDEVICEINFODLG_H__A368EF55_E81C_4C1E_A278_460A410FFD72__INCLUDED_)
#define AFX_PNPDEVICEINFODLG_H__A368EF55_E81C_4C1E_A278_460A410FFD72__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PnPDeviceInfoDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// PnPDeviceInfoDlg dialog

class PnPDeviceInfoDlg : public CDialog
{
// Construction
public:
	PnPDeviceInfoDlg(LV_ITEM *pItem, CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(PnPDeviceInfoDlg)
	enum { IDD = IDD_DEVICEINFO_DIALOG };
	CRichEditCtrl	m_wndDetailsEdit;
	CListBox	m_wndDriversList;
	CEdit	m_wndClassGUID;
	CEdit	m_wndVendor;
	CEdit	m_wndSerialNumber;
	CEdit	m_wndType;
	CEdit	m_wndDescription;
	CString	m_strDescription;
	CString	m_strType;
	CString	m_strClassGUID;
	CString	m_strSerialNumber;
	CString	m_strVendor;
	CString	m_strDetails;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(PnPDeviceInfoDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(PnPDeviceInfoDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	LV_ITEM *m_pListItem;
	void InitControlsData ();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PNPDEVICEINFODLG_H__A368EF55_E81C_4C1E_A278_460A410FFD72__INCLUDED_)
