// Disclaimer and Copyright Information
// AppOptionsDlg.h : 
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////
//

//	Revision History:
//	2/12/2001	Initial Creation
//

#pragma once


// CAppOptionsDlg dialog

class CAppOptionsDlg : public CDialog
{
	DECLARE_DYNAMIC(CAppOptionsDlg)

public:
	CAppOptionsDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CAppOptionsDlg();

// Dialog Data
	enum { IDD = IDD_OPTIONS_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
	DWORD m_dwOptionsMask;
public:

	DWORD GetOptionsMask(void)
	{
		return m_dwOptionsMask;
	}

	DWORD SetOptionsMask(DWORD dwNewMask)
	{
		DWORD dwOldMask = m_dwOptionsMask;
		m_dwOptionsMask = dwNewMask;
		return dwOldMask;
	}
};
