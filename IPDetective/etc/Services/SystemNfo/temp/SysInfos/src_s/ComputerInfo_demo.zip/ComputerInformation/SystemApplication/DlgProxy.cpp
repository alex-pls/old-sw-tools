// Disclaimer and Copyright Information
// DlgProxy.cpp : Implementation file
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SystemApplication.h"
#include "DlgProxy.h"
#include "SystemApplicationDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSystemApplicationDlgAutoProxy

IMPLEMENT_DYNCREATE(CSystemApplicationDlgAutoProxy, CCmdTarget)

CSystemApplicationDlgAutoProxy::CSystemApplicationDlgAutoProxy()
{
	EnableAutomation();
	
	// To keep the application running as long as an automation 
	//	object is active, the constructor calls AfxOleLockApp.
	AfxOleLockApp();

	// Get access to the dialog through the application's
	//  main window pointer.  Set the proxy's internal pointer
	//  to point to the dialog, and set the dialog's back pointer to
	//  this proxy.
	ASSERT (AfxGetApp()->m_pMainWnd != NULL);
	ASSERT_VALID (AfxGetApp()->m_pMainWnd);
	ASSERT_KINDOF(CSystemApplicationDlg, AfxGetApp()->m_pMainWnd);
	m_pDialog = (CSystemApplicationDlg*) AfxGetApp()->m_pMainWnd;
	m_pDialog->m_pAutoProxy = this;
}

CSystemApplicationDlgAutoProxy::~CSystemApplicationDlgAutoProxy()
{
	// To terminate the application when all objects created with
	// 	with automation, the destructor calls AfxOleUnlockApp.
	//  Among other things, this will destroy the main dialog
	if (m_pDialog != NULL)
		m_pDialog->m_pAutoProxy = NULL;
	AfxOleUnlockApp();
}

void CSystemApplicationDlgAutoProxy::OnFinalRelease()
{
	// When the last reference for an automation object is released
	// OnFinalRelease is called.  The base class will automatically
	// deletes the object.  Add additional cleanup required for your
	// object before calling the base class.

	CCmdTarget::OnFinalRelease();
}

BEGIN_MESSAGE_MAP(CSystemApplicationDlgAutoProxy, CCmdTarget)
	//{{AFX_MSG_MAP(CSystemApplicationDlgAutoProxy)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(CSystemApplicationDlgAutoProxy, CCmdTarget)
	//{{AFX_DISPATCH_MAP(CSystemApplicationDlgAutoProxy)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()

// Note: we add support for IID_ISystemApplication to support typesafe binding
//  from VBA.  This IID must match the GUID that is attached to the 
//  dispinterface in the .ODL file.

// {D9554555-CE91-11D2-8C81-000000000000}
static const IID IID_ISystemApplication =
{ 0xd9554555, 0xce91, 0x11d2, { 0x8c, 0x81, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0 } };

BEGIN_INTERFACE_MAP(CSystemApplicationDlgAutoProxy, CCmdTarget)
	INTERFACE_PART(CSystemApplicationDlgAutoProxy, IID_ISystemApplication, Dispatch)
END_INTERFACE_MAP()

// The IMPLEMENT_OLECREATE2 macro is defined in StdAfx.h of this project
// {D9554553-CE91-11D2-8C81-000000000000}
IMPLEMENT_OLECREATE2(CSystemApplicationDlgAutoProxy, "SystemApplication.Application", 0xd9554553, 0xce91, 0x11d2, 0x8c, 0x81, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0)

/////////////////////////////////////////////////////////////////////////////
// CSystemApplicationDlgAutoProxy message handlers
