#pragma once


// HWDevicesInfoPage dialog

class HWDevicesInfoPage : public CPropertyPage
{
	DECLARE_DYNAMIC(HWDevicesInfoPage)

public:
	HWDevicesInfoPage();
	virtual ~HWDevicesInfoPage();

// Dialog Data
	enum { IDD = IDD_HWDEVICESINFOPAGE };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	BOOL OnInitDialog(void);
	CListCtrl m_wndListCtl;

	void SetSystemInfo(ISystemInformation *pSystemInfo = NULL, CFile *pFile = NULL)
	{
		ASSERT (pSystemInfo != NULL);
		m_pSystemInfo = pSystemInfo;
		m_pOutputFile = pFile;
	}
private:
	CFile *m_pOutputFile;
	ISystemInformation *m_pSystemInfo;
	HRESULT GetInformation(void);
};
