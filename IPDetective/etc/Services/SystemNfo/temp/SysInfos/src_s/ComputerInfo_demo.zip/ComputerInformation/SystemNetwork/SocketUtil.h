#pragma once
#include <string>

using namespace std;

class CSocketUtil
{
public:
	CSocketUtil(void);
	virtual ~CSocketUtil(void);
	bool Startup(void);
	bool ShutDown(void);
protected:
	long m_nRefCount;
public:
	bool GetIPAddress(const string& strHost, string& strAddress);
protected:
	// Windows Socket Version Used
	string m_strWSVersion;
	// Highest Version Of Windows Scoket That Can Be Used
	string m_strWSHiVersion;
public:
	bool GetWinSockVersion(string& strWSVersion, string& strWSHiVersion);
	bool GetIPInterfaces(void);
	bool IsInitialized(void);
};
