// Disclaimer and Copyright Information
// Pardesi Services LLC.  Copyright (c) 2001
//						  All rights reserved.
// PSKeyboardInformation.cpp : Implementation of PSKeyboardInformation
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////

// Revision History:
//	4/16/2001	Initial Creation
//

#include "stdafx.h"
#include "SystemKeyboard.h"
#include "PSKeyboardInformation.h"

/////////////////////////////////////////////////////////////////////////////
// PSKeyboardInformation

STDMETHODIMP PSKeyboardInformation::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IPSKeyboardInformation
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (::InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP PSKeyboardInformation::get_Type(BSTR *pVal)
{
	ATLASSERT (NULL != pVal);
	if (NULL == pVal)
	{
		return E_POINTER;
	}

	int nRetVal = ::GetKeyboardType (0);

	switch (nRetVal)
	{
		case 1:
			this->m_bstrType = L"IBM PC/XT or compatible (83-key)";
			break;
		case 2:
			this->m_bstrType = L"Olivetti \"ICO\" (102-key)";
			break;
		case 3:
			this->m_bstrType = L"IBM PC/AT (84-key) or similar";
			break;
		case 4:
			this->m_bstrType = L"IBM enhanced (101- or 102-key)";
			break;
		case 5:
			this->m_bstrType = L"Nokia 1050 and similar";
			break;
		case 6:
			this->m_bstrType = L"Nokia 9140 and similar";
			break;
		case 7:
			this->m_bstrType = L"Japanese";
			break;
		default:
			this->m_bstrType = L"Unknown";
	}
	*pVal = this->m_bstrType.Copy ();
	return S_OK;
}

STDMETHODIMP PSKeyboardInformation::get_FunctionKeys(short *pVal)
{
	ATLASSERT (NULL != pVal);
	if (NULL == pVal)
	{
		return E_POINTER;
	}

	int nRetVal = ::GetKeyboardType (2);
	*pVal = this->m_nFunctionKeys = nRetVal;
	return S_OK;
}

STDMETHODIMP PSKeyboardInformation::get_LightIndicators(short *pVal)
{
	ATLASSERT (NULL != pVal);
	if (NULL == pVal)
	{
		return E_POINTER;
	}

	// TODO: Still not implemented.
	return E_FAIL;
//	return S_OK;
}
