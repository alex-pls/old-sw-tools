// Disclaimer and Copyright Information
// HWDevices.h : Declaration of the CHWDevices
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////

#pragma once
#include "resource.h"       // main symbols



// CHWDevices

class ATL_NO_VTABLE CHWDevices : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CHWDevices, &CLSID_HWDevices>,
	public ISupportErrorInfo,
	public IDispatchImpl<IHWDevices, &IID_IHWDevices, &LIBID_SystemDevicesLib, /*wMajor =*/ 1, /*wMinor =*/ 0>
{
public:
	CHWDevices()
		: m_bInfoGenerated(false)
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_HWDEVICES)


BEGIN_COM_MAP(CHWDevices)
	COM_INTERFACE_ENTRY(IHWDevices)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}
	
	void FinalRelease() 
	{
	}

public:

	STDMETHODIMP GetHWDevicesInfo(void);
private:
	// Function will retrieve the Hardware Device(s) information.
	HRESULT GetInformation(void);
protected:
	bool m_bInfoGenerated;
};

OBJECT_ENTRY_AUTO(__uuidof(HWDevices), CHWDevices)
