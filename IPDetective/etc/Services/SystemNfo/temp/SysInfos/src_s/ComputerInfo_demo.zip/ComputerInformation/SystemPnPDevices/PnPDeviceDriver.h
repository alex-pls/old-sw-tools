// PnPDeviceDriver.h : Declaration of the CPnPDeviceDriver

#pragma once
#include "resource.h"       // main symbols



// CPnPDeviceDriver

class ATL_NO_VTABLE CPnPDeviceDriver : 
	public CComObjectRootEx<CComMultiThreadModel>,
//	public CComCoClass<CPnPDeviceDriver, &CLSID_PnPDeviceDriver>,
	public ISupportErrorInfo,
	public IDispatchImpl<IPnPDeviceDriver, &IID_IPnPDeviceDriver, &LIBID_SYSTEMPNPDEVICESLib, /*wMajor =*/ 1, /*wMinor =*/ 0>
{
public:
	CPnPDeviceDriver()
	{
	}

//DECLARE_REGISTRY_RESOURCEID(IDR_PNPDEVICEDRIVER)


BEGIN_COM_MAP(CPnPDeviceDriver)
	COM_INTERFACE_ENTRY(IPnPDeviceDriver)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}
	
	void FinalRelease() 
	{
	}

public:

	STDMETHODIMP get_Type(BSTR* pVal);
	STDMETHODIMP get_Description(BSTR* pVal);
	STDMETHODIMP get_Manufacturer(BSTR* pVal);
	STDMETHODIMP get_Provider(BSTR* pVal);
	STDMETHODIMP get_Date(BSTR* pVal);
	STDMETHODIMP get_Version(long* pVal);

protected:
	CComBSTR m_bstrType;
	CComBSTR m_bstrDescription;
	CComBSTR m_bstrMfg;
	CComBSTR m_bstrProvider;
	CComBSTR m_bstrDate;
	long	 m_lVersion;

	friend class CPnPDevicesInfo;
};

//OBJECT_ENTRY_AUTO(__uuidof(PnPDeviceDriver), CPnPDeviceDriver)
