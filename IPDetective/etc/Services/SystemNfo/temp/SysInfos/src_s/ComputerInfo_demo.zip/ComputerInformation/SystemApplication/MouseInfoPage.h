// Disclaimer and Copyright Information
// MouseInfoPage.h : 
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////
//
#if !defined(AFX_MOUSEINFOPAGE_H__FBA6EBC3_CEA5_11D2_8C82_000000000000__INCLUDED_)
#define AFX_MOUSEINFOPAGE_H__FBA6EBC3_CEA5_11D2_8C82_000000000000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class MouseInfoPage : public CPropertyPage
{
	DECLARE_DYNCREATE(MouseInfoPage)

// Construction
public:
	MouseInfoPage();
	~MouseInfoPage();
	inline void SetSystemInfo (ISystemInformation *pSystemInfo = NULL, CFile *pFile = NULL);

// Dialog Data
	//{{AFX_DATA(MouseInfoPage)
	enum { IDD = IDD_MOUSE_PROP_PAGE };
	CListCtrl	m_ListCtrl;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(MouseInfoPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(MouseInfoPage)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	void SetListData ();
	CFile *m_pOutputFile;
	ISystemInformation *m_pSystemInfo;

	VARIANT_BOOL m_bInstalled;
	VARIANT_BOOL m_bButtonsSwapped;
	long m_lSpeed;
};

inline void
MouseInfoPage::SetSystemInfo (ISystemInformation *pSystemInfo, CFile *pFile)
{
	ASSERT (pSystemInfo != NULL);
	m_pSystemInfo = pSystemInfo;
	m_pOutputFile = pFile;
}
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MOUSEINFOPAGE_H__FBA6EBC3_CEA5_11D2_8C82_000000000000__INCLUDED_)
