// NetworkInfoPage.cpp : implementation file
//

#include "stdafx.h"
#include "SystemApplication.h"
#include "NetworkInfoPage.h"


// NetworkInfoPage dialog

IMPLEMENT_DYNAMIC(NetworkInfoPage, CPropertyPage)
NetworkInfoPage::NetworkInfoPage()
	: CPropertyPage(NetworkInfoPage::IDD)
	, m_pSystemInfo(NULL)
	, m_pOutputFile(NULL)
{
}

NetworkInfoPage::~NetworkInfoPage()
{
}

void NetworkInfoPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
}

BOOL NetworkInfoPage::OnInitDialog(void)
{
	CPropertyPage::OnInitDialog();

	if (FAILED (this->GetInformation ())) {
		AfxMessageBox (_T ("Application Failed To Get Hardisk Information From Interface Pointer"),
			MB_ICONSTOP);
		return TRUE;
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

HRESULT NetworkInfoPage::GetInformation(void)
{
	HRESULT hr = S_OK;
	// Get ISystemInformation2 from old interface.
	ISystemInformation2 *pSysInfo2 = NULL;
	hr = m_pSystemInfo->QueryInterface (IID_ISystemInformation2,
										reinterpret_cast<void **>(&pSysInfo2));
	if (SUCCEEDED (hr))
	{
		hr = pSysInfo2->GetNetworkInfo ();
	}
	return hr;
}

BEGIN_MESSAGE_MAP(NetworkInfoPage, CPropertyPage)
END_MESSAGE_MAP()


// NetworkInfoPage message handlers
