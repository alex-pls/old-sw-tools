// Disclaimer and Copyright Information
// MouseInfoPage.cpp : Implementation file
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SystemApplication.h"
#include "MouseInfoPage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// MouseInfoPage property page

IMPLEMENT_DYNCREATE(MouseInfoPage, CPropertyPage)

MouseInfoPage::MouseInfoPage() : CPropertyPage(MouseInfoPage::IDD)
{
	//{{AFX_DATA_INIT(MouseInfoPage)
	m_bInstalled = FALSE;
	m_bButtonsSwapped = FALSE;
	m_lSpeed = 0;
	//}}AFX_DATA_INIT
}

MouseInfoPage::~MouseInfoPage()
{
}

void MouseInfoPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(MouseInfoPage)
	DDX_Control(pDX, IDC_MOUSE_INFO_LIST, m_ListCtrl);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(MouseInfoPage, CPropertyPage)
	//{{AFX_MSG_MAP(MouseInfoPage)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// MouseInfoPage message handlers

BOOL MouseInfoPage::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	if (FAILED (m_pSystemInfo->GetMouseInformation (&m_bInstalled, &m_bButtonsSwapped,
		&m_lSpeed))) {
		return FALSE;
	}
	
	SetListData();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void MouseInfoPage::SetListData()
{
	CString tmpStr;
	LV_ITEM item;
	LV_COLUMN leftCol, rightCol;

	leftCol.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	leftCol.fmt = LVCFMT_LEFT;
	leftCol.iSubItem = 0;
	leftCol.cx = 130;
	leftCol.pszText = _T ("Parameter");

	rightCol.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	rightCol.fmt = LVCFMT_LEFT;
	rightCol.iSubItem = 1;
	rightCol.cx = 225;
	rightCol.pszText = _T ("Value");

	m_ListCtrl.InsertColumn (0, &leftCol);
	m_ListCtrl.InsertColumn (1, &rightCol);

	item.mask = LVIF_TEXT;
	item.iItem = 0;
	item.iSubItem = 0;
	item.pszText = _T ("Mouse Installed");
	m_ListCtrl.InsertItem (&item);
	if (!m_bInstalled) {
		item.iSubItem = 1;
		item.pszText = _T ("NO");
		return;
	}

	m_ListCtrl.SetItemText (0, 1, _T ("YES"));

	item.iItem = 1;
	item.pszText = _T ("Buttons Swapped");
	m_ListCtrl.InsertItem (&item);

	tmpStr = (m_bButtonsSwapped) ? _T ("YES") : _T ("NO");
	m_ListCtrl.SetItemText (1, 1, tmpStr);

	item.iItem = 2;
	item.pszText = _T ("Mouse Speed");
	m_ListCtrl.InsertItem (&item);

	tmpStr.Format ("%d", m_lSpeed);
	m_ListCtrl.SetItemText (2, 1, tmpStr);
}
