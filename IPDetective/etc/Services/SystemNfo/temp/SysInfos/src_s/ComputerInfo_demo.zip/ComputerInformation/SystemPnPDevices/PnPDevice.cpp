// PnPDevice.cpp : Implementation of CPnPDevice

#include "stdafx.h"
#include "SystemPnPDevices.h"
#include "PnPDevice.h"


// CPnPDevice

STDMETHODIMP CPnPDevice::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IPnPDevice
	};

	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (::InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CPnPDevice::get_Description(BSTR* pVal)
{
	ATLASSERT (NULL != pVal);
	if (NULL == pVal)
	{
		return E_POINTER;
	}

	*pVal = m_bstrDescription.Copy ();
	return S_OK;
}

STDMETHODIMP CPnPDevice::get_HardwareID(BSTR* pVal)
{
	ATLASSERT (NULL != pVal);
	if (NULL == pVal)
	{
		return E_POINTER;
	}

	*pVal = m_bstrHWId.Copy ();
	return S_OK;
}

STDMETHODIMP CPnPDevice::get_ClassGUID(BSTR* pVal)
{
	ATLASSERT (NULL != pVal);
	if (NULL == pVal)
	{
		return E_POINTER;
	}

	*pVal = m_bstrClassGUID.Copy ();
	return S_OK;
}

STDMETHODIMP CPnPDevice::get_Driver(BSTR* pVal)
{
	ATLASSERT (NULL != pVal);
	if (NULL == pVal)
	{
		return E_POINTER;
	}

	*pVal = m_bstrDriver.Copy ();
	return S_OK;
}

STDMETHODIMP CPnPDevice::get_Manufacturer(BSTR* pVal)
{
	ATLASSERT (NULL != pVal);
	if (NULL == pVal)
	{
		return E_POINTER;
	}

	*pVal = m_bstrMfg.Copy ();
	return S_OK;
}

STDMETHODIMP CPnPDevice::get_FriendlyName(BSTR* pVal)
{
	ATLASSERT (NULL != pVal);
	if (NULL == pVal)
	{
		return E_POINTER;
	}

	*pVal = m_bstrFriendlyName.Copy ();
	return S_OK;
}

STDMETHODIMP CPnPDevice::get_DeviceType(BSTR* pVal)
{
	ATLASSERT (NULL != pVal);
	if (NULL == pVal)
	{
		return E_POINTER;
	}

	*pVal = m_bstrDeviceType.Copy ();
	return S_OK;
}

STDMETHODIMP CPnPDevice::get_VendorID(BSTR* pVal)
{
	ATLASSERT (NULL != pVal);
	if (NULL == pVal)
	{
		return E_POINTER;
	}

	*pVal = m_bstrVendorID.Copy ();
	return S_OK;
}

STDMETHODIMP CPnPDevice::get_ProductID(BSTR* pVal)
{
	ATLASSERT (NULL != pVal);
	if (NULL == pVal)
	{
		return E_POINTER;
	}

	*pVal = m_bstrProductID.Copy ();
	return S_OK;
}

STDMETHODIMP CPnPDevice::get_ProductRevision(BSTR* pVal)
{
	ATLASSERT (NULL != pVal);
	if (NULL == pVal)
	{
		return E_POINTER;
	}

	*pVal = m_bstrProductRevision.Copy ();
	return S_OK;
}

STDMETHODIMP CPnPDevice::get_SerialNumber(BSTR* pVal)
{
	ATLASSERT (NULL != pVal);
	if (NULL == pVal)
	{
		return E_POINTER;
	}

	*pVal = m_bstrSerialNumber.Copy ();
	return S_OK;
}

STDMETHODIMP CPnPDevice::get_DeviceDrivers(IPnPDeviceDrivers** pVal)
{
	HRESULT hr = S_OK;
	ATLASSERT (NULL != pVal);
	if (NULL == pVal)
	{
		return E_POINTER;
	}

	*pVal = NULL;
	if (NULL != m_pDrivers)
	{
		hr = m_pDrivers->QueryInterface (IID_IPnPDeviceDrivers,
										 reinterpret_cast<void **>(pVal));
	}

	return hr;
}
