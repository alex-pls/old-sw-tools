// Disclaimer and Copyright Information
// MultiMediaInformation.cpp : Implementation of CMultiMediaInformation
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SystemMultiMedia.h"
#include "MultiMediaInformation.h"

/////////////////////////////////////////////////////////////////////////////
// CMultiMediaInformation

STDMETHODIMP CMultiMediaInformation::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IMultiMediaInformation
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (::InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CMultiMediaInformation::get_IsPresent(VARIANT_BOOL *pVal)
{
	HRESULT hRes = E_FAIL;

	if ((hRes = GetInformation ()) != S_OK)
	{
		return hRes;
	}

	*pVal = m_bIsPresent;
	return hRes;
}

STDMETHODIMP CMultiMediaInformation::get_CompanyName(BSTR *pVal)
{
	HRESULT hRes = E_FAIL;

	if ((hRes = GetInformation ()) != S_OK)
	{
		return hRes;
	}

	*pVal = m_bstrCompanyName.Copy ();
	return hRes;
}

STDMETHODIMP CMultiMediaInformation::get_ProductName(BSTR *pVal)
{
	HRESULT hRes = E_FAIL;

	if ((hRes = GetInformation ()) != S_OK)
	{
		return hRes;
	}

	*pVal = m_bstrProductName.Copy ();
	return hRes;
}

STDMETHODIMP CMultiMediaInformation::get_HasVolumeControl(VARIANT_BOOL *pVal)
{
	HRESULT hRes = E_FAIL;

	if ((hRes = GetInformation ()) != S_OK)
	{
		return hRes;
	}

	*pVal = m_bHasVolCtrl;
	return hRes;
}

STDMETHODIMP CMultiMediaInformation::get_HasSeparateLRVolControl(VARIANT_BOOL *pVal)
{
	HRESULT hRes = E_FAIL;

	if ((hRes = GetInformation ()) != S_OK)
	{
		return hRes;
	}

	*pVal = m_bHasSeparateLRVolCtrl;
	return hRes;
}

STDMETHODIMP CMultiMediaInformation::GetMultiMediaInformation(VARIANT_BOOL *pbIsInstalled,
															  VARIANT_BOOL *pbHasVolCtrl,
															  VARIANT_BOOL *pbHasSeparateLRVolCtrl,
															  BSTR *pbstrProductName,
															  BSTR *pbstrCompanyName)
{
	HRESULT hRes = E_FAIL;
	if ((hRes = GetInformation ()) != S_OK)
	{
		return hRes;
	}

	*pbIsInstalled = m_bIsPresent;
	*pbHasVolCtrl = m_bHasVolCtrl;
	*pbHasSeparateLRVolCtrl = m_bHasSeparateLRVolCtrl;
	*pbstrCompanyName = m_bstrCompanyName.Copy ();
	*pbstrProductName = m_bstrProductName.Copy ();
	return hRes;
}

HRESULT CMultiMediaInformation::GetInformation ()
{
	HRESULT hRes = S_OK;
	MMRESULT mmRes = MMSYSERR_NOERROR;
	UINT numDevices = 0;
	UINT cbCaps;
	WAVEOUTCAPS wavCaps;

	if (m_bInformationObtained)
	{
		return S_OK;
	}

	// Get the number of audio output devices installed on your system.
	numDevices = waveOutGetNumDevs ();
	m_bIsPresent = (numDevices > 0) ? TRUE : FALSE;

	// If the device is present, only then we will proceed to get other information.
	if (m_bIsPresent)
	{
		hRes = E_FAIL;
		cbCaps = sizeof (AUXCAPS);
		mmRes = waveOutGetDevCaps (0, &wavCaps, cbCaps);
		if (mmRes == MMSYSERR_NOERROR) {
			hRes = S_OK;
			m_bstrProductName = wavCaps.szPname;
			m_bHasSeparateLRVolCtrl = (wavCaps.dwSupport & WAVECAPS_VOLUME) ? TRUE : FALSE;
			m_bHasVolCtrl = (wavCaps.dwSupport & AUXCAPS_VOLUME) ? TRUE : FALSE;
			m_bstrCompanyName = GetAudioDevCompanyName (wavCaps.wMid);
		}
	}

	m_bInformationObtained = true;

	return hRes;
}

CComBSTR CMultiMediaInformation::GetAudioDevCompanyName (WORD wCompany) const
{
	CComBSTR stCompany;

	stCompany = _T ("Unknown");
	switch (wCompany) {
		case MM_MICROSOFT:
			stCompany = _T ("Microsoft Corporation");
			break;
		case MM_CREATIVE:
			stCompany = _T ("Creative Labs, Inc");
			break;
		case MM_MEDIAVISION:
			stCompany = _T ("Media Vision, Inc.");
			break;
		case MM_FUJITSU:
			stCompany = _T ("Fujitsu Corp.");
			break;
		case MM_ARTISOFT:
			stCompany = _T ("Artisoft, Inc.");
			break;
		case MM_TURTLE_BEACH:
			stCompany = _T ("Turtle Beach, Inc.");
			break;
		case MM_IBM:
			stCompany = _T ("IBM Corporation");
			break;
		case MM_VOCALTEC:
			stCompany = _T ("Vocaltec LTD.");
			break;
		case MM_ROLAND:
			stCompany = _T ("Roland");
			break;
		case MM_DSP_SOLUTIONS:
			stCompany = _T ("DSP Solutions, Inc.");
			break;
		case MM_NEC:
			stCompany = _T ("NEC");
			break;
		case MM_ATI:
			stCompany = _T ("ATI");
			break;
		case MM_WANGLABS:
			stCompany = _T ("Wang Laboratories, Inc");
			break;
		case MM_TANDY:
			stCompany = _T ("Tandy Corporation");
			break;
		case MM_VOYETRA:
			stCompany = _T ("Voyetra");
			break;
		case MM_ANTEX:
			stCompany = _T ("Antex Electronics Corporation");
			break;
		case MM_ICL_PS:
			stCompany = _T ("ICL Personal Systems");
			break;
		case MM_INTEL:
			stCompany = _T ("Intel Corporation");
			break;
		case MM_GRAVIS:
			stCompany = _T ("Advanced Gravis");
			break;
		case MM_VAL:
			stCompany = _T ("Video Associates Labs, Inc.");
			break;
		case MM_INTERACTIVE:
			stCompany = _T ("InterActive Inc");
			break;
		case MM_YAMAHA:
			stCompany = _T ("Yamaha Corporation of America");
			break;
		case MM_EVEREX:
			stCompany = _T ("Everex Systems, Inc");
			break;
		case MM_ECHO:
			stCompany = _T ("Echo Speech Corporation");
			break;
		case MM_SIERRA:
			stCompany = _T ("Sierra Semiconductor Corp");
			break;
		case MM_CAT:
			stCompany = _T ("Computer Aided Technologies");
			break;
		case MM_APPS:
			stCompany = _T ("APPS Software International");
			break;
		case MM_DSP_GROUP:
			stCompany = _T ("DSP Group, Inc");
			break;
		case MM_MELABS:
			stCompany = _T ("MicroEngineering Labs");
			break;
		case MM_COMPUTER_FRIENDS:
			stCompany = _T ("Computer Friends, Inc.");
			break;
		case MM_ESS:
			stCompany = _T ("ESS Technology");
			break;
		case MM_AUDIOFILE:
			stCompany = _T ("Audio, Inc.");
			break;
		case MM_MOTOROLA:
			stCompany = _T ("Motorola, Inc.");
		case MM_CANOPUS:
			stCompany = _T ("Canopus, co., Ltd.");
			break;
		case MM_EPSON:
			stCompany = _T ("Seiko Epson Corporation");
			break;
		case MM_TRUEVISION:
			stCompany = _T ("Truevision");
			break;
		case MM_AZTECH:
			stCompany = _T ("Aztech Labs, Inc.");
			break;
		case MM_VIDEOLOGIC:
			stCompany = _T ("Videologic");
			break;
		case MM_SCALACS:
			stCompany = _T ("SCALACS");
			break;
		case MM_KORG:
			stCompany = _T ("Korg Inc.");
			break;
		case MM_APT:
			stCompany = _T ("Audio Processing Technology");
			break;
		case MM_ICS:
			stCompany = _T ("Integrated Circuit Systems, Inc.");
			break;
		case MM_ITERATEDSYS:
			stCompany = _T ("Iterated Systems, Inc.");
			break;
		case MM_METHEUS:
			stCompany = _T ("Metheus");
			break;
		case MM_LOGITECH:
			stCompany = _T ("Logitech, Inc.");
			break;
		case MM_WINNOV:
			stCompany = _T ("Winnov, Inc.");
			break;
		case MM_NCR:
			stCompany = _T ("NCR Corporation");
			break;
		case MM_EXAN:
			stCompany = _T ("EXAN");
			break;
		case MM_AST:
			stCompany = _T ("AST Research Inc.");
			break;
		case MM_WILLOWPOND:
			stCompany = _T ("Willow Pond Corporation");
			break;
		case MM_SONICFOUNDRY:
			stCompany = _T ("Sonic Foundry");
			break;
		case MM_VITEC:
			stCompany = _T ("Vitec Multimedia");
			break;
		case MM_MOSCOM:
			stCompany = _T ("MOSCOM Corporation");
			break;
		case MM_SILICONSOFT:
			stCompany = _T ("Silicon Soft, Inc.");
			break;
		case MM_SUPERMAC:
			stCompany = _T ("Supermac");
			break;
		case MM_AUDIOPT:
			stCompany = _T ("Audio Processing Technology");
			break;
		case MM_SPEECHCOMP:
			stCompany = _T ("Speech Compression");
			break;
		case MM_AHEAD:
			stCompany = _T ("Ahead, Inc.");
			break;
		case MM_DOLBY:
			stCompany = _T ("Dolby Laboratories");
			break;
		case MM_OKI:
			stCompany = _T ("OKI");
			break;
		case MM_AURAVISION:
			stCompany = _T ("AuraVision Corporation");
			break;
		case MM_OLIVETTI:
			stCompany = _T ("Ing C. Olivetti & C., S.p.A.");
			break;
		case MM_IOMAGIC:
			stCompany = _T ("I/O Magic Corporation");
			break;
		case MM_MATSUSHITA:
			stCompany = _T ("Matsushita Electric Industrial Co., LTD.");
			break;
		case MM_CONTROLRES:
			stCompany = _T ("Control Resources Limited");
			break;
		case MM_XEBEC:
			stCompany = _T ("Xebec Multimedia Solutions Limited");
			break;
		case MM_NEWMEDIA:
			stCompany = _T ("New Media Corporation");
			break;
		case MM_NMS:
			stCompany = _T ("Natural MicroSystems");
			break;
		case MM_LYRRUS:
			stCompany = _T ("Lyrrus Inc.");
			break;
		case MM_COMPUSIC:
			stCompany = _T ("Compusic");
			break;
		case MM_OPTI:
			stCompany = _T ("OPTI Computers Inc.");
			break;
		case MM_ADLACC:
			stCompany = _T ("Adlib Accessories Inc.");
			break;
		case MM_COMPAQ:
			stCompany = _T ("Compaq Computer Corp.");
			break;
		case MM_DIALOGIC:
			stCompany = _T ("Dialogic Corporation");
			break;
		case MM_INSOFT:
			stCompany = _T ("InSoft, Inc.");
			break;
		case MM_MPTUS:
			stCompany = _T ("M.P. Technologies, Inc.");
			break;
		case MM_WEITEK:
			stCompany = _T ("Weitek");
			break;
		case MM_LERNOUT_AND_HAUSPIE:
			stCompany = _T ("Lernout & Hauspie");
			break;
		case MM_QCIAR:
			stCompany = _T ("Quanta Computer Inc.");
			break;
		case MM_APPLE:
			stCompany = _T ("Apple Computer, Inc.");
			break;
		case MM_DIGITAL:
			stCompany = _T ("Digital Equipment Corporation");
			break;
		case MM_MOTU:
			stCompany = _T ("Mark of the Unicorn");
			break;
		case MM_WORKBIT:
			stCompany = _T ("Workbit Corporation");
			break;
		case MM_OSITECH:
			stCompany = _T ("Ositech Communications Inc.");
			break;
		case MM_MIRO:
			stCompany = _T ("miro Computer Products AG");
			break;
		case MM_CIRRUSLOGIC:
			stCompany = _T ("Cirrus Logic");
			break;
		case MM_ISOLUTION:
			stCompany = _T ("ISOLUTION  B.V.");
			break;
		case MM_HORIZONS:
			stCompany = _T ("Horizons Technology, Inc");
			break;
		case MM_CONCEPTS:
			stCompany = _T ("Computer Concepts Ltd");
			break;
		case MM_VTG:
			stCompany = _T ("Voice Technologies Group, Inc.");
			break;
		case MM_RADIUS:
			stCompany = _T ("Radius");
			break;
		case MM_ROCKWELL:
			stCompany = _T ("Rockwell International");
			break;
		case MM_XYZ:
			stCompany = _T ("Co. XYZ for testing");
			break;
		case MM_OPCODE:
			stCompany = _T ("Opcode Systems");
			break;
		case MM_VOXWARE:
			stCompany = _T ("Voxware Inc");
			break;
		case MM_NORTHERN_TELECOM:
			stCompany = _T ("Northern Telecom Limited");
			break;
		case MM_APICOM:
			stCompany = _T ("APICOM");
			break;
		case MM_GRANDE:
			stCompany = _T ("Grande Software");
			break;
		case MM_ADDX:
			stCompany = _T ("ADDX");
			break;
		case MM_WILDCAT:
			stCompany = _T ("Wildcat Canyon Software");
			break;
		case MM_RHETOREX:
			stCompany = _T ("Rhetorex Inc");
			break;
		case MM_BROOKTREE:
			stCompany = _T ("Brooktree Corporation");
			break;
		case MM_ENSONIQ:
			stCompany = _T ("ENSONIQ Corporation");
			break;
		case MM_FAST:
			stCompany = _T ("///FAST Multimedia AG");
			break;
		case MM_NVIDIA:
			stCompany = _T ("NVidia Corporation");
			break;
		case MM_OKSORI:
			stCompany = _T ("OKSORI Co., Ltd.");
			break;
		case MM_DIACOUSTICS:
			stCompany = _T ("DiAcoustics, Inc.");
			break;
		case MM_GULBRANSEN:
			stCompany = _T ("Gulbransen, Inc.");
			break;
		case MM_KAY_ELEMETRICS:
			stCompany = _T ("Kay Elemetrics, Inc.");
			break;
		case MM_CRYSTAL:
			stCompany = _T ("Crystal Semiconductor Corporation");
			break;
		case MM_SPLASH_STUDIOS:
			stCompany = _T ("Splash Studios");
			break;
		case MM_QUARTERDECK:
			stCompany = _T ("Quarterdeck Corporation");
			break;
		case MM_TDK:
			stCompany = _T ("TDK Corporation");
			break;
		case MM_DIGITAL_AUDIO_LABS:
			stCompany = _T ("Digital Audio Labs, Inc.");
			break;
		case MM_SEERSYS:
			stCompany = _T ("Seer Systems, Inc.");
			break;
		case MM_PICTURETEL:
			stCompany = _T ("PictureTel Corporation");
			break;
		case MM_ATT_MICROELECTRONICS:
			stCompany = _T ("AT&T Microelectronics");
			break;
		case MM_OSPREY:
			stCompany = _T ("Osprey Technologies, Inc.");
			break;
		case MM_MEDIATRIX:
			stCompany = _T ("Mediatrix Peripherals");
			break;
		case MM_SOUNDESIGNS:
			stCompany = _T ("SounDesignS M.C.S. Ltd.");
			break;
		case MM_ALDIGITAL:
			stCompany = _T ("A.L. Digital Ltd.");
			break;
		case MM_SPECTRUM_SIGNAL_PROCESSING:
			stCompany = _T ("Spectrum Signal Processing, Inc.");
			break;
		case MM_ECS:
			stCompany = _T ("Electronic Courseware Systems, Inc.");
			break;
		case MM_AMD:
			stCompany = _T ("AMD");
			break;
		case MM_COREDYNAMICS:
			stCompany = _T ("Core Dynamics");
			break;
		case MM_CANAM:
			stCompany = _T ("CANAM Computers");
			break;
		case MM_SOFTSOUND:
			stCompany = _T ("Softsound, Ltd.");
			break;
		case MM_NORRIS:
			stCompany = _T ("Norris Communications, Inc.");
			break;
		case MM_DDD:
			stCompany = _T ("Danka Data Devices");
			break;
		case MM_EUPHONICS:
			stCompany = _T ("EuPhonics");
			break;
		case MM_PRECEPT:
			stCompany = _T ("Precept Software, Inc.");
			break;
		case MM_CRYSTAL_NET:
			stCompany = _T ("Crystal Net Corporation");
			break;
		case MM_CHROMATIC:
			stCompany = _T ("Chromatic Research, Inc");
			break;
		case MM_VOICEINFO:
			stCompany = _T ("Voice Information Systems, Inc");
			break;
		case MM_VIENNASYS:
			stCompany = _T ("Vienna Systems");
			break;
		case MM_CONNECTIX:
			stCompany = _T ("Connectix Corporation");
			break;
		case MM_GADGETLABS:
			stCompany = _T ("Gadget Labs LLC");
			break;
		case MM_FRONTIER:
			stCompany = _T ("Frontier Design Group LLC");
			break;
		case MM_VIONA:
			stCompany = _T ("Viona Development GmbH");
			break;
		case MM_CASIO:
			stCompany = _T ("Casio Computer Co., LTD");
			break;
		case MM_DIAMONDMM:
			stCompany = _T ("Diamond Multimedia");
			break;
		case MM_S3:
			stCompany = _T ("S3");
			break;
		case MM_FRAUNHOFER_IIS:
			stCompany = _T ("Fraunhofer");
			break;
		default:
			stCompany = _T ("Unknown");
			break;
	}

	return stCompany;
}
