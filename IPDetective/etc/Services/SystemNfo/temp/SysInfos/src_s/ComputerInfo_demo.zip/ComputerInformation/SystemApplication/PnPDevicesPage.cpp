// PnPDevicesPage.cpp : implementation file
//

#include "stdafx.h"
#include "SystemApplication.h"
#include "PnPDevicesPage.h"

#include "PnPDeviceInfoDlg.h"
#include "SystemPnPDevices.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// PnPDevicesPage property page

IMPLEMENT_DYNCREATE(PnPDevicesPage, CPropertyPage)

PnPDevicesPage::PnPDevicesPage() : CPropertyPage(PnPDevicesPage::IDD)
{
	//{{AFX_DATA_INIT(PnPDevicesPage)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_pDevices = NULL;
}

PnPDevicesPage::~PnPDevicesPage()
{
	if (NULL != m_pDevices)
	{
		m_pDevices->Release ();
	}
	m_pDevices = NULL;
}

void PnPDevicesPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(PnPDevicesPage)
	DDX_Control(pDX, IDC_PNP_DEVICES_LIST, m_wndDevicesList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(PnPDevicesPage, CPropertyPage)
	//{{AFX_MSG_MAP(PnPDevicesPage)
	ON_NOTIFY(NM_DBLCLK, IDC_PNP_DEVICES_LIST, OnDblclkPnpDevicesList)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// PnPDevicesPage message handlers

BOOL PnPDevicesPage::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	if (FAILED (this->GetInformation ()))
	{
		AfxMessageBox (_T ("Failed to get Devices information"));
		return TRUE;
	}

	SetListData ();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

HRESULT PnPDevicesPage::GetInformation ()
{
	HRESULT hr = S_OK;
	ISystemInformation3 *pSysInfo3 = NULL;
	hr = m_pSystemInfo->QueryInterface (IID_ISystemInformation3,
										reinterpret_cast<void **>(&pSysInfo3));
	if (SUCCEEDED (hr))
	{
		IUnknown *pUnk = NULL;
		hr = pSysInfo3->GetPnPDevices (&pUnk);
		if (SUCCEEDED (hr))
		{
			hr = pUnk->QueryInterface (IID_IPnPDevices, reinterpret_cast<void **>(&m_pDevices));
		}

		if (NULL != pUnk)
		{
			pUnk->Release ();
		}
		pUnk = NULL;
	}

	if (NULL != pSysInfo3)
	{
		pSysInfo3->Release ();
	}
	pSysInfo3 = NULL;
	return hr;
}

void PnPDevicesPage::SetListData(void)
{
	ASSERT (NULL != m_pDevices);
	if (NULL == m_pDevices)
	{
		return;
	}

	long nNumDevices = 0;
	LV_ITEM item;
	LV_COLUMN col1, col2, col3, col4, col5;

	col1.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	col1.fmt = LVCFMT_LEFT;
	col1.iSubItem = 0;
	col1.cx = 100;
	col1.pszText = _T ("Description");

	col2.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	col2.fmt = LVCFMT_LEFT;
	col2.iSubItem = 1;
	col2.cx = 80;
	col2.pszText = _T ("Manufacturer");

	col3.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	col3.fmt = LVCFMT_LEFT;
	col3.iSubItem = 2;
	col3.cx = 90;
	col3.pszText = _T ("Class GUID");

	col4.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	col4.fmt = LVCFMT_LEFT;
	col4.iSubItem = 3;
	col4.cx = 80;
	col4.pszText = _T ("Hardware ID");

	col5.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	col5.fmt = LVCFMT_LEFT;
	col5.iSubItem = 4;
	col5.cx = 85;
	col5.pszText = _T ("Driver");

	m_wndDevicesList.InsertColumn (0, &col1);
	m_wndDevicesList.InsertColumn (1, &col2);
	m_wndDevicesList.InsertColumn (2, &col3);
	m_wndDevicesList.InsertColumn (3, &col4);
	m_wndDevicesList.InsertColumn (4, &col5);

	// Get the number of devices.
	int nIdx = 0;
	BSTR tmpBstr;
	HRESULT hr = m_pDevices->get_Count (&nNumDevices);
	if (SUCCEEDED (hr) && nNumDevices > 0)
	{
		for (long i = 0; i < nNumDevices; i++)
		{
			IPnPDevice *pDevice = NULL;
			hr = m_pDevices->get_Item (i, &pDevice);
			if (SUCCEEDED (hr))
			{
				item.mask = LVIF_TEXT;
				item.iItem = nIdx;
				item.iSubItem = 0;
				item.pszText = _T (" ");
				m_wndDevicesList.InsertItem (&item);
				
				pDevice->get_Description (&tmpBstr);
				m_wndDevicesList.SetItemText (nIdx, 0, CString (tmpBstr));
				::SysFreeString (tmpBstr);

				pDevice->get_Manufacturer (&tmpBstr);
				m_wndDevicesList.SetItemText (nIdx, 1, CString (tmpBstr));
				::SysFreeString (tmpBstr);

				pDevice->get_ClassGUID (&tmpBstr);
				m_wndDevicesList.SetItemText (nIdx, 2, CString (tmpBstr));
				::SysFreeString (tmpBstr);

				pDevice->get_HardwareID (&tmpBstr);
				m_wndDevicesList.SetItemText (nIdx, 3, CString (tmpBstr));
				::SysFreeString (tmpBstr);

				pDevice->get_Driver (&tmpBstr);
				m_wndDevicesList.SetItemText (nIdx, 4, CString (tmpBstr));
				::SysFreeString (tmpBstr);

				item.lParam = (LPARAM)pDevice;

				nIdx++;
			}
		}
	}
}

void PnPDevicesPage::OnDblclkPnpDevicesList(NMHDR* pNMHDR, LRESULT* pResult) 
{
	LV_DISPINFO* pDispInfo = (LV_DISPINFO*)pNMHDR;
	LV_ITEM* pItem= &(pDispInfo)->item;

	PnPDeviceInfoDlg dlg;
	dlg.DoModal (pItem, this);

	*pResult = 0;
}
