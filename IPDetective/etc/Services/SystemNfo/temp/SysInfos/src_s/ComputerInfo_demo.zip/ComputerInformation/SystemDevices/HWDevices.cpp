// Disclaimer and Copyright Information
// HWDevices.cpp : Implementation of CHWDevices
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SystemDevices.h"
#include "HWDevices.h"

#include <wbemcli.h>


// CHWDevices

STDMETHODIMP CHWDevices::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IHWDevices
	};

	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CHWDevices::GetHWDevicesInfo(void)
{
	HRESULT hr = this->GetInformation ();

	return hr;
}

HRESULT CHWDevices::GetInformation(void)
{
	// If we already have generated the information, then there is no need to do it again.
	if (m_bInfoGenerated)
	{
		return S_OK;
	}
	HRESULT hr = S_OK;
	IWbemLocator *pWbemLocator = NULL;

	// Create instance of IWbemLocator interface.
	// This interface is the entry into WMI world. This interface is always an
	// in-proc server object.
	hr = ::CoCreateInstance (CLSID_WbemLocator,
							 NULL,
							 CLSCTX_INPROC_SERVER,
							 IID_IWbemLocator,
							 reinterpret_cast<void **>(&pWbemLocator));
	if (FAILED (hr))
	{
		return hr;
	}

	// Now we need to call ConnectServer on Locator interface to get
	// WMI we want.
	IWbemServices *pSvc = 0;
	// Connect to the desired namespace
	BSTR bstrNameSpace = ::SysAllocString( L"\\\\.\\root\\cimv2" );

	hr = pWbemLocator->ConnectServer (bstrNameSpace,
									  NULL,
									  NULL,
									  0,
									  NULL,
									  0,
									  0,
									  &pSvc);
	::SysFreeString( bstrNameSpace );
	if (SUCCEEDED (hr))
	{
		// Set the auhtentication information on IWbemServices interface.
/*
		::CoSetProxyBlanket (pSvc,
							 RPC_C_AUTHN_DEFAULT,
							 RPC_C_AUTHZ_DEFAULT,
							 NULL,
							 RPC_C_AUTHN_LEVEL_DEFAULT,
							 RPC_C_IMP_LEVEL_IMPERSONATE,
							 NULL,
							 EOAC_NONE);
*/
		IWbemClassObject *pBIOSClassObject = NULL;
		BSTR bstrPath = ::SysAllocString(L"Win32_NetworkAdapter");
		hr = pSvc->GetObject (bstrPath,
							  0L,
							  NULL,
							  &pBIOSClassObject,
							  NULL);
		::SysFreeString( bstrPath );

		if (SUCCEEDED (hr))
		{
			VARIANT varVal;
			CIMTYPE valType;
			LONG lPropFlavor;

			SAFEARRAY *psaNames = NULL;

			hr = pBIOSClassObject->GetNames (NULL,
											 WBEM_FLAG_ALWAYS | WBEM_FLAG_NONSYSTEM_ONLY,
											 NULL,
											 &psaNames);
			if (SUCCEEDED (hr))
			{
				// Get the number of properties.
				long lLower, lUpper; 

				::SafeArrayGetLBound(psaNames, 1, &lLower);
				::SafeArrayGetUBound(psaNames, 1, &lUpper);

				// For each property...
				BSTR PropName = NULL;


				for (long i = lLower; i <= lUpper; i++) 
				{
				    // Get this property.
					hr = ::SafeArrayGetElement (psaNames, &i, &PropName);
				    if (SUCCEEDED(hr))
				    {
				        // Format: name (type) ==> value
				        CComBSTR bstrsProp = PropName;
				    }
					::SysFreeString(PropName);
				}
				::SafeArrayDestroy(psaNames);
			}

			hr = pBIOSClassObject->Get (L"AdapterType",
										0,
										&varVal,
										&valType,
										&lPropFlavor);
			if (SUCCEEDED (hr))
			{
				::VariantClear (&varVal);
			}

			hr = pBIOSClassObject->Get (L"Manufacturer",
										0,
										&varVal,
										&valType,
										&lPropFlavor);
			if (SUCCEEDED (hr))
			{
				::VariantClear (&varVal);
			}

			hr = pBIOSClassObject->Get (L"ProductName",
										0,
										&varVal,
										&valType,
										&lPropFlavor);
			if (SUCCEEDED (hr))
			{
				::VariantClear (&varVal);
			}

			pBIOSClassObject->Release ();
		}
	}

	pWbemLocator->Release ();
	pSvc->Release ();
	return S_OK;
}
