// HWDevicesInfoPage.cpp : implementation file
//

#include "stdafx.h"
#include "SystemApplication.h"
#include "HWDevicesInfoPage.h"


// HWDevicesInfoPage dialog

IMPLEMENT_DYNAMIC(HWDevicesInfoPage, CPropertyPage)
HWDevicesInfoPage::HWDevicesInfoPage()
	: CPropertyPage(HWDevicesInfoPage::IDD)
{
}

HWDevicesInfoPage::~HWDevicesInfoPage()
{
}

void HWDevicesInfoPage::DoDataExchange(CDataExchange* pDX)
{
	DDX_Control(pDX, IDC_HWDEVICES_INFO_LIST, m_wndListCtl);
	CPropertyPage::DoDataExchange(pDX);

}

BOOL HWDevicesInfoPage::OnInitDialog(void)
{
	CPropertyPage::OnInitDialog();

	if (FAILED (GetInformation ())) {
		AfxMessageBox (_T ("Application Failed To Get Hardisk Information From Interface Pointer"),
			MB_ICONSTOP);
		return TRUE;
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

HRESULT HWDevicesInfoPage::GetInformation(void)
{
	HRESULT hr = m_pSystemInfo->GetHWDevicesInfo ();
	return hr;
}


BEGIN_MESSAGE_MAP(HWDevicesInfoPage, CPropertyPage)
END_MESSAGE_MAP()


// HWDevicesInfoPage message handlers
