// ModemInformation.h : Declaration of the CModemInformation

#ifndef __MODEMINFORMATION_H_
#define __MODEMINFORMATION_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CModemInformation
class ATL_NO_VTABLE CModemInformation : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CModemInformation, &CLSID_ModemInformation>,
	public ISupportErrorInfo,
	public IDispatchImpl<IModemInformation, &IID_IModemInformation, &LIBID_SYSTEMMODEMLib>
{
public:
	CModemInformation()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_MODEMINFORMATION)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CModemInformation)
	COM_INTERFACE_ENTRY(IModemInformation)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IModemInformation
public:
private:
	HRESULT GetInformation(void);
};

#endif //__MODEMINFORMATION_H_
