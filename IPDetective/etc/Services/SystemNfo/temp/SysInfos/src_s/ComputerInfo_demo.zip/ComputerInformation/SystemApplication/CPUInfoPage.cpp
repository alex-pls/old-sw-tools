// Disclaimer and Copyright Information
// CPUInfoPage.cpp : Implementation file
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SystemApplication.h"
#include "CPUInfoPage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPUInfoPage property page

IMPLEMENT_DYNCREATE(CPUInfoPage, CPropertyPage)

CPUInfoPage::CPUInfoPage() : CPropertyPage(CPUInfoPage::IDD)
{
	//{{AFX_DATA_INIT(CPUInfoPage)
	m_bstrVendor = NULL;
	m_bstrCPUType = NULL;
	m_bstrArchitecture = NULL;
	m_bstrCPULevel = NULL;
	m_bstrRevision = NULL;
	m_lNumberOfProcessors = 0;
	m_lCPUSpeed = 0;
	m_lPageSize = 0;
	m_lActiveProcessorMask = 0;
	//}}AFX_DATA_INIT
}

CPUInfoPage::~CPUInfoPage()
{
	::SysFreeString (m_bstrVendor);
	::SysFreeString (m_bstrCPUType);
	::SysFreeString (m_bstrArchitecture);
	::SysFreeString (m_bstrCPULevel);
	::SysFreeString (m_bstrRevision);
}

void CPUInfoPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPUInfoPage)
	DDX_Control(pDX, IDC_CPU_INFO_LIST, m_ListCtrl);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPUInfoPage, CPropertyPage)
	//{{AFX_MSG_MAP(CPUInfoPage)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPUInfoPage message handlers

BOOL CPUInfoPage::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	if (FAILED (m_pSystemInfo->GetCPUInformation (&m_bstrVendor, &m_bstrCPUType,
		&m_bstrArchitecture, &m_bstrCPULevel, &m_bstrRevision, &m_lNumberOfProcessors,
		&m_lCPUSpeed, &m_lPageSize, &m_lActiveProcessorMask))) {
		AfxMessageBox (_T ("Application Failed To Get CPU Information From Interface Pointer"),
			MB_ICONSTOP);
		return FALSE;
	}
	
	SetListData();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CPUInfoPage::SetListData()
{
	CString tmpStr;
	LV_ITEM item;
	LV_COLUMN leftCol, rightCol;

	int blanks = 0;
	CString padStr = _T ("");
	CString bufStr = _T ("*************** CPU Information ***************\r\n");
	m_pOutputFile->Write (bufStr, bufStr.GetLength ());

	leftCol.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	leftCol.fmt = LVCFMT_LEFT;
	leftCol.iSubItem = 0;
	leftCol.cx = 130;
	leftCol.pszText = _T ("Parameter");

	rightCol.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	rightCol.fmt = LVCFMT_LEFT;
	rightCol.iSubItem = 1;
	rightCol.cx = 225;
	rightCol.pszText = _T ("Value");

	m_ListCtrl.InsertColumn (0, &leftCol);
	m_ListCtrl.InsertColumn (1, &rightCol);

	item.mask = LVIF_TEXT;
	item.iItem = 0;
	item.iSubItem = 0;
	item.pszText = _T ("Vendor");
	m_ListCtrl.InsertItem (&item);

	m_pOutputFile->Write (item.pszText, (UINT)strlen (item.pszText));
	padStr = _T ("\t\t\t");
	m_pOutputFile->Write (padStr, padStr.GetLength ());

	bufStr = m_bstrVendor;
	m_ListCtrl.SetItemText (0, 1, CString (m_bstrVendor));
	m_pOutputFile->Write (bufStr, bufStr.GetLength ());

	m_pOutputFile->Write (LINEBREAK_STR, (UINT)strlen (LINEBREAK_STR));

	item.iItem = 1;
	item.pszText = _T ("CPU Speed");
	m_ListCtrl.InsertItem (&item);

	m_pOutputFile->Write (item.pszText, (UINT)strlen (item.pszText));
	padStr = _T ("\t\t\t");
	m_pOutputFile->Write (padStr, padStr.GetLength ());

	tmpStr.Format ("%d", m_lCPUSpeed);
	m_ListCtrl.SetItemText (1, 1, tmpStr);
	m_pOutputFile->Write (tmpStr, tmpStr.GetLength ());

	m_pOutputFile->Write (LINEBREAK_STR, (UINT)strlen (LINEBREAK_STR));

	item.iItem = 2;
	item.pszText = _T ("Number Of Processors");
	m_ListCtrl.InsertItem (&item);

	m_pOutputFile->Write (item.pszText, (UINT)strlen (item.pszText));
	padStr = _T ("\t\t\t");
	m_pOutputFile->Write (padStr, padStr.GetLength ());

	tmpStr.Format ("%d", m_lNumberOfProcessors);
	m_ListCtrl.SetItemText (2, 1, tmpStr);
	m_pOutputFile->Write (tmpStr, tmpStr.GetLength ());
	m_pOutputFile->Write (LINEBREAK_STR, (UINT)strlen (LINEBREAK_STR));

	item.iItem = 3;
	item.pszText = _T ("Processor Architecture");
	m_ListCtrl.InsertItem (&item);

	m_pOutputFile->Write (item.pszText, (UINT)strlen (item.pszText));
	padStr = _T ("\t\t\t");
	m_pOutputFile->Write (padStr, padStr.GetLength ());

	m_ListCtrl.SetItemText (3, 1, CString (m_bstrArchitecture));

	m_pOutputFile->Write (CString (m_bstrArchitecture), CString (m_bstrArchitecture).GetLength ());
	m_pOutputFile->Write (LINEBREAK_STR, (UINT)strlen (LINEBREAK_STR));

	item.iItem = 4;
	item.pszText = _T ("Processor Type");
	m_ListCtrl.InsertItem (&item);

	m_pOutputFile->Write (item.pszText, (UINT)strlen (item.pszText));
	padStr = _T ("\t\t\t");
	m_pOutputFile->Write (padStr, padStr.GetLength ());

	m_ListCtrl.SetItemText (4, 1, CString (m_bstrCPUType));

	m_pOutputFile->Write (CString (m_bstrCPUType), CString (m_bstrCPUType).GetLength ());
	m_pOutputFile->Write (LINEBREAK_STR, (UINT)strlen (LINEBREAK_STR));

	item.iItem = 5;
	item.pszText = _T ("Processor Level");
	m_ListCtrl.InsertItem (&item);
	m_ListCtrl.SetItemText (5, 1, CString (m_bstrCPULevel));

	item.iItem = 6;
	item.pszText = _T ("Processor Revision");
	m_ListCtrl.InsertItem (&item);
	m_ListCtrl.SetItemText (6, 1, CString (m_bstrRevision));

	item.iItem = 7;
	item.pszText = _T ("Active Processor Mask");
	m_ListCtrl.InsertItem (&item);

	tmpStr.Format ("%d", m_lActiveProcessorMask);
	m_ListCtrl.SetItemText (7, 1, tmpStr);

	item.iItem = 8;
	item.pszText = _T ("Page Size");
	m_ListCtrl.InsertItem (&item);

	tmpStr.Format ("%d", m_lPageSize);
	m_ListCtrl.SetItemText (8, 1, tmpStr);
}

