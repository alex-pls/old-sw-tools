// Disclaimer and Copyright Information
// SystemApplicationDlg.cpp : Implementation file
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////

// Revision History:
//
//	2/12/2001	Added Context Menu Support
//	2/26/2002	Added PnP Devices Page

#include "stdafx.h"
#include "SystemApplication.h"
#include "SystemApplicationDlg.h"
#include "DlgProxy.h"
#include <iostream.h>

#include "AppOptionsDlg.h"		// Definition Of Options Dialog Box

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_TIME,
};

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/******************************************************************************
*	Function:
*
*	Parameters:
*
*	Returns:
*
*	Description:
*
******************************************************************************/
CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

/******************************************************************************
*	Function:
*
*	Parameters:
*
*	Returns:
*
*	Description:
*
******************************************************************************/
void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSystemApplicationDlg dialog

IMPLEMENT_DYNAMIC(CSystemApplicationDlg, CDialog);

/******************************************************************************
*	Function:
*
*	Parameters:
*
*	Returns:
*
*	Description:
*
******************************************************************************/
CSystemApplicationDlg::CSystemApplicationDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSystemApplicationDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSystemApplicationDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDI_APP_ICON);
	m_pAutoProxy = NULL;
	m_bIsOutputFileOpen = false;
	m_pSystemInfo = NULL;
}

/******************************************************************************
*	Function:
*
*	Parameters:
*
*	Returns:
*
*	Description:
*
******************************************************************************/
CSystemApplicationDlg::~CSystemApplicationDlg()
{
	// If there is an automation proxy for this dialog, set
	//  its back pointer to this dialog to NULL, so it knows
	//  the dialog has been deleted.
	if (m_pAutoProxy != NULL)
	{
		m_pAutoProxy->m_pDialog = NULL;
	}

	// Release the interface pointer.

	if (m_pSystemInfo != NULL)
	{
		m_pSystemInfo->Release ();
	}
	m_pSystemInfo = NULL;
}

/******************************************************************************
*	Function:
*
*	Parameters:
*
*	Returns:
*
*	Description:
*
******************************************************************************/
void CSystemApplicationDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSystemApplicationDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSystemApplicationDlg, CDialog)
	//{{AFX_MSG_MAP(CSystemApplicationDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_DESTROY()
	ON_WM_CLOSE()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_UPDATE_COMMAND_UI(ID_INDICATOR_TIME, OnUpdateTimeIndicator)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(ID_HELP, OnHelp)
	ON_WM_CONTEXTMENU()
	ON_COMMAND(ID_SYS_ABOUTSYSTEMAPPLICATION, OnAppAbout)
	ON_COMMAND(ID_SYS_OPTIONS, OnAppOptions)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSystemApplicationDlg message handlers

/******************************************************************************
*	Function:
*
*	Parameters:
*
*	Returns:
*
*	Description:
*
******************************************************************************/
BOOL CSystemApplicationDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Create the status bar.

	if (!m_wndStatusBar.Create(this) ||
		!CreateStatusBarFont () ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}
	
	// Make a sunken or recessed border around the first pane
	m_wndStatusBar.SetPaneInfo(0, m_wndStatusBar.GetItemID(0),
		SBPS_STRETCH, NULL );

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// Before we start creating property pages, get the pointer to interface pointer.
	CreateInterfacePointer ();

	// Create the output file.
	OpenOutputFile ();

	try {
		m_OSInfoPage.SetSystemInfo (m_pSystemInfo, &m_fOutputFile);
		m_CPUInfoPage.SetSystemInfo (m_pSystemInfo, &m_fOutputFile);
		m_MemoryInfoPage.SetSystemInfo (m_pSystemInfo, &m_fOutputFile);
		m_MouseInfoPage.SetSystemInfo (m_pSystemInfo, &m_fOutputFile);
		m_HDiskInfoPage.SetSystemInfo (m_pSystemInfo, &m_fOutputFile);
		m_StorageInfoPage.SetSystemInfo (m_pSystemInfo, &m_fOutputFile);
		m_MiscInfoPage.SetSystemInfo (m_pSystemInfo, &m_fOutputFile);
		m_MMediaInfoPage.SetSystemInfo (m_pSystemInfo, &m_fOutputFile);
		m_ProtectedFilesPage.SetSystemInfo (m_pSystemInfo, &m_fOutputFile);
//		m_HWDevicesPage.SetSystemInfo (m_pSystemInfo, &m_fOutputFile);
//		m_NetworkInfoPage.SetSystemInfo (m_pSystemInfo, &m_fOutputFile);
		m_LocaleInfoPage.SetSystemInfo (m_pSystemInfo, &m_fOutputFile);
//		m_PnPDevicesPage.SetSystemInfo (m_pSystemInfo, &m_fOutputFile);
		m_KeyBoardInfoPage.SetSystemInfo (m_pSystemInfo, &m_fOutputFile);
	}
	catch (CMemoryException *e)
	{
		e->ReportError ();
		e->Delete ();
		return TRUE;
	}

	// Add each page to property sheet.

	m_PropSheet.AddPage (&m_CPUInfoPage);
	m_PropSheet.AddPage (&m_OSInfoPage);
	m_PropSheet.AddPage (&m_MemoryInfoPage);
	m_PropSheet.AddPage (&m_MouseInfoPage);
	m_PropSheet.AddPage (&m_HDiskInfoPage);
	m_PropSheet.AddPage (&m_StorageInfoPage);
	m_PropSheet.AddPage (&m_MiscInfoPage);
	m_PropSheet.AddPage (&m_MMediaInfoPage);
	m_PropSheet.AddPage (&m_ProtectedFilesPage);
//	m_PropSheet.AddPage (&m_HWDevicesPage);
//	m_PropSheet.AddPage (&m_NetworkInfoPage);
	m_PropSheet.AddPage (&m_LocaleInfoPage);
//	m_PropSheet.AddPage (&m_PnPDevicesPage);
	m_PropSheet.AddPage (&m_KeyBoardInfoPage);

	// Now create the property sheet.

	m_PropSheet.Create (this, WS_CHILD | WS_VISIBLE, 0);
	m_PropSheet.ModifyStyleEx (0, WS_EX_CONTROLPARENT);
	m_PropSheet.ModifyStyle (0, WS_TABSTOP);

	CRect rcSheet;

	GetDlgItem (IDC_PICTURE_STATIC)->GetWindowRect (&rcSheet);
	ScreenToClient (&rcSheet);
	m_PropSheet.SetWindowPos (NULL, rcSheet.left - 7, rcSheet.top - 7, 0, 0,
		SWP_NOZORDER | SWP_NOSIZE | SWP_NOACTIVATE);
	
	// Instead of using single row of tabs, use stacked row.

	m_PropSheet.EnableStackedTabs (TRUE);
	
	RepositionBars(AFX_IDW_CONTROLBAR_FIRST, AFX_IDW_CONTROLBAR_LAST, 0);

	m_nIDTimer = ::SetTimer(NULL, 0, 1000, TimerProc);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

/******************************************************************************
*	Function:
*
*	Parameters:
*
*	Returns:
*
*	Description:
*
******************************************************************************/
void CSystemApplicationDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

/******************************************************************************
*	Function:
*
*	Parameters:
*
*	Returns:
*
*	Description:
*
******************************************************************************/
void CSystemApplicationDlg::OnDestroy()
{
	WinHelp(0L, HELP_QUIT);
	CDialog::OnDestroy();
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSystemApplicationDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSystemApplicationDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

/******************************************************************************
*	Function:
*
*	Parameters:
*
*	Returns:
*
*	Description:
*
******************************************************************************/
void CSystemApplicationDlg::OnUpdateTimeIndicator(CCmdUI* pCmdUI)
{
	CTime t = CTime::GetCurrentTime();
	char szTime[6];
    int nHour = t.GetHour();
	int nMinute = t.GetMinute();
    // Base Hours on 12 instead of 24
	if (nHour > 12) {
		nHour = nHour - 12;
	}
	wsprintf(szTime, "%i:%02i", nHour, nMinute);
	// Now set the text of the pane.
	m_wndStatusBar.SetPaneText(m_wndStatusBar.CommandToIndex(ID_INDICATOR_TIME),
               LPCSTR(szTime));

	pCmdUI->Enable();
}

// Automation servers should not exit when a user closes the UI
//  if a controller still holds on to one of its objects.  These
//  message handlers make sure that if the proxy is still in use,
//  then the UI is hidden but the dialog remains around if it
//  is dismissed.

void CSystemApplicationDlg::OnClose() 
{
	if (CanExit())
		CDialog::OnClose();
}

/******************************************************************************
*	Function:
*
*	Parameters:
*
*	Returns:
*
*	Description:
*
******************************************************************************/
void CSystemApplicationDlg::OnOK() 
{
	if (CanExit())
		CDialog::OnOK();
}

/******************************************************************************
*	Function:
*
*	Parameters:
*
*	Returns:
*
*	Description:
*
******************************************************************************/
void CSystemApplicationDlg::OnCancel() 
{
	if (CanExit())
		CDialog::OnCancel();
}

/******************************************************************************
*	Function:
*
*	Parameters:
*
*	Returns:
*
*	Description:
*
******************************************************************************/
BOOL CSystemApplicationDlg::CanExit()
{
	// If the proxy object is still around, then the automation
	//  controller is still holding on to this application.  Leave
	//  the dialog around, but hide its UI.
	if (m_pAutoProxy != NULL)
	{
		ShowWindow(SW_HIDE);
		return FALSE;
	}

	return TRUE;
}

/******************************************************************************
*	Function:
*
*	Parameters:
*
*	Returns:
*
*	Description:
*
******************************************************************************/
VOID CALLBACK CSystemApplicationDlg::TimerProc(HWND hwnd, UINT uMsg, UINT uIDEvent,
											  DWORD dwTime)
{
	CSystemApplicationDlg *pMainWnd = (CSystemApplicationDlg *)AfxGetApp()->m_pMainWnd;
	ASSERT(uIDEvent == pMainWnd->m_nIDTimer);
	CCmdUI cui;
	cui.m_nID = ID_INDICATOR_TIME;
	cui.m_nIndex = 4;
	cui.m_pMenu = NULL;
	cui.m_pOther = &pMainWnd->m_wndStatusBar;
	pMainWnd->OnUpdateTimeIndicator(&cui);
}

/******************************************************************************
*	Function:
*
*	Parameters:
*
*	Returns:
*
*	Description:
*
******************************************************************************/
void CSystemApplicationDlg::CreateInterfacePointer ()
{
	HRESULT hr = E_FAIL;

	hr = ::CoCreateInstance (CLSID_SystemInformation, NULL, CLSCTX_SERVER , IID_ISystemInformation,
							reinterpret_cast<void **>(&m_pSystemInfo));
	if (FAILED (hr) || m_pSystemInfo == NULL) {
		AfxMessageBox (_T ("Application Failed to create SystemInformation Intrface"),
			MB_ICONSTOP);
		VERIFY (FALSE);
	}
}

/******************************************************************************
*	Function:
*
*	Parameters:
*
*	Returns:
*
*	Description:
*
******************************************************************************/
bool CSystemApplicationDlg::CreateStatusBarFont ()
{
	LOGFONT lFont;
	::ZeroMemory (&lFont, sizeof (lFont));

	lFont.lfWidth = 0;
	lFont.lfEscapement = 0;
	lFont.lfOrientation = 0;
	lFont.lfWeight = FW_BOLD;
	lFont.lfItalic = FALSE;
	lFont.lfUnderline = FALSE;
	lFont.lfCharSet = DEFAULT_CHARSET;
	lFont.lfQuality = DEFAULT_QUALITY;
	lFont.lfPitchAndFamily = VARIABLE_PITCH | FF_ROMAN;

	// Create the Font.

	if (!m_StatusBarFont.CreateFontIndirect (&lFont)) {
		return (false);
	}

	m_wndStatusBar.SetFont (&m_StatusBarFont);

	return (true);
}

/******************************************************************************
*	Function:
*
*	Parameters:
*
*	Returns:
*
*	Description:
*
******************************************************************************/
bool CSystemApplicationDlg::OpenOutputFile ()
{
	CFileFind finder;
	CFileException fileException;
	UINT openFlags;
	
	TCHAR  szPath[MAX_PATH];
	TCHAR  szDrive[_MAX_DRIVE];
	TCHAR  szDir[MAX_PATH];
	TCHAR  szAppPath[MAX_PATH];
	::GetModuleFileName (AfxGetInstanceHandle( ), szPath, MAX_PATH);
    _tsplitpath( szPath, szDrive, szDir, NULL, NULL );
    _tmakepath( szAppPath, szDrive, szDir, NULL, NULL );

	CString strInfoFile (szAppPath);
	strInfoFile += INFOFILE_TXT;

	// Check if the file already exists.
	BOOL bFound = finder.FindFile(strInfoFile);

	if (bFound)
	{
		TRY
		{
			CFile::Remove (strInfoFile);
		}
		CATCH (CFileException, fileException)
		{
#ifdef _DEBUG
			afxDump << "File " << strInfoFile << " cannot be removed\n";
#endif
		}
		END_CATCH
	}

	// If the file doesn't exis, then create one!

	openFlags = CFile::modeCreate | CFile::modeWrite;

	if (!m_fOutputFile.Open (strInfoFile, openFlags, &fileException)) {
#ifdef _DEBUG
		afxDump << "File could not be opened " << fileException.m_cause << "\n";
#endif
		return false;
	}

	m_bIsOutputFileOpen = true;

	return m_bIsOutputFileOpen;
}

/******************************************************************************
*	Function:
*
*	Parameters:
*
*	Returns:
*
*	Description:
*
******************************************************************************/
void CSystemApplicationDlg::OnHelp(void)
{
	// TODO: Add your control notification handler code here
}

/******************************************************************************
*	Function:
*
*	Parameters:
*
*	Returns:
*
*	Description:
*
******************************************************************************/
void CSystemApplicationDlg::OnContextMenu(CWnd* pWnd, CPoint point)
{
	// Load context menu.
	CMenu menu;
	menu.LoadMenu (IDR_OPTIONS_MENU);

	// Get popup menu from first submenu.
	CMenu *pPopupMenu = menu.GetSubMenu (0);
	ASSERT_VALID (pPopupMenu);

	pPopupMenu->TrackPopupMenu (TPM_LEFTALIGN | TPM_LEFTBUTTON,
								point.x,
								point.y,
								AfxGetMainWnd (),
								NULL);
}

/******************************************************************************
*	Function:
*
*	Parameters:
*
*	Returns:
*
*	Description:
*
******************************************************************************/
void CSystemApplicationDlg::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal ();
}

/******************************************************************************
*	Function:
*
*	Parameters:
*
*	Returns:
*
*	Description:
*
******************************************************************************/
void CSystemApplicationDlg::OnAppOptions()
{
	CAppOptionsDlg optDlg;
	optDlg.DoModal ();
}