// PnPDevice.h : Declaration of the CPnPDevice

#pragma once
#include "resource.h"       // main symbols
#include "PnPDeviceDrivers.h"



// CPnPDevice

class ATL_NO_VTABLE CPnPDevice : 
	public CComObjectRootEx<CComSingleThreadModel>,
//	public CComCoClass<CPnPDevice, &CLSID_PnPDevice>,
	public ISupportErrorInfo,
	public IDispatchImpl<IPnPDevice, &IID_IPnPDevice, &LIBID_SYSTEMPNPDEVICESLib, /*wMajor =*/ 1, /*wMinor =*/ 0>
{
public:
	CPnPDevice()
	{
	}

//DECLARE_REGISTRY_RESOURCEID(IDR_PNPDEVICE)


BEGIN_COM_MAP(CPnPDevice)
	COM_INTERFACE_ENTRY(IPnPDevice)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		m_pDrivers = NULL;
		return S_OK;
	}
	
	void FinalRelease() 
	{
		if (NULL != m_pDrivers)
		{
			m_pDrivers->Release ();
		}
		m_pDrivers = NULL;
	}

public:

	STDMETHODIMP get_Description(BSTR* pVal);
	STDMETHODIMP get_HardwareID(BSTR* pVal);
	STDMETHODIMP get_ClassGUID(BSTR* pVal);
	STDMETHODIMP get_Driver(BSTR* pVal);
	STDMETHODIMP get_Manufacturer(BSTR* pVal);
	STDMETHODIMP get_FriendlyName(BSTR* pVal);
	STDMETHODIMP get_DeviceType(BSTR* pVal);
	STDMETHODIMP get_VendorID(BSTR* pVal);
	STDMETHODIMP get_ProductID(BSTR* pVal);
	STDMETHODIMP get_ProductRevision(BSTR* pVal);
	STDMETHODIMP get_SerialNumber(BSTR* pVal);

protected:
	CComBSTR m_bstrDescription;
	CComBSTR m_bstrHWId;
	CComBSTR m_bstrClassGUID;
	CComBSTR m_bstrDriver;
	CComBSTR m_bstrMfg;
	CComBSTR m_bstrFriendlyName;
	CComBSTR m_bstrDeviceType;
	CComBSTR m_bstrVendorID;
	CComBSTR m_bstrProductID;
	CComBSTR m_bstrProductRevision;
	CComBSTR m_bstrSerialNumber;
	IPnPDeviceDrivers *m_pDrivers;

	friend class CPnPDevicesInfo;
public:
	STDMETHODIMP get_DeviceDrivers(IPnPDeviceDrivers** pVal);
};

//OBJECT_ENTRY_AUTO(__uuidof(PnPDevice), CPnPDevice)
