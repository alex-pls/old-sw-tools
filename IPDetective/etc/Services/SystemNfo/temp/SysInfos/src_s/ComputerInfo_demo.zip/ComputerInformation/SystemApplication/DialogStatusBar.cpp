// Disclaimer and Copyright Information
// DialogStatusBar.cpp : Implementation file
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "DialogStatusBar.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDialogStatusBar

CDialogStatusBar::CDialogStatusBar()
{
}

CDialogStatusBar::~CDialogStatusBar()
{
}


BEGIN_MESSAGE_MAP(CDialogStatusBar, CStatusBar)
	//{{AFX_MSG_MAP(CDialogStatusBar)
		ON_MESSAGE (WM_IDLEUPDATECMDUI,OnIdleUpdateCmdUI)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDialogStatusBar message handlers

LRESULT CDialogStatusBar::OnIdleUpdateCmdUI(WPARAM wParam, LPARAM lParam)
{
	if (IsWindowVisible()) {
		CFrameWnd* pParent = (CFrameWnd*)GetParent();
		if (pParent) {
			OnUpdateCmdUI(pParent, (BOOL)wParam);
		}
	}
	return 0L;
}
