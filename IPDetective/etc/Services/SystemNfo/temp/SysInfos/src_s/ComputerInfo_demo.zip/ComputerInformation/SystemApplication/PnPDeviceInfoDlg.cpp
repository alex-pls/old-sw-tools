// PnPDeviceInfoDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SystemApplication.h"
#include "PnPDeviceInfoDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// PnPDeviceInfoDlg dialog


PnPDeviceInfoDlg::PnPDeviceInfoDlg(LV_ITEM *pItem, CWnd* pParent /*=NULL*/)
	: CDialog(PnPDeviceInfoDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(PnPDeviceInfoDlg)
	m_strDescription = _T("");
	m_strType = _T("");
	m_strClassGUID = _T("");
	m_strSerialNumber = _T("");
	m_strVendor = _T("");
	m_strDetails = _T("");
	//}}AFX_DATA_INIT

	ASSERT (NULL != pItem);
	if (NULL != pItem)
	{
		m_pListItem = pItem;
	}
}


void PnPDeviceInfoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(PnPDeviceInfoDlg)
	DDX_Control(pDX, IDC_DRIVER_DETAILS_RICHEDIT, m_wndDetailsEdit);
	DDX_Control(pDX, IDC_DRIVERS_LIST, m_wndDriversList);
	DDX_Control(pDX, IDC_CLASSGUID_EDIT, m_wndClassGUID);
	DDX_Control(pDX, IDC_VENDOR_EDIT, m_wndVendor);
	DDX_Control(pDX, IDC_SERIAL_NUMBER_EDIT, m_wndSerialNumber);
	DDX_Control(pDX, IDC_DEVICETYPE_EDIT, m_wndType);
	DDX_Control(pDX, IDC_DESC_EDIT, m_wndDescription);
	DDX_Text(pDX, IDC_DESC_EDIT, m_strDescription);
	DDX_Text(pDX, IDC_DEVICETYPE_EDIT, m_strType);
	DDX_Text(pDX, IDC_CLASSGUID_EDIT, m_strClassGUID);
	DDX_Text(pDX, IDC_SERIAL_NUMBER_EDIT, m_strSerialNumber);
	DDX_Text(pDX, IDC_VENDOR_EDIT, m_strVendor);
	DDX_Text(pDX, IDC_DRIVER_DETAILS_RICHEDIT, m_strDetails);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(PnPDeviceInfoDlg, CDialog)
	//{{AFX_MSG_MAP(PnPDeviceInfoDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// PnPDeviceInfoDlg message handlers

BOOL PnPDeviceInfoDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	if (NULL != m_pListItem)
	{
		this->InitControlsData ();
	}
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void PnPDeviceInfoDlg::InitControlsData ()
{
}