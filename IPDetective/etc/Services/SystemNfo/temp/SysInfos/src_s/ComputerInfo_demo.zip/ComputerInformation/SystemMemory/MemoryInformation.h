// Disclaimer and Copyright Information
// MemoryInformation.h : 
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////

#ifndef __MEMORYINFORMATION_H_
#define __MEMORYINFORMATION_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CMemoryInformation
class ATL_NO_VTABLE CMemoryInformation : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CMemoryInformation, &CLSID_MemoryInformation>,
	public ISupportErrorInfo,
	public IDispatchImpl<IMemoryInformation, &IID_IMemoryInformation, &LIBID_SYSTEMMEMORYLib>
{
public:
	CMemoryInformation()
	{
		m_bInformationObtained = false;
		m_lRAMInstalled = 0;
		m_lMemoryAvailable = 0;
		m_lVirtualMemory = 0;
		m_sMemoryLoad = 0;
	}

DECLARE_REGISTRY_RESOURCEID(IDR_MEMORYINFORMATION)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CMemoryInformation)
	COM_INTERFACE_ENTRY(IMemoryInformation)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IMemoryInformation
public:
	STDMETHOD(GetMemoryInformation)(/*[out]*/ long *plRAMInstalled,
		/*[out]*/ long *plAvailablememory, /*[out]*/ long *plVirtualMemory,
		/*[out]*/ long *plMemoryLoad);
	STDMETHOD(get_MemoryLoad)(/*[out, retval]*/ long *pVal);
	STDMETHOD(get_VirtualMemory)(/*[out, retval]*/ long *pVal);
	STDMETHOD(get_MemoryAvailable)(/*[out, retval]*/ long *pVal);
	STDMETHOD(get_RAMInstalled)(/*[out, retval]*/ long *pVal);

	long m_lRAMInstalled;
	long m_lMemoryAvailable;
	long m_lVirtualMemory;
	long m_sMemoryLoad;

private:
	bool m_bInformationObtained;
	HRESULT GetInformation ();
};

#endif //__MEMORYINFORMATION_H_
