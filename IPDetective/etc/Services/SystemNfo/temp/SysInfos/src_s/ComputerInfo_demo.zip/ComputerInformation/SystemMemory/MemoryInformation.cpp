// Disclaimer and Copyright Information
// MemoryInformation.cpp
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SystemMemory.h"
#include "MemoryInformation.h"

/////////////////////////////////////////////////////////////////////////////
// CMemoryInformation

STDMETHODIMP CMemoryInformation::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IMemoryInformation
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (::InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CMemoryInformation::get_RAMInstalled(long *pVal)
{
	HRESULT hRes = S_OK;
	if ((hRes = GetInformation ()) != S_OK)
	{
		return hRes;
	}

	*pVal = m_lRAMInstalled;

	return S_OK;
}

STDMETHODIMP CMemoryInformation::get_MemoryAvailable(long *pVal)
{
	HRESULT hRes = S_OK;
	if ((hRes = GetInformation ()) != S_OK)
	{
		return hRes;
	}

	*pVal = m_lMemoryAvailable;

	return S_OK;
}

STDMETHODIMP CMemoryInformation::get_VirtualMemory(long *pVal)
{
	HRESULT hRes = S_OK;
	if ((hRes = GetInformation ()) != S_OK)
	{
		return hRes;
	}

	*pVal = m_lVirtualMemory;

	return S_OK;
}

STDMETHODIMP CMemoryInformation::get_MemoryLoad(long *pVal)
{
	HRESULT hRes = S_OK;
	if ((hRes = GetInformation ()) != S_OK)
	{
		return hRes;
	}

	*pVal = m_sMemoryLoad;

	return S_OK;
}

STDMETHODIMP CMemoryInformation::GetMemoryInformation(long *plRAMInstalled,
													  long *plAvailablememory,
													  long *plVirtualMemory,
													  long *psMemoryLoad)
{
	HRESULT hRes = S_OK;
	if ((hRes = GetInformation ()) != S_OK)
	{
		return hRes;
	}

	*plRAMInstalled	= m_lRAMInstalled;
	*plAvailablememory = m_lMemoryAvailable;
	*plVirtualMemory = m_lVirtualMemory;
	*psMemoryLoad = m_sMemoryLoad;

	return S_OK;
}

HRESULT CMemoryInformation::GetInformation ()
{
	HRESULT hRes = S_OK;
	MEMORYSTATUS memoryStatus;

	if (m_bInformationObtained)
	{
		return S_OK;
	}

	memset (&memoryStatus, sizeof (MEMORYSTATUS), 0);
	memoryStatus.dwLength = sizeof (MEMORYSTATUS);

	// The function below doesn't return a value.

	::GlobalMemoryStatus (&memoryStatus);

	m_sMemoryLoad = memoryStatus.dwMemoryLoad;
	m_lRAMInstalled = memoryStatus.dwTotalPhys;
	m_lMemoryAvailable = memoryStatus.dwAvailPhys;
	m_lVirtualMemory = memoryStatus.dwTotalVirtual;

	m_bInformationObtained = true;

	return S_OK;
}