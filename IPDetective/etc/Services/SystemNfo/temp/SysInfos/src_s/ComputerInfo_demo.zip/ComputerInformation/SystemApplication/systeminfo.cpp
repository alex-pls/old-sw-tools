// Machine generated IDispatch wrapper class(es) created with ClassWizard

#include "stdafx.h"
#include "systeminfo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif



/////////////////////////////////////////////////////////////////////////////
// ISystemInformation properties

/////////////////////////////////////////////////////////////////////////////
// ISystemInformation operations

void ISystemInformation::GetOSInformation(BSTR* pbstrPlatform, BSTR* pbstrMinorVersion, BSTR* pbstrServicePack, long* plBuildNumber)
{
	static BYTE parms[] =
		VTS_PBSTR VTS_PBSTR VTS_PBSTR VTS_PI4;
	InvokeHelper(0x60020000, DISPATCH_METHOD, VT_EMPTY, NULL, parms,
		 pbstrPlatform, pbstrMinorVersion, pbstrServicePack, plBuildNumber);
}

void ISystemInformation::GetMouseInformation(BOOL* pbInstalled, BOOL* pbButtonsSwapped, long* plSpeed)
{
	static BYTE parms[] =
		VTS_PBOOL VTS_PBOOL VTS_PI4;
	InvokeHelper(0x60020001, DISPATCH_METHOD, VT_EMPTY, NULL, parms,
		 pbInstalled, pbButtonsSwapped, plSpeed);
}

void ISystemInformation::GetCPUInformation(BSTR* pbstrVendor, BSTR* pbstrType, BSTR* pbstrArchitecture, BSTR* pbstrLevel, BSTR* pbstrRevision, long* plNumberOfProcessors, long* plSpeed, long* plPageSize, long* plMask)
{
	static BYTE parms[] =
		VTS_PBSTR VTS_PBSTR VTS_PBSTR VTS_PBSTR VTS_PBSTR VTS_PI4 VTS_PI4 VTS_PI4 VTS_PI4;
	InvokeHelper(0x60020002, DISPATCH_METHOD, VT_EMPTY, NULL, parms,
		 pbstrVendor, pbstrType, pbstrArchitecture, pbstrLevel, pbstrRevision, plNumberOfProcessors, plSpeed, plPageSize, plMask);
}

void ISystemInformation::GetHDiskInformation(long* plNumberOfPartitions, VARIANT* pbstrDriveLetterArr, VARIANT* pbBootableArr, VARIANT* pbstrTypeArr, VARIANT* plPartitionNumberArr, VARIANT* plLengthArr, VARIANT* plHiddenSectorsArr)
{
	static BYTE parms[] =
		VTS_PI4 VTS_PVARIANT VTS_PVARIANT VTS_PVARIANT VTS_PVARIANT VTS_PVARIANT VTS_PVARIANT;
	InvokeHelper(0x60020003, DISPATCH_METHOD, VT_EMPTY, NULL, parms,
		 plNumberOfPartitions, pbstrDriveLetterArr, pbBootableArr, pbstrTypeArr, plPartitionNumberArr, plLengthArr, plHiddenSectorsArr);
}

void ISystemInformation::GetMemoryInformation(long* plRAMInstalled, long* plAvailableMemory, long* plVirtualMemory, long* plMemoryLoad)
{
	static BYTE parms[] =
		VTS_PI4 VTS_PI4 VTS_PI4 VTS_PI4;
	InvokeHelper(0x60020004, DISPATCH_METHOD, VT_EMPTY, NULL, parms,
		 plRAMInstalled, plAvailableMemory, plVirtualMemory, plMemoryLoad);
}

void ISystemInformation::GetStorageMediaInformation(long* plNumberOfDrives, VARIANT* pbReadyArr, VARIANT* pbstrDriveLetterArr, VARIANT* pbstrLabelArr, VARIANT* pbSupportLongNameArr, VARIANT* pbstrFileSystemArr, VARIANT* pbstrMediaTypeArr, 
		VARIANT* plTotalSpaceArr, VARIANT* plFreeSpaceUserArr, VARIANT* plFreeSpaceTotalArr)
{
	static BYTE parms[] =
		VTS_PI4 VTS_PVARIANT VTS_PVARIANT VTS_PVARIANT VTS_PVARIANT VTS_PVARIANT VTS_PVARIANT VTS_PVARIANT VTS_PVARIANT VTS_PVARIANT;
	InvokeHelper(0x60020005, DISPATCH_METHOD, VT_EMPTY, NULL, parms,
		 plNumberOfDrives, pbReadyArr, pbstrDriveLetterArr, pbstrLabelArr, pbSupportLongNameArr, pbstrFileSystemArr, pbstrMediaTypeArr, plTotalSpaceArr, plFreeSpaceUserArr, plFreeSpaceTotalArr);
}

void ISystemInformation::GetMultiMediaInformation(BOOL* pbIsInstalled, BOOL* pbHasVolCtrl, BOOL* pbHasSeparateLRVolCtrl, BSTR* pbstrProductName, BSTR* pbstrCompanyName)
{
	static BYTE parms[] =
		VTS_PBOOL VTS_PBOOL VTS_PBOOL VTS_PBSTR VTS_PBSTR;
	InvokeHelper(0x60020006, DISPATCH_METHOD, VT_EMPTY, NULL, parms,
		 pbIsInstalled, pbHasVolCtrl, pbHasSeparateLRVolCtrl, pbstrProductName, pbstrCompanyName);
}

void ISystemInformation::GetComputerName(BSTR* pbstrComputerName)
{
	static BYTE parms[] =
		VTS_PBSTR;
	InvokeHelper(0x60020007, DISPATCH_METHOD, VT_EMPTY, NULL, parms,
		 pbstrComputerName);
}

void ISystemInformation::GetUserName_(BSTR* pbstrUserName)
{
	static BYTE parms[] =
		VTS_PBSTR;
	InvokeHelper(0x60020008, DISPATCH_METHOD, VT_EMPTY, NULL, parms,
		 pbstrUserName);
}

void ISystemInformation::GelLocalLanguage(BSTR* pbstrLocalLanguage)
{
	static BYTE parms[] =
		VTS_PBSTR;
	InvokeHelper(0x60020009, DISPATCH_METHOD, VT_EMPTY, NULL, parms,
		 pbstrLocalLanguage);
}
