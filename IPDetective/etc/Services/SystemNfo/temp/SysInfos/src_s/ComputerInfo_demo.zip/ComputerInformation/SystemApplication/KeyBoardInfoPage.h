// Disclaimer and Copyright Information
// Pardesi Services LLC.  Copyright (c) 2001
//						  All rights reserved.
// KeyBoardInfoPage.h : header file
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////

// Revision History:
//	4/16/2001	Initial Creation
//

#if !defined(AFX_KEYBOARDINFOPAGE_H__C092E6F8_DDDD_456E_BF01_D1A0EFE228E8__INCLUDED_)
#define AFX_KEYBOARDINFOPAGE_H__C092E6F8_DDDD_456E_BF01_D1A0EFE228E8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// KeyBoardInfoPage dialog

class KeyBoardInfoPage : public CPropertyPage
{
	DECLARE_DYNCREATE(KeyBoardInfoPage)

// Construction
public:
	KeyBoardInfoPage();
	~KeyBoardInfoPage();
	inline void SetSystemInfo (ISystemInformation *pSystemInfo = NULL, CFile *pFile = NULL);

// Dialog Data
	//{{AFX_DATA(KeyBoardInfoPage)
	enum { IDD = IDD_KEYBOARD_INFO_PAGE };
	CListCtrl	m_wndListCtrl;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(KeyBoardInfoPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(KeyBoardInfoPage)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	void SetListData ();
	CFile *m_pOutputFile;
	ISystemInformation *m_pSystemInfo;

	BSTR		m_bstrType;
	short		m_nFunctionKeys;
};

inline void
KeyBoardInfoPage::SetSystemInfo (ISystemInformation *pSystemInfo, CFile *pFile)
{
	ASSERT (pSystemInfo != NULL);
	m_pSystemInfo = pSystemInfo;
	m_pOutputFile = pFile;
}

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_KEYBOARDINFOPAGE_H__C092E6F8_DDDD_456E_BF01_D1A0EFE228E8__INCLUDED_)
