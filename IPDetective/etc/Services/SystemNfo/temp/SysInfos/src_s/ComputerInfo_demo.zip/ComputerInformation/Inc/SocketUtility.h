#pragma once

#include <string>
using namespace std;

typedef struct tagPROTOCOL_ATTRIB
{
	string Name;			// Name of the Protocol
	short Version;			// Protocol version
	string ProviderID;		// GUID of the Provider
	long CatalogEntryId;	// Unique Catalog Entry ID
	short Protocol;			// Protocol value
	short ByteOrder;		// Network byte order (LITTLEENDIAN, BIGENDIAN)
	long MinSockAddress;	// Min Socket Address
	long MaxSockAddress;	// Max Socket Address
	short AddressFamily;	// Address Family For Protocol
	short SecurityScheme;	// Security Scheme Used By Protocol
} PROTOCOL_ATTRIB;

class __declspec(dllexport) CSocketUtility
{
public:
	CSocketUtility(void);
	virtual ~CSocketUtility(void);
	bool Startup(void);
	bool ShutDown(void);
protected:
	long m_nRefCount;
public:
	bool GetIPAddress(const string& strHost, string& strAddress);
protected:
	// Windows Socket Version Used
	string m_strWSVersion;
	// Highest Version Of Windows Scoket That Can Be Used
	string m_strWSHiVersion;
public:
	bool GetWinSockVersion(string& strWSVersion, string& strWSHiVersion);
	bool GetIPInterfaces(void);
	bool IsInitialized(void);
	// Function enumerates all the availabe transport protocols
	bool EnumProtocols(long &lNumProtocols, PROTOCOL_ATTRIB **pAttributes);
};
