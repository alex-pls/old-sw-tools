// Disclaimer and Copyright Information
// LocaleInformation.cpp : Implementation of CLocaleInformation
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////
//

// Revision History:
//	2/10/2001	Initial Creation
//

#include "stdafx.h"
#include "SystemLocale.h"
#include "LocaleInformation.h"

/////////////////////////////////////////////////////////////////////////////
// CLocaleInformation

/******************************************************************************
 *	Function:
 *
 *	Parameters:
 *
 *	Returns:
 *
 *	Desscription:
 *
 *****************************************************************************/
STDMETHODIMP CLocaleInformation::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_ILocaleInformation
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (::InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

/******************************************************************************
 *	Function:
 *
 *	Parameters:
 *
 *	Returns:
 *
 *	Desscription:
 *
 *****************************************************************************/
STDMETHODIMP CLocaleInformation::get_CodePage(short* pVal)
{
	HRESULT hRes = S_OK;
	if ((hRes = GetInformation ()) != S_OK) {
		return hRes;
	}

	*pVal = this->m_sCodePage;
	return S_OK;
}

/******************************************************************************
 *	Function:
 *
 *	Parameters:
 *
 *	Returns:
 *
 *	Desscription:
 *
 *****************************************************************************/
HRESULT CLocaleInformation::GetInformation(void)
{
	if (m_bInfoGenerated)
	{
		return S_OK;
	}

	// Retrieves the active input locale identifier.
	HKL hKl = ::GetKeyboardLayout (0);

	// LOWORD of the returned value contains the language identifier.
	LANGID langID = LOWORD ((DWORD)hKl);

	// Retirieve the information about the locale.
	LCID lcID = MAKELCID (langID, SORT_DEFAULT);
	TCHAR chPage[7];
	TCHAR szCurrency[7];
	TCHAR szVal[MAX_PATH];
	TCHAR szFormatString[100];

	// Get currently ised code page.
	::GetLocaleInfo (lcID, LOCALE_IDEFAULTANSICODEPAGE, chPage, 7);
	this->m_sCodePage = atoi (chPage);

	// Get default OEM cod epage.
	::GetLocaleInfo (lcID, LOCALE_IDEFAULTCODEPAGE, chPage, 7);
	this->m_sOEMCodePage = atoi (chPage);
 
	// Get country name in english.
	::GetLocaleInfo (lcID, LOCALE_SENGCOUNTRY , szVal, MAX_PATH);
	this->m_bstrCountry = szVal;

	// Get language name.
	::GetLocaleInfo (lcID, LOCALE_SENGLANGUAGE , szVal, MAX_PATH);
	this->m_bstrLanguage = szVal;

	// Get TimeFormat String
	::GetLocaleInfo (lcID, LOCALE_STIMEFORMAT , szFormatString, 100);
	this->m_bstrTimeFormat = szFormatString;
	
	// Get Date Format String
	::GetLocaleInfo (lcID, LOCALE_SLONGDATE  , szFormatString, 100);
	this->m_bstrDateFormat = szFormatString;

	// Get the string used for local currency.
	::GetLocaleInfo (lcID, LOCALE_SCURRENCY, szCurrency, 7);
	this->m_bstrCurrency = szCurrency;

	// Get time format specifier i.e. 12 hour (AM/PM) or 24 hour format
	// is used to indicate time.
	::GetLocaleInfo (lcID, LOCALE_ITIME, szVal, 3);
	if (atoi (szVal) == 0)
	{
		this->m_bstrTimeFormatSpecifier = _T ("AM / PM 12-hour format");
	}
	else
	{
		this->m_bstrTimeFormatSpecifier = _T ("24-hour format");
	}
	
	// Get calendar type
	::GetLocaleInfo (lcID, LOCALE_ICALENDARTYPE, szVal, 3);
	switch (atoi (szVal))
	{
		case 1:
			this->m_bstrCalendarType = _T ("Gregorian - Localized");
			break;
		case 2:
			this->m_bstrCalendarType = _T ("Gregorian - English strings always");
			break;
		case 3:
			this->m_bstrCalendarType = _T ("Year of the Emperor - Japan");
			break;
		case 4:
			this->m_bstrCalendarType = _T ("Year of Taiwan");
			break;
		case 5:
			this->m_bstrCalendarType = _T ("Tangun Era - Korea");
			break;
		case 6:
			this->m_bstrCalendarType = _T ("Hijri - Arabic lunar");
			break;
		case 7:
			this->m_bstrCalendarType = _T ("Thai");
			break;
		case 8:
			this->m_bstrCalendarType = _T ("Hebrew - Lunar");
			break;
		case 9:
			this->m_bstrCalendarType = _T ("Gregorian Middle East French");
			break;
		case 10:
			this->m_bstrCalendarType = _T ("Gregorian Arabic");
			break;
		case 11:
			this->m_bstrCalendarType = _T ("Gregorian Transliterated English");
			break;
		case 12:
			this->m_bstrCalendarType = _T ("Gregorian Transliterated French");
			break;
		default:
			this->m_bstrCalendarType = _T ("Unknown");
	}

	return HRESULT();
}

/******************************************************************************
 *	Function:
 *
 *	Parameters:
 *
 *	Returns:
 *
 *	Desscription:
 *
 *****************************************************************************/
STDMETHODIMP CLocaleInformation::get_CalendarType(BSTR* pVal)
{
	HRESULT hRes = S_OK;
	if ((hRes = GetInformation ()) != S_OK) {
		return hRes;
	}

	*pVal = this->m_bstrCalendarType.Copy ();
	return S_OK;
}

/******************************************************************************
 *	Function:
 *
 *	Parameters:
 *
 *	Returns:
 *
 *	Desscription:
 *
 *****************************************************************************/
STDMETHODIMP CLocaleInformation::get_OEMCodePage(short* pVal)
{
	HRESULT hRes = S_OK;
	if ((hRes = GetInformation ()) != S_OK) {
		return hRes;
	}

	*pVal = this->m_sOEMCodePage;
	return S_OK;
}

/******************************************************************************
 *	Function:
 *
 *	Parameters:
 *
 *	Returns:
 *
 *	Desscription:
 *
 *****************************************************************************/
STDMETHODIMP CLocaleInformation::get_DateFormat(BSTR* pVal)
{
	HRESULT hRes = S_OK;
	if ((hRes = GetInformation ()) != S_OK) {
		return hRes;
	}

	*pVal = this->m_bstrDateFormat.Copy ();
	return S_OK;
}

/******************************************************************************
 *	Function:
 *
 *	Parameters:
 *
 *	Returns:
 *
 *	Desscription:
 *
 *****************************************************************************/
STDMETHODIMP CLocaleInformation::get_Language(BSTR* pVal)
{
	HRESULT hRes = S_OK;
	if ((hRes = GetInformation ()) != S_OK) {
		return hRes;
	}

	*pVal = this->m_bstrLanguage.Copy ();
	return S_OK;
}

/******************************************************************************
 *	Function:
 *
 *	Parameters:
 *
 *	Returns:
 *
 *	Desscription:
 *
 *****************************************************************************/
STDMETHODIMP CLocaleInformation::get_Country(BSTR* pVal)
{
	HRESULT hRes = S_OK;
	if ((hRes = GetInformation ()) != S_OK) {
		return hRes;
	}

	*pVal = this->m_bstrCountry.Copy ();
	return S_OK;
}

/******************************************************************************
 *	Function:
 *
 *	Parameters:
 *
 *	Returns:
 *
 *	Desscription:
 *
 *****************************************************************************/
STDMETHODIMP CLocaleInformation::get_CountryCode(short* pVal)
{
	HRESULT hRes = S_OK;
	if ((hRes = GetInformation ()) != S_OK) {
		return hRes;
	}

	*pVal = this->m_sCountryCode;
	return S_OK;
}

/******************************************************************************
 *	Function:
 *
 *	Parameters:
 *
 *	Returns:
 *
 *	Desscription:
 *
 *****************************************************************************/
STDMETHODIMP CLocaleInformation::get_TimeFormat(BSTR* pVal)
{
	HRESULT hRes = S_OK;
	if ((hRes = GetInformation ()) != S_OK) {
		return hRes;
	}

	*pVal = this->m_bstrTimeFormat.Copy ();
	return S_OK;
}

/******************************************************************************
 *	Function:
 *
 *	Parameters:
 *
 *	Returns:
 *
 *	Desscription:
 *
 *****************************************************************************/
STDMETHODIMP CLocaleInformation::get_Currency(BSTR* pVal)
{
	HRESULT hRes = S_OK;
	if ((hRes = GetInformation ()) != S_OK) {
		return hRes;
	}

	*pVal = this->m_bstrCurrency.Copy ();
	return S_OK;
}

/******************************************************************************
 *	Function:
 *
 *	Parameters:
 *
 *	Returns:
 *
 *	Desscription:
 *
 *****************************************************************************/
STDMETHODIMP CLocaleInformation::get_TimeFormatSpecifier(BSTR* pVal)
{
	HRESULT hRes = S_OK;
	if ((hRes = GetInformation ()) != S_OK) {
		return hRes;
	}

	*pVal = this->m_bstrTimeFormatSpecifier.Copy ();
	return S_OK;
}
