// Disclaimer and Copyright Information
// ProtectedFilesInfo.h : 
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////

#ifndef __PROTECTEDFILESINFO_H_
#define __PROTECTEDFILESINFO_H_

#include "resource.h"       // main symbols
#include <list>
#include <string>

/////////////////////////////////////////////////////////////////////////////
// ProtectedFilesInfo
class ATL_NO_VTABLE ProtectedFilesInfo : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<ProtectedFilesInfo, &CLSID_ProtectedFilesInfo>,
	public ISupportErrorInfo,
	public IDispatchImpl<IProtectedFilesInfo, &IID_IProtectedFilesInfo, &LIBID_SYSTEMPROTECTFILESLib>
{
public:
	ProtectedFilesInfo()
	{
		m_bInfoGenerated = false;
	}

DECLARE_REGISTRY_RESOURCEID(IDR_PROTECTEDFILESINFO)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(ProtectedFilesInfo)
	COM_INTERFACE_ENTRY(IProtectedFilesInfo)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IProtectedFilesInfo
public:
	STDMETHOD(GetProtectedFilesInfo)(/*[out]*/long *pNumOfFiles, /*[out]*/ VARIANT *pbstrFileNames);
	STDMETHOD(get_NumberOfProtectedFiles)(/*[out, retval]*/ long *pVal);

private:
	std::list<std::string> m_FileNamesList;
	SAFEARRAY *m_pbstrFileNames;
	long m_lNumberOfFiles;
	bool m_bInfoGenerated;
	HRESULT GetInformation ();
};

#endif //__PROTECTEDFILESINFO_H_
