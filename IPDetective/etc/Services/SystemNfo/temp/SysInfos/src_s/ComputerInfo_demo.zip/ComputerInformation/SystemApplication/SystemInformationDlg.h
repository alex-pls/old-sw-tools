// SystemInformationDlg.h : header file
//

#if !defined(AFX_SYSTEMINFORMATIONDLG_H__A7364AD7_B2D8_11D2_8C49_000000000000__INCLUDED_)
#define AFX_SYSTEMINFORMATIONDLG_H__A7364AD7_B2D8_11D2_8C49_000000000000__INCLUDED_

#include "SystemInfo.h"
#include "OSInfoPage.h"
#include "CpuInfoPage.h"
#include "MouseInfoPage.h"
#include "HDiskInfoPage.h"
#include "MemoryInfoPage.h"
#include "MiscInfoPage.h"
#include "StorageInfoPage.h"
#include "DialogStatusBar.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CSystemInformationDlg dialog

class CSystemInformationDlg : public CDialog
{
// Construction
public:
	CDialogStatusBar	m_wndStatusBar;
	CSystemInfo			m_SystemInfo;
	CPropertySheet		m_PropSheet;
	COSInfoPage			*m_pOSInfoPage;
	CCpuInfoPage		*m_pCPUInfoPage;
	CMemoryInfoPage		*m_pMemInfoPage;
	CMouseInfoPage		*m_pMouseInfoPage;
	CHDiskInfoPage		*m_pHDiskInfoPage;
	CMiscInfoPage		*m_pMiscInfoPage;
	CStorageInfoPage	*m_pStorageInfoPage;
	CSystemInformationDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CSystemInformationDlg)
	enum { IDD = IDD_SYSTEMINFORMATION_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSystemInformationDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

	static VOID CALLBACK TimerProc(HWND hwnd, UINT uMsg, UINT uIDEvent,
		DWORD dwTime);
// Implementation
protected:
	HICON m_hIcon;
	UINT m_nIDTimer;

	// Generated message map functions
	//{{AFX_MSG(CSystemInformationDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnDestroy();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnUpdateTimeIndicator(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void GetSystemInformation ();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SYSTEMINFORMATIONDLG_H__A7364AD7_B2D8_11D2_8C49_000000000000__INCLUDED_)
