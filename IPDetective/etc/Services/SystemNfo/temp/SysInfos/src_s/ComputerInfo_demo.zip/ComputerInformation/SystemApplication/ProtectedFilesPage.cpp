// Disclaimer and Copyright Information
// ProtectedFilesPage.cpp : Implementation file
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SystemApplication.h"
#include "ProtectedFilesPage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// ProtectedFilesPage property page

IMPLEMENT_DYNCREATE(ProtectedFilesPage, CPropertyPage)

ProtectedFilesPage::ProtectedFilesPage() : CPropertyPage(ProtectedFilesPage::IDD)
{
	//{{AFX_DATA_INIT(ProtectedFilesPage)
		// NOTE: the ClassWizard will add member initialization here
		m_lNumOfFiles = 0;
	//}}AFX_DATA_INIT
		m_pbstrFilesArr = NULL;
}

ProtectedFilesPage::~ProtectedFilesPage()
{
	if (m_pbstrFilesArr != NULL) {
		SafeArrayDestroy (m_pbstrFilesArr);
		m_pbstrFilesArr = NULL;
	}
}

void ProtectedFilesPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(ProtectedFilesPage)
	DDX_Control(pDX, IDC_SAFE_FILES_LIST, m_wndProtectedFilesList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(ProtectedFilesPage, CPropertyPage)
	//{{AFX_MSG_MAP(ProtectedFilesPage)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// ProtectedFilesPage message handlers

BOOL ProtectedFilesPage::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	VARIANT bstrFilesArr;
	if (FAILED (m_pSystemInfo->GetProtectedFilesInfo (&m_lNumOfFiles, &bstrFilesArr))) {
		return TRUE;
	}

	if (!(bstrFilesArr.vt & VT_BSTR)) {
		return TRUE;
	}
	
	if (bstrFilesArr.vt & VT_BYREF)
	{
		m_pbstrFilesArr = * (bstrFilesArr.pparray);
	}
	else
	{
		m_pbstrFilesArr = bstrFilesArr.parray;
	}

	SetListData ();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void ProtectedFilesPage::SetListData(void)
{
	CString tmpStr;
	LV_ITEM item;
	LV_COLUMN leftCol;

	leftCol.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	leftCol.fmt = LVCFMT_LEFT;
	leftCol.iSubItem = 0;
	leftCol.cx = 256;
	leftCol.pszText = _T ("File Name");

	m_wndProtectedFilesList.InsertColumn (0, &leftCol);

	BSTR tmpBstr;
	long lLBound, lUBound;
	SafeArrayGetLBound (m_pbstrFilesArr, 1, &lLBound);
	SafeArrayGetUBound (m_pbstrFilesArr, 1, &lUBound);

	for (long i = lLBound; i <= lUBound; i++) {
		item.mask = LVIF_TEXT;
		item.iItem = i;
		item.iSubItem = 0;
		item.pszText = _T (" ");
		m_wndProtectedFilesList.InsertItem (&item);

		SafeArrayGetElement (m_pbstrFilesArr, (long *) &i, &tmpBstr);
		m_wndProtectedFilesList.SetItemText (i, 0, CString (tmpBstr));
	}
}
