// Disclaimer and Copyright Information
// StorageMediaInformation.h : Declaration of the CStorageMediaInformation 
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////

#ifndef __STORAGEMEDIAINFORMATION_H_
#define __STORAGEMEDIAINFORMATION_H_

#include "resource.h"       // main symbols

class ATL_NO_VTABLE CStorageMediaInformation : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CStorageMediaInformation, &CLSID_StorageMediaInformation>,
	public ISupportErrorInfo,
	public IDispatchImpl<IStorageMediaInformation, &IID_IStorageMediaInformation, &LIBID_SYSTEMSTORAGELib>
{
public:
	CStorageMediaInformation()
	{
		m_bInformationObtained = false;
		m_NumberOfDrives = 0;
	}

DECLARE_REGISTRY_RESOURCEID(IDR_STORAGEMEDIAINFORMATION)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CStorageMediaInformation)
	COM_INTERFACE_ENTRY(IStorageMediaInformation)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IStorageMediaInformation
public:
	STDMETHOD(GetStorageMediaInformation)(/*[out]*/ long *plNumberOfDrives,
		/*[out]*/ VARIANT *pbReadyArr,  /*[out]*/ VARIANT *pbstrDriveLetterArr,
		/*[out]*/ VARIANT *pbstrLabelArr, /*[out]*/ VARIANT *pbSupportLongNameArr,
		/*[out]*/ VARIANT *pbstrFileSystemArr, /*[out]*/ VARIANT *pbstrMediaTypeArr,
		/*[out]*/ VARIANT *plTotalSpaceArr, /*[out]*/ VARIANT *plFreeSpaceUserArr,
		/*[out]*/ VARIANT *plFreeSpaceTotalArr);
	STDMETHOD(get_NumberOfDrives)(/*[out, retval]*/ long *pVal);

private:
	bool m_bInformationObtained;

	long m_NumberOfDrives;
	SAFEARRAY *m_pbDriveReady;
	SAFEARRAY *m_pbstrDriveLetter;
	SAFEARRAY *m_pbSupportLongName;
	SAFEARRAY *m_pbstrFileSystem;
	SAFEARRAY *m_pbstrDriveLabel;
	SAFEARRAY *m_pbstrMediaType;
	SAFEARRAY *m_plTotalSpace;
	SAFEARRAY *m_plFreeSpaceUser;
	SAFEARRAY *m_plFreeSpaceTotal;

	HRESULT GetInformation ();
	CComBSTR GetMediaType (DWORD dwType) const;
	HRESULT InitializeSafeArrays ();
};

#endif //__STORAGEMEDIAINFORMATION_H_
