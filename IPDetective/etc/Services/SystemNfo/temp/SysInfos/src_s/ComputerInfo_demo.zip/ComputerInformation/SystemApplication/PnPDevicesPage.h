#if !defined(AFX_PNPDEVICESPAGE_H__47E221B7_EEAA_43E9_981B_C268DCF398EC__INCLUDED_)
#define AFX_PNPDEVICESPAGE_H__47E221B7_EEAA_43E9_981B_C268DCF398EC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PnPDevicesPage.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// PnPDevicesPage dialog

#ifdef _DEBUG
	#import "..\Bin\Debug\SystemPnPDevices.dll" raw_interfaces_only, raw_native_types, no_namespace, named_guids
#else
	#import "..\Bin\Release\SystemPnPDevices.dll" raw_interfaces_only, raw_native_types, no_namespace, named_guids
#endif

class PnPDevicesPage : public CPropertyPage
{
	DECLARE_DYNCREATE(PnPDevicesPage)

// Construction
public:
	PnPDevicesPage();
	~PnPDevicesPage();
	inline void SetSystemInfo (ISystemInformation *pSystemInfo = NULL, CFile *pFile = NULL);

// Dialog Data
	//{{AFX_DATA(PnPDevicesPage)
	enum { IDD = IDD_PNPDEVICES_PAGE };
	CListCtrl	m_wndDevicesList;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(PnPDevicesPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(PnPDevicesPage)
	virtual BOOL OnInitDialog();
	afx_msg void OnDblclkPnpDevicesList(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	CFile *m_pOutputFile;
	ISystemInformation *m_pSystemInfo;
	IPnPDevices		*m_pDevices;
	HRESULT GetInformation ();
	void SetListData(void);
};

inline void
PnPDevicesPage::SetSystemInfo (ISystemInformation *pSystemInfo, CFile *pFile)
{
	ASSERT (pSystemInfo != NULL);
	m_pSystemInfo = pSystemInfo;
	m_pOutputFile = pFile;
}

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PNPDEVICESPAGE_H__47E221B7_EEAA_43E9_981B_C268DCF398EC__INCLUDED_)
