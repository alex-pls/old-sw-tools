// Disclaimer and Copyright Information
// MiscInformation.h : 
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////

// Revision History:
//	2/1/2001		Initial Creation
//	2/7/2001		Added IMiscInformation2 interface
//

#ifndef __MISCINFORMATION_H_
#define __MISCINFORMATION_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CMiscInformation
class ATL_NO_VTABLE CMiscInformation : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CMiscInformation, &CLSID_MiscInformation>,
	public ISupportErrorInfo,
	public IDispatchImpl<IMiscInformation, &IID_IMiscInformation, &LIBID_SYSTEMMISCLib>,
	public IDispatchImpl<IMiscInformation2, &IID_IMiscInformation2, &LIBID_SYSTEMMISCLib>
{
public:
	CMiscInformation()
	{
		m_bInformationObtained = false;

		m_bstrComputerName = _T ("");
		m_bstrUserName = _T ("");
		m_bstrLocalLanguage = _T ("");
		m_bstrTimeZone = _T ("");
	}

DECLARE_REGISTRY_RESOURCEID(IDR_MISCINFORMATION)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CMiscInformation)
	COM_INTERFACE_ENTRY(IMiscInformation)
	COM_INTERFACE_ENTRY2(IDispatch, IMiscInformation)	// Use IDispatch implementation 
														// from IMiscInformation
	COM_INTERFACE_ENTRY(IMiscInformation2)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IMiscInformation
public:
	STDMETHOD(get_Language)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(get_SystemUserName)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(get_SystemName)(/*[out, retval]*/ BSTR *pVal);
	STDMETHODIMP get_TimeZone(BSTR* pVal);

private:
	bool m_bInformationObtained;
	CComBSTR m_bstrComputerName;
	CComBSTR m_bstrUserName;
	CComBSTR m_bstrLocalLanguage;
	CComBSTR m_bstrTimeZone;

	HRESULT GetInformation ();
};

#endif //__MISCINFORMATION_H_
