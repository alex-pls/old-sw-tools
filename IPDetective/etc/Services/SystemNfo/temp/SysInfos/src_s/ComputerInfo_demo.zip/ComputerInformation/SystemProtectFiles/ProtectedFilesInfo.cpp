// Disclaimer and Copyright Information
// ProtectedFilesInfo.cpp
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SystemProtectFiles.h"
#include "ProtectedFilesInfo.h"
#include <sfc.h>

/////////////////////////////////////////////////////////////////////////////
// ProtectedFilesInfo

STDMETHODIMP ProtectedFilesInfo::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IProtectedFilesInfo
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (::InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP ProtectedFilesInfo::get_NumberOfProtectedFiles(long *pVal)
{
	HRESULT hRes = S_OK;
	if ((hRes = this->GetInformation ()) != S_OK)
	{
		return hRes;
	}

	*pVal = this->m_lNumberOfFiles;
	return S_OK;
}

HRESULT ProtectedFilesInfo::GetInformation ()
{
	// If we already have generated the information, then there is no need to do it again.
	if (m_bInfoGenerated)
	{
		return S_OK;
	}

	m_lNumberOfFiles = 0;
	m_FileNamesList.clear ();

	PROTECTED_FILE_DATA protFileData;
	HANDLE hRpcHandle = NULL;

	char szName[260];
	// Before we call the function, we need to set the FileNumber member of
	// PROTECTED_FILE_DATA to zero.
	protFileData.FileNumber = 0;
	while (0 != SfcGetNextProtectedFile (hRpcHandle, &protFileData)
		|| ERROR_NO_MORE_FILES != GetLastError ())
	{
		m_lNumberOfFiles++;
		WideCharToMultiByte (CP_ACP, NULL, protFileData.FileName,
			wcslen(protFileData.FileName), szName, 260, NULL, NULL);
		m_FileNamesList.push_back (szName);
		_strset (szName, ' ');
	}


	SAFEARRAYBOUND arrayBound[1];
	arrayBound[0].lLbound = 0;
	arrayBound[0].cElements = m_lNumberOfFiles;
	m_pbstrFileNames = SafeArrayCreate (VT_BSTR, 1, arrayBound);

	CComBSTR bstrName;
	for (long i = 0; i < m_lNumberOfFiles; i++)
	{
		bstrName.Empty ();
        bstrName = m_FileNamesList.front ().c_str ();

		SafeArrayPutElement (m_pbstrFileNames, &i, bstrName);
		m_FileNamesList.pop_front ();
	}

	return S_OK;
}

STDMETHODIMP ProtectedFilesInfo::GetProtectedFilesInfo(long *pNumOfFiles, VARIANT *pbstrFileNames)
{
	HRESULT hRes = S_OK;
	if ((hRes = this->GetInformation ()) != S_OK) {
		return hRes;
	}

	*pNumOfFiles = this->m_lNumberOfFiles;

	VariantInit (pbstrFileNames);
	V_VT (pbstrFileNames) = VT_ARRAY | VT_BSTR;
	V_ARRAY (pbstrFileNames) = m_pbstrFileNames;
	
	return S_OK;
}
