// MultiMediaDeviceList.h : Declaration of the CMultiMediaDeviceList

#pragma once
#include "resource.h"       // main symbols



// CMultiMediaDeviceList

class ATL_NO_VTABLE CMultiMediaDeviceList : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CMultiMediaDeviceList, &CLSID_MultiMediaDeviceList>,
	public ISupportErrorInfo,
	public IDispatchImpl<IMultiMediaDeviceList, &IID_IMultiMediaDeviceList, &LIBID_SYSTEMMULTIMEDIALib, /*wMajor =*/ 1, /*wMinor =*/ 0>
{
public:
	CMultiMediaDeviceList()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_MULTIMEDIADEVICELIST)


BEGIN_COM_MAP(CMultiMediaDeviceList)
	COM_INTERFACE_ENTRY(IMultiMediaDeviceList)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}
	
	void FinalRelease() 
	{
	}

public:

};

OBJECT_ENTRY_AUTO(__uuidof(MultiMediaDeviceList), CMultiMediaDeviceList)
