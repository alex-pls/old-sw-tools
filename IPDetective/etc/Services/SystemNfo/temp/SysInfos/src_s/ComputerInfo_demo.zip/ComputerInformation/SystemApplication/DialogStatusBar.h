// Disclaimer and Copyright Information
// DialogStatusBar.h : 
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////
//
#if !defined(AFX_DIALOGSTATUSBAR_H__5C925BE1_B582_11D2_80DC_00105AC8B8F6__INCLUDED_)
#define AFX_DIALOGSTATUSBAR_H__5C925BE1_B582_11D2_80DC_00105AC8B8F6__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000


class CDialogStatusBar : public CStatusBar
{
// Construction
public:
	CDialogStatusBar();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDialogStatusBar)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDialogStatusBar();

	// Generated message map functions
protected:
	//{{AFX_MSG(CDialogStatusBar)
	afx_msg LRESULT OnIdleUpdateCmdUI(WPARAM wParam, LPARAM);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DIALOGSTATUSBAR_H__5C925BE1_B582_11D2_80DC_00105AC8B8F6__INCLUDED_)
