// PnPDevices.cpp : Implementation of CPnPDevices

#include "stdafx.h"
#include "SystemPnPDevices.h"
#include "PnPDevices.h"


// CPnPDevices

STDMETHODIMP CPnPDevices::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IPnPDevices
	};

	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (::InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CPnPDevices::get_Item(long lItemIndex, IPnPDevice** pVal)
{
	HRESULT hr = S_OK;
	ATLASSERT (lItemIndex >= 0 && lItemIndex < (long)m_List.size ());
	ATLASSERT (NULL != pVal);

	if (NULL == pVal)
	{
		return E_POINTER;
	}

	if (lItemIndex < 0 || lItemIndex >= (long)m_List.size ())
	{
		return E_FAIL;
	}

	*pVal = NULL;

	CComVariant var = m_List[lItemIndex];
	if (NULL != var.pdispVal)
	{
		hr = var.pdispVal->QueryInterface (IID_IPnPDevice, reinterpret_cast<void **>(pVal));
	}

	return hr;
}

STDMETHODIMP CPnPDevices::get__NewEnum(IUnknown** pVal)
{
	ATLASSERT (NULL != pVal);
	if (NULL == pVal)
	{
		return E_POINTER;
	}

	*pVal = NULL;

	// Initialize copy of Enumerator Array.

	return S_OK;
}

STDMETHODIMP CPnPDevices::get_Count(LONG* pVal)
{
	ATLASSERT (NULL != pVal);
	if (NULL == pVal)
	{
		return E_POINTER;
	}

	*pVal = (long)m_List.size ();
	return S_OK;
}

STDMETHODIMP CPnPDevices::Add(IPnPDevice *pDevice)
{
	ATLASSERT (NULL != pDevice);
	if (NULL == pDevice)
	{
		return E_POINTER;
	}

	CComVariant varDevice (pDevice);
	m_List.push_back (varDevice);

	return S_OK;
}

STDMETHODIMP CPnPDevices::Clear(void)
{
	m_List.clear ();

	return S_OK;
}
