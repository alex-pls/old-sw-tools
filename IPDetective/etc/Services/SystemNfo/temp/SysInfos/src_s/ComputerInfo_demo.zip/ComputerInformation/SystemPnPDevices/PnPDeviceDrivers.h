// PnPDeviceDrivers.h : Declaration of the CPnPDeviceDrivers

#pragma once
#include "resource.h"       // main symbols
#include <vector>
#include <atlbase.h>

// CPnPDeviceDrivers

class ATL_NO_VTABLE CPnPDeviceDrivers : 
	public CComObjectRootEx<CComMultiThreadModel>,
//	public CComCoClass<CPnPDeviceDrivers, &CLSID_PnPDeviceDrivers>,
	public ISupportErrorInfo,
	public IDispatchImpl<IPnPDeviceDrivers, &IID_IPnPDeviceDrivers, &LIBID_SYSTEMPNPDEVICESLib, /*wMajor =*/ 1, /*wMinor =*/ 0>
{
public:
	CPnPDeviceDrivers()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_PNPDEVICEDRIVERS)


BEGIN_COM_MAP(CPnPDeviceDrivers)
	COM_INTERFACE_ENTRY(IPnPDeviceDrivers)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}
	
	void FinalRelease() 
	{
	}

public:

	STDMETHODIMP get_Item(long lItemIndex, IPnPDeviceDriver** pVal);
	STDMETHODIMP get__NewEnum(IUnknown** pVal);
	STDMETHODIMP get_Count(LONG* pVal);

private:
	std::vector<CAdapt < CComVariant > > m_List;
public:
	STDMETHODIMP Add(IPnPDeviceDriver *pDriver);
	STDMETHODIMP Clear(void);
};

//OBJECT_ENTRY_AUTO(__uuidof(PnPDeviceDrivers), CPnPDeviceDrivers)
