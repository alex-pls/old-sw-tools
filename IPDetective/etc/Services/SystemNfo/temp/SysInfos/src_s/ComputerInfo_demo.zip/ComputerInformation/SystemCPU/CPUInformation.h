// Disclaimer and Copyright Information
// CPUInformation.h : Declaration of the CCPUInformation
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////

#ifndef __CPUINFORMATION_H_
#define __CPUINFORMATION_H_

#include "resource.h"       // main symbols
#ifdef _DEBUG
	#import "..\Bin\Debug\SystemOS.dll" raw_interfaces_only, raw_native_types, no_namespace, named_guids
#else
	#import "..\Bin\Release\SystemOS.dll" raw_interfaces_only, raw_native_types, no_namespace, named_guids
#endif

/////////////////////////////////////////////////////////////////////////////
// CCPUInformation
class ATL_NO_VTABLE CCPUInformation : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CCPUInformation, &CLSID_CPUInformation>,
	public ISupportErrorInfo,
	public IDispatchImpl<ICPUInformation, &IID_ICPUInformation, &LIBID_SYSTEMCPULib>
{
public:
	CCPUInformation()
	{
		m_bstrVendor = _T ("");
		m_bstrCPUType = _T ("");;
		m_bstrArchitecture = _T ("");;
		m_CPULevel = _T ("");;
		m_lNumberOfProcessors = 0;
		m_lCPUSpeed = 0;
		m_lPageSize = 0;
		m_lActiveMask = 0;
	}

	HRESULT FinalConstruct ();
	void FinalRelease ();

DECLARE_REGISTRY_RESOURCEID(IDR_CPUINFORMATION)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CCPUInformation)
	COM_INTERFACE_ENTRY(ICPUInformation)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// ICPUInformation
public:
	STDMETHOD(GetCPUInformation)(BSTR *pbstrVendor, BSTR *pbstrType, BSTR *pbstrArchitecture,
		BSTR *pbstrLevel, BSTR *pbstrRevision, long *plNumberOfProcessors, long *plSpeed,
		long *plPageSize, long *plMask);
	STDMETHOD(get_CPURevision)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(get_CPULevel)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(get_Architecture)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(get_ProcessorType)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(get_Vendor)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(get_ActiveProcessorMask)(/*[out, retval]*/ long *pVal);
	STDMETHOD(get_PageSize)(/*[out, retval]*/ long *pVal);
	STDMETHOD(get_CPUSpeed)(/*[out, retval]*/ long *pVal);
	STDMETHOD(get_NumberOfProcessors)(/*[out, retval]*/ long *pVal);

private:
	HRESULT GetInformation ();
	HRESULT MakeAPIErrorDesc ();
private:
	bool m_bInformationObtained;
	CComBSTR m_bstrVendor;
	CComBSTR m_bstrCPUType;
	CComBSTR m_bstrArchitecture;
	CComBSTR m_CPULevel;
	CComBSTR m_CPURevision;
	long m_lNumberOfProcessors;
	long m_lCPUSpeed;
	long m_lPageSize;
	long m_lActiveMask;
	IOSInformation *m_pOSInfo;
};

#endif //__CPUINFORMATION_H_
