// GetStatusDlg.h : header file
//

#if !defined(AFX_GETSTATUSDLG_H__015ED170_913C_4D7D_8713_907C95670AEE__INCLUDED_)
#define AFX_GETSTATUSDLG_H__015ED170_913C_4D7D_8713_907C95670AEE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CGetStatusDlg dialog

class CGetStatusDlg : public CDialog
{
// Construction
public:
	void GetConStatus();
	CGetStatusDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CGetStatusDlg)
	enum { IDD = IDD_GETSTATUS_DIALOG };
	CString	m_bytesreceived;
	CString	m_bytessent;
	CString	m_connectedto;
	CString	m_connectionspeed;
	CString	m_connectionduration;
	CString	m_comprecvd;
	CString	m_compsent;
	CString	m_framercvd;
	CString	m_framesent;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGetStatusDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CGetStatusDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GETSTATUSDLG_H__015ED170_913C_4D7D_8713_907C95670AEE__INCLUDED_)
