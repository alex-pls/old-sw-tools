// GetStatusDlg.cpp : implementation file
//

#include "stdafx.h"
#include "GetStatus.h"
#include "GetStatusDlg.h"
#include <ras.h>
#include <raserror.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About
LPRASDEVINFO lpRasDevInfo;
HINSTANCE hDLLib;      // Handle to DLL.	

typedef struct _RAS_STATS {
  DWORD   dwSize;
  DWORD   dwBytesXmited;
  DWORD   dwBytesRcved;
  DWORD   dwFramesXmited;
  DWORD   dwFramesRcved;
  DWORD   dwCrcErr;
  DWORD   dwTimeoutErr;
  DWORD   dwAlignmentErr;
  DWORD   dwHardwareOverrunErr;
  DWORD   dwFramingErr;
  DWORD   dwBufferOverrunErr;
  DWORD   dwCompressionRatioIn;
  DWORD   dwCompressionRatioOut;
  DWORD   dwBps;
  DWORD   dwConnectDuration;
} RAS_STATS, *PRAS_STATS;

typedef DWORD (*lpfnDllFuncRGCS)(HRASCONN hRasConn,RAS_STATS *lpStatistics);//RasGetConnectionStatistics
typedef DWORD (*lpfnDllFuncRENCS)( LPRASCONN lprasconn, LPDWORD lpcb, LPDWORD lpcConnections );//RasEnumConnections

lpfnDllFuncRGCS lpfnDllFuncConnstat;
lpfnDllFuncRENCS lpfnDllFuncEnumConn;


/////////////////////////////////////////////////////////////////////////////
// CGetStatusDlg dialog

CGetStatusDlg::CGetStatusDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGetStatusDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CGetStatusDlg)
	m_bytesreceived = _T("");
	m_bytessent = _T("");
	m_connectedto = _T("");
	m_connectionspeed = _T("");
	m_connectionduration = _T("");
	m_comprecvd = _T("");
	m_compsent = _T("");
	m_framercvd = _T("");
	m_framesent = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CGetStatusDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGetStatusDlg)
	DDX_Text(pDX, IDC_BYTES_RECEIVED, m_bytesreceived);
	DDX_Text(pDX, IDC_BYTES_SENT, m_bytessent);
	DDX_Text(pDX, IDC_CONNECTED_TO, m_connectedto);
	DDX_Text(pDX, IDC_CONNECTIONS_SPEED, m_connectionspeed);
	DDX_Text(pDX, IDC_CONNECTIONS_DURATION, m_connectionduration);
	DDX_Text(pDX, IDC_COMP_RCVD, m_comprecvd);
	DDX_Text(pDX, IDC_COMP_SENT, m_compsent);
	DDX_Text(pDX, IDC_FRAMES_RCVD, m_framercvd);
	DDX_Text(pDX, IDC_FRAMES_SENT, m_framesent);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CGetStatusDlg, CDialog)
	//{{AFX_MSG_MAP(CGetStatusDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_TIMER()
	ON_WM_CTLCOLOR()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGetStatusDlg message handlers

BOOL CGetStatusDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
		hDLLib= LoadLibrary(_T("rasapi32"));
		if(!hDLLib)
		{
			::MessageBox(0,"Error in Loading rasapi32.lib file.","Internet Connection Status",MB_ICONERROR);
			PostQuitMessage(0);
		}
		
		lpfnDllFuncConnstat = (lpfnDllFuncRGCS)GetProcAddress(hDLLib,"RasGetConnectionStatistics");
		if(!lpfnDllFuncConnstat )
		{
			::MessageBox(0,"Error in Loading RasGetConnectionStatistics funciton.","Internet Connection Status",MB_ICONERROR);
			FreeLibrary(hDLLib);
		}

		lpfnDllFuncEnumConn = (lpfnDllFuncRENCS)GetProcAddress(hDLLib,"RasEnumConnectionsA");
		if(!lpfnDllFuncEnumConn )
		{
			::MessageBox(0,"Error in Loading RasEnumConnectionsA funciton.","Internet Connection Status",MB_ICONERROR);
			FreeLibrary(hDLLib);
		}

	
		SetTimer(1,1000,NULL);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CGetStatusDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CGetStatusDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CGetStatusDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CGetStatusDlg::GetConStatus()
{

	try
	{
		RASCONN * lpRasConn;
		DWORD     lpcb;
		DWORD     lpcConnections;

		lpRasConn = (LPRASCONN) GlobalAlloc(GPTR, sizeof(RASCONN));
		lpRasConn->dwSize = sizeof(RASCONN);
		lpcb = sizeof(RASCONN);
 
		DWORD nRet = lpfnDllFuncEnumConn(lpRasConn, &lpcb, &lpcConnections);
		

		if (nRet != 0)
		{

			FreeLibrary(hDLLib);
			KillTimer(1);
			EndDialog(TRUE);
						
		}
		else
		{
			RAS_STATS *lpStatistics;
			lpStatistics= (RAS_STATS *)GlobalAlloc(GPTR, sizeof(RAS_STATS));
			lpStatistics->dwSize=sizeof(RAS_STATS);	
			if(lpRasConn->hrasconn)
			{
				this->m_connectedto.Format("%s", lpRasConn->szEntryName);
			
				DWORD nR=lpfnDllFuncConnstat(lpRasConn->hrasconn,lpStatistics);
				if(nR == ERROR_SUCCESS)
				{
					this->m_bytesreceived.Format("%d",lpStatistics->dwBytesRcved);
					this->m_bytessent.Format("%d",lpStatistics->dwBytesXmited);
					this->m_connectionspeed.Format("%d bps",lpStatistics->dwBps);

					CString strsec;
					int nSec = lpStatistics->dwConnectDuration/1000;
					nSec %=  60;
					int nMin = lpStatistics->dwConnectDuration/60000;
					nMin %= 60;
					int nHour =lpStatistics->dwConnectDuration/(60000*60);
					nHour %= 24;
					this->m_connectionduration.Format("%2d hrs : %2d mins : %2d secs",nHour,nMin,nSec);

					this->m_comprecvd.Format("%d%%",lpStatistics->dwCompressionRatioIn);
					this->m_compsent.Format("%d%%",lpStatistics->dwCompressionRatioOut);

					this->m_framercvd.Format("%d",lpStatistics->dwFramesRcved);
					this->m_framesent.Format("%d",lpStatistics->dwFramesXmited);
					UpdateData(FALSE);
				}
				else
				{
					try
					{
						FreeLibrary(hDLLib);
						KillTimer(1);
						EndDialog(TRUE);
					}
					catch(CException* theException2)
					{
						theException2->Delete();
					}


				}
			}
			else
			{
				try
				{
					FreeLibrary(hDLLib);
					KillTimer(1);
					EndDialog(TRUE);
				}
				catch(CException* theException)
				{
					theException->Delete();
				}
			}
		}
	}
	catch(CException* theException1)
	{
		theException1->Delete();
	}
	
}

void CGetStatusDlg::OnTimer(UINT nIDEvent) 
{
	GetConStatus();
	CDialog::OnTimer(nIDEvent);
}



HBRUSH CGetStatusDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	UINT nId = pWnd->GetDlgCtrlID();
	if(nId == IDC_CON || nId == IDC_ACT)
		pDC->SetTextColor(RGB(0,0,255));
	if(nId == IDC_CONNECTED_TO)
	{
		CFont font;
		font.CreateFont(
		14,                        // nHeight
		0,                         // nWidth
		0,                         // nEscapement
		0,                         // nOrientation
		FW_HEAVY,                  // nWeight
		FALSE,                     // bItalic
		FALSE,                     // bUnderline
		0,                         // cStrikeOut
		DEFAULT_CHARSET,           // nCharSet
		OUT_DEFAULT_PRECIS,        // nOutPrecision
		CLIP_DEFAULT_PRECIS,       // nClipPrecision
		DEFAULT_QUALITY,           // nQuality
		DEFAULT_PITCH | FF_SWISS,  // nPitchAndFamily
		"Tahoma");                 // lpszFacename

		pDC->SelectObject(&font);
		font.DeleteObject();

		pDC->SetTextColor(RGB(255,100,0));


	}

	pDC->SetBkMode(TRANSPARENT);
	if(nId == IDC_BTOP || nId == IDC_BBTM || nId == IDC_BRT || nId == IDC_BLT)
		return hbr; 

	
	return CreateSolidBrush(RGB(255,255,255));
}
