// GetStatus.h : main header file for the GETSTATUS application
//

#if !defined(AFX_GETSTATUS_H__E4366680_C161_46CA_AE2A_1525397F81DB__INCLUDED_)
#define AFX_GETSTATUS_H__E4366680_C161_46CA_AE2A_1525397F81DB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CGetStatusApp:
// See GetStatus.cpp for the implementation of this class
//

class CGetStatusApp : public CWinApp
{
public:
	CGetStatusApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGetStatusApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CGetStatusApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GETSTATUS_H__E4366680_C161_46CA_AE2A_1525397F81DB__INCLUDED_)
