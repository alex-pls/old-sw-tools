#include "SysMain.h"
#include "_GlobalVars.h"
#include "_Constants.h"
#include "_Utils.h"
#include "EventLogThreads.h"
#include "resource.h"

LRESULT CALLBACK 
MDIChildData_WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	LRESULT lResult = 0;

	switch(uMsg)
	{
		case WM_CREATE:
			MDIChildData_OnCreate(hWnd, wParam, lParam, &lResult);
			break;

		case WM_SIZE:
			MDIChildData_OnSize(hWnd, wParam, lParam, &lResult);
			break;

		case WM_MDIACTIVATE:
			MDIChildData_OnMDIActivate(hWnd, wParam, lParam, &lResult);
			break;

		case WM_DESTROY:
			MDIChildData_OnDestroy(hWnd, wParam, lParam, &lResult);
			g_hDataWnd = 0;
			break;

		case WM_USER_UPDATEEVENTDATA:
			MDIChildData_OnUpdateEventData(hWnd, wParam, lParam, &lResult);
			break;

		case WM_CTLCOLOREDIT:
			wParam = wParam;
			break;

		default:
			lResult = DefMDIChildProc(hWnd, uMsg, wParam, lParam);
			break;
	}

	return lResult;
}

LRESULT*
MDIChildData_OnCreate(HWND hWnd, WPARAM wParam, LPARAM lParam, LRESULT *plResult)
{
	HWND    hWndTemp;
	TCHAR lpszMachineName[_MAX_PATH + 1];

	ComboBox_GetLBText(g_hComboToolbarWnd, ComboBox_GetCurSel(g_hComboToolbarWnd), lpszMachineName);

	g_hWndActiveChild = hWnd;
	hWndTemp = CreateDialogParam(g_hInstance, 
		MAKEINTRESOURCE(IDD_MDIDATA), hWnd, MDIChildData_DlgProc, (LPARAM)0/*pelf*/);

	if(!hWndTemp)
	{
		*plResult = -1;
		return plResult;
	}

	SetWindowLong(hWnd, GWLAPP_HDLG , (LONG)hWndTemp);
	SetWindowLong(hWnd, GWL_USERDATA, (LONG)0); // has no thread (yet)

	ShowWindow(hWndTemp, SW_SHOW);
	UpdateWindow(hWndTemp);

	{
		RECT rc;
		GetClientRect(hWnd, &rc);
		SendMessage(hWnd, WM_SIZE, (WPARAM)SIZE_RESTORED, 
			(LPARAM)MAKELPARAM(rc.right - rc.left, rc.bottom - rc.top));
	}

	*plResult = 0;
	return plResult;

	_UNREFERENCED_PARAMETER_(wParam);
	_UNREFERENCED_PARAMETER_(lParam);
}

LRESULT*
MDIChildData_OnSize(HWND hWnd, WPARAM wParam, LPARAM lParam, LRESULT *plResult)
{
	DefMDIChildProc(hWnd, WM_SIZE, wParam, lParam);
	SendMessage((HWND)GetWindowLong(hWnd, GWLAPP_HDLG), WM_SIZE, wParam, lParam);

	*plResult = 0;
	return plResult;
}

LRESULT*
MDIChildData_OnMDIActivate(HWND hWnd, WPARAM wParam, LPARAM lParam, LRESULT *plResult)
{
	*plResult = 0;
	return plResult;

	_UNREFERENCED_PARAMETER_(hWnd);
	_UNREFERENCED_PARAMETER_(wParam);
	_UNREFERENCED_PARAMETER_(lParam);
}

LRESULT*
MDIChildData_OnDestroy(HWND hWnd, WPARAM wParam, LPARAM lParam, LRESULT *plResult)
{
	DLGPROC lpDlgProc;

	lpDlgProc = (DLGPROC)GetWindowLong((HWND)GetWindowLong(hWnd, GWLAPP_HDLG), DWL_DLGPROC);
	
	DestroyWindow((HWND)GetWindowLong(hWnd, GWLAPP_HDLG));
	FreeProcInstance(lpDlgProc);
	
	if(hWnd == g_hWndActiveChild)
		g_hWndActiveChild = (HWND)0;

	*plResult = 0;
	return plResult;

	_UNREFERENCED_PARAMETER_(wParam);
	_UNREFERENCED_PARAMETER_(lParam);
}

LRESULT*
MDIChildData_OnUpdateEventData(HWND hWnd, WPARAM wParam, LPARAM lParam, LRESULT *plResult)
{
	TCHAR lpszCaption[_MAX_PATH + 1];
	LPEVENTID peid = (LPEVENTID)lParam;
	unsigned dwThreadId;
	
	_stprintf(lpszCaption, 
		_T("Data/Description for %s\\%s (%ld)"), 
		peid->lpszMachineName, peid->lpszEventName, peid->dwEventId);
	SetWindowText(hWnd, lpszCaption);

	_beginthreadex(0, 0, ShowEventData, (LPVOID)peid, 0, &dwThreadId);

	*plResult = 0;
	return plResult;

	_UNREFERENCED_PARAMETER_(wParam);
}
