#include "_Constants.h"
#include "_GlobalHeader.h"

const TCHAR *g_lpcszApplicationName				= _T("WindowsNT Event Log Viewer");

const TCHAR *g_lpcszMainWindowClassName			= _T("__ZS_MainWindow__");
const TCHAR *g_lpcszMDIClientWindowClassName	= _T("MDICLIENT");
	const TCHAR *g_lpcszChildWindowClassName	= _T("__ZS_MDIChildWindow__");
	const TCHAR *g_lpcszDataWindowClassName		= _T("__ZS_MDIDataWindow__");

const TCHAR *g_lpcszNetworkNeighborhood			= _T("Entire Network");

EVENTLOGCOL g_pcEventLogListColumns[]			= 
{
	{ _T("Source")		,	100, STRING		, ASCENDING	},
	{ _T("User Name")	,	 60, STRING		, ASCENDING	},
	{ _T("User SID")	,	 60, STRING		, ASCENDING	},
	{ _T("Domain")		,	100, STRING		, ASCENDING	},
	{ _T("Type")		,	100, STRING		, ASCENDING	},
	{ _T("Submitted")	,	100, DATETIME	, ASCENDING	},
	{ _T("Written")		,	100, DATETIME	, ASCENDING	},
	{ 0					,	  0, 0			, 0			},
};

