#include "SysMain.h"
#include "_Constants.h"
#include "_GlobalVars.h"
#include "_ExtraResources.h"
#include "_Utils.h"

#pragma data_seg(".text")
#include <objbase.h>
#define INITGUID
#include <initguid.h>
#define NO_SHDOCVW_GUIDS
#include <shlguid.h>
#include <shlobj.h>
#pragma data_seg()

void CopyStartupVariables(HINSTANCE hThisInstance, LPSTR lpszCmdLine)
{
	g_hInstance = hThisInstance;
	_tcscpy(g_lpszCmdLine, lpszCmdLine);
}

fatal		
InitializeCommonControls()
{
	fatal _retval = 0;
	INITCOMMONCONTROLSEX iccEx;

	iccEx.dwSize = sizeof(INITCOMMONCONTROLSEX);
	iccEx.dwICC	 = 
		ICC_LISTVIEW_CLASSES	|	//	list view
		ICC_PROGRESS_CLASS		|	//	progress bar
		ICC_TREEVIEW_CLASSES	|	//	tree view & tooltip
		ICC_BAR_CLASSES			|	//	toolbar, status bar, trackbar & tooltip
		ICC_UPDOWN_CLASS		|	//	up-down
		ICC_TAB_CLASSES			|	//	tab & tooltip
		ICC_USEREX_CLASSES		|	//	extended combo box 
		0
		;

	_retval = !InitCommonControlsEx(&iccEx);

	// check also version
//	g_hRichEditLibrary = LoadLibrary("riched32.dll");

	return _retval;
}

fatal		
RegisterWindowClasses()
{
	fatal _retval = 0;

	_retval = RegisterMainWindowClass();
	_retval = RegisterChildWindowClass();
	_retval = RegisterChildDataWindowClass();
	_retval = RegisterOtherWindowClasses();

	return _retval;
}

fatal 
RegisterMainWindowClass()
{
	WNDCLASSEX wcEx;

	wcEx.cbClsExtra		= 0;
	wcEx.cbSize			= sizeof(WNDCLASSEX);
	wcEx.cbWndExtra		= 0;
	wcEx.hbrBackground	= (HBRUSH)(COLOR_BTNFACE + 1);
	wcEx.hCursor		= LoadCursor(0, IDC_ARROW);
	wcEx.hIcon			= LoadIcon(g_hInstance, MAKEINTRESOURCE(IDI_SYS));
	wcEx.hIconSm		= 0;
	wcEx.hInstance		= g_hInstance;
	wcEx.lpfnWndProc	= SysMain_WndProc;
	wcEx.lpszClassName	= g_lpcszMainWindowClassName;
	wcEx.lpszMenuName	= MAKEINTRESOURCE(IDM_MAIN);
	wcEx.style			= 0; //CS_HREDRAW | CS_VREDRAW;

	return !RegisterClassEx(&wcEx);
}

fatal 
RegisterChildWindowClass()
{
	WNDCLASSEX wcEx;

	wcEx.cbClsExtra		= 0;
	wcEx.cbSize			= sizeof(WNDCLASSEX);
	wcEx.cbWndExtra		= CBWNDEXTRA;
	wcEx.hbrBackground	= (HBRUSH)(COLOR_BTNFACE + 1);
	wcEx.hCursor		= LoadCursor(0, IDC_ARROW);
	wcEx.hIcon			= LoadIcon(g_hInstance, MAKEINTRESOURCE(IDI_MACHINE));
	wcEx.hIconSm		= 0;
	wcEx.hInstance		= g_hInstance;
	wcEx.lpfnWndProc	= MDIChild_WndProc;
	wcEx.lpszClassName	= g_lpcszChildWindowClassName;
	wcEx.lpszMenuName	= 0;
	wcEx.style			= 0; //CS_HREDRAW | CS_VREDRAW;

	return !RegisterClassEx(&wcEx);
}

fatal 
RegisterChildDataWindowClass()
{
	WNDCLASSEX wcEx;

	wcEx.cbClsExtra		= 0;
	wcEx.cbSize			= sizeof(WNDCLASSEX);
	wcEx.cbWndExtra		= CBWNDEXTRA;
	wcEx.hbrBackground	= (HBRUSH)(COLOR_BTNFACE + 1);
	wcEx.hCursor		= LoadCursor(0, IDC_ARROW);
	wcEx.hIcon			= LoadIcon(g_hInstance, MAKEINTRESOURCE(IDI_DATA));
	wcEx.hIconSm		= 0;
	wcEx.hInstance		= g_hInstance;
	wcEx.lpfnWndProc	= MDIChildData_WndProc;
	wcEx.lpszClassName	= g_lpcszDataWindowClassName;
	wcEx.lpszMenuName	= 0;
	wcEx.style			= 0;

	return !RegisterClassEx(&wcEx);
}

fatal 
RegisterOtherWindowClasses()
{
	return 0;
}

fatal 
CreateWindows()
{
	fatal _retval = 0;

	_retval = CreateMainWindow();
	_retval = CreateToolbar();

	ShowWindow(g_hMainWnd, SW_SHOWMAXIMIZED);

	return _retval;
}

fatal 
CreateMainWindow()
{
	g_hMainWnd = CreateWindowEx(
		WS_EX_OVERLAPPEDWINDOW | WS_EX_WINDOWEDGE, 
		g_lpcszMainWindowClassName,
		g_lpcszApplicationName, 
		WS_OVERLAPPEDWINDOW | WS_VISIBLE | WS_CLIPCHILDREN | WS_CLIPSIBLINGS, 
		CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, 
		0, 
		0, 
		g_hInstance, 
		0);
	if(g_hMainWnd)
	{
		ShowWindow(g_hMainWnd, SW_SHOW);
		UpdateWindow(g_hMainWnd);
	}

	return 0;
}

fatal 
CreateToolbar()
{
	int i, iNumButtons, iNumBitmaps = 0;
	for(iNumButtons = 0; g_arToolbarButtons[iNumButtons].iBitmap != -1; iNumButtons++)
		;
	for(i = 0; i < iNumButtons; i++)
	{
		if(!(g_arToolbarButtons[i].fsStyle & TBSTYLE_SEP))
			iNumBitmaps++;
	}

	g_hToolBarWnd = CreateToolbarEx(g_hMainWnd, 
		WS_CHILD | WS_BORDER | WS_VISIBLE | WS_CLIPSIBLINGS | WS_CLIPCHILDREN | 
		TBSTYLE_TOOLTIPS | TBSTYLE_ALTDRAG | TBSTYLE_FLAT | TBSTYLE_TRANSPARENT | TBSTYLE_WRAPABLE |
		CCS_ADJUSTABLE,
		ID_TOOLBAR_MAIN, iNumBitmaps, g_hInstance, IDB_TOOLBAR_MAIN, (LPCTBBUTTON)&g_arToolbarButtons, iNumButtons,
		16, 16, 16, 16, sizeof(TBBUTTON));

	if(g_hToolBarWnd)
		CreateToolbarComboBox();

	return 0;
}

retcode 
FillComputersCombo()
{
	retcode _retval = 0;
	LPENUMIDLIST lpe = 0;
	LPITEMIDLIST lpi = 0;
	LPMALLOC lpMalloc = 0;
	ULONG ulFetched = 0L;
	HRESULT hr = 0;
	TCHAR lpszItemName[_MAX_PATH + 1];
	LPSHELLFOLDER lpsf = 0; 
	LPITEMIDLIST lpi1 = 0;
	LPSHELLFOLDER lpsfNetworkNeighborhood = 0;
	ULONG ulAttrs;
	STRRET strretName;

	hr = SHGetDesktopFolder(&lpsf);
	if(FAILED (hr))
	{
		_retval = -1;
		goto _cleanup_;
	}

	hr = SHGetSpecialFolderLocation(g_hMainWnd, CSIDL_NETWORK, &lpi1);
	if(FAILED (hr))
	{
		_retval = -2;
		goto _cleanup_;
	}

	hr = lpsf->lpVtbl->BindToObject(lpsf, lpi1, 0, &IID_IShellFolder, (LPVOID *)&lpsfNetworkNeighborhood);
	if(FAILED (hr))
	{
		_retval = -3;
		goto _cleanup_;
	}

	hr = SHGetMalloc(&lpMalloc);
	if(FAILED (hr))
	{
		_retval = -4;
		goto _cleanup_;
	}

	if(SUCCEEDED(hr))
	{
		hr = lpsfNetworkNeighborhood->lpVtbl->EnumObjects(lpsfNetworkNeighborhood, 
			g_hMainWnd, SHCONTF_FOLDERS | SHCONTF_NONFOLDERS, &lpe);
		if (SUCCEEDED (hr))
		{
			while (S_OK == lpe->lpVtbl->Next(lpe, 1, &lpi, &ulFetched))
			{
				ulAttrs = SFGAO_HASSUBFOLDER;
				hr = lpsfNetworkNeighborhood->lpVtbl->GetAttributesOf(lpsfNetworkNeighborhood, 
					1, (const struct _ITEMIDLIST **)&lpi, &ulAttrs);
				if(SUCCEEDED(hr))
				{
					if(ulAttrs & SFGAO_HASSUBFOLDER)
					{
						strretName.uType = STRRET_CSTR;
						hr = lpsfNetworkNeighborhood->lpVtbl->GetDisplayNameOf(lpsfNetworkNeighborhood, 
							lpi, SHGDN_NORMAL, &strretName);
						if(SUCCEEDED(hr))
						{
							switch(strretName.uType)
							{
								case STRRET_CSTR:
									_tcscpy(lpszItemName, strretName.cStr);
									break;
								case STRRET_WSTR:
									_tcscpy(lpszItemName, _MBSTR(strretName.pOleStr));
									break;
								case STRRET_OFFSET:
									_tcscpy(lpszItemName, (char *)lpi + strretName.uOffset);
									break;
								default:
									break;
							}

							ComboBox_AddString(g_hComboToolbarWnd, 
								_tcsicmp(lpszItemName, g_lpcszNetworkNeighborhood) != 0 ? lpszItemName : _T("<Select>"));
						}
					}
				}

				lpMalloc->lpVtbl->Free(lpMalloc, lpi); 
				lpi = 0;
			}
		}
	}
	else
		_retval = -5;

_cleanup_:
	if(lpe)
		lpe->lpVtbl->Release(lpe);
	if(lpi && lpMalloc)
		lpMalloc->lpVtbl->Free(lpMalloc, lpi);
	if(lpi1 && lpMalloc)
		lpMalloc->lpVtbl->Free(lpMalloc, lpi1);
	if(lpMalloc)
		lpMalloc->lpVtbl->Release(lpMalloc);
	if(lpsf)
		lpsf->lpVtbl->Release(lpsf);
	if(lpsfNetworkNeighborhood)
		lpsfNetworkNeighborhood->lpVtbl->Release(lpsf);

	return _retval;
}

fatal 
CreateStatusBar()
{
	return 0;
}

retcode 
CreateToolbarComboBox()
{
	g_hComboToolbarWnd = CreateWindowEx(0L, "COMBOBOX", "", 
		WS_CHILD | WS_BORDER | WS_VISIBLE | CBS_HASSTRINGS | CBS_DROPDOWNLIST, 
		2, 2, 100, 250, 
		g_hToolBarWnd, (HMENU)IDM_COMPUTERCOMBO, g_hInstance, 0);

	if(g_hComboToolbarWnd)
	{
		FillComputersCombo();
		InitComputersCombo();
	}

	return 0;
}

retcode
InitComputersCombo()
{
	SubclassToolbarCombo();
	AddToolbarComboTooltip();
	SetToolbarComboFont();

	return 0;
}

retcode 
SubclassToolbarCombo()
{
	g_lpfnDefTlbCB_WndProc = (WNDPROC)GetWindowLong(g_hComboToolbarWnd, GWL_WNDPROC);
	SetWindowLong(g_hComboToolbarWnd, GWL_WNDPROC, (LONG)ToolbarCombo_WndProc);

	return 0;
}

retcode 
AddToolbarComboTooltip()
{
    static HWND hWndTT;
	static CHAR szBuf[128];
    TOOLINFO lpToolInfo;

	hWndTT = (HWND)SendMessage(g_hToolBarWnd, TB_GETTOOLTIPS, 0, 0);
    if(hWndTT)
    {
		lpToolInfo.cbSize	= sizeof(lpToolInfo);
		lpToolInfo.uFlags	= TTF_IDISHWND | TTF_CENTERTIP;
		lpToolInfo.lpszText = (LPSTR)IDM_COMPUTERCOMBO;
		lpToolInfo.hwnd		= g_hMainWnd;
		lpToolInfo.uId		= (UINT)g_hComboToolbarWnd;
		lpToolInfo.hinst	= g_hInstance;
		
		SendMessage(hWndTT, TTM_ADDTOOL, 0, (LPARAM)(LPTOOLINFO)&lpToolInfo);
    }

	return 0;
}

retcode 
SetToolbarComboFont()
{
	return SendMessage(g_hComboToolbarWnd, WM_SETFONT, 
		(WPARAM)(HFONT)SendMessage(g_hToolBarWnd, WM_GETFONT, 0, 0), MAKELPARAM(1, 0));
}
