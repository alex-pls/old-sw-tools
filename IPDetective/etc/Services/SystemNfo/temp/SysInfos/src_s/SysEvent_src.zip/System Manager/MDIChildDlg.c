#include "SysMain.h"
#include "_GlobalVars.h"
#include "_Constants.h"
#include "EventLogThreads.h"
#include "ListViewX.h"
#include "_Utils.h"
#include "resource.h"

static POINT g_ptCurPos = {0, 0};

BOOL CALLBACK 
MDIChild_DlgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	BOOL bResult = FALSE;

	switch(uMsg)
	{
		case WM_INITDIALOG:
			MDIChildDlg_OnInitDialog(hWnd, wParam, lParam, &bResult);
			break;

		case WM_SIZE:
			MDIChildDlg_OnSize(hWnd, wParam, lParam, &bResult);
			break;

		case WM_COMMAND:
			MDIChildDlg_OnCommand(hWnd, wParam, lParam, &bResult);
			break;

		case WM_NOTIFY:
			MDIChildDlg_OnNotify(hWnd, wParam, lParam, &bResult);
			break;

		default:
			break;
	}

	return bResult;
}

BOOL*
MDIChildDlg_OnCommand(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult)
{
	WORD wIdentificator = HIWORD(wParam);
 
	if(wIdentificator == 0) // menu or button (BN_CLICKED also is 0)
	{
		//	give a chance to execute if is BN_CLICKED
		MDIChildDlg_OnButtonClicked(hWnd, wParam, lParam, pbResult);
		
		if(!(*pbResult))	//	wasn't processed, so it must be a menu
		{
			WORD wMenuId = LOWORD(wParam);

			switch(wMenuId)
			{
				case IDM_LV_COLVIEWINTEGRAL:
					MDIChildDlg_OnViewColIntegral(hWnd, wParam, lParam, pbResult);
					break;

				case IDM_LV_ALLVIEWINTEGRAL:
					MDIChildDlg_OnViewAllColIntegral(hWnd, wParam, lParam, pbResult);
					break;

				default:
					break;
			}
		}
	}

	*pbResult = TRUE;
	return pbResult;


	*pbResult = TRUE;
	return pbResult;
}

BOOL*
MDIChildDlg_OnButtonClicked(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult)
{
	WORD wButton = LOWORD(wParam);
 
	switch(wButton)
	{
		case IDOK:
			break;

		case IDCANCEL:
			MDIChildDlg_OnCancel(hWnd, wParam, lParam, pbResult);
			break;

		default:
			break;
	}

	*pbResult = FALSE;
	return pbResult;
}

BOOL*
MDIChildDlg_OnCancel(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult)
{
	LPEVENTLOGFILTER pelf = (LPEVENTLOGFILTER)GetWindowLong(GetParent(hWnd), GWL_USERDATA);
	if(pelf)
		SetEvent(pelf->hCancelEvent);

	*pbResult = TRUE;
	return pbResult;

	_UNREFERENCED_PARAMETER_(wParam);
	_UNREFERENCED_PARAMETER_(lParam);
}

BOOL*
MDIChildDlg_OnInitDialog(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult)
{
	MDIChildDlg_OnInitControls(hWnd, wParam, lParam, pbResult);

	*pbResult = TRUE;
	return pbResult;
}

BOOL*
MDIChildDlg_OnInitControls(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult)
{
	MDIChildDlg_OnInitEventList(hWnd, wParam, lParam, pbResult);
	MDIChildDlg_OnInitProgress(hWnd, wParam, lParam, pbResult);

	*pbResult = TRUE;
	return pbResult;
}

BOOL*
MDIChildDlg_OnInitProgress(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult)
{
	HWND hwndProgr;
	hwndProgr = GetDlgItem(hWnd, IDPROGR_ENUM);

	SendMessage(hwndProgr, PBM_SETBARCOLOR, 0, (LPARAM)((COLORREF)RGB(0, 0, 0)));

	*pbResult = TRUE;
	return pbResult;

	_UNREFERENCED_PARAMETER_(wParam);
	_UNREFERENCED_PARAMETER_(lParam);
}

BOOL*
MDIChildDlg_OnInitEventList(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult)
{
	HWND hWndLV;
	HWND hwndProgr;
	LVCOLUMN lvCol;
	TCHAR lpszBuffer[_MAX_PATH + 1];
	int iColCount, iColIdx;
	EVENTLOGFILTER *pelf = (EVENTLOGFILTER *)lParam;
	HWND hParentWnd;
	unsigned uThreadId = 0;

	hParentWnd = GetParent(hWnd);

	hWndLV = GetDlgItem(hWnd, IDL_EVENTS);
	hwndProgr = GetDlgItem(hWnd, IDPROGR_ENUM);

	ListView_SetExtendedListViewStyle(hWndLV, 
		LVS_EX_GRIDLINES		| 
		LVS_EX_FLATSB			| 
		LVS_EX_SUBITEMIMAGES	|
		LVS_EX_FULLROWSELECT	|
		0);
	if(g_hEventListImageList)
		ListView_SetImageList(hWndLV, g_hEventListImageList, LVSIL_SMALL);

	//	invariant
	lvCol.mask			= LVCF_TEXT | LVCF_WIDTH;
	lvCol.pszText		= lpszBuffer;

	for(iColCount = 0; g_pcEventLogListColumns[iColCount].lpszName[0] != 0; iColCount++)
		;

	for(iColIdx = 0; iColIdx < iColCount; iColIdx++)
	{
		_tcscpy(lpszBuffer, g_pcEventLogListColumns[iColIdx].lpszName);
		lvCol.cx			= g_pcEventLogListColumns[iColIdx].uCXCol;
		lvCol.cchTextMax	= _tcslen(lpszBuffer);
		
		ListView_InsertColumn(hWndLV, iColIdx, &lvCol);
	}

	//	now we have the dialog & list handles'
	pelf->hwndDlg		= hWnd;
	pelf->hwndLV		= hWndLV;
	pelf->hwndProgr		= hwndProgr;

	if(_beginthreadex(0, 0, FillEventLogList, (LPVOID)pelf, 0, &uThreadId) != 0)
	{
		pelf->uThreadId = uThreadId;

		{
			TCHAR tszEventName[_MAX_PATH + 1];

			// assume creation succeed
			_stprintf(tszEventName, _T("CancelEnumerateThread_%p_%ld"), hWnd, uThreadId);
			pelf->hCancelEvent	= CreateEvent(0, TRUE, FALSE, _T("CancelThread"));
		
			_stprintf(tszEventName, _T("CloseEnumerateThread_%p_%ld"), hWnd, uThreadId);
			pelf->hCloseEvent	= CreateEvent(0, TRUE, FALSE, _T("CloseThread"));
		}
	}
	else
	{
		#pragma warning(disable:4127)
		SafeDeletePointer(pelf, sizeof(pelf));
		MessageBox(hWnd, _T("Fail creation thread."), 0, MB_OK | MB_ICONINFORMATION);
	}

	*pbResult = TRUE;
	return pbResult;

	_UNREFERENCED_PARAMETER_(wParam);
}

BOOL*
MDIChildDlg_OnSize(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult)
{
	HWND hParentWnd;
	RECT rc;
	HWND hWndLV;

	hParentWnd = GetParent(hWnd);
	GetClientRect(hParentWnd, &rc);
	MoveWindow
		(
			hWnd,
			rc.left, 
			rc.top, 
			rc.right - rc.left, 
			rc.bottom - rc.top, 
			TRUE
		);

	//	move child controls
	GetClientRect(hWnd, &rc);
	hWndLV = GetDlgItem(hWnd, IDL_EVENTS);
	MoveWindow
		(
			hWndLV,
			rc.left + 1, 
			rc.top + 1, 
			rc.right - rc.left - 2, 
			rc.bottom - rc.top - 2, 
			TRUE
		);

	MDIChild_ResizeDlg(hWnd, GetWindowLong(hParentWnd, GWL_USERDATA));

	*pbResult = TRUE;
	return pbResult;

	_UNREFERENCED_PARAMETER_(wParam);
	_UNREFERENCED_PARAMETER_(lParam);
}

void 
MDIChild_ResizeDlg(HWND hWnd, BOOL bShow)
{
	HWND hParentWnd;
	RECT rc;
	HWND hWndLV;
	HWND hwndProgr;

	hWndLV = GetDlgItem(hWnd, IDL_EVENTS);
	hwndProgr = GetDlgItem(hWnd, IDPROGR_ENUM);

	hParentWnd = GetParent(hWnd);
	GetClientRect(hParentWnd, &rc);
	MoveWindow
		(
			hWnd,
			rc.left, 
			rc.top, 
			rc.right - rc.left, 
			rc.bottom - rc.top, 
			TRUE
		);
	GetClientRect(hWnd, &rc);
	
	//	move child controls
	if(bShow)
	{
		MoveWindow
			(
				hWndLV,
				rc.left + 1, 
				rc.top + 1, 
				rc.right - rc.left - 2, 
				rc.bottom - rc.top - 18, 
				TRUE
			);

		ShowWindow(hwndProgr, SW_SHOW);
		MoveWindow
			(
				hwndProgr,
				rc.left + 1, 
				rc.bottom - rc.top - 18 + 2, 
				rc.right - rc.left - 2, 
				16 - 1, 
				TRUE
			);
	}
	else
	{
		//	move child controls
		MoveWindow
			(
				hWndLV,
				rc.left + 1, 
				rc.top + 1, 
				rc.right - rc.left - 2, 
				rc.bottom - rc.top - 2, 
				TRUE
			);

		ShowWindow(hwndProgr, SW_HIDE);
	}
}


BOOL*
MDIChildDlg_OnNotify(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult)
{
	LPNMHDR pNMHDR = (LPNMHDR)lParam;
	HWND hCtl;
	UINT uIDFrom;
	UINT uCode;

	hCtl	= pNMHDR->hwndFrom;
	uIDFrom = pNMHDR->idFrom;
	uCode	= pNMHDR->code;

	*pbResult = TRUE;

	if(hCtl == GetDlgItem(hWnd, IDL_EVENTS))
		MDIChildDlg_ListEvents_OnNotify(hWnd, wParam, lParam, pbResult);
	if(hCtl == GetDlgItem(hWnd, IDPROGR_ENUM))
		MDIChildDlg_Progress_OnNotify(hWnd, wParam, lParam, pbResult);
	
	return pbResult;
}

BOOL*
MDIChildDlg_Progress_OnNotify(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult)
{
	LPNMHDR pNMHDR = (LPNMHDR)lParam;
	UINT uIDFrom;
	UINT uCode;

	uIDFrom = pNMHDR->idFrom;
	uCode	= pNMHDR->code;

	switch(uCode)
	{
		case WM_CTLCOLOR:
			MDIChildDlg_Progress_OnCtlColor(hWnd, wParam, lParam, pbResult);
			break;
		default:
			break;
	}

	*pbResult = TRUE;
	return pbResult;
}

BOOL*
MDIChildDlg_ListEvents_OnNotify(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult)
{
	LPNMHDR pNMHDR = (LPNMHDR)lParam;
	UINT uIDFrom;
	UINT uCode;

	uIDFrom = pNMHDR->idFrom;
	uCode	= pNMHDR->code;

	switch(uCode)
	{
		case LVN_COLUMNCLICK:
			SendMessage(GetParent(GetParent(hWnd)), WM_MDIACTIVATE, (WPARAM)(HWND)GetParent(hWnd), 0);
//			MDIChildDlg_ListEvents_OnColumnClick(hWnd, wParam, lParam, pbResult);
			break;

		case NM_CLICK:
			SendMessage(GetParent(GetParent(hWnd)), WM_MDIACTIVATE, (WPARAM)(HWND)GetParent(hWnd), 0);
			break;

		case NM_DBLCLK:
			SendMessage(GetParent(GetParent(hWnd)), WM_MDIACTIVATE, (WPARAM)(HWND)GetParent(hWnd), 0);
			MDIChildDlg_ListEvents_OnDblClick(hWnd, wParam, lParam, pbResult);
			break;

		case LVN_KEYDOWN:
			MDIChildDlg_ListEvents_OnKeyDown(hWnd, wParam, lParam, pbResult);
			break;

		case NM_RCLICK:
			MDIChildDlg_ListEvents_OnRClick(hWnd, wParam, lParam, pbResult);
			break;

		default:
			break;
	}

	*pbResult = TRUE;
	return pbResult;
}

BOOL*
MDIChildDlg_ListEvents_OnKeyDown(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult)
{
	LPNMLVKEYDOWN pNMLVKD = (LPNMLVKEYDOWN)lParam;
	WORD wKeyCode = pNMLVKD->wVKey;

	switch(wKeyCode)
	{
		case VK_F5:
			break;

		default:
			break;
	}

	*pbResult = TRUE;
	return pbResult;

	_UNREFERENCED_PARAMETER_(hWnd);
	_UNREFERENCED_PARAMETER_(wParam);
}

BOOL*
MDIChildDlg_ListEvents_OnColumnClick(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult)
{
	LPNMLISTVIEW pNMLV = (LPNMLISTVIEW)lParam;
	HWND hwndLV = GetDlgItem(hWnd, IDL_EVENTS);

	if(GetWindowLong(GetParent(hWnd), GWL_USERDATA) == 0) // thread is not running
	{
		HCURSOR hcur = GetCursor();
		SetCursor(LoadCursor(0, IDC_WAIT));

		if(ListView_OnSort(hWnd, hwndLV, pNMLV->iSubItem, CompareItems))
		{
			SetCursor(hcur);

			ListView_SetNextHeaderAppearance(hwndLV);
			ListView_RefillLParamOrder(hwndLV);
		}
	}

	*pbResult = TRUE;
	return pbResult;

	_UNREFERENCED_PARAMETER_(wParam);
}

BOOL*
MDIChildDlg_ListEvents_OnDblClick(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult)
{
	TCHAR lpszCaption[_MAX_PATH + 1], lpszEventName[_MAX_PATH + 1], lpszMachineName[_MAX_PATH + 1], 
		lpszCaptionFmt[_MAX_PATH + 1];
	LVITEM lvItem;
//	int nHasThread;
	DWORD dwEventId;
	LPNMITEMACTIVATE pNMLVA = (LPNMITEMACTIVATE)lParam;
//	EVENTLISTPARAM *pelp;

	ComboBox_GetLBText(g_hComboToolbarWnd, ComboBox_GetCurSel(g_hComboToolbarWnd), lpszMachineName);

	lvItem.mask			= LVIF_TEXT | LVIF_PARAM;
	lvItem.iItem		= pNMLVA->iItem;
	lvItem.iSubItem		= 0;
	lvItem.pszText		= lpszEventName;
	lvItem.cchTextMax	= _MAX_PATH + 1;
	ListView_GetItem(pNMLVA->hdr.hwndFrom, &lvItem);
	
//	pelp = (EVENTLISTPARAM *)lvItem.lParam;
//	nHasThread = pelp->dwListId;
	dwEventId = (DWORD)(lvItem.lParam); // pelp->dwEventId;

	LoadString(g_hInstance, IDS_DATACAPTION, lpszCaptionFmt, _MAX_PATH + 1);
	_stprintf(lpszCaption, lpszCaptionFmt, lpszMachineName, lpszEventName, dwEventId);

	if(!g_hDataWnd)
	{
		MDICREATESTRUCT mdics;
		HWND hWndChild; 

		mdics.szClass	= g_lpcszDataWindowClassName;
		mdics.szTitle	= lpszCaption;
		mdics.x			= CW_USEDEFAULT;
		mdics.y			= CW_USEDEFAULT;
		mdics.cx		= CW_USEDEFAULT;
		mdics.cy		= CW_USEDEFAULT;
		mdics.hOwner	= g_hInstance;
		mdics.lParam	= 0;
		mdics.style		= g_hWndActiveChild && IsZoomed(g_hWndActiveChild) ? WS_MAXIMIZE : 0;

		hWndChild = (HWND)SendMessage(g_hMDIClientWnd, WM_MDICREATE, 0, (LPARAM)(LPMDICREATESTRUCT)&mdics);
		if(hWndChild)
		{
			g_hWndActiveChild = hWndChild;
			SendMessage(g_hMDIClientWnd, WM_MDIACTIVATE, (WPARAM)hWndChild, 0);
		}

		g_hDataWnd = hWndChild;
	}

	{
		LPEVENTID peid = (LPEVENTID)GlobalAlloc(GPTR, sizeof(EVENTID));

		_tcscpy(peid->lpszMachineName, lpszMachineName);
		_tcscpy(peid->lpszEventName, lpszEventName);
		peid->dwEventId	= dwEventId;
		peid->hwndDlg	= GetWindow(g_hDataWnd, GW_CHILD);

		SendMessage(g_hDataWnd, WM_USER_UPDATEEVENTDATA, 0, (LPARAM)peid);
	}

	*pbResult = TRUE;
	return pbResult;

	_UNREFERENCED_PARAMETER_(hWnd);
	_UNREFERENCED_PARAMETER_(wParam);
}

BOOL*
MDIChildDlg_Progress_OnCtlColor(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult)
{
	*pbResult = TRUE;
	return pbResult;

	_UNREFERENCED_PARAMETER_(hWnd);
	_UNREFERENCED_PARAMETER_(wParam);
	_UNREFERENCED_PARAMETER_(lParam);
}

BOOL*
MDIChildDlg_ListEvents_OnRClick(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult)
{
	HMENU hFloatMenu = GetSubMenu(g_hLVFloatMenu, 0);
	POINT pt;

	_UNREFERENCED_PARAMETER_(wParam);
	_UNREFERENCED_PARAMETER_(lParam);

	if(hFloatMenu && GetCursorPos(&pt))
	{
		g_ptCurPos = pt;	//	save mouse position to retrieve right-clicked column

		TrackPopupMenu
			(
				hFloatMenu, 
				TPM_LEFTALIGN | TPM_TOPALIGN | TPM_LEFTBUTTON, 
				pt.x, pt.y, 
				0, 
				hWnd, 
				0
			);
	}

	*pbResult = TRUE;
	return pbResult;
}

BOOL*
MDIChildDlg_OnViewColIntegral(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult)
{
	HWND hwndLV;
	POINT pt;
	int nX = 0;
	short sColCount, sColIndex;

	_UNREFERENCED_PARAMETER_(wParam);
	_UNREFERENCED_PARAMETER_(lParam);

	//	Retrieve right-clicked column.
	pt = g_ptCurPos;
	hwndLV = GetDlgItem(hWnd, IDL_EVENTS);
	ScreenToClient(hwndLV, &pt);
	
	sColCount = ListView_GetColumnCount(hwndLV);
	
	for(sColIndex = 0; sColIndex < sColCount; sColIndex++)
	{
		if(nX >= pt.x)
			break;
		nX += ListView_GetColumnWidth(hwndLV, sColIndex);
	}
	sColIndex--;

	//	if right-click was produced outside - menu should be grayed
	if(nX >= pt.x) // inside valid column
		ListView_EnsureColumnVisible(hwndLV, sColIndex);

	*pbResult = TRUE;
	return pbResult;
}

BOOL*
MDIChildDlg_OnViewAllColIntegral(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult)
{
	HWND hwndLV;

	_UNREFERENCED_PARAMETER_(wParam);
	_UNREFERENCED_PARAMETER_(lParam);

	hwndLV = GetDlgItem(hWnd, IDL_EVENTS);
	ListView_EnsureAllColumnsVisible(hwndLV);

	*pbResult = TRUE;
	return pbResult;
}
