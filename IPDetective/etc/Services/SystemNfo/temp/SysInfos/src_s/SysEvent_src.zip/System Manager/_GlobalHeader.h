#ifndef __GlobalHeader_Defined__
#define __GlobalHeader_Defined__

	#pragma warning(disable:4115)
	#include <windows.h>

	#include <windowsx.h>

	#pragma warning(disable:4201)
	#include <commctrl.h>
	#include <commdlg.h>

	#include <tchar.h>
	#include <stdio.h>
	#include <wchar.h>
	#include <malloc.h>
	#include <process.h>
	#include <stdarg.h>
	#include <time.h>

#endif /* __GlobalHeader_Defined__ */
