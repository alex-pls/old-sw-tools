#include "SysMain.h"
#include "_GlobalVars.h"
#include "resource.h"

void		
AdjustTypeEventToolbarButtons()
{
	TBBUTTONINFO tbi;
	tbi.cbSize = sizeof(TBBUTTONINFO);
	tbi.dwMask = TBIF_STATE; 
	
	//	application
	if(SendMessage(g_hToolBarWnd, TB_GETBUTTONINFO, (WPARAM)(int)ID_TBCMD_APPLICATION, 
		(LPARAM)(LPTBBUTTONINFO)&tbi) != -1)
	{
		if(g_fApplication && ~(tbi.fsState & TBSTATE_CHECKED))
		{
			tbi.fsState |= TBSTATE_CHECKED;
			SendMessage(g_hToolBarWnd, TB_SETBUTTONINFO, (WPARAM)(int)ID_TBCMD_APPLICATION, 
				(LPARAM)(LPTBBUTTONINFO)&tbi);
		}
		else if(tbi.fsState & TBSTATE_CHECKED)
		{
			tbi.fsState &= ~TBSTATE_CHECKED;
			SendMessage(g_hToolBarWnd, TB_SETBUTTONINFO, (WPARAM)(int)ID_TBCMD_APPLICATION, 
				(LPARAM)(LPTBBUTTONINFO)&tbi);
		}
	}

	//	system
	if(SendMessage(g_hToolBarWnd, TB_GETBUTTONINFO, (WPARAM)(int)ID_TBCMD_SYSTEM, 
		(LPARAM)(LPTBBUTTONINFO)&tbi) != -1)
	{
		if(g_fSystem && ~(tbi.fsState & TBSTATE_CHECKED))
		{
			tbi.fsState |= TBSTATE_CHECKED;
			SendMessage(g_hToolBarWnd, TB_SETBUTTONINFO, (WPARAM)(int)ID_TBCMD_SYSTEM, 
				(LPARAM)(LPTBBUTTONINFO)&tbi);
		}
		else if(tbi.fsState & TBSTATE_CHECKED)
		{
			tbi.fsState &= ~TBSTATE_CHECKED;
			SendMessage(g_hToolBarWnd, TB_SETBUTTONINFO, (WPARAM)(int)ID_TBCMD_SYSTEM, 
				(LPARAM)(LPTBBUTTONINFO)&tbi);
		}
	}

	//	security
	if(SendMessage(g_hToolBarWnd, TB_GETBUTTONINFO, (WPARAM)(int)ID_TBCMD_SECURITY, 
		(LPARAM)(LPTBBUTTONINFO)&tbi) != -1)
	{
		if(g_fSecurity && ~(tbi.fsState & TBSTATE_ENABLED))
		{
			tbi.fsState |= TBSTATE_CHECKED;
			SendMessage(g_hToolBarWnd, TB_SETBUTTONINFO, (WPARAM)(int)ID_TBCMD_SECURITY, 
				(LPARAM)(LPTBBUTTONINFO)&tbi);
		}
		else if(tbi.fsState & TBSTATE_CHECKED)
		{
			tbi.fsState &= ~TBSTATE_CHECKED;
			SendMessage(g_hToolBarWnd, TB_SETBUTTONINFO, (WPARAM)(int)ID_TBCMD_SECURITY, 
				(LPARAM)(LPTBBUTTONINFO)&tbi);
		}
	}

	//	custom
	if(SendMessage(g_hToolBarWnd, TB_GETBUTTONINFO, (WPARAM)(int)ID_TBCMD_CUSTOM, 
		(LPARAM)(LPTBBUTTONINFO)&tbi) != -1)
	{
		if(g_fCustom && ~(tbi.fsState & TBSTATE_CHECKED))
		{
			tbi.fsState |= TBSTATE_CHECKED;
			SendMessage(g_hToolBarWnd, TB_SETBUTTONINFO, (WPARAM)(int)ID_TBCMD_CUSTOM, 
				(LPARAM)(LPTBBUTTONINFO)&tbi);
		}
		else if(tbi.fsState & TBSTATE_CHECKED)
		{
			tbi.fsState &= ~TBSTATE_CHECKED;
			SendMessage(g_hToolBarWnd, TB_SETBUTTONINFO, (WPARAM)(int)ID_TBCMD_CUSTOM, 
				(LPARAM)(LPTBBUTTONINFO)&tbi);
		}
	}
}
