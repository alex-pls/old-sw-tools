//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SysMain.rc
//
#define IDI_SYS                         101
#define IDANICUR_DEFAULT                103
#define IDB_TOOLBAR_MAIN                106
#define IDIMGLIST_WKSTA                 107
#define IDM_MAIN                        109
#define IDA_ACCEL                       110
#define IDD_MDICHILD                    111
#define IDI_MACHINE                     112
#define IDB_EVENTLIST                   113
#define IDI_DATA                        114
#define IDB_DESC                        129
#define IDD_MDIDATA                     129
#define IDB_ASC                         130
#define IDB_NONE                        222
#define IDM_LVCUSTOMIZE                 401
#define IDL_EVENTS                      1001
#define IDPROGR_ENUM                    1004
#define IDE_DATA                        1006
#define IDE_STRINGS                     1007
#define ID_TBCMD_APPLICATION            30002
#define ID_TBCMD_SYSTEM                 30004
#define ID_TBCMD_SECURITY               30005
#define ID_TBCMD_CUSTOM                 30006
#define ID_TBCMD_OPEN                   30007
#define ID_TBCMD_SAVE                   30008
#define IDM_COMPUTERCOMBO               30009
#define IDS_SIDTYPE_USER                30010
#define IDS_SIDTYPE_GROUP               30011
#define IDS_SIDTYPE_DOMAIN              30012
#define IDS_SIDTYPE_ALIAS               30013
#define IDS_SIDTYPE_WELLKNOWNGROUP      30014
#define IDS_SIDTYPE_DELETEDACCOUNT      30015
#define IDS_SIDTYPE_INVALID             30016
#define IDS_SIDTYPE_UNKNOWN             30017
#define IDS_SIDTYPE_COMPUTER            30018
#define IDS_SIDTYPE_OUTOFTYPE           30019
#define IDS_DATACAPTION                 30020
#define ID_TBCMD_BACKUP                 30021
#define IDS_ERR_ALLOCATIONFAILURE       30022
#define IDS_OPENEVENTLOG_TITLE          30023
#define IDS_OPENEVENTLOG_DEFEXT         30025
#define IDS_BACKUPFMT_SUCCESS           30026
#define IDS_BACKUPFMT_FAIL              30027
#define IDM_WINDOW_TILE                 40003
#define IDM_WINDOW_TILEHORZ             40003
#define IDM_WINDOW_CASCADE              40004
#define IDM_WINDOW_ARRANGEICONS         40005
#define IDM_WINDOW_CLOSEALL             40006
#define IDM_HELP_CONTENTS               40100
#define IDM_LV_COLVIEWINTEGRAL          40100
#define IDM_HELP_ABOUT                  40101
#define IDM_LV_ALLVIEWINTEGRAL          40101
#define IDA_HELP                        40102
#define IDM_WINDOW_DATAWINDOW           40103
#define IDM_WINDOW_TILEVERT             40104

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        118
#define _APS_NEXT_COMMAND_VALUE         40105
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
