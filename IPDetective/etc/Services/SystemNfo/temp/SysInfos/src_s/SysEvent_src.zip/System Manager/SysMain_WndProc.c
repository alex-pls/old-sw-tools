#include "SysMain.h"
#include "_GlobalVars.h"
#include "_Constants.h"
#include "_Utils.h"
#include "_ExtraResources.h"

LRESULT CALLBACK
SysMain_WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	LRESULT lResult = 0;
	
	switch(uMsg)
	{
		case WM_CREATE:
			OnCreate(hWnd, wParam, lParam, &lResult);
			break;

		case WM_SYSCOMMAND:
			ComboBox_ShowDropdown(g_hComboToolbarWnd, FALSE);
			lResult = DefFrameProc(hWnd, g_hMDIClientWnd, uMsg, wParam, lParam);
			break;

		case WM_MDIACTIVATE:		
			break;

		case WM_MDICREATE:
			break;

		case WM_LBUTTONDBLCLK:
			SendMessage(g_hToolBarWnd, TB_CUSTOMIZE, 0L, 0L);
			break;

		case WM_CLOSE:
			OnClose(hWnd, &lResult);
			return lResult;
			break;

		case WM_SIZE:
			if(g_hToolBarWnd)
				lResult = SendMessage(g_hToolBarWnd, TB_AUTOSIZE, 0L, 0L);
			OnSize(hWnd, wParam, lParam, &lResult);
			break;

		case WM_COMMAND:
			OnCommand(hWnd, wParam, lParam, &lResult);
			break;

		case WM_NOTIFY:
			OnNotify(hWnd, wParam, lParam, &lResult);
			break;

		default:
			OnIdle(hWnd, &lResult);
			lResult = DefFrameProc(hWnd, g_hMDIClientWnd, uMsg, wParam, lParam);
			break;
	}
	
	return lResult;
}

LRESULT *
OnCreate(HWND hWnd, WPARAM wParam, LPARAM lParam, LRESULT *plResult)
{
	OnCreateMDIClient(hWnd, plResult);
	return plResult;

	_UNREFERENCED_PARAMETER_(wParam);
	_UNREFERENCED_PARAMETER_(lParam);
}

LRESULT *
OnSize(HWND hWnd, WPARAM wParam, LPARAM lParam, LRESULT *plResult)
{
	RECT rc, rcTlb;

	if(g_hToolBarWnd)
		GetWindowRect(g_hToolBarWnd, &rcTlb);
	else
		rcTlb.left = rcTlb.top = rcTlb.right = rcTlb.bottom = 0;

	GetClientRect(hWnd, &rc);
	MoveWindow
		(
			g_hMDIClientWnd, 
			rc.left, 
			rc.top + (rcTlb.bottom - rcTlb.top), 
			rc.right - rc.left, 
			rc.bottom - rc.top - (rcTlb.bottom - rcTlb.top) - 4,
			TRUE
		);

	*plResult = 0;
	return plResult;

	_UNREFERENCED_PARAMETER_(wParam);
	_UNREFERENCED_PARAMETER_(lParam);
}

LRESULT *
OnCreateMDIClient(HWND hWnd, LRESULT *plResult)
{
	CLIENTCREATESTRUCT  ccs;
	RECT rc;

	GetClientRect(hWnd, &rc);

	ccs.hWindowMenu = GetSubMenu(GetMenu(hWnd), IDM_WINDOWMENU);
	ccs.idFirstChild = IDM_MDICHILD;

	g_hMDIClientWnd = 
		CreateWindowEx
			(
				0L, 
				g_lpcszMDIClientWindowClassName, 
				0,
				WS_CHILD | WS_CLIPCHILDREN | WS_VSCROLL | WS_HSCROLL, 
				0,
				0,
				rc.right - rc.left,
				rc.bottom - rc.top,
				hWnd, 
				(HMENU)IDW_MDICLIENT, 
				g_hInstance, 
				(LPSTR)&ccs
			);

	ShowWindow(g_hMDIClientWnd, SW_SHOW);
	UpdateWindow(g_hMDIClientWnd);

	*plResult = 0;
	return plResult;
}

LRESULT*
OnClose(HWND hWnd, LRESULT *plResult)
{
	*plResult = 0;
	PostQuitMessage(0);
	return plResult;

	_UNREFERENCED_PARAMETER_(hWnd);
}

LRESULT*
OnCloseAll(HWND hWnd, LRESULT *plResult)
{
	HWND hWndTemp;

	hWnd = hWnd;

	ShowWindow(g_hMDIClientWnd, SW_HIDE);
	do
	{
		hWndTemp = GetWindow(g_hMDIClientWnd, GW_CHILD);
		
		if(!hWndTemp)
			break;

		SendMessage(g_hMDIClientWnd, WM_MDIDESTROY, (WPARAM)hWndTemp, 0);

	}while(hWndTemp);

	ShowWindow(g_hMDIClientWnd, SW_SHOW);

	*plResult = 0;
	return plResult;
}

LRESULT *
OnCommand(HWND hWnd, WPARAM wParam, LPARAM lParam, LRESULT *plResult)
{
	WORD wCode = LOWORD(wParam);

	switch(wCode)
	{
		// toolbar messages
		case ID_TBCMD_APPLICATION:
			OnApplication(hWnd, plResult);
			break;
		case ID_TBCMD_SYSTEM:
			OnSystem(hWnd, plResult);
			break;
		case ID_TBCMD_SECURITY:
			OnSecurity(hWnd, plResult);
			break;
		case ID_TBCMD_CUSTOM:
			OnCustom(hWnd, plResult);
			break;
		case ID_TBCMD_OPEN:
			OnOpen(hWnd, plResult);
			break;
		case ID_TBCMD_SAVE:
			OnSave(hWnd, plResult);
			break;
		case ID_TBCMD_BACKUP:
			OnBackup(hWnd, plResult);
			break;

		// menu messages
		case IDM_WINDOW_TILEHORZ:
			SendMessage(g_hMDIClientWnd, WM_MDITILE, (WPARAM)MDITILE_HORIZONTAL, 0);
			break;
		case IDM_WINDOW_TILEVERT:
			SendMessage(g_hMDIClientWnd, WM_MDITILE, (WPARAM)MDITILE_VERTICAL, 0);
			break;
		case IDM_WINDOW_CASCADE:
			SendMessage(g_hMDIClientWnd, WM_MDICASCADE, 0, 0);
			break;
		case IDM_WINDOW_ARRANGEICONS:
			SendMessage(g_hMDIClientWnd, WM_MDIICONARRANGE, 0, 0);
			break;
		case IDM_WINDOW_CLOSEALL:
			OnCloseAll(hWnd, plResult);
			break;
		case IDM_WINDOW_DATAWINDOW:
			if(g_hDataWnd)
				SendMessage(g_hMDIClientWnd, WM_MDIACTIVATE, (WPARAM)g_hDataWnd, 0);
			break;

		default:
			*plResult = DefFrameProc(hWnd, g_hMDIClientWnd, WM_COMMAND, wParam, lParam);
			break;
	}

	return plResult;
}

LRESULT *
OnNotify(HWND hWnd, WPARAM wParam, LPARAM lParam, LRESULT *plResult)
{
	UINT uNotifyCode = ((LPNMHDR)lParam)->code;

	switch(uNotifyCode)
	{
		//	Toolbar
		case TTN_NEEDTEXT:
			OnNeedText(hWnd, lParam, plResult);
			*plResult = 0;
			break;

        case TBN_QUERYDELETE:
            *plResult = 1;
            break;

        case TBN_GETBUTTONINFO:
            *plResult = 0;
            break;

        case TBN_QUERYINSERT:
            *plResult = 1;
            break;

        case TBN_CUSTHELP:
            break;

		case TBN_TOOLBARCHANGE:
			*plResult = SendMessage(g_hToolBarWnd, TB_AUTOSIZE, 0L, 0L);
			break;

		default:
			*plResult = 0;
			break;
	}

	return plResult;

	_UNREFERENCED_PARAMETER_(wParam);
}

LRESULT *
OnNeedText(HWND hWnd, LPARAM lParam, LRESULT *plResult)
{
    ((LPTOOLTIPTEXT)lParam)->hinst = g_hInstance;
    ((LPTOOLTIPTEXT)lParam)->lpszText = (LPTSTR)((LPTOOLTIPTEXT)lParam)->hdr.idFrom;

	*plResult = 0;
	return plResult;

	_UNREFERENCED_PARAMETER_(hWnd);
}

LRESULT *
OnApplication(HWND hWnd, LRESULT *plResult)
{
	*plResult = 0;
	g_fApplication = !g_fApplication;
	
	if(g_fApplication)
	{
		g_fApplication	= TRUE;
		g_fSystem		= FALSE;
		g_fSecurity		= FALSE;
		g_fCustom		= FALSE;

		AdjustTypeEventToolbarButtons();
	}
	
	return plResult;

	_UNREFERENCED_PARAMETER_(hWnd);
}

LRESULT *
OnSystem(HWND hWnd, LRESULT *plResult)
{
	*plResult = 0;
	g_fSystem = !g_fSystem;
	
	if(g_fSystem)
	{
		g_fApplication	= FALSE;
		g_fSystem		= TRUE;
		g_fSecurity		= FALSE;
		g_fCustom		= FALSE;

		AdjustTypeEventToolbarButtons();
	}
	
	return plResult;

	_UNREFERENCED_PARAMETER_(hWnd);
}

LRESULT *
OnSecurity(HWND hWnd, LRESULT *plResult)
{
	*plResult = 0;
	g_fSecurity = !g_fSecurity;
	
	if(g_fSecurity)
	{
		g_fApplication	= FALSE;
		g_fSystem		= FALSE;
		g_fSecurity		= TRUE;
		g_fCustom		= FALSE;

		AdjustTypeEventToolbarButtons();
	}
	
	return plResult;

	_UNREFERENCED_PARAMETER_(hWnd);
}

LRESULT *
OnCustom(HWND hWnd, LRESULT *plResult)
{
	*plResult = 0;
	g_fCustom = !g_fCustom;
	
	if(g_fCustom)
	{
		g_fApplication	= FALSE;
		g_fSystem		= FALSE;
		g_fSecurity		= FALSE;
		g_fCustom		= TRUE;

		AdjustTypeEventToolbarButtons();
	}

	return plResult;

	_UNREFERENCED_PARAMETER_(hWnd);
}

LRESULT*
OnOpen(HWND hWnd, LRESULT *plResult)
{
	MDICREATESTRUCT mdics;
	HWND hWndChild; 
	TCHAR lpszBuffer[_MAX_PATH + 1], lpszCaption[_MAX_PATH + 1], lpszMachineName[_MAX_PATH + 1], *lpszFileName = 0;
	BOOL fHasPrec = FALSE, fCreated = TRUE;

	ComboBox_GetLBText(g_hComboToolbarWnd, ComboBox_GetCurSel(g_hComboToolbarWnd), lpszMachineName);

	_stprintf(lpszCaption, "Event Log on %s - ", lpszMachineName);
	if(g_fApplication)
	{
		_stprintf(lpszBuffer, "%s%s", fHasPrec ? ", " : "", "Application"); 
		_tcscat(lpszCaption, lpszBuffer);
		fHasPrec = TRUE;
	}
	if(g_fSecurity)
	{
		_stprintf(lpszBuffer, "%s%s", fHasPrec ? ", " : "", "Security"); 
		_tcscat(lpszCaption, lpszBuffer);
		fHasPrec = TRUE;
	}
	if(g_fSystem)
	{
		_stprintf(lpszBuffer, "%s%s", fHasPrec ? ", " : "", "System"); 
		_tcscat(lpszCaption, lpszBuffer);
		fHasPrec = TRUE;
	}
	if(g_fCustom)
	{
		_stprintf(lpszBuffer, "%s%s", fHasPrec ? ", " : "", "Custom"); 
		_tcscat(lpszCaption, lpszBuffer);
		fHasPrec = TRUE;

		MessageBox(hWnd, _T("This feature is currently under construction and not(yet) available."), 0, MB_OK | MB_ICONINFORMATION);

		return plResult;

		fCreated = GetCustomLogFileName((TCHAR **)&lpszFileName);
	}

	mdics.szClass	= g_lpcszChildWindowClassName;
	mdics.szTitle	= lpszCaption;
	mdics.x			= CW_USEDEFAULT;
	mdics.y			= CW_USEDEFAULT;
	mdics.cx		= CW_USEDEFAULT;
	mdics.cy		= CW_USEDEFAULT;
	mdics.hOwner	= g_hInstance;
	mdics.style		= g_hWndActiveChild && IsZoomed(g_hWndActiveChild) ? WS_MAXIMIZE : 0;

	if(!g_fCustom)
		mdics.lParam = 0;
	else
	{
		if(!fCreated)
		{
			*plResult = 1;
			return plResult;
		}

		mdics.lParam = (LPARAM)(LPCTSTR)lpszFileName;
	}

	hWndChild = (HWND)SendMessage(g_hMDIClientWnd, WM_MDICREATE, 0, (LPARAM)(LPMDICREATESTRUCT)&mdics);
	if(hWndChild)
	{
		g_hWndActiveChild = hWndChild;
		SendMessage(g_hMDIClientWnd, WM_MDIACTIVATE, (WPARAM)hWndChild, 0);
	}

	*plResult = 0;
	return plResult;

	_UNREFERENCED_PARAMETER_(hWnd);
}

LRESULT *
OnSave(HWND hWnd, LRESULT *plResult)
{
	//	save using diferent formats

	*plResult = 0;
	return plResult;

	_UNREFERENCED_PARAMETER_(hWnd);
}

LRESULT*
OnBackup(HWND hWnd, LRESULT *plResult)
{
	HANDLE hEventLog = 0;
	TCHAR lpUNCServerName[_MAX_PATH + 1], lpszEventLogSourceName[_MAX_PATH + 1], lpszComputerName[1024];
	TCHAR *szCaptionDiff;
	TCHAR *lpszBackupFileName = 0;
	TCHAR szFmt[128], szMsg[1024];

	MessageBox(hWnd, _T("This feature is currently under construction and not(yet) available."), 0, MB_OK | MB_ICONINFORMATION);
	return plResult;

	//	get computer name
	{
		GetWindowText(g_hWndActiveChild, lpszComputerName, 1024);
		szCaptionDiff = lpszComputerName + strlen(_T("Event Log on ")) * sizeof(TCHAR);
		szCaptionDiff = _tcstok(szCaptionDiff, _T(" "));
		wsprintf(lpUNCServerName, _T("\\\\%s"), szCaptionDiff);
	}

	//	get source type
	if(g_fApplication)
		_tcscpy(lpszEventLogSourceName, _T("Application"));				//	APPLICATION
	else if(g_fSystem)
		_tcscpy(lpszEventLogSourceName, _T("System"));					//	SYSTEM
	else if(g_fSecurity)
		_tcscpy(lpszEventLogSourceName, _T("Security"));				//	SECURITY
	else
		_tcscpy(lpszEventLogSourceName, _T("Application"));				//	defaulting to APPLICATION

	hEventLog = OpenEventLog((LPCTSTR)lpUNCServerName, (LPCTSTR)lpszEventLogSourceName);
	if(hEventLog)
	{
		if(GetBackupLogFileName(&lpszBackupFileName))
		{
			if(BackupEventLog(hEventLog, (LPCTSTR)lpszBackupFileName))
			{
				LoadString(g_hInstance, IDS_BACKUPFMT_SUCCESS, szFmt, 128);
				_stprintf(szMsg, szFmt, szCaptionDiff, lpszBackupFileName);
			}
			else
			{
				LoadString(g_hInstance, IDS_BACKUPFMT_FAIL, szFmt, 128);
				_stprintf(szMsg, szFmt, szCaptionDiff);
			}

			{
				TCHAR pszErrMsg[1024];
				ReportLastError(pszErrMsg, 0, TRUE);
			}

			MessageBox(0, szMsg, _T("WindowsNT Event Log"), MB_OK | MB_ICONINFORMATION);

			GlobalFree(lpszBackupFileName);
			lpszBackupFileName = 0;
		}

		CloseEventLog(hEventLog);
		hEventLog = 0;
	}

	*plResult = 0;
	return plResult;

	_UNREFERENCED_PARAMETER_(hWnd);
}

LRESULT *
OnIdle(HWND hWnd, LRESULT *plResult)
{
	OnUpdateOpen(hWnd, plResult);
	OnUpdateSave(hWnd, plResult);
	OnUpdateBackup(hWnd, plResult);

	*plResult = 0;
	return plResult;
}

LRESULT* 
OnUpdateOpen(HWND hWnd, LRESULT *plResult)
{
	BOOL fSelected;

	if(!g_hComboToolbarWnd || !g_hToolBarWnd)
	{
		*plResult = 1;
		return plResult;
	}

	fSelected = ComboBox_GetCurSel(g_hComboToolbarWnd) > 0 ? TRUE : FALSE;

	if(!g_fApplication && !g_fSystem && !g_fSecurity && !g_fCustom)
	{
		TBBUTTONINFO tbi;
		tbi.cbSize = sizeof(TBBUTTONINFO);
		tbi.dwMask = TBIF_STATE; 
		
		if(SendMessage(g_hToolBarWnd, TB_GETBUTTONINFO, (WPARAM)(int)ID_TBCMD_OPEN, (LPARAM)(LPTBBUTTONINFO)&tbi) != -1)
		{
			if(tbi.fsState & TBSTATE_ENABLED)
			{
				tbi.fsState &= ~TBSTATE_ENABLED;
				SendMessage(g_hToolBarWnd, TB_SETBUTTONINFO, (WPARAM)(int)ID_TBCMD_OPEN, (LPARAM)(LPTBBUTTONINFO)&tbi);
			}
		}
	}
	else
	{
		TBBUTTONINFO tbi;
		tbi.cbSize = sizeof(TBBUTTONINFO);
		tbi.dwMask = TBIF_STATE; 

		if(SendMessage(g_hToolBarWnd, TB_GETBUTTONINFO, (WPARAM)(int)ID_TBCMD_OPEN, (LPARAM)(LPTBBUTTONINFO)&tbi) != -1)
		{
			if(fSelected)
			{
				if(~(tbi.fsState & TBSTATE_ENABLED))
				{
					tbi.fsState |= TBSTATE_ENABLED;
					SendMessage(g_hToolBarWnd, TB_SETBUTTONINFO, (WPARAM)(int)ID_TBCMD_OPEN, (LPARAM)(LPTBBUTTONINFO)&tbi);
				}
			}
			else
			{
				if(tbi.fsState & TBSTATE_ENABLED)
				{
					tbi.fsState &= ~TBSTATE_ENABLED;
					SendMessage(g_hToolBarWnd, TB_SETBUTTONINFO, (WPARAM)(int)ID_TBCMD_OPEN, (LPARAM)(LPTBBUTTONINFO)&tbi);
				}
			}
		}
	}

	*plResult = 0;
	return plResult;

	_UNREFERENCED_PARAMETER_(hWnd);
}

LRESULT* 
OnUpdateSave(HWND hWnd, LRESULT *plResult)
{
	BOOL fEnabled;

	if(!IsWindow(g_hMDIClientWnd))
		fEnabled = FALSE;
	else
		fEnabled = GetWindow(g_hMDIClientWnd, GW_CHILD) != 0 ? TRUE : FALSE;

	if(IsWindow(g_hToolBarWnd))
	{
		TBBUTTONINFO tbi;
		tbi.cbSize = sizeof(TBBUTTONINFO);
		tbi.dwMask = TBIF_STATE; 

		if(SendMessage(g_hToolBarWnd, TB_GETBUTTONINFO, (WPARAM)(int)ID_TBCMD_SAVE, (LPARAM)(LPTBBUTTONINFO)&tbi) != -1)
		{
			if(!fEnabled)
			{
				if(tbi.fsState & TBSTATE_ENABLED)
				{
					tbi.fsState &= ~TBSTATE_ENABLED;
					SendMessage(g_hToolBarWnd, TB_SETBUTTONINFO, (WPARAM)(int)ID_TBCMD_SAVE, (LPARAM)(LPTBBUTTONINFO)&tbi);
				}
			}
			else if(~(tbi.fsState & TBSTATE_ENABLED))
			{
				tbi.fsState |= TBSTATE_ENABLED;
				SendMessage(g_hToolBarWnd, TB_SETBUTTONINFO, (WPARAM)(int)ID_TBCMD_SAVE, (LPARAM)(LPTBBUTTONINFO)&tbi);
			}
		}
	}

	*plResult = 0;
	return plResult;

	_UNREFERENCED_PARAMETER_(hWnd);
}

LRESULT*
OnUpdateBackup(HWND hWnd, LRESULT *plResult)
{
	BOOL fEnabled;

	if(!IsWindow(g_hMDIClientWnd))
		fEnabled = FALSE;
	else
		fEnabled = GetWindow(g_hMDIClientWnd, GW_CHILD) != 0 ? TRUE : FALSE;

	if(IsWindow(g_hToolBarWnd))
	{
		TBBUTTONINFO tbi;
		tbi.cbSize = sizeof(TBBUTTONINFO);
		tbi.dwMask = TBIF_STATE; 

		if(SendMessage(g_hToolBarWnd, TB_GETBUTTONINFO, (WPARAM)(int)ID_TBCMD_BACKUP, 
			(LPARAM)(LPTBBUTTONINFO)&tbi) != -1)
		{
			if(!fEnabled)
			{
				if(tbi.fsState & TBSTATE_ENABLED)
				{
					tbi.fsState &= ~TBSTATE_ENABLED;
					SendMessage(g_hToolBarWnd, TB_SETBUTTONINFO, (WPARAM)(int)ID_TBCMD_BACKUP, 
						(LPARAM)(LPTBBUTTONINFO)&tbi);
				}
			}
			else if(~(tbi.fsState & TBSTATE_ENABLED))
			{
				tbi.fsState |= TBSTATE_ENABLED;
				SendMessage(g_hToolBarWnd, TB_SETBUTTONINFO, (WPARAM)(int)ID_TBCMD_BACKUP, 
					(LPARAM)(LPTBBUTTONINFO)&tbi);
			}
		}
	}

	*plResult = 0;
	return plResult;

	_UNREFERENCED_PARAMETER_(hWnd);
}
