#ifndef __DataTypes_Header_Defined__
#define __DataTypes_Header_Defined__

	#include "_GlobalHeader.h"

	typedef int fatal;
	typedef int retcode;

#endif /* __DataTypes_Header_Defined__ */
