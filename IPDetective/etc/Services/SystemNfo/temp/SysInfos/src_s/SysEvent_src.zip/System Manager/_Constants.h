#ifndef __Constants_Defined__
#define __Constants_Defined__

	#include "_Structures.h"

	#define CBWNDEXTRA  8
	#define GWLAPP_HDLG 0
	#define GWLAPP_TYPE 4

	extern const TCHAR		*g_lpcszApplicationName;

	extern const TCHAR		*g_lpcszMainWindowClassName;
	extern const TCHAR		*g_lpcszMDIClientWindowClassName;
	extern const TCHAR		*g_lpcszChildWindowClassName;
	extern const TCHAR		*g_lpcszDataWindowClassName;

	extern const TCHAR		*g_lpcszNetworkNeighborhood;

	extern EVENTLOGCOL		 g_pcEventLogListColumns[];

	// user messages
	#define WM_USER_UPDATEEVENTDATA	(WM_USER + 1)

	// 'warning-combat' method
	#define _UNREFERENCED_PARAMETER_(_p_) \
	{\
		(_p_)=(_p_);\
	}

#endif /* __Constants_Defined__ */