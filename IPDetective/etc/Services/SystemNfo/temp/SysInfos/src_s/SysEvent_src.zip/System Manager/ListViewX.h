#ifndef __ListView_Utilities_Defined__
#define __ListView_Utilities_Defined__

	#include "_GlobalHeader.h"

	short ListView_GetColumnCount(HWND hwndLV);
	void  ListView_RefillLParamOrder(HWND hwndLV);
	int	  ListView_OnSort(HWND hDlg, HWND hwndLV, int iColumn, PFNLVCOMPARE lpfnCompare);
	void  ListView_SetNextHeaderAppearance(HWND hwndLV);
	BOOL  ListView_EnsureColumnVisible(HWND hwndLV, short sColIndex);
	BOOL  ListView_EnsureAllColumnsVisible(HWND hwndLV);

#endif /* __ListView_Utilities_Defined__ */
