#ifndef __Utilities_Defined__
#define __Utilities_Defined__

	#include "_GlobalHeader.h"

	#define		CopyStruct(pDest, pSrc)  CopyMemory(pDest, pSrc, sizeof(*(pDest)))

	extern int  LocalToWideChar(LPWSTR pWide, LPTSTR pLocal, DWORD dwChars);
	extern int  WideCharToLocal(LPTSTR pLocal, LPWSTR pWide, DWORD dwChars);

	#define _MBSTR(wstr) hf_wctomb((LPSTR)alloca(wcslen(wstr) + 1), (wstr),wcslen(wstr) + 1)
	#define _WCSTR(str) hf_mbtowc((LPWSTR)alloca((strlen(str) + 1) * sizeof(WCHAR)),(str),strlen(str) + 1)

	LPWSTR hf_mbtowc(LPWSTR lpw, LPCSTR lpa, int nChars);
	LPSTR hf_wctomb(LPSTR lpa, LPCWSTR lpw, int nChars);

	BOOL ReportLastError(LPSTR pszErrMsg, LPCTSTR lpcszCaption, BOOL bShow);
	BOOL ConvertSid(PSID pSid, LPTSTR pszSidText, LPDWORD dwBufferLen);

	BOOL GetNameUse(SID_NAME_USE _SidNameUse, TCHAR *szSIDType, DWORD *pdwIOLen);
	BOOL GetEventLogType(TCHAR *sz, unsigned short uEventType, DWORD *pdwSize);
	BOOL GetEventLogImage(UINT *puImage, unsigned short uEventType);

//	void SafeDeletePointer(void *pBlock, DWORD dwBlockLen);
	#define SafeAllocatePointer(pointer,type,flags,size) (pointer)=(type)(GlobalAlloc((flags),(size)))
	#define SafeDeletePointer(block,size) {if((size)>=0){if((block)&&!(IsBadReadPtr((block),(size)))) {GlobalFree((block));(block)=0;}}}

	BOOL InsertRowInList(HWND hwndLV, int nInsertion, ...);

	int	 FlagToIntCode();
	void IntCodeAdjustFlags(int nCode);

	BOOL GetCustomLogFileName(TCHAR **lppszFileName);
	BOOL GetBackupLogFileName(TCHAR **lppszFileName);

#endif /* __Utilities_Defined__ */
