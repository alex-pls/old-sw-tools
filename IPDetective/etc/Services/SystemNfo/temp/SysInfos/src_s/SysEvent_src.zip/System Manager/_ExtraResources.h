#ifndef __Resources_Defined__
#define __Resources_Defined__

	#include "resource.h"

	#define IDW_SBAR			102
	#define ID_TOOLBAR_MAIN		103

	#define IDW_MDICLIENT		200
	#define IDM_MDICHILD		40007
	#define IDM_WINDOWMENU		  0

	// toolbar constants
	#define NUMIMAGES       2
	#define IMAGEWIDTH      16
	#define IMAGEHEIGHT     16
	#define BUTTONWIDTH     16
	#define BUTTONHEIGHT    16

	#define STATUSICONSIZE  16

	// status bar parts
	#define IDSBP_MSG        0
	#define IDSBP_USERCOUNT  1
	#define IDSBP_ICON       2

	extern TBBUTTON g_arToolbarButtons[];

#endif /* __Resources_Defined__ */
