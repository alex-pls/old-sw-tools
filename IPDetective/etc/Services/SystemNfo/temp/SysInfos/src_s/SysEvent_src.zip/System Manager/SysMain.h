#ifndef __SysMain_Header_Defined__
#define __SysMain_Header_Defined__

	#include "_GlobalHeader.h"
	#include "_DataTypes.h"

	//	initialization
	fatal Initialize(HINSTANCE hThisInstance, HINSTANCE hPrevInstance, LPSTR lpszCmdLine, int nCmdShow);

		//	initialize some startup variables
		void CopyStartupVariables(HINSTANCE hThisInstance, LPSTR lpszCmdLine);
		//	call of InitCommonControlsEx
		fatal InitializeCommonControls();
	
		//	class registerer
		fatal RegisterWindowClasses();
			//	main application's window
			fatal RegisterMainWindowClass();
			//	child window - event list
			fatal RegisterChildWindowClass();
			//	child window - data window
			fatal RegisterChildDataWindowClass();
			//	other additional windows
			fatal RegisterOtherWindowClasses();

		//	window creation
		fatal CreateWindows();
			//	main window
			fatal CreateMainWindow();
			//	toolbar
			fatal CreateToolbar();
				//	toolbar's combo
				retcode CreateToolbarComboBox();
					// init combo
					retcode InitComputersCombo();
						//	subclass to use the appropriate toolbar's combo window procedure
						retcode SubclassToolbarCombo();
						//	add combo tooltip
						retcode AddToolbarComboTooltip();
						//	set font
						retcode SetToolbarComboFont();
					//	fill combo with network workstations
					retcode FillComputersCombo();
			//	status bar
			fatal CreateStatusBar();

		//	dealers with resource handling
		fatal LoadResources();
		fatal UnloadResources();

	//	run application
	retcode		Run();
		//	main window procedure
		LRESULT CALLBACK SysMain_WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
			//	WM_CREATE
			LRESULT *OnCreate(HWND hWnd, WPARAM wParam, LPARAM lParam, LRESULT *plResult);
				//	create MDI client
				LRESULT *OnCreateMDIClient(HWND hWnd, LRESULT *plResult);
			//	WM_CLOSE
			LRESULT *OnClose(HWND hWnd, LRESULT *plResult);
				LRESULT *OnCloseAll(HWND hWnd, LRESULT *plResult);
			//	WM_NOTIFY
			LRESULT *OnNotify(HWND hWnd, WPARAM wParam, LPARAM lParam, LRESULT *plResult);
				//	TTN_NEEDTEXT
				LRESULT *OnNeedText(HWND hWnd, LPARAM lParam, LRESULT *plResult);
			//	WM_COMMAND
			LRESULT *OnCommand(HWND hWnd, WPARAM wParam, LPARAM lParam, LRESULT *plResult);
				//	toolbar buttons
				LRESULT *OnApplication(HWND hWnd, LRESULT *plResult);
				LRESULT *OnSystem(HWND hWnd, LRESULT *plResult);
				LRESULT *OnSecurity(HWND hWnd, LRESULT *plResult);
				LRESULT *OnCustom(HWND hWnd, LRESULT *plResult);
				LRESULT *OnOpen(HWND hWnd, LRESULT *plResult); 
				LRESULT *OnSave(HWND hWnd, LRESULT *plResult); 
				LRESULT *OnBackup(HWND hWnd, LRESULT *plResult); 
			//	WM_SIZE
			LRESULT *OnSize(HWND hWnd, WPARAM wParam, LPARAM lParam, LRESULT *plResult);
				//	simulate ON_UPDATE_COMMAND_UI
				LRESULT *OnIdle(HWND hWnd, LRESULT *plResult); 	
					//	ON_UPDATE_COMMAND_UI - Open
					LRESULT *OnUpdateOpen(HWND hWnd, LRESULT *plResult);
					//	ON_UPDATE_COMMAND_UI - Save
					LRESULT *OnUpdateSave(HWND hWnd, LRESULT *plResult); 
					//	ON_UPDATE_COMMAND_UI - Backup
					LRESULT *OnUpdateBackup(HWND hWnd, LRESULT *plResult); 

			//	toolbar's combo window procedure
			LRESULT CALLBACK ToolbarCombo_WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

			// child event list window procedure
			LRESULT CALLBACK MDIChild_WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
				//	WM_CREATE
				LRESULT *MDIChild_OnCreate(HWND hWnd, WPARAM wParam, LPARAM lParam, LRESULT *plResult);
				//	WM_SIZE
				LRESULT *MDIChild_OnSize(HWND hWnd, WPARAM wParam, LPARAM lParam, LRESULT *plResult);
				//	WM_MDIACTIVATE
				LRESULT *MDIChild_OnMDIActivate(HWND hWnd, WPARAM wParam, LPARAM lParam, LRESULT *plResult);
				//	WM_CLOSE
				LRESULT *MDIChild_OnClose(HWND hWnd, WPARAM wParam, LPARAM lParam, LRESULT *plResult);
				//	WM_DESTROY
				LRESULT *MDIChild_OnDestroy(HWND hWnd, WPARAM wParam, LPARAM lParam, LRESULT *plResult);

			BOOL	CALLBACK MDIChild_DlgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
				//	WM_INITDIALOG
				BOOL *MDIChildDlg_OnInitDialog(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult);
					BOOL *MDIChildDlg_OnInitControls(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult);
						BOOL *MDIChildDlg_OnInitEventList(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult);
						BOOL *MDIChildDlg_OnInitProgress(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult);
				//	WM_SIZE
				BOOL *MDIChildDlg_OnSize(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult);
					void MDIChild_ResizeDlg(HWND hWnd, BOOL bShow);				
				//	WM_COMMAND
				BOOL *MDIChildDlg_OnCommand(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult);
					BOOL *MDIChildDlg_OnButtonClicked(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult);
						BOOL *MDIChildDlg_OnCancel(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult);
					BOOL *MDIChildDlg_OnViewColIntegral(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult);
					BOOL *MDIChildDlg_OnViewAllColIntegral(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult);
				//	WM_NOTIFY
				BOOL *MDIChildDlg_OnNotify(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult);
					//	from list control
					BOOL *MDIChildDlg_ListEvents_OnNotify(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult);
						BOOL *MDIChildDlg_ListEvents_OnColumnClick(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult);
						BOOL *MDIChildDlg_ListEvents_OnRClick(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult);
						BOOL *MDIChildDlg_ListEvents_OnDblClick(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult);
						BOOL *MDIChildDlg_ListEvents_OnKeyDown(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult);
					//	from progress bar
					BOOL *MDIChildDlg_Progress_OnNotify(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult);
						BOOL *MDIChildDlg_Progress_OnCtlColor(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult);

			// child data/description strings window
			LRESULT CALLBACK MDIChildData_WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
				//	WM_CREATE
				LRESULT *MDIChildData_OnCreate(HWND hWnd, WPARAM wParam, LPARAM lParam, LRESULT *plResult);
				//	WM_SIZE
				LRESULT *MDIChildData_OnSize(HWND hWnd, WPARAM wParam, LPARAM lParam, LRESULT *plResult);
				//	WM_MDIACTIVATE
				LRESULT *MDIChildData_OnMDIActivate(HWND hWnd, WPARAM wParam, LPARAM lParam, LRESULT *plResult);
				//	WM_DESTROY
				LRESULT *MDIChildData_OnDestroy(HWND hWnd, WPARAM wParam, LPARAM lParam, LRESULT *plResult);
				//	WM_USER_UPDATEEVENTDATA
				LRESULT *MDIChildData_OnUpdateEventData(HWND hWnd, WPARAM wParam, LPARAM lParam, LRESULT *plResult);

			// child data dialog 
			BOOL CALLBACK MDIChildData_DlgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
				//	WM_INITDIALOG
				BOOL *MDIChildDataDlg_OnInitDialog(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult);
					BOOL *MDIChildDataDlg_OnInitControls(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult);
						BOOL *MDIChildDataDlg_OnInitEditControls(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult);
				//	WM_SIZE
				BOOL *MDIChildDataDlg_OnSize(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult);
					void MDIChildData_ResizeDlg(HWND hWnd, BOOL bShow);
				//	WM_COMMAND
				BOOL *MDIChildDataDlg_OnCommand(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult);
				//	WM_NOTIFY
				BOOL *MDIChildDataDlg_OnNotify(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult);
					BOOL *MDIChildDlg_Data_OnNotify(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult);
					BOOL *MDIChildDlg_Strings_OnNotify(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult);

	retcode		Terminate();	

	// helpers
	void		AdjustTypeEventToolbarButtons();

#endif /* __SysMain_Header_Defined__ */
