#ifndef __Structures_Defined__
#define __Structures_Defined__

	#include "_GlobalHeader.h"

	#define ASCENDING	 1
	#define NONE		 0
	#define DESCENDING	-1

	#define STRING		 0
	#define NUMERIC		 1
	#define DATE		 2
	#define DATETIME	 3

	typedef struct _tagDLGSORTDATA
	{
		HWND	hDlg;
		int		nSortOrder;
		int		nSortType;
		int		nColIdx;
	} DLGSORTDATA;

	typedef struct _tagEVENTLOGCOL
	{
		TCHAR lpszName[32];
		UINT  uCXCol;
		int   nSortType;
		int   nSortOrder;
	} EVENTLOGCOL;

	typedef struct _tagEVENTLOGFILTER
	{
		BOOL		fApplication;
		BOOL		fSecurity;
		BOOL		fSystem;
		BOOL		fCustom;
		TCHAR		lpszComputerName[_MAX_PATH + 1];
		HWND		hwndLV;
		HWND		hwndDlg;
		HWND		hwndProgr;
		HANDLE		hCancelEvent;
		HANDLE		hCloseEvent;
		unsigned	uThreadId;
		TCHAR		lpszCustomEventFileName[_MAX_PATH + 1];
	} EVENTLOGFILTER, *LPEVENTLOGFILTER;

	typedef struct _tagEVENTID
	{
		TCHAR lpszMachineName[_MAX_PATH + 1];
		TCHAR lpszEventName[_MAX_PATH + 1];
		DWORD   dwEventId;
		HWND  hwndDlg;
	} EVENTID, *LPEVENTID;

	typedef struct _tagEVENTLISTPARAM
	{
		DWORD dwEventId;
		DWORD dwListId;
	} EVENTLISTPARAM;

#endif /* __Structures_Defined__ */

