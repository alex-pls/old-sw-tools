#ifndef __EventLogThreads_Defined__
#define __EventLogThreads_Defined__

	#include "_GlobalHeader.h"

	int CALLBACK CompareItems(LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort);

	unsigned int __stdcall FillEventLogList(LPVOID lpParam);
	unsigned int __stdcall ShowEventData(LPVOID lpParam);

#endif /* __EventLogThreads_Defined__ */
