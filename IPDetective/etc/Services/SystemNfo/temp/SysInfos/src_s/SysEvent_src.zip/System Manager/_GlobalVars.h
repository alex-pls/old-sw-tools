#ifndef __GlobalVariables_Header_Defined__
#define __GlobalVariables_Header_Defined__

	#include "_GlobalHeader.h"

	extern HINSTANCE	g_hInstance;
	extern TCHAR		g_lpszCmdLine[_MAX_PATH + 1];
	extern HWND			g_hMainWnd;
	extern HWND			g_hMDIClientWnd;
	extern HWND			g_hWndActiveChild;
	extern HWND			g_hDataWnd;
	extern HWND			g_hToolBarWnd;
	extern HWND			g_hComboToolbarWnd;
	extern WNDPROC		g_lpfnDefTlbCB_WndProc;
	extern BOOL			g_fApplication;
	extern BOOL			g_fSystem;
	extern BOOL			g_fSecurity;
	extern BOOL			g_fCustom;
	extern DWORD		g_dwLastError;
	extern HIMAGELIST	g_hEventListImageList;
	extern HBITMAP		g_hbmAsc;
	extern HBITMAP		g_hbmDesc;
	extern HBITMAP		g_hbmNone;
//	extern HMODULE		g_hRichEditLibrary;
	extern HMENU		g_hLVFloatMenu;

#endif /* __GlobalVariables_Header_Defined__ */
