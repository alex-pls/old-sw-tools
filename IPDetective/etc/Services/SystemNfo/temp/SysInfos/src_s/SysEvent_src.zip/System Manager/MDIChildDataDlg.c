#include "SysMain.h"
#include "_GlobalVars.h"
#include "_Constants.h"
#include "resource.h"

BOOL CALLBACK 
MDIChildData_DlgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	BOOL bResult = FALSE;

	switch(uMsg)
	{
		case WM_INITDIALOG:
			MDIChildDataDlg_OnInitDialog(hWnd, wParam, lParam, &bResult);
			break;

		case WM_SIZE:
			MDIChildDataDlg_OnSize(hWnd, wParam, lParam, &bResult);
			break;

		case WM_COMMAND:
			MDIChildDataDlg_OnCommand(hWnd, wParam, lParam, &bResult);
			break;
			
		case WM_NOTIFY:
			MDIChildDataDlg_OnNotify(hWnd, wParam, lParam, &bResult);
			break;

		case WM_CTLCOLOREDIT:
			wParam = wParam;
			break;

		default:
			break;
	}

	return bResult;
}

BOOL*
MDIChildDataDlg_OnInitDialog(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult)
{
	MDIChildDataDlg_OnInitControls(hWnd, wParam, lParam, pbResult);

	*pbResult = TRUE;
	return pbResult;
}

BOOL *
MDIChildDataDlg_OnNotify(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult)
{
	LPNMHDR pNMHDR = (LPNMHDR)lParam;
	HWND hCtl;
	UINT uIDFrom;
	UINT uCode;

	hCtl	= pNMHDR->hwndFrom;
	uIDFrom = pNMHDR->idFrom;
	uCode	= pNMHDR->code;

	*pbResult = TRUE;

	if(hCtl == GetDlgItem(hWnd, IDE_DATA))
		MDIChildDlg_Data_OnNotify(hWnd, wParam, lParam, pbResult);
	else if(hCtl == GetDlgItem(hWnd, IDE_STRINGS))
		MDIChildDlg_Strings_OnNotify(hWnd, wParam, lParam, pbResult);

	return pbResult;
}

BOOL*
MDIChildDataDlg_OnCommand(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult)
{
	WORD wMsgCode = HIWORD(wParam);
	switch(wMsgCode)
	{
		case EN_SETFOCUS:
			SendMessage(GetParent(GetParent(hWnd)), WM_MDIACTIVATE, (WPARAM)(HWND)GetParent(hWnd), 0);
			break;

		default:
			break;
	}

	*pbResult = TRUE;
	return pbResult;

	_UNREFERENCED_PARAMETER_(lParam);
}

BOOL*
MDIChildDataDlg_OnSize(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult)
{
	HWND hParentWnd, hwndData, hwndStrings;
	RECT rc;
	int xClient = (int)LOWORD(lParam), yClient = (int)HIWORD(lParam);

	hParentWnd  = GetParent(hWnd);
	hwndData	= GetDlgItem(hWnd, IDE_DATA);
	hwndStrings	= GetDlgItem(hWnd, IDE_STRINGS);

	GetClientRect(hWnd, &rc);
	
	MoveWindow(hWnd, 0, 0, xClient, yClient, TRUE);
	MoveWindow(hwndData, rc.left + 2, rc.top + 2, rc.right - rc.left - 4, (rc.bottom - rc.top - 6) / 2, TRUE);
	MoveWindow(hwndStrings, rc.left + 2, rc.top + 4 + (rc.bottom - rc.top - 6) / 2, rc.right - rc.left - 4, 
		(rc.bottom - rc.top - 6) / 2, TRUE);

	if(GetWindowLong(hParentWnd, GWL_USERDATA))
		MDIChildData_ResizeDlg(hWnd, TRUE);

	*pbResult = TRUE;
	return pbResult;

	_UNREFERENCED_PARAMETER_(wParam);
}

BOOL*
MDIChildDataDlg_OnInitControls(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult)
{
	MDIChildDataDlg_OnInitEditControls(hWnd, wParam, lParam, pbResult);

	*pbResult = TRUE;
	return pbResult;
}

BOOL*
MDIChildDataDlg_OnInitEditControls(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult)
{
	*pbResult = TRUE;
	return pbResult;

	_UNREFERENCED_PARAMETER_(hWnd);
	_UNREFERENCED_PARAMETER_(wParam);
	_UNREFERENCED_PARAMETER_(lParam);
}

void 
MDIChildData_ResizeDlg(HWND hWnd, BOOL bShow)
{
//	HWND hParentWnd;
//	RECT rc;

	hWnd  = hWnd;
	bShow = bShow;

	// ...
}

BOOL*
MDIChildDlg_Data_OnNotify(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult)
{
	LPNMHDR pNMHDR = (LPNMHDR)lParam;
	UINT uIDFrom;
	UINT uCode;

	uIDFrom = pNMHDR->idFrom;
	uCode	= pNMHDR->code;

	switch(uCode)
	{
		case NM_CLICK:
			SendMessage(GetParent(GetParent(hWnd)), WM_MDIACTIVATE, (WPARAM)(HWND)GetParent(hWnd), 0);
//			MDIChildDlg_ListEvents_OnClick(hWnd, wParam, lParam, pbResult);
			break;

		case NM_DBLCLK:
			SendMessage(GetParent(GetParent(hWnd)), WM_MDIACTIVATE, (WPARAM)(HWND)GetParent(hWnd), 0);
//			MDIChildDlg_ListEvents_OnDblClick(hWnd, wParam, lParam, pbResult);
			break;

		default:
			break;
	}

	*pbResult = TRUE;
	return pbResult;

	_UNREFERENCED_PARAMETER_(wParam);
}

BOOL*
MDIChildDlg_Strings_OnNotify(HWND hWnd, WPARAM wParam, LPARAM lParam, BOOL *pbResult)
{
	LPNMHDR pNMHDR = (LPNMHDR)lParam;
	UINT uIDFrom;
	UINT uCode;

	uIDFrom = pNMHDR->idFrom;
	uCode	= pNMHDR->code;

	switch(uCode)
	{
		case NM_CLICK:
			SendMessage(GetParent(GetParent(hWnd)), WM_MDIACTIVATE, (WPARAM)(HWND)GetParent(hWnd), 0);
//			MDIChildDlg_ListEvents_OnClick(hWnd, wParam, lParam, pbResult);
			break;

		case NM_DBLCLK:
			SendMessage(GetParent(GetParent(hWnd)), WM_MDIACTIVATE, (WPARAM)(HWND)GetParent(hWnd), 0);
//			MDIChildDlg_ListEvents_OnDblClick(hWnd, wParam, lParam, pbResult);
			break;

		default:
			break;
	}

	*pbResult = TRUE;
	return pbResult;

	_UNREFERENCED_PARAMETER_(wParam);
}
