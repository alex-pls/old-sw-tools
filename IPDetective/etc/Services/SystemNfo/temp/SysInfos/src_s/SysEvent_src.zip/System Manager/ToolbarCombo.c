#include "SysMain.h"
#include "_GlobalVars.h"

LRESULT CALLBACK 
ToolbarCombo_WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch(uMsg)
	{
		case WM_MOUSEMOVE:
		case WM_LBUTTONDOWN:
		case WM_LBUTTONUP:
		{
			MSG msg;
			HWND hWndTT;
			msg.lParam	= lParam;
			msg.wParam	= wParam;
			msg.message = uMsg;
			msg.hwnd	= hWnd;
			hWndTT		= (HWND)SendMessage(g_hToolBarWnd, TB_GETTOOLTIPS, 0, 0);

			SendMessage(hWndTT, TTM_RELAYEVENT, 0, (LPARAM)(LPMSG)&msg);

			break;
		}

		default:
			break;
	}

	return (CallWindowProc(g_lpfnDefTlbCB_WndProc, hWnd, uMsg, wParam, lParam));
}
