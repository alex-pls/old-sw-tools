#include "_Utils.h"
#include "_GlobalVars.h"
#include "_ExtraResources.h"
#include "_Constants.h"

TBBUTTON g_arToolbarButtons[] =
{
	{0 , 0						, TBSTATE_ENABLED					, TBSTYLE_SEP					,  0,  0,  0,  0},
	{0 , 0						, TBSTATE_ENABLED					, TBSTYLE_SEP					,  0,  0,  0,  0},
	{0 , 0						, TBSTATE_ENABLED					, TBSTYLE_SEP					,  0,  0,  0,  0},
	{0 , 0						, TBSTATE_ENABLED					, TBSTYLE_SEP					,  0,  0,  0,  0},
	{0 , 0						, TBSTATE_ENABLED					, TBSTYLE_SEP					,  0,  0,  0,  0},
	{0 , 0						, TBSTATE_ENABLED					, TBSTYLE_SEP					,  0,  0,  0,  0},
	{0 , 0						, TBSTATE_ENABLED					, TBSTYLE_SEP					,  0,  0,  0,  0},
	{0 , 0						, TBSTATE_ENABLED					, TBSTYLE_SEP					,  0,  0,  0,  0},
	{0 , 0						, TBSTATE_ENABLED					, TBSTYLE_SEP					,  0,  0,  0,  0},
	{0 , 0						, TBSTATE_ENABLED					, TBSTYLE_SEP					,  0,  0,  0,  0},
	{0 , 0						, TBSTATE_ENABLED					, TBSTYLE_SEP					,  0,  0,  0,  0},
	{0 , 0						, TBSTATE_ENABLED					, TBSTYLE_SEP					,  0,  0,  0,  0},
	{0 , 0						, TBSTATE_ENABLED					, TBSTYLE_SEP					,  0,  0,  0,  0},
	{0 , ID_TBCMD_APPLICATION	, TBSTATE_ENABLED | TBSTATE_CHECKED	, TBSTYLE_BUTTON | TBSTYLE_CHECK,  0,  0,  0,  0}, 
	{1 , ID_TBCMD_SYSTEM		, TBSTATE_ENABLED					, TBSTYLE_BUTTON | TBSTYLE_CHECK,  0,  0,  0,  0}, 
	{2 , ID_TBCMD_SECURITY		, TBSTATE_ENABLED					, TBSTYLE_BUTTON | TBSTYLE_CHECK,  0,  0,  0,  0}, 
//	{3 , ID_TBCMD_CUSTOM		, TBSTATE_ENABLED					, TBSTYLE_BUTTON | TBSTYLE_CHECK,  0,  0,  0,  0}, 
	{0 , 0						, TBSTATE_ENABLED					, TBSTYLE_SEP					,  0,  0,  0,  0},
	{4 , ID_TBCMD_OPEN			, TBSTATE_ENABLED					, TBSTYLE_BUTTON				,  0,  0,  0,  0},
//	{5 , ID_TBCMD_SAVE			, TBSTATE_ENABLED					, TBSTYLE_BUTTON				,  0,  0,  0,  0},
//	{6 , ID_TBCMD_BACKUP		, TBSTATE_ENABLED					, TBSTYLE_BUTTON				,  0,  0,  0,  0},
	{-1, -1						, (BYTE)-1							, (BYTE)-1						, (BYTE)-1, (BYTE)-1, (BYTE)-1, -1},
};

// none - 0, application - 1, system - 2, security - 3, custom - 4
int	 
FlagToIntCode()
{
	if(g_fApplication)
		return 1;
	if(g_fSystem)
		return 2;
	if(g_fSecurity)
		return 3;
	if(g_fCustom)
		return 4;
	return 0;
}

void IntCodeAdjustFlags(int nCode)
{
	g_fApplication	= FALSE;
	g_fSystem		= FALSE;
	g_fSecurity		= FALSE;
	g_fCustom		= FALSE;

	if(nCode == 1)
		g_fApplication = TRUE;
	if(nCode == 2)
		g_fSystem = TRUE;
	if(nCode == 3)
		g_fSecurity = TRUE;
	if(nCode == 4)
		g_fCustom = TRUE;
}

int 
WideCharToLocal(LPTSTR pLocal, LPWSTR pWide, DWORD dwChars)
{
	*pLocal = 0;

	#ifdef UNICODE
		lstrcpyn(pLocal, pWide, dwChars);
	#else
		WideCharToMultiByte(CP_ACP, 0, pWide, -1, pLocal, dwChars, 0, 0);
	#endif

	return lstrlen(pLocal);
}

int 
LocalToWideChar(LPWSTR pWide, LPTSTR pLocal, DWORD dwChars)
{
	*pWide = 0;

	#ifdef UNICODE
		lstrcpyn(pWide, pLocal, dwChars);
	#else
		MultiByteToWideChar(CP_ACP, 0, pLocal, -1, pWide, dwChars); 
	#endif

	return lstrlenW(pWide);
}

LPWSTR 
hf_mbtowc(LPWSTR lpw, LPCSTR lpa, int nChars)
{
//	assert(lpa != NULL);
//	assert(lpw != NULL);
	
	lpw[0] = '\0';
	MultiByteToWideChar(CP_ACP, 0, lpa, -1, lpw, nChars);
	return lpw;
}

LPSTR 
hf_wctomb(LPSTR lpa, LPCWSTR lpw, int nChars)
{
//	assert(lpw != NULL);
//	assert(lpa != NULL);
	
	lpa[0] = '\0';
	WideCharToMultiByte(CP_ACP, 0, lpw, -1, lpa, nChars, NULL, NULL);
	return lpa;
}


BOOL ConvertSid(PSID pSid, LPTSTR pszSidText, LPDWORD dwBufferLen) 
{ 
     DWORD                     dwSubAuthorities; 
     DWORD                     dwSidRev = SID_REVISION; 
     DWORD                     dwCounter; 
     DWORD                     dwSidSize; 
     PSID_IDENTIFIER_AUTHORITY psia; 
 
     if(!IsValidSid(pSid))  
          return FALSE; 
 
     psia = GetSidIdentifierAuthority(pSid); 

     dwSubAuthorities =* GetSidSubAuthorityCount(pSid); 
 
     dwSidSize = (15 + 12 + (12 * dwSubAuthorities) + 1) * sizeof(TCHAR); 
 
     if (*dwBufferLen < dwSidSize)
	 { 
          *dwBufferLen = dwSidSize; 
          SetLastError(ERROR_INSUFFICIENT_BUFFER); 
          return FALSE; 
	 } 
 
     dwSidSize=wsprintf(pszSidText, TEXT("S-%lu-"), dwSidRev ); 
 
     if((psia->Value[0] != 0) || (psia->Value[1] != 0))
          dwSidSize += wsprintf(pszSidText + lstrlen(pszSidText), 
          TEXT("0x%02hx%02hx%02hx%02hx%02hx%02hx"), 
          (USHORT)psia->Value[0], 
          (USHORT)psia->Value[1], 
          (USHORT)psia->Value[2], 
          (USHORT)psia->Value[3], 
          (USHORT)psia->Value[4], 
          (USHORT)psia->Value[5]); 
     else 
          dwSidSize += wsprintf(pszSidText + lstrlen(pszSidText), 
                               TEXT("%lu"), 
                               (ULONG)(psia->Value[5]      )   + 
                               (ULONG)(psia->Value[4] <<  8)   + 
                               (ULONG)(psia->Value[3] << 16)   + 
                               (ULONG)(psia->Value[2] << 24)   ); 
 
     for (dwCounter=0 ; dwCounter < dwSubAuthorities ; dwCounter++)
          dwSidSize+=wsprintf(pszSidText + dwSidSize, TEXT("-%lu"), *GetSidSubAuthority(pSid, dwCounter)); 
 
     return TRUE; 
} 

BOOL ReportLastError(LPSTR pszErrMsg, LPCTSTR lpcszCaption, BOOL bShow)
{
	LPVOID lpMsgBuf = 0;
	int cchSizeOf = 1024;
//	TCHAR *p;

	g_dwLastError = GetLastError();
	if(g_dwLastError != NOERROR)
	{
		FormatMessage(
			FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_IGNORE_INSERTS | FORMAT_MESSAGE_FROM_SYSTEM, 
			0, g_dwLastError, MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), (LPTSTR)&lpMsgBuf, cchSizeOf, 0);

		if(lpMsgBuf)
		{
			if(bShow)
				MessageBox(0, (LPCTSTR)lpMsgBuf, lpcszCaption, MB_OK | MB_ICONEXCLAMATION);
			
			if(pszErrMsg)
			{
				*pszErrMsg = '\0';
				strcpy(pszErrMsg, (LPCTSTR)lpMsgBuf);

//				p = strstr(pszErrMsg, "\r\n");
//				if(p)
//					pszErrMsg[p - pszErrMsg] = '\0';
			}

			LocalFree(lpMsgBuf);
			lpMsgBuf = 0;
		}
		else
			MessageBox(0, TEXT("Cannot allocate error message buffer."), 0, MB_OK | MB_ICONSTOP);
	}

	return pszErrMsg ? TRUE : FALSE;
}

BOOL GetEventLogType(TCHAR *sz, unsigned short uEventType, DWORD *pdwSize)
{
	if(!sz || !pdwSize)
		return FALSE;

	switch(uEventType)
	{
		case EVENTLOG_SUCCESS:
			strncpy(sz, _T("Success"), *pdwSize);
			break;
		case EVENTLOG_ERROR_TYPE:
			strncpy(sz, _T("Error"), *pdwSize);
			break;
		case EVENTLOG_WARNING_TYPE:
			strncpy(sz, _T("Warning"), *pdwSize);
			break;
		case EVENTLOG_INFORMATION_TYPE:
			strncpy(sz, _T("Information"), *pdwSize);
			break;
		case EVENTLOG_AUDIT_SUCCESS:
			strncpy(sz, _T("Success Audit"), *pdwSize);
			break;
		case EVENTLOG_AUDIT_FAILURE:
			strncpy(sz, _T("Failure Audit"), *pdwSize);
			break;
		default:
			strncpy(sz, _T("Unknown"), *pdwSize);
			break;
	}

	*pdwSize = strlen(sz);
	return TRUE;
}

BOOL GetEventLogImage(UINT *puImage, unsigned short uEventType)
{
	if(!puImage)
		return FALSE;

	switch(uEventType)
	{
		case EVENTLOG_SUCCESS:
			*puImage = 2;
			break;
		case EVENTLOG_ERROR_TYPE:
			*puImage = 1;
			break;
		case EVENTLOG_WARNING_TYPE:
			*puImage = 0;
			break;
		case EVENTLOG_INFORMATION_TYPE:
			*puImage = 2;
			break;
		case EVENTLOG_AUDIT_SUCCESS:
			*puImage = 4;
			break;
		case EVENTLOG_AUDIT_FAILURE:
			*puImage = 3;
			break;
		default:
			*puImage = 0;
			break;
	}

	return TRUE;
}

BOOL GetNameUse(SID_NAME_USE _SidNameUse, TCHAR *szSIDType, DWORD *pdwIOLen)
{
	if(!szSIDType || !pdwIOLen)
		return FALSE;

	szSIDType[0] = '\0';
	switch(_SidNameUse)
	{
		case SidTypeUser:
			LoadString(g_hInstance, IDS_SIDTYPE_USER, szSIDType, *pdwIOLen);
			break;
		case SidTypeGroup:
			LoadString(g_hInstance, IDS_SIDTYPE_GROUP, szSIDType, *pdwIOLen);
			break;
		case SidTypeDomain:
			LoadString(g_hInstance, IDS_SIDTYPE_DOMAIN, szSIDType, *pdwIOLen);
			break;
		case SidTypeAlias:
			LoadString(g_hInstance, IDS_SIDTYPE_ALIAS, szSIDType, *pdwIOLen);
			break;
		case SidTypeWellKnownGroup:
			LoadString(g_hInstance, IDS_SIDTYPE_WELLKNOWNGROUP, szSIDType, *pdwIOLen);
			break;
		case SidTypeDeletedAccount:
			LoadString(g_hInstance, IDS_SIDTYPE_DELETEDACCOUNT, szSIDType, *pdwIOLen);
			break;
		case SidTypeInvalid:
			LoadString(g_hInstance, IDS_SIDTYPE_INVALID, szSIDType, *pdwIOLen);
			break;
		case SidTypeUnknown:
			LoadString(g_hInstance, IDS_SIDTYPE_UNKNOWN, szSIDType, *pdwIOLen);
			break;
		case SidTypeComputer:
			LoadString(g_hInstance, IDS_SIDTYPE_COMPUTER, szSIDType, *pdwIOLen);
			break;
		default:
			LoadString(g_hInstance, IDS_SIDTYPE_OUTOFTYPE, szSIDType, *pdwIOLen);
			break;
	}						

	*pdwIOLen = strlen(szSIDType);
	return TRUE;
}

/*
void SafeDeletePointer(void *pBlock, DWORD dwBlockLen)
{
	if(dwBlockLen >= 0)
	{
		if(pBlock && !IsBadReadPtr(pBlock, dwBlockLen))
		{
			GlobalFree(pBlock);
			pBlock = 0;
		}
	}
}
*/

BOOL InsertRowInList(HWND hwndLV, int nInsertCount, ...)
{
	int nCount, nItem;
	va_list marker;
	DWORD dwId;
	register int i;
	LVITEM lvItem;
	EVENTLISTPARAM elp;

	if(!IsWindow(hwndLV))
		return FALSE;

	nCount = ListView_GetItemCount(hwndLV);

	lvItem.mask = LVIF_TEXT | LVIF_PARAM;
	lvItem.pszText = " ";
	lvItem.cchTextMax = strlen(" ");
	lvItem.iItem = nCount;
	lvItem.iImage = 0;
	lvItem.iSubItem = 0;
	lvItem.state = 0;
	lvItem.stateMask = 0;
	lvItem.iIndent = 0;
	lvItem.lParam = nCount;
	
	nItem = ListView_InsertItem(hwndLV, &lvItem);

	va_start(marker, nInsertCount);

	dwId = *((DWORD *)(va_arg(marker, DWORD*)));

	elp.dwEventId	= dwId;
	elp.dwListId	= nCount;

	lvItem.mask = LVIF_PARAM;
	lvItem.iItem = nCount;
	lvItem.iSubItem = 0;
	lvItem.lParam = (LPARAM)dwId; //(EVENTLISTPARAM *)(&elp);
	ListView_SetItem(hwndLV, &lvItem);

	for(i = 0; i < nInsertCount - 1; i++)
	{
		char *szItemText = va_arg(marker, char *);
		ListView_SetItemText(hwndLV, nItem, i, szItemText);

		if(i == 4) // error
		{
			UINT uImage = va_arg(marker, UINT);
			LVITEM lvItem;
			lvItem.mask = LVIF_IMAGE;
			lvItem.iImage = uImage;
			lvItem.iItem = nItem;
			lvItem.iSubItem = 0;
			ListView_SetItem(hwndLV, &lvItem);
		}
	}
	va_end(marker);

	return TRUE;
}

BOOL 
GetCustomLogFileName(TCHAR **lppszFileName)
{
	BOOL fCreated = FALSE;
	OPENFILENAME *pofn = 0;
	TCHAR lpszTitle[_MAX_PATH + 1], lpszFilter[_MAX_PATH + 1] = _T("Event log files (*.evt)\0*.evt\0All files (*.*)\0*.*\0\0"),
		lpszDefExt[_MAX_PATH + 1],
//		lpszInitialDir[_MAX_PATH + 1]	= _T("C:\\"),
		lpszFileName[_MAX_PATH + 1];
	DWORD dwFlags;

	if(!lppszFileName)
		goto _cleanup_;

	*lppszFileName = (TCHAR *)GlobalAlloc(GPTR, (_MAX_PATH + 1) * sizeof(TCHAR));
	if(!*lppszFileName)
		goto _cleanup_;

	_tcscpy(*lppszFileName, _T(""));
	*lppszFileName[0] = _T('\0');

	dwFlags = 
		OFN_EXPLORER			| 
		OFN_EXTENSIONDIFFERENT	| 
		OFN_FILEMUSTEXIST		| 
		OFN_LONGNAMES			| 
		OFN_NOCHANGEDIR			| 
		OFN_PATHMUSTEXIST		| 
		OFN_READONLY			|
		0;

	pofn = (LPOPENFILENAME)GlobalAlloc(GPTR, sizeof(OPENFILENAME));
	if(!pofn)
		goto _cleanup_;

	// preparations
	lpszFileName[0] = _T('\0'); // a must
	// strings
	LoadString(g_hInstance, IDS_OPENEVENTLOG_TITLE , lpszTitle, _MAX_PATH + 1);
	LoadString(g_hInstance, IDS_OPENEVENTLOG_DEFEXT, lpszDefExt, _MAX_PATH + 1);

	pofn->hInstance			= g_hInstance;
	pofn->hwndOwner			= g_hMainWnd;
	pofn->nMaxFile			= _MAX_PATH + 1;
	pofn->nFilterIndex		= 1;
	pofn->Flags				= dwFlags;
	pofn->lpstrFile			= lpszFileName;
	pofn->lpstrFilter		= lpszFilter;
	pofn->lpstrTitle		= lpszTitle;
	pofn->lpstrDefExt		= lpszDefExt;
	pofn->lCustData			= 0;
    pofn->lpfnHook			= 0;
    pofn->lpTemplateName	= 0;
    pofn->lpstrFileTitle	= 0;
    pofn->nMaxFileTitle		= 0;
    pofn->lpstrInitialDir	= 0;
	pofn->nFileOffset		= 0;
	pofn->nFileExtension	= 0;
	pofn->lStructSize		= sizeof(OPENFILENAME);

	fCreated = GetOpenFileName(pofn);
	if(fCreated)
	{
		_tcscpy(*lppszFileName, lpszFileName);
		goto _return_;
	}

_cleanup_:
	if(*lppszFileName)
	{
		GlobalFree(*lppszFileName);
		*lppszFileName = 0;
	}

_return_:
	if(pofn)
	{
		GlobalFree(pofn);
		pofn = 0;
	}

	return fCreated;
}

BOOL 
GetBackupLogFileName(TCHAR **lppszFileName)
{
	BOOL fCreated = FALSE;
	OPENFILENAME ofn;
	TCHAR lpszTitle[_MAX_PATH + 1], 
		//lpszFilter[_MAX_PATH + 1] = _T("Event log files (*.evt)\0*.evt\0\0"),
		lpszDefExt[_MAX_PATH + 1],
		lpszFileName[_MAX_PATH + 1];
	DWORD dwFlags;

	if(!lppszFileName)
		goto _cleanup_;

	*lppszFileName = (TCHAR *)GlobalAlloc(GPTR, (_MAX_PATH + 1) * sizeof(TCHAR));
	if(!*lppszFileName)
		goto _cleanup_;

	_tcscpy(*lppszFileName, _T(""));
	*lppszFileName[0] = _T('\0');

	dwFlags = 
//		OFN_EXPLORER			| 
//		OFN_EXTENSIONDIFFERENT	| 
//		OFN_FILEMUSTEXIST		| 
//		OFN_LONGNAMES			| 
//		OFN_NOCHANGEDIR			| 
//		OFN_PATHMUSTEXIST		| 
//		OFN_READONLY			|
		0;

	ZeroMemory(&ofn, sizeof(OPENFILENAME));

	// preparations
	lpszFileName[0] = _T('\0'); // a must
	// strings
	LoadString(g_hInstance, IDS_OPENEVENTLOG_TITLE , lpszTitle, _MAX_PATH + 1);
	LoadString(g_hInstance, IDS_OPENEVENTLOG_DEFEXT, lpszDefExt, _MAX_PATH + 1);

	ofn.lStructSize			= sizeof(OPENFILENAME);
	ofn.hwndOwner			= 0;
	ofn.hInstance			= (HANDLE)g_hInstance;
	ofn.lpstrFilter			= _T("Event log files (*.evt)\0*.evt\0\0");
	ofn.lpstrCustomFilter	= 0;
	ofn.nMaxCustFilter		= 0L;
	ofn.nFilterIndex		= 1L;
	ofn.lpstrFile			= lpszFileName;
	ofn.nMaxFile			= (_MAX_PATH + 1)*sizeof(TCHAR);
	ofn.lpstrFileTitle		= 0;
	ofn.nMaxFileTitle		= 0;
	ofn.lpstrInitialDir		= NULL;
	ofn.lpstrTitle			= "Save event log:";
	ofn.nFileOffset			= 0;
	ofn.nFileExtension		= 0;
	ofn.lpstrDefExt			= _T("*.evt");
	ofn.lCustData			= 0;

	fCreated = GetOpenFileName(&ofn);
	if(fCreated)
	{
		_tcscpy(*lppszFileName, lpszFileName);
		goto _return_;
	}

_cleanup_:
	if(*lppszFileName)
	{
		GlobalFree(*lppszFileName);
		*lppszFileName = 0;
	}

_return_:
	return fCreated;
}
