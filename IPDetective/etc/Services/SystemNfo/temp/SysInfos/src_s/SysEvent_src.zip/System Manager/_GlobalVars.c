#include "_GlobalVars.h"

TCHAR		g_lpszCmdLine[_MAX_PATH + 1];
HINSTANCE	g_hInstance				= 0;
HWND		g_hMainWnd				= 0;
HWND		g_hMDIClientWnd			= 0;
HWND		g_hWndActiveChild		= 0;
HWND		g_hDataWnd				= 0;
HWND		g_hToolBarWnd			= 0;
HWND		g_hComboToolbarWnd		= 0;
WNDPROC		g_lpfnDefTlbCB_WndProc	= 0;
BOOL		g_fApplication			= TRUE;
BOOL		g_fSystem				= FALSE;
BOOL		g_fSecurity				= FALSE;
BOOL		g_fCustom				= FALSE;
DWORD		g_dwLastError			= 0L;
HIMAGELIST	g_hEventListImageList	= 0;
HBITMAP		g_hbmAsc				= 0;
HBITMAP		g_hbmDesc				= 0;
HBITMAP		g_hbmNone				= 0;
//HMODULE		g_hRichEditLibrary		= 0;
HMENU		g_hLVFloatMenu			= 0;
