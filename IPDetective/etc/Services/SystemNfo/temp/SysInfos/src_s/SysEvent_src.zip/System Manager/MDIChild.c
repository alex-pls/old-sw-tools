#include "SysMain.h"
#include "_GlobalVars.h"
#include "_Constants.h"
#include "_Utils.h"
#include "resource.h"

LRESULT CALLBACK 
MDIChild_WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	LRESULT lResult = 0;

	switch(uMsg)
	{
		case WM_CREATE:
			MDIChild_OnCreate(hWnd, wParam, lParam, &lResult);
			break;

		case WM_SIZE:
			MDIChild_OnSize(hWnd, wParam, lParam, &lResult);
			break;

		case WM_CLOSE:
			MDIChild_OnClose(hWnd, wParam, lParam, &lResult);
			break;

		case WM_MDIACTIVATE:
			MDIChild_OnMDIActivate(hWnd, wParam, lParam, &lResult);
			break;

		case WM_DESTROY:
			MDIChild_OnDestroy(hWnd, wParam, lParam, &lResult);
			break;

		default:
			lResult = DefMDIChildProc(hWnd, uMsg, wParam, lParam);
			break;
	}

	return lResult;
}

LRESULT*
MDIChild_OnClose(HWND hWnd, WPARAM wParam, LPARAM lParam, LRESULT *plResult)
{
	EVENTLOGFILTER *pelf = (EVENTLOGFILTER *)(GetWindowLong(hWnd, GWL_USERDATA));
	if(pelf)
		SetEvent(pelf->hCloseEvent);

	*plResult = DefMDIChildProc(hWnd, WM_CLOSE, wParam, lParam);
	g_hWndActiveChild = (HWND)SendMessage(g_hMDIClientWnd, WM_MDIGETACTIVE, 0, 0);
	return plResult;

	_UNREFERENCED_PARAMETER_(wParam);
	_UNREFERENCED_PARAMETER_(lParam);
}

LRESULT*
MDIChild_OnCreate(HWND hWnd, WPARAM wParam, LPARAM lParam, LRESULT *plResult)
{
	HWND    hWndTemp;
	TCHAR lpszMachineName[_MAX_PATH + 1];
	EVENTLOGFILTER *pelf = 0;

	ComboBox_GetLBText(g_hComboToolbarWnd, ComboBox_GetCurSel(g_hComboToolbarWnd), lpszMachineName);

	pelf = GlobalAlloc(GPTR, sizeof(EVENTLOGFILTER));
	if(!pelf)
	{
		*plResult = 1;
		return plResult;
	}

	pelf->fApplication	= g_fApplication;
	pelf->fSecurity		= g_fSecurity;
	pelf->fSystem		= g_fSystem;
	pelf->fCustom		= g_fCustom;
	pelf->hwndDlg		= 0;
	pelf->hwndLV		= 0;
	_tcscpy(pelf->lpszComputerName, lpszMachineName);

	//
	//	This can be REALLY quite hard to read. But I like it!!!
	//
	//	lParam is 0 if creation of child window is not using a custom event log file. 
	//	In case is not 0, for sure we are using a custom log file. 
	//	lParam is in fact a LPCREATESTRUCT, used by MDI client window to inform child window how to create. 
	//	This CREATESTRUCT parameter has the member lpCreateParams, which is, in fact, the LPMDICREATESTRUCT 
	//	we pass when sending WM_MDICREATE. 
	//	In the lParam member resides the name of the custom event log file name.
	//	
	//	lParam					==> LPCREATESTRUCT		lpcs					
	//	lpcs->lpCreateParams	==>	LPMDICREATESTRUCT	lpmdics					
	//	lpmdics->lParam			==> LPSTR				lpszCustomEventFileName
	//
	{
		TCHAR *lpszFileName = (TCHAR *)(((LPMDICREATESTRUCT)(((LPCREATESTRUCT)lParam)->lpCreateParams))->lParam);
		if(lpszFileName)
		{
			_tcscpy(pelf->lpszCustomEventFileName, lpszFileName);

			//	Because was allocated by GetCustomLogFileName, the string must be deallocated NOW.
			GlobalFree(lpszFileName);
			lpszFileName = 0;
		}
		else
			pelf->lpszCustomEventFileName[0] = _T('\0');
	}

	g_hWndActiveChild = hWnd;
	hWndTemp = CreateDialogParam(g_hInstance, MAKEINTRESOURCE(IDD_MDICHILD), hWnd, MDIChild_DlgProc, (LPARAM)pelf);

	if(!hWndTemp)
	{
		*plResult = -1;
		return plResult;
	}

	SetWindowLong(hWnd, GWLAPP_HDLG , (LONG)hWndTemp);
	SetWindowLong(hWnd, GWLAPP_TYPE,  (LONG)FlagToIntCode());
	SetWindowLong(hWnd, GWL_USERDATA, (LONG)0); // has no thread (yet)

	ShowWindow(hWndTemp, SW_SHOW);
	UpdateWindow(hWndTemp);

	*plResult = 0;
	return plResult;

	_UNREFERENCED_PARAMETER_(wParam);
	_UNREFERENCED_PARAMETER_(lParam);
}

LRESULT *
MDIChild_OnSize(HWND hWnd, WPARAM wParam, LPARAM lParam, LRESULT *plResult)
{
	DefMDIChildProc(hWnd, WM_SIZE, wParam, lParam);
	SendMessage((HWND)GetWindowLong(hWnd, GWLAPP_HDLG), WM_SIZE, wParam, lParam);

	*plResult = 0;
	return plResult;
}

LRESULT *
MDIChild_OnMDIActivate(HWND hWnd, WPARAM wParam, LPARAM lParam, LRESULT *plResult)
{
	int nType = (int)GetWindowLong(hWnd, GWLAPP_TYPE);

	IntCodeAdjustFlags(nType);
	AdjustTypeEventToolbarButtons();

	g_hWndActiveChild = (HWND)SendMessage(g_hMDIClientWnd, WM_MDIGETACTIVE, 0, 0);

	*plResult = 0;
	return plResult;

	_UNREFERENCED_PARAMETER_(wParam);
	_UNREFERENCED_PARAMETER_(lParam);
}

LRESULT *
MDIChild_OnDestroy(HWND hWnd, WPARAM wParam, LPARAM lParam, LRESULT *plResult)
{
	DLGPROC lpDlgProc;

	lpDlgProc = (DLGPROC)GetWindowLong((HWND)GetWindowLong(hWnd, GWLAPP_HDLG), DWL_DLGPROC);
	
	DestroyWindow((HWND)GetWindowLong(hWnd, GWLAPP_HDLG));
	FreeProcInstance(lpDlgProc);
	
	if(hWnd == g_hWndActiveChild)
		g_hWndActiveChild = (HWND)0;

	*plResult = 0;
	return plResult;

	_UNREFERENCED_PARAMETER_(wParam);
	_UNREFERENCED_PARAMETER_(lParam);
}

