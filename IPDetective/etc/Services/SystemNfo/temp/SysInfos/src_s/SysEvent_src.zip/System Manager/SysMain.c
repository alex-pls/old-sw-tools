#include "SysMain.h"
#include "_GlobalVars.h"
#include "_Constants.h"
#include "resource.h"

int WINAPI
WinMain(HINSTANCE hThisInstance, HINSTANCE hPrevInstance, LPSTR lpszCmdLine, int nCmdShow)
{
	retcode _retval;

	Initialize(hThisInstance, hPrevInstance, lpszCmdLine, nCmdShow);
	_retval = Run();
	Terminate();

	return _retval;
}

fatal
Initialize(HINSTANCE hThisInstance, HINSTANCE hPrevInstance, LPSTR lpszCmdLine, int nCmdShow)
{
	fatal _retval = 0;

	CoInitialize(0);

	CopyStartupVariables(hThisInstance, lpszCmdLine);

	_retval = InitializeCommonControls();
	_retval = RegisterWindowClasses(hThisInstance);
	_retval = CreateWindows(hThisInstance);

	_retval = LoadResources();
	
	return _retval;

	_UNREFERENCED_PARAMETER_(nCmdShow);
	_UNREFERENCED_PARAMETER_(hPrevInstance);
}

retcode
Run()
{
	retcode _retval = 0;
	MSG Msg;

	HWND   hWndMDIChild;
	TCHAR  lpszBuffer[_MAX_PATH + 1];
	BOOL   bDialogMessage = FALSE;
	HACCEL hAccel;

	hAccel = LoadAccelerators(g_hInstance, MAKEINTRESOURCE(IDA_ACCEL));

	while(GetMessage(&Msg, 0, 0, 0))
	{
		if(TranslateAccelerator(g_hMainWnd, hAccel, &Msg))
			continue;

		if(TranslateMDISysAccel(g_hMDIClientWnd, &Msg))
			continue;

		for(
			hWndMDIChild = GetWindow(g_hMDIClientWnd, GW_CHILD); 
			hWndMDIChild; 
			hWndMDIChild = GetWindow(hWndMDIChild, GW_HWNDNEXT)
		) 
		{
			GetClassName(hWndMDIChild, lpszBuffer, _MAX_PATH + 1);
			if(_tcscmp(lpszBuffer, g_lpcszChildWindowClassName))
				continue;

			if(IsDialogMessage((HWND)GetWindowLong(hWndMDIChild, GWLAPP_HDLG), &Msg)) 
			{
				bDialogMessage = TRUE;
				break;
			}
		}

		if(bDialogMessage) 
		{
			bDialogMessage = FALSE;
			continue;
		}

		TranslateMessage(&Msg);
		DispatchMessage(&Msg);
	}

	return _retval;
}

retcode
Terminate()
{
	retcode _retval = 0;

	CoUninitialize();

	UnloadResources();

//	{
//		FreeLibrary(g_hRichEditLibrary);
//		g_hRichEditLibrary = 0;
//	}

	return _retval;
}

fatal 
LoadResources()
{
	retcode _retval = 0;
	
	g_hEventListImageList = ImageList_LoadBitmap(g_hInstance, MAKEINTRESOURCE(IDB_EVENTLIST), 
		16, 0, (COLORREF)(RGB(255, 255, 255)));

	g_hbmAsc  = LoadBitmap(g_hInstance, MAKEINTRESOURCE(IDB_ASC));
	g_hbmDesc = LoadBitmap(g_hInstance, MAKEINTRESOURCE(IDB_DESC));
	g_hbmNone = LoadBitmap(g_hInstance, MAKEINTRESOURCE(IDB_NONE));

	g_hLVFloatMenu		= LoadMenu(g_hInstance, MAKEINTRESOURCE(IDM_LVCUSTOMIZE));

	if(!g_hEventListImageList || !g_hbmAsc || !g_hbmDesc || !g_hbmNone || !g_hLVFloatMenu)
		_retval = -1;
	return _retval;
}

fatal 
UnloadResources()
{
	retcode _retval = 0;

	ImageList_Destroy(g_hEventListImageList);

	DeleteObject(g_hbmAsc);
	DeleteObject(g_hbmDesc);
	DeleteObject(g_hbmNone);

	DestroyMenu(g_hLVFloatMenu);

	return _retval;
}

