// EnumNtServices.h : main header file for the ENUMNTSERVICES application
//

#if !defined(AFX_ENUMNTSERVICES_H__F786EED6_AA38_11D3_8F72_0080AD4311B1__INCLUDED_)
#define AFX_ENUMNTSERVICES_H__F786EED6_AA38_11D3_8F72_0080AD4311B1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CEnumNtServicesApp:
// See EnumNtServices.cpp for the implementation of this class
//

class CEnumNtServicesApp : public CWinApp
{
public:
	CEnumNtServicesApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEnumNtServicesApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CEnumNtServicesApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ENUMNTSERVICES_H__F786EED6_AA38_11D3_8F72_0080AD4311B1__INCLUDED_)
