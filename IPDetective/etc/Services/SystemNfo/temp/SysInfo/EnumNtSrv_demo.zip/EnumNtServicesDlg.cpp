// EnumNtServicesDlg.cpp : implementation file
//

#include "stdafx.h"
#include "EnumNtServices.h"
#include "EnumNtServicesDlg.h"
#include <WinSvc.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEnumNtServicesDlg dialog

CEnumNtServicesDlg::CEnumNtServicesDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CEnumNtServicesDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CEnumNtServicesDlg)
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CEnumNtServicesDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CEnumNtServicesDlg)
	DDX_Control(pDX, IDC_SERVICE_SERVICE, m_SrvService);
	DDX_Control(pDX, IDC_SERVICE_INACTIVE, m_SrvInactive);
	DDX_Control(pDX, IDC_SERVICE_DRIVER, m_SrvDriver);
	DDX_Control(pDX, IDC_SERVICE_ACTIVE, m_SrvActive);
	DDX_Control(pDX, IDC_LIST, m_List);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CEnumNtServicesDlg, CDialog)
	//{{AFX_MSG_MAP(CEnumNtServicesDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_SERVICE_ACTIVE, OnServiceActive)
	ON_BN_CLICKED(IDC_SERVICE_DRIVER, OnServiceDriver)
	ON_BN_CLICKED(IDC_SERVICE_INACTIVE, OnServiceInactive)
	ON_BN_CLICKED(IDC_SERVICE_SERVICE, OnServiceService)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEnumNtServicesDlg message handlers

BOOL CEnumNtServicesDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
  m_List.InsertColumn(0, _T("Name"), LVCFMT_LEFT, 80);
  m_List.InsertColumn(1, _T("Display"), LVCFMT_LEFT, 100);
  m_List.InsertColumn(2, _T("Type"), LVCFMT_LEFT, 150);
  m_List.InsertColumn(3, _T("Start"), LVCFMT_LEFT, 150);
  m_List.InsertColumn(4, _T("Path"), LVCFMT_LEFT, 350);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CEnumNtServicesDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CEnumNtServicesDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CEnumNtServicesDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

DWORD CEnumNtServicesDlg::getType(void)
{
  DWORD dwType = 0;
  if (m_SrvService.GetCheck())
    dwType |= SERVICE_WIN32;
  if (m_SrvDriver.GetCheck()) 
    dwType |= SERVICE_DRIVER;
  return dwType;
}

DWORD CEnumNtServicesDlg::getState(void)
{
  DWORD dwState = 0;
  if (m_SrvActive.GetCheck()) 
    dwState |= SERVICE_ACTIVE;
  if (m_SrvInactive.GetCheck())
    dwState |= SERVICE_INACTIVE;
  return dwState;
}

void CEnumNtServicesDlg::OnServiceActive() 
{
  buildList(getType(), getState());
}

void CEnumNtServicesDlg::OnServiceDriver() 
{
  buildList(getType(), getState());
}

void CEnumNtServicesDlg::OnServiceInactive() 
{
  buildList(getType(), getState());
}

void CEnumNtServicesDlg::OnServiceService() 
{
  buildList(getType(), getState());
}

void CEnumNtServicesDlg::buildList(DWORD dwType, DWORD dwState)
{
  /*
  TNtServiceInfo *pList = NULL;
  DWORD dwCount = 0;

  pList = TNtServiceInfo::EnumServices(dwType, dwState, &dwCount);

  m_List.DeleteAllItems();
  for (int nIndex = 0; nIndex < dwCount; nIndex ++) {
    m_List.InsertItem(nIndex, pList[nIndex].m_strServiceName);
    m_List.SetItemText(nIndex, 1, pList[nIndex].m_strDisplayName);
    m_List.SetItemText(nIndex, 2, pList[nIndex].GetServiceType());
    m_List.SetItemText(nIndex, 3, pList[nIndex].GetStartType());
    m_List.SetItemText(nIndex, 4, pList[nIndex].m_strBinaryPath);
  }
  */

  TNtServiceInfoList srvList;
  TNtServiceInfo::EnumServices(dwType, dwState, &srvList);

  m_List.DeleteAllItems();

  TNtServiceInfoList::iterator it;
  int nIndex = 0;
  for (it = srvList.begin(); it != srvList.end(); it ++) {
    m_List.InsertItem(nIndex, it->m_strServiceName);
    m_List.SetItemText(nIndex, 1, it->m_strDisplayName);
    m_List.SetItemText(nIndex, 2, it->GetServiceType());
    m_List.SetItemText(nIndex, 3, it->GetStartType());
    m_List.SetItemText(nIndex, 4, it->m_strBinaryPath);
    nIndex ++;
  }
}

void CEnumNtServicesDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
}
