#include "stdafx.h"
#include "PopWatch.h"
#include "Settings.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif



CPopWatchApp* GetApp()
{
  return (CPopWatchApp*) AfxGetApp();
}

CMainFrame* GetMainFrame()
{
  return (CMainFrame*) AfxGetMainWnd();
}






class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

protected:
  HICON m_hIcon;

	//{{AFX_VIRTUAL(CAboutDlg)
	virtual void DoDataExchange(CDataExchange* pDX);
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()





BEGIN_MESSAGE_MAP(CPopWatchApp, CWinApp)
	//{{AFX_MSG_MAP(CPopWatchApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	ON_COMMAND(ID_APP_SETTINGS, OnAppSettings)
	ON_COMMAND(ID_HELP, OnHelp)
	ON_COMMAND(ID_APP_CHECKNOW, OnAppChecknow)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

CPopWatchApp::CPopWatchApp()
{
}

CPopWatchApp theApp;

BOOL CPopWatchApp::InitInstance()
{
  //Usual MFC initialisation
  Enable3dControls();

  //Initialise the Winsock stack
  if (!AfxSocketInit())
	{
		AfxMessageBox(IDP_SOCKETS_INIT_FAILED);
		return FALSE;
	}

  //Change the INI file to use to point to the directory where the EXE is located
  TCHAR pszFileName[_MAX_PATH];
  GetModuleFileName(NULL, pszFileName, _MAX_PATH);
  TCHAR drive[_MAX_DRIVE];   
  TCHAR dir[_MAX_DIR];
  TCHAR fname[_MAX_FNAME];   
  _tsplitpath(pszFileName, drive, dir, fname, NULL);
  _tmakepath(pszFileName, drive, dir, fname, _T("INI"));
  free((void*)m_pszProfileName);
  m_pszProfileName = _tcsdup(pszFileName);

  OSVERSIONINFO osvi;
  osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
  m_bWin2k = (GetVersionEx(&osvi) && osvi.dwPlatformId == VER_PLATFORM_WIN32_NT && osvi.dwMajorVersion >= 5);

  //Load up the settings from the ini file
  LoadSettings();

  //Create the main window initially hidden
  CMainFrame* pMainFrame = new CMainFrame;
  m_pMainWnd = pMainFrame;
  if (!pMainFrame->Create(NULL, _T("PopWatch Hidden Wnd")))
    return FALSE;

  m_pMainWnd->ShowWindow(SW_HIDE);
  m_pMainWnd->UpdateWindow();

	return TRUE;
}

void CPopWatchApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}

void CPopWatchApp::LoadSettings()
{
  //Load the values up from the ini file
  m_nInterval = GetProfileInt(_T("General"), _T("Interval"), 5);
  m_sPassword = GetProfileString(_T("General"), _T("Password"), _T(""));
  m_sPop3Server = GetProfileString(_T("General"), _T("Server"), _T(""));
  m_sUsername = GetProfileString(_T("General"), _T("Username"), _T(""));
  m_bCheckUsingRas = (BOOL) GetProfileInt(_T("General"), _T("UseRas"), FALSE);
  m_bBalloon = (BOOL) GetProfileInt(_T("General"), _T("Balloon"), m_bWin2k);
}

void CPopWatchApp::OnAppSettings() 
{
	CSettingsPropertySheet propSheet;
  propSheet.m_psh.dwFlags |= PSH_NOAPPLYNOW; 

  //Load the values up from the member variables
  propSheet.m_Page1.m_nInterval = m_nInterval;
  propSheet.m_Page1.m_sPassword = m_sPassword;
  propSheet.m_Page1.m_sPop3Server = m_sPop3Server;
  propSheet.m_Page1.m_sUsername = m_sUsername;
  propSheet.m_Page1.m_bCheckUsingRas = m_bCheckUsingRas;
  propSheet.m_Page1.m_bBalloon = m_bBalloon;

  //Bring up the tabbed dialog to allow the values to be edited
	if (propSheet.DoModal() == IDOK)
  {
    //Update the member variables
    m_nInterval = propSheet.m_Page1.m_nInterval;
    m_sPassword = propSheet.m_Page1.m_sPassword;
    m_sPop3Server = propSheet.m_Page1.m_sPop3Server;
    m_sUsername = propSheet.m_Page1.m_sUsername;
    m_bCheckUsingRas = propSheet.m_Page1.m_bCheckUsingRas;
    m_bBalloon = propSheet.m_Page1.m_bBalloon;

    //Save the values in the ini file
    WriteProfileInt(_T("General"), _T("Interval"), m_nInterval);
    WriteProfileString(_T("General"), _T("Password"), m_sPassword);
    WriteProfileString(_T("General"), _T("Server"), m_sPop3Server);
    WriteProfileString(_T("General"), _T("Username"), m_sUsername);
    WriteProfileInt(_T("General"), _T("UseRas"), m_bCheckUsingRas);
    WriteProfileInt(_T("General"), _T("Balloon"), m_bBalloon);

    //Inform te mainframe of the changes
    GetMainFrame()->OnSettingsUpdate();
  }
}

void CPopWatchApp::OnHelp() 
{
  TCHAR sFilename[_MAX_PATH];
  GetModuleFileName(NULL, sFilename, _MAX_PATH);
  TCHAR sDrive[_MAX_DRIVE];
  TCHAR sDir[_MAX_DIR];
  TCHAR sFname[_MAX_FNAME];
  _tsplitpath(sFilename, sDrive, sDir, sFname, NULL);
  _tmakepath(sFilename, sDrive, sDir, sFname, _T("HTM"));

	HINSTANCE hRun = ShellExecute(AfxGetMainWnd()->m_hWnd, _T("open"), sFilename, NULL, NULL, SW_SHOW);
  if ((int) hRun <= 32)
    AfxMessageBox(IDS_FAIL_RUN_HELP, MB_OK | MB_ICONEXCLAMATION);
}

void CPopWatchApp::OnAppChecknow() 
{
	GetMainFrame()->CheckNow();	
}

