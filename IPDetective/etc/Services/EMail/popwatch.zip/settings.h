#ifndef __SETTINGS_H__
#define __SETTINGS_H__

class CGeneralSettingsPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CGeneralSettingsPage)

public:
	CGeneralSettingsPage();
	~CGeneralSettingsPage();

	//{{AFX_DATA(CGeneralSettingsPage)
	enum { IDD = IDD_GENERAL_SETTINGS };
	CSpinButtonCtrl	m_ctrlSpinInterval;
	int		m_nInterval;
	CString	m_sPassword;
	CString	m_sPop3Server;
	BOOL	m_bCheckUsingRas;
	CString	m_sUsername;
	BOOL	m_bBalloon;
	//}}AFX_DATA

	//{{AFX_VIRTUAL(CGeneralSettingsPage)
	virtual void DoDataExchange(CDataExchange* pDX);
	//}}AFX_VIRTUAL

protected:
	//{{AFX_MSG(CGeneralSettingsPage)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};



class CSettingsPropertySheet : public CPropertySheet
{
public:
	CSettingsPropertySheet(CWnd* pWndParent = NULL);
	virtual ~CSettingsPropertySheet();

	CGeneralSettingsPage m_Page1;

protected:
	DECLARE_DYNAMIC(CSettingsPropertySheet)

	//{{AFX_VIRTUAL(CSettingsPropertySheet)
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CSettingsPropertySheet)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


#endif	//__SETTINGS_H__
