#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols
#include "MainFrm.h"

class CPopWatchApp : public CWinApp
{
public:
  CPopWatchApp();

	//{{AFX_VIRTUAL(CPopWatchApp)
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

//Public variables
  int m_nInterval;
  CString m_sPassword;
  CString m_sPop3Server;
  CString m_sUsername;
  BOOL    m_bCheckUsingRas;
  BOOL    m_bWin2k;
  BOOL    m_bBalloon;

protected:

	//{{AFX_MSG(CPopWatchApp)
	afx_msg void OnAppAbout();
	afx_msg void OnAppSettings();
	afx_msg void OnHelp();
	afx_msg void OnAppChecknow();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

  void LoadSettings();
};

CPopWatchApp* GetApp();
CMainFrame* GetMainFrame();