#include "stdafx.h"
#include "resource.h"
#include "settings.h"
#include "popwatch.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif



IMPLEMENT_DYNCREATE(CGeneralSettingsPage, CPropertyPage)

CGeneralSettingsPage::CGeneralSettingsPage() : CPropertyPage(CGeneralSettingsPage::IDD)
{
	//{{AFX_DATA_INIT(CGeneralSettingsPage)
	m_nInterval = 0;
	m_sPassword = _T("");
	m_sPop3Server = _T("");
	m_bCheckUsingRas = FALSE;
	m_sUsername = _T("");
	m_bBalloon = FALSE;
	//}}AFX_DATA_INIT

  //Set some reasonable defaults
  m_nInterval = 5;

  if (!GetApp()->m_bWin2k)
    m_bBalloon = FALSE;
}

CGeneralSettingsPage::~CGeneralSettingsPage()
{
}

void CGeneralSettingsPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGeneralSettingsPage)
	DDX_Control(pDX, IDC_SPIN_INTERVAL, m_ctrlSpinInterval);
	DDX_Text(pDX, IDC_INTERVAL, m_nInterval);
	DDV_MinMaxInt(pDX, m_nInterval, 1, 60);
	DDX_Text(pDX, IDC_PASSWORD, m_sPassword);
	DDX_Text(pDX, IDC_POP3_SERVER, m_sPop3Server);
	DDX_Check(pDX, IDC_RAS, m_bCheckUsingRas);
	DDX_Text(pDX, IDC_USERNAME, m_sUsername);
	DDX_Check(pDX, IDC_BALLOON, m_bBalloon);
	//}}AFX_DATA_MAP

  if (pDX->m_bSaveAndValidate)
  {
    if (m_sPop3Server.IsEmpty())
    {
      AfxMessageBox(_T("Please enter a valid POP3 server"));
      pDX->PrepareEditCtrl(IDC_POP3_SERVER);
      pDX->Fail();
    }
    if (m_sUsername.IsEmpty())
    {
      AfxMessageBox(_T("Please enter a valid Username"));
      pDX->PrepareEditCtrl(IDC_USERNAME);
      pDX->Fail();
    }
  }
  else
  {
    GetDlgItem(IDC_BALLOON)->EnableWindow(GetApp()->m_bWin2k);
  }
}

BEGIN_MESSAGE_MAP(CGeneralSettingsPage, CPropertyPage)
	//{{AFX_MSG_MAP(CGeneralSettingsPage)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BOOL CGeneralSettingsPage::OnInitDialog() 
{
  //Let the parent do its thing
	CPropertyPage::OnInitDialog();
	
  //Set the spin range
  m_ctrlSpinInterval.SetRange(1, 60);

  	
	return TRUE;
}




IMPLEMENT_DYNAMIC(CSettingsPropertySheet, CPropertySheet)

CSettingsPropertySheet::CSettingsPropertySheet(CWnd* pWndParent)
	 : CPropertySheet(IDS_SETTINGS_CAPTION, pWndParent)
{
	AddPage(&m_Page1);
}

CSettingsPropertySheet::~CSettingsPropertySheet()
{
}

BEGIN_MESSAGE_MAP(CSettingsPropertySheet, CPropertySheet)
	//{{AFX_MSG_MAP(CSettingsPropertySheet)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()




