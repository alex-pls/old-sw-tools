/*
Module : RASMONITOR.H
Purpose: Defines the interface for a number of wrapper classes for 
         monitoring Ras connections 

Copyright (c) 1998 - 2001 by PJ Naughter.  (Web: www.naughter.com, Email: pjna@naughter.com)

All rights reserved.

Copyright / Usage Details:

You are allowed to include the source code in any product (commercial, shareware, freeware or otherwise) 
when your product is released in binary form. You are allowed to modify the source code in any way you want 
except you cannot modify the copyright details at the top of each module. If you want to distribute source 
code with your application, then you are only allowed to distribute versions released by the author. This is 
to maintain a single distribution point for the source code. 

*/

#ifndef __RASMONITOR_H__
#define __RASMONITOR_H__
                      
#ifndef __AFXTEMPL_H__
#pragma message("To avoid this message please put afxtempl.h in your PCH")                                                                                
#include <afxtempl.h>
#endif

#ifndef _WINSVC_
#pragma message("To avoid this message please put winsvc.h in your PCH")                                                                                
#include <winsvc.h>
#endif

#ifndef TAPI_H
#pragma message("To avoid this message please put tapi.h in your PCH")                                                                                
#include <Tapi.h>
#endif


//Function pointer typedefs used internally by CRasMonitor class
typedef DWORD (__stdcall *PFNRASENUMCONNECTIONS)(LPRASCONN, LPDWORD, LPDWORD);
typedef DWORD (__stdcall *PFNRASGETCONNECTSTATUS)(HRASCONN, LPRASCONNSTATUS);


///////////////////// Includes //////////////////////////////////////
#include "cpdh.h"     //my own wrapper class for performance data on NT
#include <pdhmsg.h>


//A class represeing a Dial-Up Networking connection
class CRasConnection
{
public:
//Constructors / Destructors
  CRasConnection();
	CRasConnection(const RASCONN& Connection);
  ~CRasConnection();

//Methods
  void Serialize(CArchive& ar);
  static void SerializeTime(CArchive& ar, SYSTEMTIME& st);
  void GetInitialConnectionDetails();
  void GetCurrentConnectionDetails();

//Serialized Data
  CString    m_sName;             //Name of the connection
	CString    m_sDeviceName;       //Name of the Device this connection is using
	CString    m_sDeviceType;       //Name of the Device Type this connection is using
  SYSTEMTIME m_ConnectionTime;    //The local time when the connection was started
  SYSTEMTIME m_DialTime;          //The local time when the connection was dialled
  BOOL       m_bConnected;        //True if currently connected, FALSE during the dialing
                                  //stage of a connection
  DWORD      m_ConnectDuration;   //how long the connection was made (in Seconds)
  DWORD      m_DialDuration;      //how long the connection took to be made (in Seconds)
  SYSTEMTIME m_HangupTime;        //The local time when the connection was closed
  DWORD      m_dwBytesReceived;   //The total number of bytes received
  DWORD      m_dwBytesSent;       //The number of bytes sent
  DWORD      m_dwConnectionSpeed; //The connection speed

protected:
//Temporary Data
  DWORD        m_dwInitialBytesReceived; //The total number of bytes received when connection is made
  DWORD        m_dwInitialBytesSent;     //The number of bytes sent received when connection is made

#ifndef RAS_MONITOR_NO_PDH
  CPdhCounter* m_pNTcounterR;             //NT performance counter for bytes received
  CPdhCounter* m_pNTcounterT;             //NT performance counter for bytes transmitted
  CPdhQuery    m_NTquery;                //NT performance query 

//Methods
  static CString GetPDHTotalBytesTxCounterName(); //Allows the PDH counter names to be overridden
  static CString GetPDHTotalBytesRxCounterName();
#endif
};


//Wparam which is used in notification message
const WPARAM RAS_DIAL_EVENT = 1;
const WPARAM RAS_CONNECT_EVENT = 2;
const WPARAM RAS_DISCONNECT_EVENT = 3;
const WPARAM RAS_CHECK_EVENT = 4;


//The Ras Monitor class which client applications should 
//derive from and override the virtual functions to perform
//whatever application specific behaviour they want
class CRasMonitor : public CWnd
{
public:
//Constructors / Destructors
  CRasMonitor();
  virtual ~CRasMonitor();

//Methods
	//Start monitoring ras connections
  BOOL Start(CWnd* pNotifyWnd, UINT nNotifyMessage);

	//Stop monitoring ras connections.
  BOOL Stop();

  //Determines if a ras connection handle is currently connected
  static BOOL IsConnected(HRASCONN hConnection);

  //Serializes the current state of the connections to and from disk
  void Serialize(CArchive& ar);

  //Accessors
  int NumberOfConnections() const { return m_Connections.GetSize(); };

protected:
//Data
  CArray<CRasConnection*, CRasConnection*&> m_Connections;
  UINT m_nTimerID;
  CWnd* m_pNotificationWnd;
  UINT m_nNotifyMessage;
  BOOL m_bStarted;
  BOOL m_bArchivedDataLoaded;
  SYSTEMTIME m_archiveTime;

//Methods
	BOOL ConnectionExists(const CString& sName);
  int GetConnection(const CString& sName);
	void DoCheck(BOOL bClosing);
  void OnDial(const CRasConnection& connection);
  void OnConnect(const CRasConnection& connection);
  void OnDisconnect(const CRasConnection& connection);
  void OnCheck(BOOL bClosing, RASCONN* pConnections, DWORD dwConnections);

//Static Methods
  static DWORD RasEnumConnections(LPRASCONN lprasconn, LPDWORD lpcb, LPDWORD lpcConnections); 
  static DWORD RasGetConnectStatus(HRASCONN hrasconn, LPRASCONNSTATUS lprasconnstatus);
#ifndef RAS_MONITOR_NO_TAPI
  static void CALLBACK lineCallbackFunc(DWORD dwDevice, DWORD dwMsg, DWORD dwCallbackInstance, DWORD dwParam1, DWORD dwParam2, DWORD dwParam3);
  static BOOL GetRasBaudRate(const CString& sDeviceName, LPDWORD lpdwBaud);
  static BOOL InitializeTapi();
  static void TerminateTapi();
#endif

//Static Data
  static DWORD sm_dwRefCount;
  static SC_HANDLE sm_hSCM;
  static SC_HANDLE sm_hRasMan;
  static PFNRASENUMCONNECTIONS sm_pfnRasEnumConnections;
  static PFNRASGETCONNECTSTATUS sm_pfnRasGetConnectStatus;
  static HINSTANCE sm_hRasApi32;
  static BOOL sm_bRunningNT;
  static DWORD sm_dwNumTapiDevs;
  static HLINEAPP sm_hLineApp;

	//{{AFX_MSG(CRasMonitor)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
  DECLARE_MESSAGE_MAP()

  DECLARE_DYNAMIC(CRasMonitor)

  friend class CRasConnection;
};

#endif //__RASMONITOR_H__