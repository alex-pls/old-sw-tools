//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PopWatch.rc
//
#define IDD_ABOUTBOX                    100
#define IDS_SETTINGS_CAPTION            102
#define IDD_GENERAL_SETTINGS            103
#define IDP_SOCKETS_INIT_FAILED         104
#define IDS_FAIL_RUN_HELP               105
#define IDR_MAINFRAME                   128
#define IDR_TRAYPOPUP                   130
#define IDI_SERVER                      131
#define IDI_HAVEMAIL                    132
#define IDI_NOMAIL                      133
#define IDI_ERRORMAIL                   134
#define IDI_CHECKMAIL                   135
#define IDC_POP3_SERVER                 1000
#define IDC_USERNAME                    1001
#define IDC_PASSWORD                    1002
#define IDC_INTERVAL                    1003
#define IDC_SPIN_INTERVAL               1004
#define IDC_RAS                         1007
#define IDC_BALLOON                     1008
#define ID_APP_SETTINGS                 32771
#define ID_APP_CHECKNOW                 32772

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
