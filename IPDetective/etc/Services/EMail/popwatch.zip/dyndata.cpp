#include "stdafx.h"
#include "dyndata.h"


///////////////////////////// Statics / Locals ////////////////////////////////

#ifdef _DEBUG
#undef THIS_FILE
#define new DEBUG_NEW
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif
             

///////////////////////////// Implementation //////////////////////////////////


CDynDataObject::CDynDataObject(LPCTSTR pszObjName, HKEY hObjectKey)
{
  //Store away the values
  m_sName = pszObjName;
  m_hObjectKey = hObjectKey;

  //validate our parameters
  ASSERT(m_sName.GetLength());
  ASSERT(hObjectKey);

  //Hive away the Object description
  TCHAR szDescription[_MAX_PATH];
  DWORD dwType;
  DWORD dwBufSize = _MAX_PATH;
  DWORD dwConnect = RegQueryValueEx(hObjectKey, _T("Name"), NULL, &dwType, (LPBYTE) szDescription, &dwBufSize);
  if (dwConnect == ERROR_SUCCESS)
    m_sDescription = szDescription;
  else
    TRACE(_T("Failed to get object description, Return code was %d"), dwConnect);
}

CDynDataObject::CDynDataObject(LPCTSTR pszObjName, LPCTSTR pszComputerName)
{
  //Store away the values
  m_hObjectKey = NULL;
  m_sName = pszObjName;
  if (pszComputerName)
    m_sComputerName = pszComputerName;

  //validate our parameters
  ASSERT(m_sName.GetLength());

  //Cannot hive away the description until EnumCounters is called
}

BOOL CDynDataObject::_EnumCounters(ENUMERATE_DYNDATA_OBJECT_COUNTERS lpEnumFunc, DWORD dwItemData, HKEY hObjectKey)
{
  BOOL bSuccess = FALSE;
  DWORD dwIndex = 0;
  TCHAR szObjectName[_MAX_PATH];
  DWORD dwBufSize = _MAX_PATH;
  DWORD dwConnect = RegEnumKeyEx(hObjectKey, dwIndex, szObjectName, &dwBufSize, NULL, NULL, NULL, NULL);
  BOOL bContinue = TRUE;
  while ((dwConnect == ERROR_SUCCESS) && bContinue)
  {
    //We've enumerated at least one object, so the call is successful.
    bSuccess = TRUE;

    //Call the enum function with an object setup
    HKEY hCounter;
    dwConnect = RegOpenKeyEx(hObjectKey, szObjectName, 0, KEY_READ, &hCounter);
    if (dwConnect == ERROR_SUCCESS)
    {
      //Get the name of the counter
      TCHAR szCounterName[_MAX_PATH];
      DWORD dwType;
      DWORD dwBufSize = _MAX_PATH;
      DWORD dwConnect = RegQueryValueEx(hCounter, _T("Name"), NULL, &dwType, (LPBYTE) szCounterName, &dwBufSize);
      if (dwConnect != ERROR_SUCCESS)
      {
        _tcscpy(szCounterName, _T(""));
        TRACE(_T("Failed to get counter name, Return code was %d"), dwConnect);
      }

      //Get the description of the counter
      TCHAR szDescription[_MAX_PATH];
      dwBufSize = _MAX_PATH;
      dwConnect = RegQueryValueEx(hCounter, _T("Description"), NULL, &dwType, (LPBYTE) szDescription, &dwBufSize);
      if (dwConnect != ERROR_SUCCESS)
      {
        _tcscpy(szCounterName, _T(""));
        TRACE(_T("Failed to get counter description, Return code was %d"), dwConnect);
      }

      //Get the differentiate flag of the counter
      TCHAR szDifferentiate[_MAX_PATH];
      dwBufSize = _MAX_PATH;
      BOOL bDifferentiate = FALSE;
      dwConnect = RegQueryValueEx(hCounter, _T("Differentiate"), NULL, &dwType, (LPBYTE) szDifferentiate, &dwBufSize);
      if (dwConnect != ERROR_SUCCESS)
        TRACE(_T("Failed to get counter differentiate flag, Return code was %d"), dwConnect);
      else
      {
        if (_tcscmp(szDifferentiate, _T("TRUE")) == 0)
          bDifferentiate = TRUE;
      }

      //Call the callback function
      bContinue = lpEnumFunc(dwItemData, *this, szObjectName, szCounterName, szDescription, bDifferentiate);
    }
    else
      TRACE(_T("Failed in call to open counter key, Return code was %d\n"), dwConnect);

    //Don't forget to close the key
    RegCloseKey(hCounter);

    if (bContinue)
    {
      //Set up for the next loop around
      dwIndex++;
      dwBufSize = _MAX_PATH;
      dwConnect = RegEnumKeyEx(hObjectKey, dwIndex, szObjectName, &dwBufSize, NULL, NULL, NULL, NULL);
    }
  }

  return bSuccess;
}

BOOL CDynDataObject::EnumCounters(ENUMERATE_DYNDATA_OBJECT_COUNTERS lpEnumFunc, DWORD dwItemData)
{
  //Validate our parameters
  ASSERT(lpEnumFunc != NULL);
  ASSERT(m_sName.GetLength());

  BOOL bSuccess = FALSE;

  //If the object registry key is not open then open it and call the internal enum function
  //with the registry key obtained
  if (m_hObjectKey == NULL)
  {
    //Open up the HKEY_LOCAL_MACHINE key on the specified macine
    HKEY hKeyLocalMachine;
    LPTSTR pszComputerName = m_sComputerName.GetBuffer(m_sComputerName.GetLength());
    DWORD dwConnect = RegConnectRegistry(pszComputerName, HKEY_LOCAL_MACHINE, &hKeyLocalMachine);
    m_sComputerName.ReleaseBuffer();
    if (dwConnect == ERROR_SUCCESS)
    {
      //Open up the "System\CurrentControlSet\Control\PerfStats\Enum\'m_sName'" key
      HKEY hObjectKey;
      CString sRegKey;
      sRegKey.Format(_T("System\\CurrentControlSet\\Control\\PerfStats\\Enum\\%s"), m_sName);
      dwConnect = RegOpenKeyEx(hKeyLocalMachine, sRegKey, 0, KEY_READ, &hObjectKey);
      if (dwConnect == ERROR_SUCCESS)
      {
        //Hive away the Object description
        TCHAR szDescription[_MAX_PATH];
        DWORD dwType;
        DWORD dwBufSize = _MAX_PATH;
        DWORD dwConnect = RegQueryValueEx(hObjectKey, _T("Name"), NULL, &dwType, (LPBYTE) szDescription, &dwBufSize);
        if (dwConnect == ERROR_SUCCESS)
          m_sDescription = szDescription;
        else
          TRACE(_T("Failed to get object description, Return code was %d"), dwConnect);

        //Call the internal function to do the enumeration
        bSuccess = _EnumCounters(lpEnumFunc, dwItemData, hObjectKey);

        //Don't forget to close our key
        RegCloseKey(hObjectKey);
      }
      
      //Don't forget to close our key
      RegCloseKey(hKeyLocalMachine);
    }
  }
  else
    bSuccess = _EnumCounters(lpEnumFunc, dwItemData, m_hObjectKey);
  
  return bSuccess;
}





BOOL CDynDataEnumerator::EnumObjects(ENUMERATE_DYNDATA_OBJECTS lpEnumFunc, DWORD dwItemData, LPCTSTR pszComputerName)
{
  //Validate out parameters
  ASSERT(lpEnumFunc);

  BOOL bSuccess = FALSE;

  //Open up the HKEY_LOCAL_MACHINE key on the specified macine
  HKEY hKeyLocalMachine;
  DWORD dwConnect;
  if (pszComputerName)
  {
    TCHAR pszComputer[_MAX_PATH];
    _tcscpy(pszComputer, pszComputerName);
    dwConnect = RegConnectRegistry(pszComputer, HKEY_LOCAL_MACHINE, &hKeyLocalMachine);
  }
  else
    dwConnect = RegConnectRegistry(NULL, HKEY_LOCAL_MACHINE, &hKeyLocalMachine);
  if (dwConnect == ERROR_SUCCESS)
  {
    //Open up the "System\CurrentControlSet\Control\PerfStats\Enum" key
    HKEY hEnumKey;
    dwConnect = RegOpenKeyEx(hKeyLocalMachine, _T("System\\CurrentControlSet\\Control\\PerfStats\\Enum"), 0, KEY_READ, &hEnumKey);
    if (dwConnect == ERROR_SUCCESS)
    {
      //Enumerate all the keys under the Enum key
      DWORD dwIndex = 0;
      TCHAR szObjectName[_MAX_PATH];
      DWORD dwBufSize = _MAX_PATH;
      dwConnect = RegEnumKeyEx(hEnumKey, dwIndex, szObjectName, &dwBufSize, NULL, NULL, NULL, NULL);
      BOOL bContinue = TRUE;
      while ((dwConnect == ERROR_SUCCESS) && bContinue)
      {
        //We've enumerated at least one object, so the call is successful.
        bSuccess = TRUE;

        //Call the enum function with an object setup
        HKEY hObject;
        dwConnect = RegOpenKeyEx(hEnumKey, szObjectName, 0, KEY_READ, &hObject);
        if (dwConnect == ERROR_SUCCESS)
        {
          CDynDataObject object(szObjectName, hObject);
          bContinue = lpEnumFunc(dwItemData, object);
        }
        else
          TRACE(_T("Failed in call to open object key, Return code was %d\n"), dwConnect);

        //Don't forget to close the key
        RegCloseKey(hObject);

        if (bContinue)
        {
          //Set up for the next loop around
          dwIndex++;
          dwBufSize = _MAX_PATH;
          dwConnect = RegEnumKeyEx(hEnumKey, dwIndex, szObjectName, &dwBufSize, NULL, NULL, NULL, NULL);
        }
      }

      //Don't forget to close our key
      RegCloseKey(hEnumKey);
    }
    else
      TRACE(_T("Failed to open the PerfStats\\Enum key, Return code was %d\n"), dwConnect);

    //Don't forget to close our key
    RegCloseKey(hKeyLocalMachine);
  } 
  else
    TRACE(_T("Failed to open the HKEY_LOCAL_MACHINE key, Return code was %d\n"), dwConnect);

  return bSuccess;
}





CDynDataCounter::CDynDataCounter()
{
}

CDynDataCounter::~CDynDataCounter()
{
  Stop();
}

BOOL CDynDataCounter::Start(LPCTSTR pszObjName, LPCTSTR pszCounterName, LPCTSTR pszComputerName)
{
  //Stop any previous collection
  Stop();

  BOOL bSuccess = FALSE;

  //Open up the HKEY_DYN_DATA key on the specified machine
  HKEY hKeyDynData;
  DWORD dwConnect;
  if (pszComputerName)
  {
    TCHAR pszComputer[_MAX_PATH];
    _tcscpy(pszComputer, pszComputerName);
    dwConnect = RegConnectRegistry(pszComputer, HKEY_DYN_DATA, &hKeyDynData);
  }
  else
    dwConnect = RegConnectRegistry(NULL, HKEY_DYN_DATA, &hKeyDynData);

  if (dwConnect == ERROR_SUCCESS)
  {
    //Open the "HKEY_DYN_DATA\PerfStats\StartStat" registry key
    HKEY hOpen;
    if (RegOpenKeyEx(hKeyDynData, _T("PerfStats\\StartStat"), 0, KEY_READ, &hOpen) == ERROR_SUCCESS)
    {
      //Query to get data size
      DWORD dwType;
      DWORD cbData;

      //Form the counter name which we are querying
      CString sCounterName;
      sCounterName.Format(_T("%s\\%s"), pszObjName, pszCounterName);

      if (RegQueryValueEx(hOpen, sCounterName, NULL, &dwType, NULL, &cbData) == ERROR_SUCCESS)
      {
        //Query the performance start key to initialise the performace data
        BYTE* pByte = new BYTE[cbData];
        bSuccess = (RegQueryValueEx(hOpen, sCounterName, NULL, &dwType, pByte, &cbData) == ERROR_SUCCESS);

        //Remember the name of the computer we want
        m_sComputerName = pszComputerName;

        //Remember the name of the counter we want
        m_sCounterName = sCounterName;

        //Don't forget to delete the bit of memory we allocated
        delete [] pByte;
      }

      //Don't forget to close the registry key
      RegCloseKey(hOpen);
    }
    else
      TRACE(_T("Failed to open the PerfStats\\StartStat key, Return code was %d\n"), dwConnect);
  
    //Don't forget to close the registry key
    RegCloseKey(hKeyDynData);
  }
  else
    TRACE(_T("Failed to open the HKEY_DYN_DATA key, Return code was %d\n"), dwConnect);

  return bSuccess;
}

BOOL CDynDataCounter::Collect(DWORD& dwData)
{
  ASSERT(m_sCounterName.GetLength()); //did you forget to call Start

  BOOL bSuccess = FALSE;

  //Open up the HKEY_DYN_DATA key on the specified machine
  HKEY hKeyDynData;
  LPTSTR pszComputerName = m_sComputerName.GetBuffer(m_sComputerName.GetLength());
  DWORD dwConnect = RegConnectRegistry(pszComputerName, HKEY_DYN_DATA, &hKeyDynData);
  m_sComputerName.ReleaseBuffer();
  if (dwConnect == ERROR_SUCCESS)
  {
    HKEY hOpen;
    //Open up the "HKEY_DYN_DATA\PerfStats\StatData" key
    if (RegOpenKeyEx(hKeyDynData, _T("PerfStats\\StatData"), 0, KEY_READ, &hOpen) == ERROR_SUCCESS)
    {
      //Query the specifed key for the data
      DWORD dwType;
      DWORD cbData = 4;
      bSuccess = (RegQueryValueEx(hOpen, m_sCounterName, NULL, &dwType, (LPBYTE) &dwData, &cbData) == ERROR_SUCCESS);

      //Don't forget to close the registry key
      RegCloseKey(hOpen);
    }
    else
      TRACE(_T("Failed to open the PerfStats\\StatData key, Return code was %d\n"), dwConnect);
  }
  else
    TRACE(_T("Failed to open the HKEY_DYN_DATA key, Return code was %d\n"), dwConnect);
  
  return bSuccess;
}

BOOL CDynDataCounter::Stop()
{
  //Handle calling StopCollecting twice
  if (m_sCounterName.IsEmpty())
    return TRUE;

  BOOL bSuccess = FALSE;

  //Open up the HKEY_DYN_DATA key on the specified machine
  HKEY hKeyDynData;
  LPTSTR pszComputerName = m_sComputerName.GetBuffer(m_sComputerName.GetLength());
  DWORD dwConnect = RegConnectRegistry(pszComputerName, HKEY_DYN_DATA, &hKeyDynData);
  m_sComputerName.ReleaseBuffer();
  if (dwConnect == ERROR_SUCCESS)
  {
    //Open the "HKEY_DYN_DATA\PerfStats\StopStat" registry key
    HKEY hOpen;
    if (RegOpenKeyEx(hKeyDynData, _T("PerfStats\\StopStat"), 0, KEY_READ, &hOpen) == ERROR_SUCCESS)
    {
      //Query to get data size
      DWORD dwType;
      DWORD cbData;
      if (RegQueryValueEx(hOpen, m_sCounterName, NULL, &dwType, NULL, &cbData) == ERROR_SUCCESS)
      {
        //Query the performance stop key to disable collection of performace data
        BYTE* pByte = new BYTE[cbData];
        bSuccess = (RegQueryValueEx(hOpen, m_sCounterName, NULL, &dwType, pByte, &cbData) == ERROR_SUCCESS);
        delete [] pByte;
      }
      else
        TRACE(_T("Failed to open the PerfStats\\StopData key, Return code was %d\n"), dwConnect);

      //Don't forget to close the registry key
      RegCloseKey(hOpen);
    }
    else

    //Don't forget to close the registry key
    RegCloseKey(hKeyDynData);
  }
  else
    TRACE(_T("Failed to open the HKEY_DYN_DATA key, Return code was %d\n"), dwConnect);
  

  //Empty out the name of the counter we are collecting
  m_sCounterName.Empty();

  return bSuccess;
}
