#ifndef __MAINFRM_H__
#define __MAINFRM_H__


#include "ntray.h"
#include "pop3.h"
#include "rasmonitor.h"
                                        
class CMainFrame : public CFrameWnd
{
public:
	CMainFrame();
	virtual ~CMainFrame();

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

  void OnSettingsUpdate();
  void CheckNow();

protected:
	DECLARE_DYNCREATE(CMainFrame)

	//{{AFX_VIRTUAL(CMainFrame)
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
  afx_msg LRESULT OnTrayNotification(WPARAM wParam, LPARAM lParam);
  afx_msg LRESULT OnRasMonitor(WPARAM wParam, LPARAM lParam);


	DECLARE_MESSAGE_MAP()

  CTrayNotifyIcon* m_pTrayIcon;    
  CPop3Connection m_Pop3Connection;
  CRasMonitor     m_RasMonitor;

  BOOL m_bRasConnected;
  UINT m_nTimerId;
  HICON m_hNormalIcon;
  HICON m_hSomeMail;
  HICON m_hNoMail;
  HICON m_hErrorIcon;
  HICON m_hCheckMail;
};

#endif //__MAINFRM_H__

