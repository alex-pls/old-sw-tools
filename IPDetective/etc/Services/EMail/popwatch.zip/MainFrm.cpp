#include "stdafx.h"
#include "PopWatch.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
                                             
#define WM_TRAYNOTIFY WM_APP + 100
#define WM_RASMONITOR WM_APP + 101


IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
  ON_MESSAGE(WM_TRAYNOTIFY, OnTrayNotification)
  ON_MESSAGE(WM_RASMONITOR, OnRasMonitor)
END_MESSAGE_MAP()

CMainFrame::CMainFrame()
{
  m_bRasConnected = FALSE;
  m_hNormalIcon = (HICON) ::LoadImage(AfxGetResourceHandle(), MAKEINTRESOURCE(IDR_MAINFRAME), IMAGE_ICON, 16, 16, LR_DEFAULTCOLOR);
  m_hSomeMail   = (HICON) ::LoadImage(AfxGetResourceHandle(), MAKEINTRESOURCE(IDI_HAVEMAIL), IMAGE_ICON, 16, 16, LR_DEFAULTCOLOR);
  m_hNoMail     = (HICON) ::LoadImage(AfxGetResourceHandle(), MAKEINTRESOURCE(IDI_NOMAIL), IMAGE_ICON, 16, 16, LR_DEFAULTCOLOR);
  m_hErrorIcon  = (HICON) ::LoadImage(AfxGetResourceHandle(), MAKEINTRESOURCE(IDI_ERRORMAIL), IMAGE_ICON, 16, 16, LR_DEFAULTCOLOR);
  m_hCheckMail = (HICON) ::LoadImage(AfxGetResourceHandle(), MAKEINTRESOURCE(IDI_CHECKMAIL), IMAGE_ICON, 16, 16, LR_DEFAULTCOLOR);
  m_pTrayIcon = NULL;
}

CMainFrame::~CMainFrame()
{
  if (m_pTrayIcon)
    delete m_pTrayIcon;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	return CFrameWnd::PreCreateWindow(cs);
}

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG


int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

  //Create the tray icon	
  CString sCaption;
  sCaption.LoadString(AFX_IDS_APP_TITLE);
  m_pTrayIcon = new CTrayNotifyIcon;
  if (!m_pTrayIcon->Create(this, IDR_TRAYPOPUP, sCaption, m_hNormalIcon, WM_TRAYNOTIFY))
    return -1;

  //Create the RAS monitor if necessary
  if (GetApp()->m_bCheckUsingRas)
    m_RasMonitor.Start(this, WM_RASMONITOR);

  //Create the timer which will be used for checking the POP3 Server
  m_nTimerId = SetTimer(1, GetApp()->m_nInterval * 60000, NULL);

	return 0;
}

LRESULT CMainFrame::OnTrayNotification(WPARAM wParam, LPARAM lParam)
{
  //Delegate all the work back to the default implementation in
  //CTrayNotifyIcon.
  return m_pTrayIcon->OnTrayNotification(wParam, lParam);
}

LRESULT CMainFrame::OnRasMonitor(WPARAM wParam, LPARAM /*lParam*/)
{
  if (wParam == RAS_CONNECT_EVENT)
    m_bRasConnected = TRUE;
  else if (wParam == RAS_DISCONNECT_EVENT)
    m_bRasConnected = FALSE;

  return 0L;
}


void CMainFrame::OnDestroy() 
{
  //Kill the timer used for POP3 checks
	KillTimer(m_nTimerId);

  if (GetApp()->m_bCheckUsingRas)
    m_RasMonitor.Stop();

  //Let the parent do its thing
	CFrameWnd::OnDestroy();
}

void CMainFrame::OnTimer(UINT nIDEvent) 
{
	if (nIDEvent == m_nTimerId)
  {
    CString sToolTip;
    int nNumberOfMails = 0;
    int nTotalMailSize = 0;
	  m_pTrayIcon->SetIcon(m_hNormalIcon);
    BOOL bSuccess = FALSE;
    CPopWatchApp* pApp = GetApp();

    if ((pApp->m_bCheckUsingRas && m_bRasConnected) || !pApp->m_bCheckUsingRas)
    {
      //Change the icon to show that we are checking mail
      m_pTrayIcon->SetIcon(m_hCheckMail);
      m_pTrayIcon->SetTooltipText(_T("PopWatch: Checking Mail"));

      //Connect to the POP3 server and get its statistics
      if (m_Pop3Connection.Connect(pApp->m_sPop3Server, pApp->m_sUsername, pApp->m_sPassword))
      {
        if (m_Pop3Connection.Statistics(nNumberOfMails, nTotalMailSize))
        {
          if (nNumberOfMails)
            sToolTip.Format(_T("PopWatch: %d Messages, Total size: %d KB"), nNumberOfMails, nTotalMailSize/1024);
          else
            sToolTip = _T("PopWatch: No Messages");
          bSuccess = TRUE;
        }

        //Don't forget to disconnect
        m_Pop3Connection.Disconnect();
      }

      //Update the tray icon tooltip and icon 
      if (bSuccess)
      {
        if (nNumberOfMails)
        {
          if (GetApp()->m_bBalloon)
          {
            delete m_pTrayIcon;
            m_pTrayIcon = new CTrayNotifyIcon;
            CString sCaption;
            sCaption.LoadString(AFX_IDS_APP_TITLE);
            CString sBalloonText;
            sBalloonText.Format(_T("%d Messages, Total size: %d KB"), nNumberOfMails, nTotalMailSize/1024);
            m_pTrayIcon->Create(this, IDR_TRAYPOPUP, sToolTip, sBalloonText, _T("You have Mail!"), 5000, CTrayNotifyIcon::Info, m_hSomeMail, WM_TRAYNOTIFY);                  
          }
          else
          {
            m_pTrayIcon->SetTooltipText(sToolTip);
            m_pTrayIcon->SetIcon(m_hSomeMail);
          }
        }
        else
          m_pTrayIcon->SetIcon(m_hNoMail);
      }
      else
      {
        //An error has occured, do a message beep and update the tray icon tooltip and icon
        MessageBeep(MB_ICONEXCLAMATION);
        m_pTrayIcon->SetTooltipText(_T("PopWatch: An error occurred accessing the server"));
        m_pTrayIcon->SetIcon(m_hErrorIcon);
      }
    }
    else if (pApp->m_bCheckUsingRas && !m_bRasConnected)
    {
      //Update the UI about the fact that no server checks were done
      m_pTrayIcon->SetTooltipText(_T("PopWatch: Currently not connected to the Internet"));
      m_pTrayIcon->SetIcon(m_hNormalIcon);
    }
  }
  else
  	CFrameWnd::OnTimer(nIDEvent);
}

void CMainFrame::OnSettingsUpdate()
{
  //Stop the RAS monitor
  m_RasMonitor.Stop();

  //Restart the RAS monitor if necessary
  if (GetApp()->m_bCheckUsingRas)
    m_RasMonitor.Start(this, WM_RASMONITOR);

  //Kill the existing timer
  KillTimer(m_nTimerId);

  //Recreate the timer which will be used for checking the POP3 Server
  m_nTimerId = SetTimer(1, GetApp()->m_nInterval * 60000, NULL);
}

void CMainFrame::CheckNow()
{
	KillTimer(m_nTimerId);
	OnTimer(m_nTimerId);
	m_nTimerId = SetTimer(1, GetApp()->m_nInterval * 60000, NULL);
}