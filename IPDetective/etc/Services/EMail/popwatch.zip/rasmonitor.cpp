/*
Module : RASMONITOR.CPP
Purpose: Defines the implementation for a number of wrapper classes for 
         monitoring Ras connections 
Created: PJN / 18-06-1997
History: PJN / 28-09-1998 1.  Updated code to include a virtual OnDial method
                          2.  Optimized the code by using CArray::ElementAt
                          3.  Added the following member variables to CRasConnection:
                              Dial Time, whether or not the connection is currently
                              connected, Dial Duration and the RAS handle
                          4.  Renamed the connection variable of CRasConnection
                          5.  Updated the sample program to v1.1
                          6.  Updated the version info in the sample app to include 
                              the build date
                          7.  Fixed a problem when enumerating more than one ras
                              connection at a time.
                          8.  Sample app now uses LoadImage instead of LoadIcon to avoid
                              the shell first scaling up to 32*32 and then back to 16*16.
                              What this means is that the icons RasMan puts in the tray
                              notification area will not look blurred.
                          9.  Fixed a memory leak in CRasMonitor::DoCheck() when multiple
                              connections were being enumerated.
                          10. Included a new selection of tray icons in the sample app.
                          11. Added a popup menu item to bring up the help file.
         PJN / 28-10-1998 1.  Major optimisation added to reduce memory usage (c. 3 MB) 
                              on NT when Ras service is not running. Thanks to Daniel 
                              Harth for this very neat optimisation.
                          2.  Internally the code now uses a hidden window to perform 
                              the monitoring instead of a worker thread. This helps avoid 
                              potential deadlock problems which can occur as previously 
                              the code used a worker thread.
                          3.  Now uses window messages instead of virtual functions to 
                              implement class customisation
         PJN / 02-02-1999 1.  Fixed a compile problem which was occurring when code was 
                              compiled for UNICODE.
                          2.  Fixed a crash which was occuring when the code was run on NT 
                              and you do not have Ras installed.
                          3.  When running on NT, the code now only uses 
                              SC_MANAGER_ENUMERATE_SERVICE priviledges when connecting to 
                              the Service Configuration Manager.
                          4.  CRasConnection connection now includes a standard MFC 
                              Serialize method.
         PJN / 11-02-1999 1.  Now reports the following additional statistics:
                              a) Connection speed (Bytes / Second) (on Windows 95, 98 only)
                              b) Bytes sent (Windows 95, 98 & NT)
                              c) Bytes received (Windows 95, 98 & NT)
         PJN / 25-01-2000 1.  Removed a memory leak which was occuring on NT where the 
                              CPdhCounter instances in the GetInitialConnectionDetails and
                              GetCurrentConnectionDetails functions were not being tidied 
                              up. This has been accomplised by restructuring the code to 
                              create and add the counters to the performance once of in the
                              CRasConnection constructors.
         PJN / 07-05-2000 1.  Fixed a problem on NT where the PDH counters were being freed
                              prior to the being added to the m_Connections array
                          2.  Also now allows the PDH counter names to be customized via an advanced 
                              registry value.
         PJN / 30-04-2001 1.  Updated copyright messages.
                          2.  Fixed a problem where the code would not run correctly on Win 9x.
                          3.  Connection speed for a connection is now reported on via a call to
                              TAPI just like the way the SDK sample RasBaud operates.
                          4.  Provision of the following defines which allow fine grained control
                              over what API's RasMonitor pulls in:
                              RAS_MONITOR_NO_DYNDATA
                              RAS_MONITOR_NO_PDH
                              RAS_MONITOR_NO_TAPI
                              

Copyright (c) 1998 - 2001 by PJ Naughter.  (Web: www.naughter.com, Email: pjna@naughter.com)

All rights reserved.

Copyright / Usage Details:

You are allowed to include the source code in any product (commercial, shareware, freeware or otherwise) 
when your product is released in binary form. You are allowed to modify the source code in any way you want 
except you cannot modify the copyright details at the top of each module. If you want to distribute source 
code with your application, then you are only allowed to distribute versions released by the author. This is 
to maintain a single distribution point for the source code. 

*/


///////////////////////////// Includes ////////////////////////////////////////

#include "stdafx.h"
#include "dyndata.h"
#include <afxpriv.h>
#include "rasmonitor.h"





///////////////////////////// Statics / Locals ////////////////////////////////

TCHAR sz95CounterTotalBytesRecvd[] = _T("TotalBytesRecvd");
TCHAR sz95CounterTotalBytesSent[]  = _T("TotalBytesXmit");
TCHAR sz95ObjName[] = _T("Dial-Up Adapter");
PFNRASENUMCONNECTIONS CRasMonitor::sm_pfnRasEnumConnections=NULL;
PFNRASGETCONNECTSTATUS CRasMonitor::sm_pfnRasGetConnectStatus=NULL;
HINSTANCE CRasMonitor::sm_hRasApi32 = NULL;
SC_HANDLE CRasMonitor::sm_hSCM = NULL;
SC_HANDLE CRasMonitor::sm_hRasMan = NULL;
BOOL CRasMonitor::sm_bRunningNT = FALSE;
DWORD CRasMonitor::sm_dwNumTapiDevs = 0;
HLINEAPP CRasMonitor::sm_hLineApp = NULL;
DWORD CRasMonitor::sm_dwRefCount = 0;


#ifdef _DEBUG
#undef THIS_FILE
#define new DEBUG_NEW
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif




///////////////////////////// Implementation //////////////////////////////////

#ifndef RAS_MONITOR_NO_PDH
CString CRasConnection::GetPDHTotalBytesTxCounterName()
{
  CString sName(_T("\\Ras Total\\Bytes Transmitted"));
  
  //Query the registry to allow the value to be overridden  
  HKEY hOpen;
  if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("Software\\PJ Naughter\\RasMonitor"), 0, KEY_READ, &hOpen) == ERROR_SUCCESS)
  {
    //Query to get data size
    DWORD dwType = 0;
    DWORD cbData = 0;

    //Form the counter name which we are querying
    if (RegQueryValueEx(hOpen, _T("BytesTxCounterName"), NULL, &dwType, NULL, &cbData) == ERROR_SUCCESS)
    {
      //Query the performance start key to initialise the performace data
      TCHAR* pszName = new TCHAR[cbData];
      if ((RegQueryValueEx(hOpen, _T("BytesTxCounterName"), NULL, &dwType, (LPBYTE) pszName, &cbData) == ERROR_SUCCESS) && dwType == REG_SZ)
        sName = pszName;

      //Don't forget to delete the bit of memory we allocated
      delete [] pszName;
    }

    //Don't forget to close the registry key
    RegCloseKey(hOpen);
  }

  return sName;
}

CString CRasConnection::GetPDHTotalBytesRxCounterName()
{
  CString sName(_T("\\Ras Total\\Bytes Received"));
  
  //Query the registry to allow the value to be overridden  
  HKEY hOpen;
  if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("Software\\PJ Naughter\\RasMonitor"), 0, KEY_READ, &hOpen) == ERROR_SUCCESS)
  {
    //Query to get data size
    DWORD dwType = 0;
    DWORD cbData = 0;

    //Form the counter name which we are querying
    if (RegQueryValueEx(hOpen, _T("BytesRxCounterName"), NULL, &dwType, NULL, &cbData) == ERROR_SUCCESS)
    {
      //Query the performance start key to initialise the performace data
      TCHAR* pszName = new TCHAR[cbData];
      if ((RegQueryValueEx(hOpen, _T("BytesRxCounterName"), NULL, &dwType, (LPBYTE) pszName, &cbData) == ERROR_SUCCESS) && dwType == REG_SZ)
        sName = pszName;

      //Don't forget to delete the bit of memory we allocated
      delete [] pszName;
    }

    //Don't forget to close the registry key
    RegCloseKey(hOpen);
  }

  return sName;
}
#endif

CRasConnection::CRasConnection()
{
#ifndef RAS_MONITOR_NO_PDH
  m_pNTcounterR = NULL;
  m_pNTcounterT = NULL;
#endif
  ZeroMemory(&m_DialTime, sizeof(SYSTEMTIME));
  ZeroMemory(&m_ConnectionTime, sizeof(SYSTEMTIME));
  ZeroMemory(&m_HangupTime, sizeof(SYSTEMTIME));
  m_bConnected = FALSE;
  m_ConnectDuration = 0;
  m_DialDuration = 0;
  m_dwBytesReceived = 0;
  m_dwBytesSent = 0;        
  m_dwConnectionSpeed = 0;
  m_dwInitialBytesReceived = 0;
  m_dwInitialBytesSent = 0;

  //Setup the NT performance counters. Note that NT performance counters 
  //currently does not support the connection speed
#ifndef RAS_MONITOR_NO_PDH
  if (CRasMonitor::sm_bRunningNT)
  {
    try
    {
      //Allocate the counters
      m_pNTcounterR = new CPdhCounter(GetPDHTotalBytesRxCounterName());
      m_pNTcounterT = new CPdhCounter(GetPDHTotalBytesTxCounterName());

      //Open the query
      m_NTquery.Open();

      //Add the counters
      m_NTquery.Add(*m_pNTcounterR);
      m_NTquery.Add(*m_pNTcounterT);
    }
    catch (CPdhException* pEx)
    {
      TRACE(_T("An error occurred setting up the performance values on NT\n"));
		  pEx->Delete();
    }
  }
#endif
}

CRasConnection::CRasConnection(const RASCONN& Connection) 
{
#ifndef RAS_MONITOR_NO_PDH
  m_pNTcounterR = NULL;
  m_pNTcounterT = NULL;
#endif
  m_sName       = Connection.szEntryName;
	m_sDeviceType = Connection.szDeviceType;
	m_sDeviceName = Connection.szDeviceName;
  m_bConnected  = CRasMonitor::IsConnected(Connection.hrasconn);
  m_ConnectDuration = 0;
  m_DialDuration = 0;
  if (m_bConnected)
  {
	  GetLocalTime(&m_ConnectionTime);
    CopyMemory(&m_DialTime, &m_ConnectionTime, sizeof(SYSTEMTIME));
  }
  else
  {
    GetLocalTime(&m_DialTime);
    ZeroMemory(&m_ConnectionTime, sizeof(SYSTEMTIME));
  }
  ZeroMemory(&m_HangupTime, sizeof(SYSTEMTIME));
  m_dwBytesReceived = 0;
  m_dwBytesSent = 0;        
  m_dwConnectionSpeed = 0;

  //Setup the NT performance counters. Note that NT performance counters 
  //currently does not support the connection speed
#ifndef RAS_MONITOR_NO_PDH
  if (CRasMonitor::sm_bRunningNT)
  {
    try
    {
      //Allocate the counters
      m_pNTcounterR = new CPdhCounter(GetPDHTotalBytesRxCounterName());
      m_pNTcounterT = new CPdhCounter(GetPDHTotalBytesTxCounterName());

      //Open the query
      m_NTquery.Open();

      //Add the counters
      m_NTquery.Add(*m_pNTcounterR);
      m_NTquery.Add(*m_pNTcounterT);
    }
    catch (CPdhException* pEx)
    {
      TRACE(_T("An error occurred setting up the performance values on NT\n"));
		  pEx->Delete();
    }
  }
#endif
}

CRasConnection::~CRasConnection()
{
  //Free up the NT performance counter if we are running on NT
#ifndef RAS_MONITOR_NO_PDH
  if (CRasMonitor::sm_bRunningNT)
  {
    try
    {
      //Remove the counters
      m_NTquery.Remove(*m_pNTcounterR);
      m_NTquery.Remove(*m_pNTcounterT);

      //Close the query
      m_NTquery.Close();

      //Free up the heap memory
      if (m_pNTcounterR)
      {
        delete m_pNTcounterR;
        m_pNTcounterR = NULL;
      }
      if (m_pNTcounterT)
      {
        delete m_pNTcounterT;
        m_pNTcounterT = NULL;
      }
    }
    catch (CPdhException* pEx)
    {
      TRACE(_T("An error occurred freeing up the performance values on NT\n"));
		  pEx->Delete();
    }
  }
#endif
}

void CRasConnection::GetInitialConnectionDetails()
{
  if (CRasMonitor::sm_bRunningNT)
  {
  #ifndef RAS_MONITOR_NO_PDH
    //Note that NT performance counters currently does not support the connection speed
    try
    {
      //Collect the data and interpret
      m_NTquery.Collect();

      //Interpret the results
      PDH_FMT_COUNTERVALUE Received;
      m_pNTcounterR->GetFormattedValue(PDH_FMT_LONG, Received);
      if (Received.CStatus == PDH_CSTATUS_VALID_DATA)
        m_dwInitialBytesReceived = (DWORD) Received.longValue;
      else
        TRACE(_T("Failed in call to get formatted value for Bytes received\n"));

      PDH_FMT_COUNTERVALUE Txmitted;
      m_pNTcounterT->GetFormattedValue(PDH_FMT_LONG , Txmitted);
      if (Txmitted.CStatus == PDH_CSTATUS_VALID_DATA)
        m_dwInitialBytesSent = (DWORD) Txmitted.longValue;
      else
        TRACE(_T("Failed in call to get formatted value for Bytes sent\n"));
    }
    catch (CPdhException* pEx)
    {
      TRACE(_T("An error occurred get the performance values on NT\n"));
		  pEx->Delete();
    }
  #endif
  }
  else
  {
  #ifndef RAS_MONITOR_NO_DYNDATA
    //Collect the Initial Bytes received
    CDynDataCounter counter;
    if (counter.Start(sz95ObjName, sz95CounterTotalBytesRecvd))
      if (!counter.Collect(m_dwInitialBytesReceived))
        TRACE(_T("Failed to retrieve the initial bytes received\n"));

    //Collect the Initial Bytes sent
    if (counter.Start(sz95ObjName, sz95CounterTotalBytesSent))
      if (!counter.Collect(m_dwInitialBytesSent))
        TRACE(_T("Failed to retrieve the initial bytes sent\n"));
  #endif
  }

  //Get the connection speed
  #ifndef RAS_MONITOR_NO_TAPI
  CRasMonitor::GetRasBaudRate(m_sDeviceName, &m_dwConnectionSpeed);
  #endif
}

void CRasConnection::GetCurrentConnectionDetails()
{
  // Check for Windows NT
  if (CRasMonitor::sm_bRunningNT)
  {
  #ifndef RAS_MONITOR_NO_PDH
    //Note that NT performance counters currently do not support the connection speed
    try
    {
      //Collect the data and interpret
      m_NTquery.Collect();

      //Interpret the results
      PDH_FMT_COUNTERVALUE Received;
      m_pNTcounterR->GetFormattedValue(PDH_FMT_LONG, Received);
      if (Received.CStatus == PDH_CSTATUS_VALID_DATA)
        m_dwBytesReceived = ((DWORD) Received.longValue) - m_dwInitialBytesReceived;
      else
        TRACE(_T("Failed in call to get formatted value for Bytes received\n"));

      PDH_FMT_COUNTERVALUE Txmitted;
      m_pNTcounterT->GetFormattedValue(PDH_FMT_LONG , Txmitted);
      if (Txmitted.CStatus == PDH_CSTATUS_VALID_DATA)
        m_dwBytesSent = ((DWORD) Txmitted.longValue) - m_dwInitialBytesSent;
      else
        TRACE(_T("Failed in call to get formatted value for Bytes sent\n"));
    }
    catch (CPdhException* pEx)
    {
      TRACE(_T("An error occurred get the performance values on NT\n"));
		  pEx->Delete();
    }
  #endif
  }
  else
  {
  #ifndef RAS_MONITOR_NO_DYNDATA
    //Collect the Bytes received
    CDynDataCounter counter;
    DWORD dwData;
    if (counter.Start(sz95ObjName, sz95CounterTotalBytesRecvd))
      if (counter.Collect(dwData))
        m_dwBytesReceived = dwData - m_dwInitialBytesReceived;

    //Collect the Bytes sent
    if (counter.Start(sz95ObjName, sz95CounterTotalBytesSent))
      if (counter.Collect(dwData))
        m_dwBytesSent = dwData - m_dwInitialBytesSent;
  #endif  
  }

  //Get the connection speed
  #ifndef RAS_MONITOR_NO_TAPI
  CRasMonitor::GetRasBaudRate(m_sDeviceName, &m_dwConnectionSpeed);
  #endif
}

void CRasConnection::SerializeTime(CArchive& ar, SYSTEMTIME& st)
{
  if (ar.IsLoading())
  {
    //Version stamp
    WORD wVersion;
    ar >> wVersion;

    //the actual data
    ar >> st.wYear;
    ar >> st.wMonth;
    ar >> st.wDayOfWeek;
    ar >> st.wDay;
    ar >> st.wHour;
    ar >> st.wMinute;
    ar >> st.wSecond;
    ar >> st.wMilliseconds;
  }
  else
  {
    //Version stamp the data
    WORD wVersion = 0x100;
    ar << wVersion;

    //the actual data
    ar << st.wYear;
    ar << st.wMonth;
    ar << st.wDayOfWeek;
    ar << st.wDay;
    ar << st.wHour;
    ar << st.wMinute;
    ar << st.wSecond;
    ar << st.wMilliseconds;
  }
}

void CRasConnection::Serialize(CArchive& ar)
{
  if (ar.IsLoading())
  {
    //Version stamp
    WORD wVersion;
    ar >> wVersion;

    ar >> m_sName;
    ar >> m_sDeviceName;
    ar >> m_sDeviceType;
    SerializeTime(ar, m_ConnectionTime);
    SerializeTime(ar, m_DialTime);
    ar >> m_bConnected;
    ar >> m_ConnectDuration;
    ar >> m_DialDuration;
    SerializeTime(ar, m_HangupTime);
    ar >> m_dwBytesReceived;
    ar >> m_dwBytesSent;        
    ar >> m_dwConnectionSpeed;
  }
  else
  {
    //Version stamp the data
    WORD wVersion = 0x100;
    ar << wVersion;

    ar << m_sName;
    ar << m_sDeviceName;
    ar << m_sDeviceType;
    SerializeTime(ar, m_ConnectionTime);
    SerializeTime(ar, m_DialTime);
    ar << m_bConnected;
    ar << m_ConnectDuration;
    ar << m_DialDuration;
    SerializeTime(ar, m_HangupTime);
    ar << m_dwBytesReceived;
    ar << m_dwBytesSent;        
    ar << m_dwConnectionSpeed;
  }
}







CRasMonitor::CRasMonitor()
{
  m_pNotificationWnd = NULL;
  m_nNotifyMessage = 0;
  m_bStarted = FALSE;
  m_bArchivedDataLoaded = FALSE;
  ZeroMemory(&m_archiveTime, sizeof(SYSTEMTIME));

  if (sm_dwRefCount == 0)
  {
    // Check for Windows NT
    OSVERSIONINFO osi;
    osi.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
    GetVersionEx(&osi);
    sm_bRunningNT = (osi.dwPlatformId == VER_PLATFORM_WIN32_NT);

    //Initialize TAPI
    #ifndef RAS_MONITOR_NO_TAPI
    InitializeTapi();
    #endif

    if (sm_bRunningNT)
    {
      // Open the Service control manager
      sm_hSCM = OpenSCManager(NULL, NULL, SC_MANAGER_ENUMERATE_SERVICE);
      if (sm_hSCM == NULL)
      {
        TRACE(_T("CRasMonitor::CRasMonitor, Can't open SCM, GetLastError() returns: %d.\n"), GetLastError());
        return;
      }

      //Open up the RasMan service from the SCM
      sm_hRasMan = OpenService(sm_hSCM, _T("RasMan"), SERVICE_QUERY_STATUS);
      if (sm_hRasMan == NULL)
      {
        CloseServiceHandle(sm_hSCM);
	      sm_hSCM = NULL;
        TRACE(_T("CRasMonitor::CRasMonitor, Can't open RasMan service, GetLastError() returns: %d.\n"), GetLastError());
        return;
      }
    }
  }

  ++sm_dwRefCount;
}

CRasMonitor::~CRasMonitor()
{
  Stop();

  --sm_dwRefCount;

  if (sm_dwRefCount == 0)
  {
    //Release the RasMan service Handle
	  if (sm_hRasMan)
	  {
		  CloseServiceHandle(sm_hRasMan);
      sm_hRasMan = NULL;
	  }

    //Release the SCM Handle
	  if (sm_hSCM)
	  {
		  CloseServiceHandle(sm_hSCM);
	    sm_hSCM = NULL;
	  }

    //Free up the Rasapi32 handle
	  if (sm_hRasApi32)
	  {
		  FreeLibrary(sm_hRasApi32);
		  sm_hRasApi32 = NULL;
      sm_pfnRasGetConnectStatus = NULL;
      sm_pfnRasEnumConnections = NULL;
	  }

    //Close down TAPI
    #ifndef RAS_MONITOR_NO_TAPI
    TerminateTapi();
    #endif
  }
}

IMPLEMENT_DYNAMIC(CRasMonitor, CWnd)

BEGIN_MESSAGE_MAP(CRasMonitor, CWnd)
	//{{AFX_MSG_MAP(CRasMonitor)
	ON_WM_CREATE()
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

int CRasMonitor::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
  //Let the parent do its thing
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
  //create the timer
	m_nTimerID = SetTimer(1, 1000, NULL);
	
	return 0;
}

void CRasMonitor::OnTimer(UINT /*nIDEvent*/) 
{
  //Perform the check
  DoCheck(FALSE);
}

BOOL CRasMonitor::Start(CWnd* pNotifyWnd, UINT nNotifyMessage)
{
  ASSERT(!m_bStarted);

  //Store away the notification window
  ASSERT(pNotifyWnd && ::IsWindow(pNotifyWnd->GetSafeHwnd()));
  m_pNotificationWnd = pNotifyWnd;

  //Store away the notification message
  m_nNotifyMessage = nNotifyMessage;

  //create the hidden window which will do the monitoring
  CRect r(0, 0, 10, 10);
  if (!CreateEx(0, AfxRegisterWndClass(0), _T("CRasMonitor Notification Window"), WS_OVERLAPPED, r, NULL, 0))
  {
    TRACE(_T("Failed in creation of hidden Ras monitoring window\n"));
    return FALSE;
  }

  m_bStarted = TRUE;

  return TRUE;
}

BOOL CRasMonitor::Stop()
{
  if (m_bStarted)
  {
    //Final check since we are closing
    DoCheck(TRUE);

    //kill the timer
    KillTimer(m_nTimerID);

    //Destroy the hidden monitoring window
    DestroyWindow();

    m_pNotificationWnd = NULL;
    m_nNotifyMessage = 0;

    m_bStarted = FALSE;
  }

  //Free up the connections array
  for (int i=0; i<m_Connections.GetSize(); i++)
    delete m_Connections.GetAt(i);
  m_Connections.SetSize(0);

  return TRUE;
}

BOOL CRasMonitor::ConnectionExists(const CString& sName)
{
  return (GetConnection(sName) != -1);
}

BOOL CRasMonitor::IsConnected(HRASCONN hConnection)
{
  RASCONNSTATUS rcs;
  rcs.dwSize = sizeof(RASCONNSTATUS);
  if (RasGetConnectStatus(hConnection, &rcs) == 0)
    return (rcs.rasconnstate == RASCS_Connected);
  else
    return FALSE;
}

int CRasMonitor::GetConnection(const CString& sName)
{
	for (int i=0; i<m_Connections.GetSize(); i++)
	{
		if (m_Connections.GetAt(i)->m_sName == sName)
			return i;
	}

	return -1;
}

void CRasMonitor::OnConnect(const CRasConnection& connection)
{ 
  //Display some debug info
  TRACE(_T("%s has just connected, Dial Duration was %d\n"), connection.m_sName, connection.m_DialDuration);

  //Inform the notify window of the event
  ASSERT(m_pNotificationWnd);
  ASSERT(m_pNotificationWnd->GetSafeHwnd());
  m_pNotificationWnd->SendMessage(m_nNotifyMessage, RAS_CONNECT_EVENT, (LPARAM) &connection);
}

void CRasMonitor::OnDial(const CRasConnection& connection)
{
  //Display some debug info
  TRACE(_T("%s has just dialled\n"), connection.m_sName);

  //Inform the notify window of the event
  ASSERT(m_pNotificationWnd);
  ASSERT(m_pNotificationWnd->GetSafeHwnd());
  m_pNotificationWnd->SendMessage(m_nNotifyMessage, RAS_DIAL_EVENT, (LPARAM) &connection);
}

void CRasMonitor::OnDisconnect(const CRasConnection& connection)
{
  //Display some debug info
  TRACE(_T("%s has just disconnected, Dial Duration was %d, Connection Time was %d\n"), connection.m_sName, connection.m_DialDuration, connection.m_ConnectDuration);

  //Inform the notify window of the event
  ASSERT(m_pNotificationWnd);
  ASSERT(m_pNotificationWnd->GetSafeHwnd());
  m_pNotificationWnd->SendMessage(m_nNotifyMessage, RAS_DISCONNECT_EVENT, (LPARAM) &connection);
}

void CRasMonitor::OnCheck(BOOL bClosing, RASCONN* pConnections, DWORD dwConnections)
{
	//Iterate through all the previously active connections
	//which has now disappeared and call the virtual OnDisconnect
	//function for the connection
	for (int i=m_Connections.GetUpperBound(); i>=0; i--)
	{
    BOOL bFound = FALSE;
    for (DWORD j=0; j<dwConnections && !bFound; j++)
      bFound = m_Connections.GetAt(i)->m_sName == pConnections[j].szEntryName;

    if (!bFound)
		{
      CRasConnection* pConnection = m_Connections.GetAt(i);
			SYSTEMTIME st;
      //If we are dealing with archived data then use the archive time stamp and
      //not the current time
      if (m_bArchivedDataLoaded)
        CopyMemory(&st, &m_archiveTime, sizeof(SYSTEMTIME));
      else  
			  GetLocalTime(&st);
      if (pConnection->m_bConnected)
        pConnection->m_ConnectDuration = (CTime(st) - CTime(pConnection->m_ConnectionTime)).GetTotalSeconds();
      else
        pConnection->m_DialDuration = (CTime(st) - CTime(pConnection->m_DialTime)).GetTotalSeconds();
      pConnection->m_bConnected = FALSE;
      pConnection->m_HangupTime = st;

      //Call the virtual function
      OnDisconnect(*pConnection);

      //Free up the memory allocated for the connection
      delete m_Connections.GetAt(i);
      m_Connections.RemoveAt(i);
		}
	}

  //Iterate through all the current connections
  for (i=0; i<(int)dwConnections; i++)
  {
    int nConnection = GetConnection(pConnections[i].szEntryName);
    if (nConnection == -1)
    {
    	//For any new active connections which have appeared call the 
      //OnDial or the OnConnect function
      CRasConnection* pNewConnection = new CRasConnection(pConnections[i]);
      if (pNewConnection->m_bConnected)
      {
        pNewConnection->GetInitialConnectionDetails();
        OnConnect(*pNewConnection);
      }
      else
        OnDial(*pNewConnection);
      m_Connections.Add(pNewConnection);
    }
    else
    {
      CRasConnection* pConnection = m_Connections.GetAt(nConnection);

      //For existing connections, check to see if their connection state
      //has changed to connected and call the OnConnect function, Also call 
      //the GetInitialConnectionDetails method of CRasConnection
      if (IsConnected(pConnections[i].hrasconn))
      {
        if (!pConnection->m_bConnected)
        {
			    SYSTEMTIME now;
			    GetLocalTime(&now);
          pConnection->m_ConnectionTime = now;
          pConnection->m_DialDuration = (CTime(now) - CTime(pConnection->m_DialTime)).GetTotalSeconds();
          pConnection->m_bConnected = TRUE;
          pConnection->GetInitialConnectionDetails();
          OnConnect(*pConnection); 
        }
        else
          pConnection->GetCurrentConnectionDetails();
      }
    }

    if (bClosing)
    {
      //Call the Disconnect for all connections as we are about to finish
      //our monitoring
      CRasConnection* pConnection = m_Connections.GetAt(i);
		  SYSTEMTIME now;
		  GetLocalTime(&now);
      if (pConnection->m_bConnected)
        pConnection->m_ConnectDuration = (CTime(now) - CTime(pConnection->m_ConnectionTime)).GetTotalSeconds();
      else
        pConnection->m_DialDuration = (CTime(now) - CTime(pConnection->m_DialTime)).GetTotalSeconds();
      pConnection->m_bConnected = FALSE;
      pConnection->m_HangupTime = now;
      OnDisconnect(*pConnection);

      //Free up the memory associated with the connection
      delete m_Connections.GetAt(i);
      m_Connections.RemoveAt(i);
    }
  }

  //Now give the notification window a chance of updating ifself
  ASSERT(m_pNotificationWnd);
  ASSERT(m_pNotificationWnd->GetSafeHwnd());
  m_pNotificationWnd->SendMessage(m_nNotifyMessage, RAS_CHECK_EVENT, (LPARAM) &m_Connections);
}

void CRasMonitor::DoCheck(BOOL bClosing)
{
	//First work out how many connections there are currently
	DWORD dwConnections;
	RASCONN rasconn;
	rasconn.dwSize = sizeof(RASCONN);
	DWORD dwSize = rasconn.dwSize;
	DWORD dwSuccess = RasEnumConnections(&rasconn, &dwSize, &dwConnections);

	RASCONN* pRasConn = NULL;
	RASCONN* pActiveConnections = NULL;
	DWORD dwActiveConnections = 0;
	if (dwSuccess == 0)
	{
		if (dwConnections)
		{
			//At this stage we have a single active RASCONN
		  pActiveConnections = &rasconn;
		  dwActiveConnections = dwConnections;
		}
	}
	else if (dwSuccess != ERROR_BUFFER_TOO_SMALL)
	  return;
	else
	{
		//Allocate enough memory to satisy the request
		pRasConn = new RASCONN[dwConnections];
		pRasConn[0].dwSize = sizeof(RASCONN);
		dwSize = dwConnections*sizeof(RASCONN);

		//Now enumerate all the connections
		dwSuccess = RasEnumConnections(pRasConn, &dwSize, &dwConnections);

		//Some unknown error
		if (dwSuccess != 0)
		{
			delete [] pRasConn;
			return;
		}

		//At this stage we have an array of RASCONN which
		//are currently active
		pActiveConnections = pRasConn;
		dwActiveConnections = dwConnections;
	}

	//Call the virtual function to allow client customisation
  OnCheck(bClosing, pActiveConnections, dwActiveConnections);

	//Clean up any heap memory we may have used
	if (pRasConn)
	  delete [] pRasConn;
}

DWORD CRasMonitor::RasEnumConnections(LPRASCONN lprasconn, LPDWORD lpcb, LPDWORD lpcConnections)
{
  //if we are on NT and we cannot get a handle to the SCM or RasMan
  //they proceed no further with out checks
  if (sm_bRunningNT && (sm_hRasMan == NULL))
  {
		*lpcb = 0;
		*lpcConnections = 0;
		return 0;
  }

  //First do the check on the SCM
	if (sm_bRunningNT)
	{
    SERVICE_STATUS stat;
    QueryServiceStatus(sm_hRasMan, &stat);
    if (stat.dwCurrentState != SERVICE_RUNNING) // not running?
		{
      //If the RasMan service is not running there is definitely not
      //any RAS connections active. This avoids us having to unnecessarily
      //load up the RASAPI32.DLL under NT. This reduces the working set
      //of any programs which use CRasMonitor by c. 3 MB when on NT when
      //no ras connections are active.
			*lpcb = 0;
			*lpcConnections = 0;
			return 0;
		}
	}

  //Now try RAS directly
	if (!sm_hRasApi32)
	{
		sm_hRasApi32 = LoadLibrary(_T("RASAPI32.DLL"));
		if (!sm_hRasApi32)
		{
			TRACE(_T("CRasMonitor::RasEnumConnections: Can't load RASAPI32.DLL, GetLastError() returns: %d.\n"), GetLastError());
			*lpcb=0;
			*lpcConnections=0;
			return 0;
		}

#ifndef UNICODE
		sm_pfnRasEnumConnections = (PFNRASENUMCONNECTIONS) GetProcAddress(sm_hRasApi32, "RasEnumConnectionsA");
		sm_pfnRasGetConnectStatus = (PFNRASGETCONNECTSTATUS) GetProcAddress(sm_hRasApi32, "RasGetConnectStatusA");
#else
		sm_pfnRasEnumConnections = (PFNRASENUMCONNECTIONS) GetProcAddress(sm_hRasApi32, "RasEnumConnectionsW");
		sm_pfnRasGetConnectStatus = (PFNRASGETCONNECTSTATUS) GetProcAddress(sm_hRasApi32, "RasGetConnectStatusW");
#endif

    //In the unlikely event that any of the GetProcAddresses fail, Cleanup gracefully
    if (sm_pfnRasEnumConnections == NULL || sm_pfnRasGetConnectStatus == NULL)
    {
			TRACE(_T("CRasMonitor::RasEnumConnections: Can't get RASAPI32.DLL entry points, GetLastError() returns: %d.\n"), GetLastError());
			*lpcb=0;
			*lpcConnections=0;

      //Release our Rasapi handle
			FreeLibrary(sm_hRasApi32);
			sm_hRasApi32 = NULL;
      sm_pfnRasGetConnectStatus = NULL;
      sm_pfnRasEnumConnections = NULL;

			return 0;
    }
	}
  VERIFY(sm_pfnRasEnumConnections);
	DWORD dwRet = sm_pfnRasEnumConnections(lprasconn, lpcb, lpcConnections);

	return dwRet;
}

DWORD CRasMonitor::RasGetConnectStatus(HRASCONN hrasconn, LPRASCONNSTATUS lprasconnstatus)
{
	if (sm_hSCM)
	{
    SERVICE_STATUS stat;
    QueryServiceStatus(sm_hRasMan, &stat);
    if (stat.dwCurrentState != SERVICE_RUNNING) // not running?
		{
			ZeroMemory(lprasconnstatus, sizeof(RASCONNSTATUS));
			lprasconnstatus->dwSize = sizeof(RASCONNSTATUS);
			lprasconnstatus->rasconnstate = RASCS_Disconnected;
			return 0;
		}
	}
	if (!sm_hRasApi32)
	{
		sm_hRasApi32 = LoadLibrary(_T("RASAPI32.DLL"));
		if (!sm_hRasApi32)
		{
			TRACE(_T("CRasMonitor::RasGetConnectStatus: Can't load RASAPI32.DLL, GetLastError() returns: %d.\n"), GetLastError());
			ZeroMemory(lprasconnstatus, sizeof(RASCONNSTATUS));
			lprasconnstatus->dwSize=sizeof(RASCONNSTATUS);
			lprasconnstatus->rasconnstate=RASCS_Disconnected;
			return 0;
		}

#ifndef UNICODE
		sm_pfnRasEnumConnections = (PFNRASENUMCONNECTIONS) GetProcAddress(sm_hRasApi32, "RasEnumConnectionsA");
		sm_pfnRasGetConnectStatus = (PFNRASGETCONNECTSTATUS) GetProcAddress(sm_hRasApi32, "RasGetConnectStatusA");
#else
		sm_pfnRasEnumConnections = (PFNRASENUMCONNECTIONS) GetProcAddress(sm_hRasApi32, "RasEnumConnectionsW");
		sm_pfnRasGetConnectStatus = (PFNRASGETCONNECTSTATUS) GetProcAddress(sm_hRasApi32, "RasGetConnectStatusW");
#endif

    //In the unlikely event that any of the GetProcAddresses fail, Cleanup gracefully
    if (sm_pfnRasEnumConnections == NULL || sm_pfnRasGetConnectStatus == NULL)
    {
			TRACE(_T("CRasMonitor::RasGetConnectStatus: Can't get RASAPI32.DLL entry points, GetLastError() returns: %d.\n"), GetLastError());
			ZeroMemory(lprasconnstatus, sizeof(RASCONNSTATUS));
			lprasconnstatus->dwSize=sizeof(RASCONNSTATUS);
			lprasconnstatus->rasconnstate=RASCS_Disconnected;

      //Release our Rasapi handle
			FreeLibrary(sm_hRasApi32);
			sm_hRasApi32 = NULL;
      sm_pfnRasGetConnectStatus = NULL;
      sm_pfnRasEnumConnections = NULL;

			return 0;
    }
	}

  VERIFY(sm_pfnRasGetConnectStatus);
	return sm_pfnRasGetConnectStatus(hrasconn, lprasconnstatus);
}

void CRasMonitor::Serialize(CArchive& ar)
{
  if (ar.IsLoading())
  {
    //Version stamp the data
    WORD wVersion;
    ar >> wVersion;

    //the actual data
    int nSize;
    ar >> nSize;
    m_Connections.SetSize(nSize);
    for (int i=0; i<nSize; i++)
    {
      CRasConnection* pConnection = new CRasConnection;
      pConnection->Serialize(ar);
      m_Connections.SetAt(i, pConnection);
    }

    //Don't forget to read in the archive time
    CRasConnection::SerializeTime(ar, m_archiveTime);

    //Call the OnCheck method with the archived data
    m_bArchivedDataLoaded = TRUE;
    OnCheck(FALSE, NULL, 0);
    m_bArchivedDataLoaded = FALSE;
  }
  else
  {
    //Version stamp the data
    WORD wVersion = 0x100;
    ar << wVersion;

    //the actual data
    int nSize = m_Connections.GetSize();
    ar << nSize;
    for (int i=0; i<nSize; i++)
    {
      CRasConnection* pConnection = m_Connections.GetAt(i);
      pConnection->Serialize(ar);
    }

    //Archive out the current time aswell.
 		SYSTEMTIME archiveTime;
		GetLocalTime(&archiveTime);
    CRasConnection::SerializeTime(ar, archiveTime);
  }
}

#ifndef RAS_MONITOR_NO_TAPI
BOOL CRasMonitor::InitializeTapi()
{
  USES_CONVERSION;

  //Initialize TAPI
  long lReturn = lineInitialize(&sm_hLineApp, AfxGetInstanceHandle(), lineCallbackFunc, T2A((LPTSTR) AfxGetAppName()), &sm_dwNumTapiDevs); 
  if (lReturn)
  {
    TRACE(_T("lineInitialize failed, Error:%x\n"), lReturn);
    return FALSE;
  }
  return TRUE;
}

void CRasMonitor::TerminateTapi()
{
  //Close down TAPI
  lineShutdown(sm_hLineApp);  // closing all calls and lines here also.
  sm_hLineApp = NULL;
}

BOOL CRasMonitor::GetRasBaudRate(const CString& sDeviceName, LPDWORD lpdwBaud)
{
  //By default assume a baud rate of 0
  *lpdwBaud = 0;

  //Allocate some structures we will need
  DWORD dwSize = sizeof(LINECALLLIST) + 128;
  LPLINECALLLIST lpCallList = (LPLINECALLLIST) new BYTE[dwSize];
  lpCallList->dwTotalSize = dwSize;
  dwSize = sizeof(LINEDEVCAPS) + 1024;
  LPLINEDEVCAPS lpLineDevCaps = (LPLINEDEVCAPS) new BYTE[dwSize];
  lpLineDevCaps->dwTotalSize = dwSize;

  //Iterate thro all the line devices
  HCALL hCall = 0;
  for (DWORD dwDeviceID=0; dwDeviceID<sm_dwNumTapiDevs; dwDeviceID++)
  {
    DWORD dwApiVersion;
    LINEEXTENSIONID ExtensionID;
    long lReturn = lineNegotiateAPIVersion(sm_hLineApp, dwDeviceID, TAPI_CURRENT_VERSION, TAPI_CURRENT_VERSION, &dwApiVersion, &ExtensionID);
    if (lReturn)
    {
      // This line device isn't useable by RAS anyway.
      continue;
    }

    //Get the name of this TAPI line device.
    while (TRUE)
    {
      lReturn = lineGetDevCaps(sm_hLineApp, dwDeviceID, dwApiVersion, 0, lpLineDevCaps);
      if (lReturn)
      {
        TRACE(_T("lineGetDevCaps failed, Error:%x\n"), lReturn);
        break;
      }

      if (lpLineDevCaps->dwNeededSize <= lpLineDevCaps->dwTotalSize)
        break;
   
      // Buffer wasn't big enough.  Reallocate.
      dwSize = lpLineDevCaps->dwNeededSize;
      delete [] lpLineDevCaps;
      lpLineDevCaps = (LPLINEDEVCAPS) new BYTE[dwSize];
      lpLineDevCaps->dwTotalSize = dwSize;
    }
    if (lReturn)  // Failed to lineGetDevCaps
      continue;

    LPTSTR lpszTapiDeviceName = (LPTSTR) ((LPBYTE) lpLineDevCaps + lpLineDevCaps->dwLineNameOffset);

    //Is this TAPI line device the one RAS is using?
    if (lstrcmp(sDeviceName, lpszTapiDeviceName) != 0)
      continue;

    //Have to open the line to get any possible call handles
    HLINE hLine;
    lReturn = lineOpen(sm_hLineApp, dwDeviceID, &hLine, dwApiVersion, 0, 0, LINECALLPRIVILEGE_NONE, 0, 0);
    if (lReturn)
    {
      //Failed to open.  RAS can't be using this line.
      TRACE(_T("lineOpen failed, Error:%x\n"), lReturn);
      continue;
    }

    // Now get all outstanding call handles
    while (TRUE)
    {
      lReturn = lineGetNewCalls(hLine, 0, LINECALLSELECT_LINE, lpCallList);
      if (lReturn)
      {
        // If this fails, something is seriously wrong, but RAS
        // is very unlikely to be using this line.
        TRACE(_T("lineGetNewCalls failed, Error:%x\n"), lReturn);
        break;
      }

      if (lpCallList->dwNeededSize <= lpCallList->dwTotalSize)
        break;

      //buffer wasn't big enough (not likely to happen, but could).
      //Reallocate and try again.
      DWORD dwSize = lpCallList->dwNeededSize;
      delete [] lpCallList;
      lpCallList = (LPLINECALLLIST) new BYTE[dwSize];
      lpCallList->dwTotalSize = dwSize;
    }

    if (lReturn)  //Failed to get the new call list.
      continue;

    DWORD dwNumCalls = lpCallList->dwCallsNumEntries;
    HCALL* lpCalls = (HCALL*) ((LPBYTE)lpCallList + lpCallList->dwCallsOffset);

    //No calls on this line?  Try the next line.
    if (dwNumCalls == 0)
       continue;

    //Identify which call RAS is using.

    //ASSUMPTION:  The speed of the first call is good enough.
    //If a modem is used, only one call per line is possible.
    //If ISDN is used, all calls on the line are the same speed.
    //Modem banks will be represented as one modem per line.
    hCall = lpCalls[0];

    break;
  }

  //Did we find the TAPI call of interest?
  if (hCall)
  {
    LINECALLINFO LineCallInfo;
    LineCallInfo.dwTotalSize = sizeof(LINECALLINFO);
    long lReturn = lineGetCallInfo(hCall, &LineCallInfo);
    if (lReturn)
    {
      TRACE(_T("lineGetCallInfo failed, Error:%x\n"), lReturn);
      hCall = 0;
    }
    else
      *lpdwBaud = LineCallInfo.dwRate;
  }

  //Tidy up the heap memory we have used
  delete [] lpCallList;
  delete [] lpLineDevCaps;

  if (hCall == 0)
    return FALSE;

  return TRUE;
}

void CALLBACK CRasMonitor::lineCallbackFunc(DWORD /*dwDevice*/, DWORD /*dwMsg*/, DWORD /*dwCallbackInstance*/, DWORD /*dwParam1*/, DWORD /*dwParam2*/, DWORD /*dwParam3*/)
{
   // Not doing anything in the callback.
}
#endif //RAS_MONITOR_NO_TAPI