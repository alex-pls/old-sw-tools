/************************************************************************
WEBRELAY Software -- a multithreaded HTTP relay server
Copyright (C) 1999 Peter Zhang

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

Please address all correspondence concerning the software to 
zhangc@ucalgary.ca
************************************************************************/

#include "dbtbl.h"

#define MAXLINELENGTH 1024

static htable_t db_table;

/* Read a line from the configuration file. Return a number of char 
read if successful, 0 if EOF, -1 otherwise */
static ssize_t read_line(int fd, char *buf, int maxlen)
{
  ssize_t n, rc;
  char c;

  for (n = 1; n < maxlen; n++) {
    if( (rc = read(fd, &c, 1)) == 1) {
      *buf++ = c;
      if(c == '\n')
        break;                  /* newline is stored as fgets() */
    } else if (rc == 0) {
      if (n == 1) 
        return 0; /*EOF, no data read */
      else
        break;
    } else {
      return -1; /* error */
    }
  }
  *buf = 0;     /* Null terminated like fgets() */
  return n;
}

static ssize_t get_line(int fd, char **buf)
{
  ssize_t n;
  *buf = (char *)Smalloc(MAXLINELENGTH + 1);

  /* Newline is stored like fgets() */
  n = read_line(fd, *buf, MAXLINELENGTH);

  return n;
}

int init_dburls(char *dburls_path)
{
  /* take a default size of 101 and a default hash function */
  ht_init(&db_table, 0, NULL, &dburl_free);

  if (!load_dburls(dburls_path))
    return 0;
  else
    return -1;
}

static int load_dburls(char *dburls_path)
{
  int fd;
  int lineno = 0;

  fd = Sopen(dburls_path, O_RDONLY, 0644);

  while (1) {
    int status;
    char *line_buf = NULL;
    char *buf, *key, *p, *q;
    hentry_t *hep;
    dbinfo_t *dbip;
    char *tmp;

    status = get_line(fd, &line_buf);
    /* buf is a cursor */
    buf = line_buf;

    lineno += 1;
    if(status == -1) {
      fprintf(stderr, "Bad record at line %d\n", lineno);
      FREE_MAYBE(line_buf);
      Sclose(fd);
      return -1;
    } else if (status == 0) {
      FREE_MAYBE(line_buf);
      break;
    }

    /* Skip over empty lines and any line beginning with a '#' */
    if(*buf == '\n' || (*buf == '\r' && *(buf+1) == '\n') ||
       *buf == '#') {
      FREE_MAYBE(line_buf);
      continue;
    }

    dbip = (dbinfo_t *)Smalloc(sizeof(dbinfo_t));
    /* Skip over leading linear white space */
    buf += skip_lws(buf);
    /* look for space */
    p = strchr(buf, ' ');
    if (p != NULL) {
      key = strdupdelim(buf, p);
      buf = p;
      buf += skip_lws(buf);
      p = buf;
      q = strchr(buf, ' ');
      if (q != NULL) {
	dbip->db_url = strdupdelim(p, q);
	buf = q;
	buf += skip_lws(buf);
	p = strchr(buf, '#');
	if (p != NULL) {
	  tmp = strdupdelim(buf, p);
	  if (*tmp == '0')
	    dbip->auth_mandated = 0;
	  else
	    dbip->auth_mandated = 1;
	  p++;
	  p += skip_lws(p);
	  dbip->db_official_name = xstrdup(p);
	} else {
	  fprintf(stderr, "Missing # sign at line %d\n", lineno);
	  FREE_MAYBE(line_buf);
	  Sclose(fd);
	  return -1;
	}
      } else {
	fprintf(stderr, "Missing delimiter at line %d\n", lineno);
	FREE_MAYBE(line_buf);
	Sclose(fd);
	return -1;
      }
    } else {
      fprintf(stderr, "Missing delimiter for URL at line %d\n", lineno);
      FREE_MAYBE(line_buf);
      Sclose(fd);
      return -1;
    }
    hep = ht_insert(&db_table, key, 0, (void *)dbip, 0, &dburl_free);
    /* Free memory of returned hep structure */
    ht_release(hep);
    FREE_MAYBE(tmp);
    FREE_MAYBE(key);
    FREE_MAYBE(line_buf);
  }
  Sclose(fd);
  return 0;
}

static void dburl_free(void *data)
{
  dbinfo_t *dbip = (dbinfo_t *)data;
  FREE_MAYBE(dbip->db_url);
  FREE_MAYBE(dbip->db_official_name);
  /*FREE_MAYBE(dbip);*/
}

int dburl_foreach(int (*foreach_func)(hentry_t *hep, void *misc),
	       void *misc)
{
  return ht_foreach(&db_table, foreach_func, misc);
}

hentry_t *dburl_lookup(const void *key, unsigned keylen)
{
  return ht_lookup(&db_table, key, keylen);
}

void dburl_destroy(void)
{
  ht_destroy(&db_table);
}

