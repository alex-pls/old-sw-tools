/************************************************************************
WEBRELAY Software -- a multithreaded HTTP relay server
Copyright (C) 1999 Peter Zhang

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

Please address all correspondence concerning the software to 
zhangc@ucalgary.ca
************************************************************************/

#ifndef HTML_H
#define HTML_H

#include "mywrap.h"
#include "url.h"
#include "utils.h"

/* Structure of a parser state*/
typedef struct
{
  int has_js;
  int is_js_arg;
  int at_value, in_quote;
  char quote_char;
  char *tag, *attr;
  char *base;
  char *func_name;
} state_t;

typedef struct
{
  int at_value, in_quote;
  char quote_char;
  char *tag, *event_handler;
} js_event_t;

typedef struct
{
  char *tag;
  char *attr;
} tag_t;

/* Function declarations */
static int idmatch PARAMS ((tag_t *tags, const char *tag, const char *attr));
const char *find_url PARAMS ((const char *, int, int *, state_t *));
const char *find_event_handler PARAMS ((const char *, int, int *, js_event_t *));

#endif /* HTML_H */
