/************************************************************************
WEBRELAY Software -- a multithreaded HTTP relay server
Copyright (C) 1999 Peter Zhang

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

Please address all correspondence concerning the software to 
zhangc@ucalgary.ca
************************************************************************/

#ifndef MYWRAP_H
#define MYWRAP_H

#include "ar_relay.h"

#ifndef INADDR_NONE
#define INADDR_NONE 0xffffffff
#endif

#define BACKLOG 1024

typedef void Sigfunc(int);

struct group *Sgetgrnam_r PARAMS ((const char *name,
				    struct group *grent,
				    char *buffer, int buflen));

struct passwd *Sgetpwnam_r PARAMS ((const char *name,
				    struct passwd *pwent,
				    char *buffer, int buflen));

struct passwd *Sgetpwuid_r PARAMS ((const uid_t uid,
				    struct passwd *pwent,
				    char *buffer, int buflen));

Sigfunc *Ssignal PARAMS ((int, Sigfunc *));

void Spthread_create PARAMS ((pthread_t *, const pthread_attr_t *,
			   void * (*)(void *), void *));

void Spthread_attr_init PARAMS ((pthread_attr_t *));

void Spthread_attr_setdetachstate PARAMS ((pthread_attr_t *, int));

void Spthread_attr_setscope PARAMS ((pthread_attr_t *, int));

void Spthread_join PARAMS ((pthread_t, void **));

void Spthread_detach PARAMS ((pthread_t));

void Spthread_mutex_init PARAMS ((pthread_mutex_t *, pthread_mutexattr_t *));

void Spthread_mutex_lock PARAMS ((pthread_mutex_t *));

void Spthread_mutex_trylock PARAMS ((pthread_mutex_t *));

void Spthread_mutex_unlock PARAMS ((pthread_mutex_t *));

void Spthread_mutex_destroy PARAMS ((pthread_mutex_t *));

void Spthread_cond_init PARAMS ((pthread_cond_t *condition,
				 pthread_condattr_t *attr));

void Spthread_cond_timedwait PARAMS ((pthread_cond_t *condition,
			      pthread_mutex_t *mutex, 
			      const struct timespec *timeout));

int Saccept PARAMS ((int, struct sockaddr *, socklen_t *));
void Sbind PARAMS ((int, struct sockaddr *, socklen_t));
int Sconnect PARAMS ((int, struct sockaddr *, socklen_t));

void Slisten PARAMS ((int, int));

void Ssetsockopt PARAMS ((int, int, int, const void *, socklen_t));

int Ssocket PARAMS ((int, int, int));

void Sclose PARAMS ((int));

void Sfclose PARAMS ((FILE *));

FILE *Sfdopen PARAMS ((int, const char *));

char *Sfgets PARAMS ((char *, int, FILE *));

FILE *Sfopen PARAMS ((const char *, const char *));

void Sfputs PARAMS ((const char *, FILE *));

void *Scalloc PARAMS ((int, size_t));

void *Smalloc PARAMS ((size_t));

void *Srealloc PARAMS ((void *, size_t));

int Sopen PARAMS ((const char *, int, unsigned long));

void Sgethostbyname PARAMS ((const char *, struct hostent **));

void Sgethostbyaddr PARAMS ((char *, struct hostent **));

int iread (int fd, char *buf, int len);

ssize_t readn PARAMS ((int, void *, size_t));

ssize_t Readn PARAMS ((int, void *, size_t));

ssize_t	writen PARAMS ((int, const void *, size_t));

void Writen PARAMS ((int, void *, size_t));

ssize_t readline PARAMS ((register int, register char *, register int));

int ServerConnect PARAMS ((const unsigned short));

int ClientConnect PARAMS ((int *res, const char *, const int));

#endif
