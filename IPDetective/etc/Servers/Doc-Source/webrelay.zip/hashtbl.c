/************************************************************************
WEBRELAY Software -- a multithreaded HTTP relay server
Copyright (C) 1999 Peter Zhang

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

Please address all correspondence concerning the software to 
zhangc@ucalgary.ca
************************************************************************/

#include "hashtbl.h"

static unsigned int hash(const void *key,
			 unsigned int keylen,
			 unsigned int hashsize)
{
  const unsigned char *keyp;
  unsigned int res = 0;
  unsigned int hs = 0;

  keyp = (const unsigned char *) key;

  if (keylen == 0) {
    while (*keyp) {
      res += (*keyp++) << hs;
      hs = (hs+1)&7;
    }
  } else {
    while (keylen-- > 0) {
      res += (*keyp++) << hs;
      hs = (hs+1)&7;
    }
  }

  return res;
}

static int keycmp(const void *p1,
		  unsigned int len1,
		  const void *p2,
		  unsigned int len2)
{
  if (len1 == 0 && len2 == 0)
    return strcmp((char *) p1, (char *) p2);
  else if (len1 == 0 && len2 != 0)
    return strncmp(p1, p2, len2);
  else if (len1 == len2)
    return memcmp(p1, p2, len2);
  else
    return -1;
}

void ht_init(htable_t *htp,
	     unsigned int hashsize,
	     unsigned int (*hash_func)(const void *key,
				  unsigned int keylen,
				  unsigned int hashsize),
	     void(*release_func)(void *data))
{
  unsigned int i;
  hentry_t *head;

  htp->size = hashsize ? hashsize : 101;
  htp->hash_func = (hash_func != NULL) ? hash_func : &hash;
  htp->release_func = release_func;

  htp->table = Smalloc(htp->size * sizeof(hentry_t));

  for (i = 0; i < htp->size; i++) {
    head = &htp->table[i];
    Spthread_mutex_init(&head->lock, NULL);
    Spthread_mutex_lock(&head->lock);
    head->next = NULL;
    Spthread_mutex_unlock(&head->lock);
  }
}

hentry_t *ht_lookup(htable_t *htp,
		    const void *key,
		    unsigned int keylen)
{
  unsigned int i;
  hentry_t *prev, *current;
    
  if (htp == NULL)
    return NULL;
    
  i = (*(htp->hash_func))(key, keylen, htp->size) % htp->size;

  prev = &htp->table[i];
  Spthread_mutex_lock(&prev->lock);
    
  while ((current = prev->next) != NULL) {
    Spthread_mutex_unlock(&prev->lock);
      
    Spthread_mutex_lock(&current->lock);
    current->h_count++;
    Spthread_mutex_unlock(&current->lock);
	
    if (keycmp(current->key, current->keylen, key, keylen) == 0)
      return current;

    Spthread_mutex_lock(&current->lock);
    current->h_count--;
	
    prev = current;
  }

  Spthread_mutex_unlock(&prev->lock);
  return NULL;
}

/* Releases a hash table entry when it has been bypassed by an
   operation, such as replace or delete. Only when the use becomes
   zero we may release its memory as well. */
void ht_release(hentry_t *hep)
{
  if (hep == NULL)
    return;
    
  Spthread_mutex_lock(&hep->lock);
  hep->h_count--;
    
  if (hep->h_count > 0) {
    Spthread_mutex_unlock(&hep->lock);
    return;
  }

  if (hep->release_func != NULL)
    (*(hep->release_func))(hep->data);

  Spthread_mutex_unlock(&hep->lock);
  Spthread_mutex_destroy(&hep->lock);

  FREE_MAYBE(hep->key);
  FREE_MAYBE(hep);
}

/* Free the memory of the hash table entry that is returned from
   another function of ht_find and ht_insert. */
void ht_free(hentry_t *hep)
{
  if (hep == NULL)
    return;
    
  Spthread_mutex_lock(&hep->lock);
    
  if (hep->release_func != NULL)
    (*(hep->release_func))(hep->data);

  Spthread_mutex_unlock(&hep->lock);
  Spthread_mutex_destroy(&hep->lock);

  FREE_MAYBE(hep->key);
  FREE_MAYBE(hep);
}

hentry_t *ht_insert(htable_t *htp,
		    const void *key,
		    unsigned int keylen,
		    void *data,
		    unsigned int flags,
		    void (*release_func)(void *data))
{
  unsigned int i;
  hentry_t *prev, *current, *new;

  if (htp == NULL)
    return NULL;
    
  i = (*(htp->hash_func))(key, keylen, htp->size) % htp->size;

  new = Smalloc(sizeof(hentry_t));
  Spthread_mutex_init(&new->lock, NULL);
  if (keylen) {
    new->key = Smalloc(keylen);
    memcpy(new->key, key, keylen);
  } else
    new->key = xstrdup(key);

  new->keylen = keylen;
  new->data = data;
  new->h_count = 1;
  new->next = NULL;
  new->release_func = release_func;
  
  prev = &htp->table[i];
  Spthread_mutex_lock(&prev->lock);
    
  while ((current = prev->next) != NULL) {
    Spthread_mutex_lock(&current->lock);
    if (keycmp(current->key, current->keylen, key, keylen) == 0) {
	  /* Already in table */
      if (flags & HTF_REPLACE) {
	prev->next = new;
	new->next = current->next;
	new->h_count++;
		
	Spthread_mutex_unlock(&current->lock);
	Spthread_mutex_unlock(&prev->lock);
		
	ht_release(current);
	
	return new;
      } else {
	Spthread_mutex_unlock(&current->lock);
	Spthread_mutex_unlock(&prev->lock);

	ht_release(new);
		
	return NULL;
      }
    }

    Spthread_mutex_unlock(&prev->lock);
    prev = current;
  }

  if (flags & HTF_NOINSERT) {
    /* Only replace already existing data */
      
    Spthread_mutex_unlock(&prev->lock);
    
    ht_release(new);
	
    return NULL;
  }

  new->h_count++;
    
  prev->next = new;
  Spthread_mutex_unlock(&prev->lock);
    
  return new;
}


int ht_delete(htable_t *htp, hentry_t *hep)
{
  unsigned int i;
  hentry_t *prev, *current;
    
  if (htp == NULL)
    return -1;
  
  i = (*(htp->hash_func))(hep->key, hep->keylen, htp->size) % htp->size;

  prev = &htp->table[i];
  Spthread_mutex_lock(&prev->lock);
    
  while ((current = prev->next) != NULL) {
    Spthread_mutex_lock(&current->lock);
    if (current == hep) {
      prev->next = current->next;
      current->next = NULL;
	    
      Spthread_mutex_unlock(&current->lock);
      Spthread_mutex_unlock(&prev->lock);

      ht_release(current);
      return 0;
    }
		
    Spthread_mutex_unlock(&prev->lock);
    prev = current;
  }

  Spthread_mutex_unlock(&prev->lock);
  return -1;
}


int ht_foreach(htable_t *htp,
	       int (*foreach_func)(hentry_t *hep, void *misc),
	       void *misc)
{
  int retval;
  unsigned int i;
  hentry_t *prev, *current;

  if (htp == NULL)
    return -1;
    
  for (i = 0; i < htp->size; i++) {
    prev = &htp->table[i];

    Spthread_mutex_lock(&prev->lock);
    while ((current = prev->next) != NULL) {
      Spthread_mutex_unlock(&prev->lock);
	    
      Spthread_mutex_lock(&current->lock);
      current->h_count++;
      Spthread_mutex_unlock(&current->lock);

      retval = foreach_func(current, misc);

      Spthread_mutex_lock(&current->lock);
      current->h_count--;
	    
      if (retval < 0) {
	Spthread_mutex_unlock(&current->lock);
	return retval;
      }
	    
      prev = current;
    }
	
    Spthread_mutex_unlock(&prev->lock);
  }

  return 0;
}


void ht_destroy(htable_t *htp)
{
  ht_clean(htp);
  FREE_MAYBE(htp->table);
}


int ht_clean(htable_t *htp)
{
  unsigned int i;
  hentry_t *prev, *current;
    
  if (htp == NULL)
    return -1;
    
  for (i = 0; i < htp->size; i++) {
    prev = &htp->table[i];

    Spthread_mutex_lock(&prev->lock);
    while ((current = prev->next) != NULL) {
      Spthread_mutex_lock(&current->lock);

      prev->next = current->next;
      current->next = NULL;
	  
      Spthread_mutex_unlock(&current->lock);

      ht_release(current);
    }
	
    Spthread_mutex_unlock(&prev->lock);
  }

  return 0;
}



