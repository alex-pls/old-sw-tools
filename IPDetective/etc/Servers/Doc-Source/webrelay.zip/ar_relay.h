/************************************************************************
WEBRELAY Software -- a multithreaded HTTP relay server
Copyright (C) 1999 Peter Zhang

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

Please address all correspondence concerning the software to 
zhangc@ucalgary.ca
************************************************************************/

#ifndef AR_RELAY_H
#define AR_RELAY_H

#include <pthread.h>
#include <libgen.h>
#include <ctype.h>
#include <errno.h>
#ifdef AIX4_3
#include <sys/mbuf.h> /* for mbuf in net/route.h of AIX4.3 */
#include <netinet/if_ether.h>   /* for ether_add in arpa/inet.h of AIX4.3 */
#include <net/if_dl.h>  /* for sockaddr_dl in arpa/inet.h of AIX4.3 */
#endif
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <malloc.h>
#include <stdio.h>
#include <fcntl.h>
#include <ndbm.h>
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/time.h>
#include <time.h>
#include <sys/signal.h>
#include <unistd.h>
#include <sys/select.h>
#include <stdarg.h>		/* ANSI C header file */
#include <syslog.h>		/* for syslog() */
#include <pwd.h>
#include <grp.h>
#include <utime.h>

#define HAS_PROTOTYPES 1

#ifndef PARAMS
# if HAS_PROTOTYPES
#  define PARAMS(args) args
# else
#  define PARAMS(args) ()
# endif
#endif

#ifdef AIX4_1
typedef int socklen_t;
#endif
#ifdef AIX4_2
typedef size_t socklen_t;
#endif

#define MAXNAME 256
#define MAXLINE 3072
/* Retrieval buffer size for get_body.  */
#define BUFFER_SIZE 8192
#define HEAD_SIZE 1024

#define AR_EOF_SOURCE     1
#define AR_EOF_TARGET 	  2
#define AR_CLOSED_SOURCE  3
#define AR_CLOSED_TARGET  4

#define AR_OK      	1
#define AR_ERROR  	-1
#define AR_EOF     	0
#define AR_AUTH_WAIT  	2
#define AR_REDIR_WAIT   3
#define AR_SES_END  	4
#define AR_REDIR_SENT  	5

#define SHUT_RD 0
#define SHUT_WR 1
#define SHUT_RDWR 2

#define AR_STATE_OK      1
#define AR_STATE_ERR     -1

#define DEFAULT_SERVER_ROOT "/usr/local/webrelay/"
#define DEFAULT_SERVER_LOG "/var/spool/local/log/"

#define DEFAULT_SERVER_USER "nobody"
#define DEFAULT_SERVER_GROUP "nobody"

#define DEFAULT_AUTH_TYPE  "custom"
#define DEFAULT_ACCLOG_FILE  "log.ar_acclog"
#define DEFAULT_ERRLOG_FILE  "log.ar_errlog"
#define DEFAULT_CNTLOG_FILE  "log.ar_cntlog"
#define DEFAULT_SYSLOG_FILE  "log.ar_syslog"
#define DEFAULT_DBURLS_FILE   "dburls.conf"

/* Some structures used by the relay server. */

typedef struct _accept_info_s {
  char *relay_hostname;		/* hostname of my relay server */
  unsigned short relay_port; 	/* my relay server's port number */
  struct sockaddr_in *cliaddr;	/* client, values returned from accept */
  socklen_t clilen;			/* function call.*/
  int clifd;			/* file descriptor of client socket */
  char *auth_type;		/* Authentication type */
  char *ClientHostname;		/* Hostname of our patron */
} accept_info;

typedef struct _relay_info_s {
  char *db_key;		/* Key of remote database server */
  char *db_official_name;	/* official database name */
  char *targethost;	/* Target hostname corresponding to db_key */
  int targethost_size;	/* Size of targethost string */
  unsigned short targetport;	/* port number of the target database */
  char *targetpath;	/* Target path */
  char *targetdir;	/* Target dir */
  char *targetfile;	/* Target file */
  int autoredir_now;	/* Whether to do auto redirect now? */
  int redirect_flag;	/* Whether to redirect or did we redirect? */
  char *redir_targethost;	/* Redirected Target hostname */
  unsigned short redir_targetport;	/* port number of redirected target */
  char *redir_targetpath;	/* Path of redirected target */
  char *redir_targetdir;	/* Dir of redirected target  */
  char *redir_targetfile;	/* File of redirected target */    
  int sourcefd; 	/* talking with our client, can be read or write */
  int targetfd; 	/* talking with databse server, can be read or write */
  char *client_auth;	/* Authorization: header value from client*/
  char *seskey;		/* Session control key */
  char *client_proto_vs;		/* HTTP Version of the client */
  char *client_user_agent;		/* User Agent of the client */  
  int  persist_flag;		/* Client wants Persistent connection? */
  char *cookie;		/* Cookie set by remote database server */      
  int has_js;		/* Has Javascript? */
  int has_base;		/* Originally has base url? */
  char *base_url;	/* Base URL. We have not really used it a lot */
  int auth_flag;	/* Pass through the relay server or not */
  int fix_opt_value;	/* Need fix OPTION VALUE? */
  int num_bytes;	/* Number of bytes we send to our patron */
  unsigned int rs_status_code; /* Status Code of the response */
} relay_info;

#define ISASCII(x)  isascii ((unsigned char)(x))
#define ISALPHA(x)  isalpha ((unsigned char)(x))
#define ISSPACE(x)  isspace ((unsigned char)(x))
#define ISDIGIT(x)  isdigit ((unsigned char)(x))
#define ISXDIGIT(x) isxdigit ((unsigned char)(x))

/* Defined in `mywrap.c', but used literally everywhere.  */
void *Smalloc PARAMS ((size_t));
void *Srealloc PARAMS ((void *, size_t));
char *xstrdup PARAMS ((const char *));

#define AR_RELAY_PORT 32888

/* Useful macros used across the code: */

/* The smaller value of the two.  */
#define MINVAL(x, y) ((x) < (y) ? (x) : (y))

/* ASCII char -> HEX digit */
#define ASC2HEXD(x) (((x) >= '0' && (x) <= '9') ?               \
		     ((x) - '0') : (toupper(x) - 'A' + 10))

/* HEX digit -> ASCII char */
#define HEXD2ASC(x) (((x) < 10) ? ((x) + '0') : ((x) - 10 + 'A'))

#define ARRAY_SIZE(array) (sizeof (array) / sizeof (*(array)))

/* Free FOO if it is non-NULL.  */
#define FREE_MAYBE(foo) do 					\
{								\
  if ((foo) != NULL) {						\
    free (foo); 						\
    (foo) = NULL; 						\
  }								\
} while (0)


/* Universal error type */
typedef enum
{
  URLOK, URLHTTP, URLFTP, URLFILE, URLUNKNOWN, URLBADPORT,
  URLBADHOST
} uerr_t;

#endif /* AR_RELAY_H */
