/************************************************************************
WEBRELAY Software -- a multithreaded HTTP relay server
Copyright (C) 1999 Peter Zhang

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

Please address all correspondence concerning the software to 
zhangc@ucalgary.ca
************************************************************************/

#include "chainhash.h"

/* Default hash function */
static unsigned int c_hash(const void *key,
			 unsigned int keylen,
			 unsigned int hashsize)
{
  unsigned char *keyp;
  unsigned int res = 0;
  unsigned int hs = 0;

  keyp = (unsigned char *) key;

  if (keylen == 0) {
    while (*keyp) {
      res += (*keyp++) << hs;
      hs = (hs+1)&7;
    }
  } else {
    while (keylen-- > 0) {
      res += (*keyp++) << hs;
      hs = (hs+1)&7;
    }
  }

  return res;
}

/* Key comparison */
static int keycmp(void *p1,
		   void *p2,
		   unsigned int len)
{
  if (len == 0)
    return strcmp((char *) p1, (char *) p2);
  else
    return memcmp(p1, p2, len);
}

/* Allocate memory and initialize data for a chain hash node */
static chain_node_t *chain_node_alloc(void *key,
				  unsigned int keylen,
				  void *data,
				  void (*release_func)(void *data))
{
  chain_node_t *new;

  new = Smalloc(sizeof(chain_node_t));

  Spthread_mutex_init(&(new->lock), NULL);
  new->ref_count = 1;

  time(&new->SesStart);
  time(&new->LastUpdated);

  new->release_func = release_func;
    
  new->keylen = keylen;
  if (keylen == 0)
    new->key = xstrdup(key);
  else {/* keylen > 0, all keys have the same length */
    new->key = Smalloc(keylen);
    memcpy(new->key, key, keylen);
  }
  new->data = data;
  new->next = NULL;

  return new;
}


/* A garbage collection daemon thread */
static void *gc_thrd(void *arg)
{
  chain_hash_t *chp = arg;
  unsigned int i;
  chain_node_t *prev, *current;
  time_t current_time;
    
Loop:
  sleep(chp->gc_sleep);
  time(&current_time);
    
  for (i = 0; i < chp->size; i++) {
    prev = &chp->table[i];
	
    Spthread_mutex_lock(&prev->lock);
    
    while ((current = prev->next) != NULL) {
      Spthread_mutex_lock(&current->lock);

      if (difftime(current_time, current->LastUpdated) > chp->refresh) {
	prev->next = current->next;
	current->next = NULL;
	Spthread_mutex_unlock(&current->lock);

	chain_hash_release(current);
      } else {
	Spthread_mutex_unlock(&prev->lock);
	prev = current;
      }
    }
	
    Spthread_mutex_unlock(&prev->lock);
  }
    
  /* This thread will never return */
  goto Loop;
}

/* Start up function */
void chain_hash_init(chain_hash_t *chp,
		int refresh,
		int ttl,
		int gc_sleep,
		unsigned int hashsize,
		unsigned int (*hash_func)(const void *key,
				     unsigned int keylen,
				     unsigned int hashsize),
		void (*release_func)(void *data))
{
  unsigned int i;
  pthread_attr_t attr;
  pthread_t thr_id;
  chain_node_t *head;

  chp->size = hashsize ? hashsize : 101;
  chp->hash_func = (hash_func != NULL) ? hash_func : &c_hash;
  chp->release_func = release_func;

  chp->refresh = refresh;
  chp->ttl = ttl;
  chp->gc_sleep = gc_sleep;
    
  chp->table = Smalloc(chp->size * sizeof(chain_node_t));

  for (i = 0; i < chp->size; i++) {
    head = &chp->table[i];
    Spthread_mutex_init(&head->lock, NULL);
    Spthread_mutex_lock(&head->lock);
    head->next = NULL;
    Spthread_mutex_unlock(&head->lock);	
  }

  /* Idle session sweeper is started */
  if (chp->gc_sleep >= 0) {
    Spthread_attr_init( &attr );
    Spthread_attr_setdetachstate( &attr, PTHREAD_CREATE_DETACHED );
    Spthread_create(&thr_id, &attr, &gc_thrd, (void *) chp);
  }
}

/* Find an entry in a chain hash table */
chain_node_t *chain_hash_find(chain_hash_t *chp, void *key, unsigned int keylen)
{
  unsigned int i;
  chain_node_t *prev, *current;
  time_t current_time;

  time(&current_time);

  i = (*(chp->hash_func))(key, keylen, chp->size) % chp->size;

  prev = &chp->table[i];

  Spthread_mutex_lock(&prev->lock);
    
  while ((current = prev->next) != NULL) {
    Spthread_mutex_lock(&current->lock);
    if (keylen == current->keylen &&
	keycmp(current->key, key, keylen) == 0) {
      if (difftime(current_time, current->LastUpdated) <= chp->refresh) {
	current->ref_count++;
	Spthread_mutex_unlock(&current->lock);
	Spthread_mutex_unlock(&prev->lock);
	return current;
      }
    }
    Spthread_mutex_unlock(&prev->lock);
    /* New prev will gain the lock that was set up already for the
       current node */
    prev = current;
  }
  Spthread_mutex_unlock(&prev->lock);
  return NULL;
}

/* Insert an entry into chain hash table */
chain_node_t *chain_hash_insert(chain_hash_t *chp, void *key, unsigned int keylen,
			   void *data, unsigned int flags,
			   void (*release_func)(void *data))
{
  unsigned int i;
  chain_node_t *prev, *current, *new;
  time_t current_time;
    
  if(chp == NULL)
    return NULL;

  time(&current_time);

  /* This will set new->SesStart and new->LastUpdated to the current time */
  new = chain_node_alloc(key, keylen, data, release_func);

  i = (*(chp->hash_func))(key, keylen, chp->size) % chp->size;

  prev = &chp->table[i];

  Spthread_mutex_lock(&prev->lock);
 
  while ((current = prev->next) != NULL) {
    Spthread_mutex_lock(&current->lock);
    if (keylen == current->keylen &&
	keycmp(current->key, key, keylen) == 0) {
      /* Already in table */
      if ((flags & CF_REPLACE) || 
	  (difftime(current_time, current->LastUpdated) >= chp->refresh)) {
	prev->next = new;
	new->next = current->next;
	new->ref_count++;
	Spthread_mutex_unlock(&current->lock);
	Spthread_mutex_unlock(&prev->lock);

	chain_hash_release(current);
	return new;
      } else {
	Spthread_mutex_unlock(&current->lock);
	Spthread_mutex_unlock(&prev->lock);

	chain_hash_release(new);
	return NULL;
      }
    }
    Spthread_mutex_unlock(&prev->lock);
    prev = current;
  }

  /* Not in the table yet */
  if(flags & CF_NOINSERT) {
    /* Only replace already existing data */
    Spthread_mutex_unlock(&prev->lock);
    chain_hash_release(new);
    return NULL;
  }

  /* Otherwise insert new at the end of the linked list */
  new->ref_count++;
  prev->next = new;
  Spthread_mutex_unlock(&prev->lock);
  return new;
}

/* If the ref_count is not zero, it would not release the memory of the 
   entry, because other threads are using this segment of the memory. 
   Only if the ref_count  becomes zero, it will release the memory 
   occupied by the entry. The memory of the data member structure of 
   the entry is released by a user defined release_func() */
void chain_hash_release(chain_node_t *cnp)
{
  if(cnp == NULL)
    return;

  Spthread_mutex_lock(&cnp->lock);
  cnp->ref_count--;
    
  if (cnp->ref_count > 0) {
    Spthread_mutex_unlock(&cnp->lock);
    return;
  }

  if (cnp->release_func != NULL && cnp->data != NULL)
    (*(cnp->release_func))((void *) cnp->data);

  Spthread_mutex_unlock(&cnp->lock);
  Spthread_mutex_destroy(&cnp->lock);

  FREE_MAYBE(cnp->key);
  FREE_MAYBE(cnp);
}


/* Delete an entry of cep from the chain hash table */
int chain_hash_delete(chain_hash_t *chp, chain_node_t *cnp)
{
  unsigned int i;
  chain_node_t *prev, *current;
    
  if (chp == NULL)
    return -1;
    
  i = (*(chp->hash_func))(cnp->key, cnp->keylen, chp->size) % chp->size;

  prev = &chp->table[i];
  Spthread_mutex_lock(&prev->lock);
    
  while ((current = prev->next) != NULL) {
    Spthread_mutex_lock(&current->lock);
    if (current == cnp) {
      prev->next = current->next;
      current->next = NULL;
      
      Spthread_mutex_unlock(&current->lock);
      Spthread_mutex_unlock(&prev->lock);

      chain_hash_release(current);
      return 0;
    }
    Spthread_mutex_unlock(&prev->lock);
    prev = current;
  }

  Spthread_mutex_unlock(&prev->lock);
  return -1;
}

/* A scanning function across the table with a user-defined foreach_func */
int chain_hash_foreach(chain_hash_t *chp,
		  int (*foreach_func)(chain_node_t *cnp, void *misc),
		  void *misc)
{
  int retval;
  unsigned int i;
  chain_node_t *prev, *current;
    
  if (chp == NULL)
    return -1;
    
  for (i = 0; i < chp->size; i++) {
    prev = &chp->table[i];

    Spthread_mutex_lock(&prev->lock);

    while ( (current = prev->next) != NULL) {
      Spthread_mutex_lock(&current->lock);
      current->ref_count++;

      retval = foreach_func(current, misc);

      current->ref_count--;
	    
      if (retval < 0) {
	Spthread_mutex_unlock(&current->lock);
	Spthread_mutex_unlock(&prev->lock);
	return retval;
      }
      Spthread_mutex_unlock(&prev->lock);
      prev = current;
    }

    Spthread_mutex_unlock(&prev->lock);
  }
  return 0;
}

