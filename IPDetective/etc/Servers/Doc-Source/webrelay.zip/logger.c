/************************************************************************
WEBRELAY Software -- a multithreaded HTTP relay server
Copyright (C) 1999 Peter Zhang

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

Please address all correspondence concerning the software to 
zhangc@ucalgary.ca
************************************************************************/

#include "logger.h"

static char *acclog_path = NULL;
static char *errlog_path = NULL;
static int acclog_fd = -1;
static int errlog_fd = -1;
static FILE *acclog_fp = NULL;
static FILE *errlog_fp = NULL;
static pthread_mutex_t acclog_lock;
static pthread_mutex_t errlog_lock;
static pthread_mutex_t count_lock;
static char *count_path = NULL;
static DBM *count_fd = NULL;
  
void log_init(char *accpath, char *errpath, char *cnt_path)
{
  Spthread_mutex_init(&acclog_lock, NULL);
  Spthread_mutex_init(&errlog_lock, NULL);
  Spthread_mutex_init(&count_lock, NULL);

  Spthread_mutex_lock(&acclog_lock);
  if (accpath != NULL) {
    acclog_path = accpath;
    acclog_fd = Sopen(accpath, O_WRONLY+O_CREAT+O_APPEND, 0644);
    acclog_fp = Sfdopen(acclog_fd, "w");
  }
  Spthread_mutex_unlock(&acclog_lock);
    
  Spthread_mutex_lock(&errlog_lock);
  if (errpath != NULL) {
    errlog_path = errpath;
    errlog_fd = Sopen(errpath, O_WRONLY+O_CREAT+O_APPEND, 0644);
    errlog_fp = Sfdopen(errlog_fd, "w");
  }
  Spthread_mutex_unlock(&errlog_lock);
}

void log_reopen(void)
{
  Spthread_mutex_lock(&acclog_lock);
  if (acclog_fd >= 0) {
    Sclose(acclog_fd);
    acclog_fd = -1;
  }

  if (acclog_path != NULL) {
    acclog_fd = Sopen(acclog_path, O_WRONLY+O_CREAT+O_APPEND, 0644);
    acclog_fp = Sfdopen(acclog_fd, "w");
  }

  Spthread_mutex_unlock(&acclog_lock);
  
  Spthread_mutex_lock(&errlog_lock);
  if (errlog_fd >= 0) {
    Sclose(errlog_fd);
    errlog_fd = -1;
  }
  
  if (errlog_path != NULL) {
    errlog_fd = Sopen(errlog_path, O_WRONLY+O_CREAT+O_APPEND, 0644);
    errlog_fp = Sfdopen(errlog_fd, "w");
  }

  Spthread_mutex_unlock(&errlog_lock);
  
}

void log_close(void)
{
  Spthread_mutex_lock(&acclog_lock);
  if (acclog_fd >= 0) {
    Sclose(acclog_fd);
    acclog_fd = -1;
  }
  Spthread_mutex_unlock(&acclog_lock);
 
  Spthread_mutex_lock(&errlog_lock);
  if (errlog_fd >= 0) {
    Sclose(errlog_fd);
    errlog_fd = -1;
  }
  Spthread_mutex_unlock(&errlog_lock);
}

void log_err(time_t tm, accept_info *aip, relay_info *rip, char *msg)
{
  Spthread_mutex_lock(&errlog_lock);
	
  if (errlog_fp != NULL) {
    char *ClientIP;
    char *logtimestamp = NULL;
    chain_node_t *cnp;
    sess_info_t *sip;
    char *username = NULL;
    char *db_key = NULL;
    char *targethost = NULL;
    struct in_addr zero_addr;

    zero_addr.s_addr = (in_addr_t)0;

    log_time_r(tm, &logtimestamp);

    if(rip == NULL) {
      goto done;
    }
    if (rip->seskey != NULL) {
      cnp = sess_manager_find(rip->seskey, 0);
      if(cnp != NULL) {
	sip = cnp->data;
	username = xstrdup(sip->username);
	chain_hash_release(cnp);
      }
    }

    if(rip->targethost != NULL)
      targethost = xstrdup(rip->targethost);
    else if(rip->redir_targethost != NULL)
      targethost = xstrdup(rip->redir_targethost);
    else
      targethost = NULL;

    if(rip->db_key != NULL)
      db_key = xstrdup(rip->db_key);
    else
      db_key = NULL;

  done:     
    if(aip != NULL)
      ClientIP = inet_ntoa((aip->cliaddr)->sin_addr);
    else
      ClientIP = inet_ntoa(zero_addr);
    fprintf(errlog_fp,
	    "%s [%s] %s: While accessing DB \"%s\" at \"%s\", %s\n",
	    logtimestamp,
	    (ClientIP != NULL) ? ClientIP : "0.0.0.0",
	    (username != NULL) ? username : "-",
	    (db_key != NULL) ? db_key : "-",
	    (targethost != NULL) ? targethost : "-",
	    msg);
	
    fflush(errlog_fp);
    FREE_MAYBE(logtimestamp);
    FREE_MAYBE(ClientIP);
    FREE_MAYBE(username);
    FREE_MAYBE(db_key);
    FREE_MAYBE(targethost);
  }
    
  Spthread_mutex_unlock(&errlog_lock);
}

void log_redir_err(time_t tm, accept_info *aip, relay_info *rip, char *msg)
{
  Spthread_mutex_lock(&errlog_lock);
	
  if (errlog_fp != NULL) {
    char *ClientIP;
    char *logtimestamp = NULL;
    chain_node_t *cnp;
    sess_info_t *sip;
    char *username = NULL;
    char *targethost = NULL;
    char *db_key = NULL;
    struct in_addr zero_addr;

    zero_addr.s_addr = (in_addr_t)0;

    log_time_r(tm, &logtimestamp);

    if(rip == NULL) {
      goto done;
    }

    if (rip->seskey != NULL) {
      cnp = sess_manager_find(rip->seskey, 0);
      if(cnp != NULL) {
	sip = cnp->data;
	username = xstrdup(sip->username);
	chain_hash_release(cnp);
      }
    }

    if(rip->targethost != NULL)
      targethost = xstrdup(rip->targethost);
    else if(rip->redir_targethost != NULL)
      targethost = xstrdup(rip->redir_targethost);
    else
      targethost = NULL;

    if(rip->db_key != NULL)
      db_key = xstrdup(rip->db_key);
    else
      db_key = NULL;

  done:     
    if(aip != NULL)
      ClientIP = inet_ntoa((aip->cliaddr)->sin_addr);
    else
      ClientIP = inet_ntoa(zero_addr);
    fprintf(errlog_fp,
	    "%s [%s] %s: While accessing DB \"%s\" at \"%s\", %s\n",
	    logtimestamp,
	    (ClientIP != NULL) ? ClientIP : "0.0.0.0",
	    (username != NULL) ? username : "-",
	    (db_key != NULL) ? db_key : "-",
	    (targethost != NULL) ? targethost : "-",
	    msg);
	
    fflush(errlog_fp);
    FREE_MAYBE(logtimestamp);
    FREE_MAYBE(ClientIP);
    FREE_MAYBE(username);
    FREE_MAYBE(db_key);
    FREE_MAYBE(targethost);
  }
    
  Spthread_mutex_unlock(&errlog_lock);
}


void log_conn(time_t tm, accept_info *aip, relay_info *rip)
{
  Spthread_mutex_lock(&acclog_lock);
	
  if (acclog_fp != NULL) {
    char *ClientIP;
    char *logtimestamp = NULL;
    chain_node_t *cnp;
    sess_info_t *sip;
    char *username = NULL;
    char *db_key = NULL;
    struct in_addr zero_addr;
    
    zero_addr.s_addr = (in_addr_t)0;
    
    log_time_r(tm, &logtimestamp);

    if(rip == NULL)
      goto done;

    if (rip->seskey != NULL) {
      cnp = sess_manager_find(rip->seskey, 0);
      if(cnp != NULL) {
	sip = cnp->data;
	username = xstrdup(sip->username);
	chain_hash_release(cnp);
      }
    }

    if(rip->db_key != NULL)
      db_key = xstrdup(rip->db_key);
    else
      db_key = NULL;

  done:     
    if(aip != NULL)
      ClientIP = inet_ntoa((aip->cliaddr)->sin_addr);
    else
      ClientIP = inet_ntoa(zero_addr);
    fprintf(acclog_fp,
	    "%s [%s] %s: Target DB: \"%s\", \"%s\" %d bytes.\n",
	    logtimestamp,
	    (ClientIP != NULL) ? ClientIP : "0.0.0.0",
	    (username != NULL) ? username : "-",
	    (db_key != NULL) ? db_key : "-",
	    (rip->targetpath != NULL) ? rip->targetpath : "-",
	    rip->num_bytes);
	
    fflush(acclog_fp);
    FREE_MAYBE(logtimestamp);
    FREE_MAYBE(ClientIP);
    FREE_MAYBE(username);
    FREE_MAYBE(db_key);
  }
    
  Spthread_mutex_unlock(&acclog_lock);
}


void log_pass(time_t tm, accept_info *aip, relay_info *rip)
{
  Spthread_mutex_lock(&acclog_lock);
	
  if (acclog_fp != NULL) {
    char *ClientIP;
    char *logtimestamp = NULL;
    char *db_key = NULL;
    struct in_addr zero_addr;
    
    zero_addr.s_addr = (in_addr_t)0;
    
    log_time_r(tm, &logtimestamp);

    if(rip == NULL)
      goto done;

    if(rip->db_key != NULL)
      db_key = xstrdup(rip->db_key);
    else
      db_key = NULL;

  done:     
    if(aip != NULL)
      ClientIP = inet_ntoa((aip->cliaddr)->sin_addr);
    else
      ClientIP = inet_ntoa(zero_addr);
    fprintf(acclog_fp,
	    "%s [%s]: Went directly to target DB: \"%s\"\n",
	    logtimestamp,
	    (ClientIP != NULL) ? ClientIP : "0.0.0.0",
	    (db_key != NULL) ? db_key : "-");
	
    fflush(acclog_fp);
    FREE_MAYBE(logtimestamp);
    FREE_MAYBE(ClientIP);
    FREE_MAYBE(db_key);
  }
    
  Spthread_mutex_unlock(&acclog_lock);
}


void log_sesstart(time_t tm, accept_info *aip, relay_info *rip)
{
  Spthread_mutex_lock(&acclog_lock);
	
  if (acclog_fp != NULL) {
    char *ClientIP;
    char *logtimestamp = NULL;
    struct in_addr zero_addr;
    
    zero_addr.s_addr = (in_addr_t)0;
    
    log_time_r(tm, &logtimestamp);

    if(aip != NULL)
      ClientIP = inet_ntoa((aip->cliaddr)->sin_addr);
    else
      ClientIP = inet_ntoa(zero_addr);
 
    fprintf(acclog_fp,
	    "%s [%s]: Starts Session %s for \"%s\"\n",
	    logtimestamp,
	    (ClientIP != NULL) ? ClientIP : "0.0.0.0",
	    rip->seskey,
	    (rip->db_key != NULL) ? rip->db_key : "-");
	
    fflush(acclog_fp);
    FREE_MAYBE(logtimestamp);
    FREE_MAYBE(ClientIP);
  }
    
  Spthread_mutex_unlock(&acclog_lock);
}

void log_sesend(time_t tm, accept_info *aip, relay_info *rip)
{
  Spthread_mutex_lock(&acclog_lock);
	
  if (acclog_fp != NULL) {
    char *logtimestamp = NULL;
    char *ClientIP;
    struct in_addr zero_addr;
    
    zero_addr.s_addr = (in_addr_t)0;
 
    log_time_r(tm, &logtimestamp);

    if(aip != NULL)
      ClientIP = inet_ntoa((aip->cliaddr)->sin_addr);
    else
      ClientIP = inet_ntoa(zero_addr);
 
    fprintf(acclog_fp,
	    "%s [%s]: Ends Session %s\n",
	    logtimestamp,
	    (ClientIP != NULL) ? ClientIP : "0.0.0.0",
	    rip->seskey);
	
    fflush(acclog_fp);
    FREE_MAYBE(ClientIP);
    FREE_MAYBE(logtimestamp);
  }
    
  Spthread_mutex_unlock(&acclog_lock);
}

