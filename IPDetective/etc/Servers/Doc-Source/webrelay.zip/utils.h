/************************************************************************
WEBRELAY Software -- a multithreaded HTTP relay server
Copyright (C) 1999 Peter Zhang

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

Please address all correspondence concerning the software to 
zhangc@ucalgary.ca
************************************************************************/

#ifndef UTILS_H
#define UTILS_H

#include "mywrap.h"
#include "fnmatch.h"
#include "error.h"

char *find_first_token PARAMS ((const char *buf, const char *token));

void daemon_init PARAMS ((const char *pname, int facility));
int uidgid_get PARAMS ((const char *user, const char *group, uid_t *uid, 
	       gid_t *gid)); 
int setup_uidgid PARAMS ((char *server_user, uid_t server_uid, gid_t server_gid));

void stderr_open PARAMS ((const char *path));

void print_aip PARAMS ((accept_info *rip));
void deep_free_aip PARAMS ((accept_info *));

void print_rip PARAMS ((relay_info *rip));
void deep_free_rip PARAMS ((relay_info *));

char *strdupdelim PARAMS ((const char *, const char *));
void path_simplify PARAMS ((char *));

char *base64_decode PARAMS ((const char *b64data));
int http_time_r PARAMS ((const time_t *btp, char **buf));
int datetime PARAMS ((const time_t btp, char **timestamp));
int log_time_r PARAMS ((const time_t btp, char **logtimestamp));
int snprintf(char *, size_t, const char *, ...);

#endif /* UTILS_H */
