/************************************************************************
WEBRELAY Software -- a multithreaded HTTP relay server
Copyright (C) 1999 Peter Zhang

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

Please address all correspondence concerning the software to 
zhangc@ucalgary.ca
************************************************************************/
		       
#ifndef GETRS_H
#define GETRS_H

#include "mywrap.h"
#include "utils.h"
#include "url.h"
#include "headers.h"
#include "sess_manager.h"
#include "auth.h"


int rs_get_header PARAMS ((int fd, char **hdr));
int parse_statusline PARAMS ((char *line, char **http_ver, unsigned *status_code, 
		     char **reason_phrase));
int http_process_type PARAMS ((const char *hdr, void *arg));
int rs_get_body PARAMS ((int fd, char **buf, long *contlen));
int do_redirect PARAMS ((accept_info *aip, relay_info *rip));
int get_res_headers PARAMS ((accept_info *aip,
			     relay_info *rip, char **conttype,
			     long *old_contlen, char **headers));
/* return code: 1 OK, 0 EOF, -1 ERROR */
int mod_rs PARAMS ((accept_info *aip, relay_info *rip,
		    char **response, int *rs_size));
void redir_load_err PARAMS ((relay_info *rip));

#endif
