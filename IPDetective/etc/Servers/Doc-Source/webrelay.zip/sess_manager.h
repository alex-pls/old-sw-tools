/************************************************************************
WEBRELAY Software -- a multithreaded HTTP relay server
Copyright (C) 1999 Peter Zhang

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

Please address all correspondence concerning the software to 
zhangc@ucalgary.ca
************************************************************************/

#ifndef SESS_MANAGER_H
#define SESS_MANAGER_H

#include "chainhash.h"
#include "auth.h"

#define DEFAULT_SESS_MANAGER_REFRESH 900
#define DEFAULT_SESS_MANAGER_TTL 9000		 
#define MAX_NUM_COOKIE 20
		 
/* This is for data field of chain_node_t, which has a mutex lock */
typedef struct sess_info_s
{
    char *username;
    char *password;
    char *db_key;
    ulong ClientIPAddr;
    char *ClientHostname;
    /* 20 cookies per server or domain.
       There should be no limits on the size of a cookie, while NS
       sets a limit of 4 KB per cookie. */
    char *cookie_name[MAX_NUM_COOKIE];
    char *cookie_value[MAX_NUM_COOKIE];
    char *cookie_path[MAX_NUM_COOKIE];
    char *cookie_domain[MAX_NUM_COOKIE];
    int auth_flag;
} sess_info_t;

void sess_manager_init PARAMS ((void));

sess_info_t *sess_info_init PARAMS ((char *username, char *password,
				 char *db_key, ulong ClientIPAddr,
				 char *ClientHostname, int auth_flag));

/* Should have filled in data for sip already before calling
this routine */
chain_node_t *sess_manager_insert PARAMS ((char *seskey,
				   unsigned int keylen,
				   sess_info_t *data, unsigned int flags));

int sess_manager_update_timer PARAMS ((char *seskey, unsigned int keylen,
				   accept_info *aip));

int sess_manager_update_cookie PARAMS ((char *seskey, unsigned int keylen, 
				    accept_info *aip, relay_info *rip));

int sess_manager_retrieve_cookie PARAMS ((char *seskey, unsigned int keylen,
				      accept_info *aip, relay_info *rip));

/* We will check client's IP addr, DB_KEY and maybe ClientHostname in
the subsequent requests */ 
chain_node_t *sess_manager_find PARAMS ((char *seskey, unsigned int keylen));

void sess_info_free PARAMS ((void *data));

int sess_manager_foreach PARAMS ((int (*foreach_func)(chain_node_t
			      *cnp, void *misc), void *misc));

int sess_manager_delete PARAMS ((chain_node_t *cnp));

#endif



