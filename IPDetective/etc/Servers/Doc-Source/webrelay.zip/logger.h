/************************************************************************
WEBRELAY Software -- a multithreaded HTTP relay server
Copyright (C) 1999 Peter Zhang

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

Please address all correspondence concerning the software to 
zhangc@ucalgary.ca
************************************************************************/

#ifndef LOGGER_H
#define LOGGER_H

#include "mywrap.h"
#include "sess_manager.h"

extern void log_init PARAMS ((char *accpath, char *errpath, char *cnt_path));

extern void log_reopen PARAMS ((void));
extern void log_close PARAMS ((void));

extern void log_pass PARAMS ((time_t tm, accept_info *aip, relay_info *rip));
extern void log_conn PARAMS ((time_t tm, accept_info *aip, relay_info *rip));

extern void log_sesstart PARAMS ((time_t tm, accept_info *aip, relay_info *rip));

extern void log_sesend PARAMS ((time_t tm, accept_info *aip, relay_info *rip));

extern void log_err PARAMS ((time_t tm, accept_info *aip, relay_info *rip, char *msg));

extern void log_redir_err PARAMS ((time_t tm, accept_info *aip, relay_info *rip, char *msg));

#endif



