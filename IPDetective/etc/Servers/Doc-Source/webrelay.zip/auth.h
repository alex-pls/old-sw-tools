/************************************************************************
WEBRELAY Software -- a multithreaded HTTP relay server
Copyright (C) 1999 Peter Zhang

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

Please address all correspondence concerning the software to 
zhangc@ucalgary.ca
************************************************************************/

#ifndef AUTH_H
#define AUTH_H

#include "mywrap.h"  
#include "chainhash.h"
#include "sess_manager.h"

#define FORM_TTL		300

#define BASIC_CRED_OK		0
#define FORM_CRED_OK		0
#define FORM_CRED_TIMEOUT	1

#define SES_OK			0
#define SES_CLIENT_ENDS		1
#define SES_TIMEOUT	 	2
#define SES_FAIL		3

#define AUTH_OK			0
#define AUTH_FAIL		1

#define ACL_REJECT		0
#define ACL_ALLOW		1
#define ACL_AUTHENTIFICATE	2

typedef struct auth_info_s
{
    char *data;		/* Raw, undecoded, basic authentication data */
    char *username;
    char *password;
    char *db_key;
} auth_info_t;

typedef struct cookie_info_s
{
    char *ExpireDate;
    char *db_key;
    char *path;
    ulong ClientIPAddr;
    char *ClientHostname;
    time_t LastUpdated;
} cookie_info_t;

extern int send_redirect PARAMS ((accept_info *aip, relay_info *rip));

extern int redir_to_autherrhtml PARAMS ((accept_info *aip, relay_info *rip));

extern int send_form_ttl PARAMS ((accept_info *aip, relay_info *rip));

extern int send_challenge PARAMS ((const char *type, accept_info *aip, relay_info *rip));

/* not used any more, redirected to a general html */
extern int send_auth_error PARAMS ((accept_info *aip, relay_info *rip, char *msg));

extern int send_sesend_error PARAMS ((accept_info *aip, relay_info *rip));

extern int send_sesctl_error PARAMS ((accept_info *aip, relay_info *rip));

extern int basic_get_credential PARAMS ((relay_info *rip, auth_info_t *auip));

extern int form_get_credential PARAMS ((char *body, long contlen, accept_info *aip, relay_info *rip, auth_info_t *auip));

static int qstr2nv PARAMS ((char *qstr, char **name, char**value));

extern int basic_check_sess PARAMS ((char *seskey, auth_info_t *auip,
		     accept_info *aip, relay_info *rip));

extern int custom_check_sess PARAMS ((char *seskey, auth_info_t *auip,
		     accept_info *aip, relay_info *rip));

extern int insert_cookie_sess PARAMS ((char *seskey, 
		     accept_info *aip, relay_info *rip));

extern int retrieve_cookie_sess PARAMS ((char *seskey, 
		     accept_info *aip, relay_info *rip));

extern int update_timer_sess PARAMS ((char *seskey, 
		     accept_info *aip, relay_info *rip));

extern int make_seskey PARAMS ((char **seskey, accept_info *aip));

extern int sess_start PARAMS ((accept_info *aip, relay_info *rip,
			      auth_info_t *auip));

extern void auth_free PARAMS ((accept_info *aip, auth_info_t *auip));

extern char *parse_cookie PARAMS ((char *cookie, char **cookie_path, char **cookie_domain));

extern int libuser_test PARAMS ((char *username, char *password,
				 accept_info *aip, relay_info *rip));

#endif

