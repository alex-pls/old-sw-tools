/************************************************************************
WEBRELAY Software -- a multithreaded HTTP relay server
Copyright (C) 1999 Peter Zhang

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

Please address all correspondence concerning the software to 
zhangc@ucalgary.ca
************************************************************************/

/* This is based on Richard Stevens's Unix Network Programming */
#include "error.h"

extern int	daemon_proc;		/* set nonzero by daemon_init() */

static void	err_doit(int, int, const char *, va_list);

/* Nonfatal error related to a system call.
 * Print a message and return. */

void
err_ret(const char *fmt, ...)
{
  va_list ap;

  va_start(ap, fmt);
  err_doit(1, LOG_DEBUG, fmt, ap);
  va_end(ap);
  return;
}

/* Fatal error related to a system call.
 * Print a message and exit from that thread. */

void
err_sys_thr(const char *fmt, ...)
{
  va_list ap;

  va_start(ap, fmt);
  err_doit(1, LOG_DEBUG, fmt, ap);
  va_end(ap);
  pthread_exit(NULL);
}

/* Fatal error related to a system call.
 * Print a message and exit.*/

void
err_sys(const char *fmt, ...)
{
  va_list ap;

  va_start(ap, fmt);
  err_doit(1, LOG_DEBUG, fmt, ap);
  va_end(ap);
  exit(1);
}

/* Fatal error related to a system call.
 * Print a message, dump core, and terminate. */

void
err_dump(const char *fmt, ...)
{
  va_list ap;

  va_start(ap, fmt);
  err_doit(1, LOG_DEBUG, fmt, ap);
  va_end(ap);
  abort();		/* dump core and terminate */
  exit(1);		/* shouldn't get here */
}

/* Nonfatal error unrelated to a system call.
 * Print a message and return. */

void
err_msg(const char *fmt, ...)
{
  va_list ap;

  va_start(ap, fmt);
  err_doit(0, LOG_DEBUG, fmt, ap);
  va_end(ap);
  return;
}

/* Fatal error unrelated to a system call.
 * Print a message and terminate. */

void
err_quit(const char *fmt, ...)
{
  va_list ap;

  va_start(ap, fmt);
  err_doit(0, LOG_DEBUG, fmt, ap);
  va_end(ap);
  exit(1);
}

/* Print a message and return to caller.
 * Caller specifies "errnoflag" and "level". */

static void
err_doit(int errnoflag, int level, const char *fmt, va_list ap)
{
  int	errno_save, n, status;
  char	buf[MAXLINE];
  char  strerrbuf[MAXNAME];
  /*time_t ct;*/

  errno_save = errno;		/* value caller might want printed */
#ifdef	HAVE_VSNPRINTF
  vsnprintf(buf, sizeof(buf), fmt, ap);	/* this is safe */
#else
  vsprintf(buf, fmt, ap);	/* this is not safe */
#endif
  n = strlen(buf);
  if (errnoflag) {
    /* We must use thread-safe version of strerror_r */
    status = strerror_r(errno_save, strerrbuf, sizeof(strerrbuf));
    if(status == 0)
      /* sprintf is not really safe */
      snprintf(buf+n, sizeof(buf)-n, ": %s", strerror(errno_save));
    /*sprintf(buf+n, ": %s", strerrbuf);*/
  }
  strcat(buf, "\n");

  if (daemon_proc) {
    struct syslog_data syslogdata;
    syslog_r(level, &syslogdata, buf);
  } else {
    fflush(stdout);
    fputs(buf, stderr);
    fflush(stderr);
  }

  /*  time(&ct);
  log_err(ct, NULL, NULL, buf); */

  return;
}


