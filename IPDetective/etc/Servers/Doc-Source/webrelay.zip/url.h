/************************************************************************
WEBRELAY Software -- a multithreaded HTTP relay server
Copyright (C) 1999 Peter Zhang

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

Please address all correspondence concerning the software to 
zhangc@ucalgary.ca
************************************************************************/

#ifndef URL_H
#define URL_H

#include "mywrap.h"
#include "utils.h"
#include "html.h"
#include "error.h"
#include "logger.h"
#include "headers.h"

/* Structure containing info on a URL.  */
struct urlinfo
{
  char *url;			/* Unchanged URL */
  char *scheme;                 /* Scheme such as http */
  uerr_t proto;			/* URL protocol */
  char *host;			/* Extracted hostname */
  unsigned short port;
  char ftp_type;
  char *path, *dir, *file;	/* Path, as well as dir and file
				   (properly decoded) */
  char *user, *passwd;		/* Username and password */
  struct urlinfo *proxy;	/* The exact string to pass to proxy
				   server */
  char *referer;		/* The source from which the request
				   URI was obtained */
  char *local;			/* The local filename of the URL
				   document */
};

enum uflags
{
  URELATIVE     = 0x0001,      /* Is URL relative? */
  UNOPROTO      = 0x0002,      /* Is URL without a protocol? */
  UABS2REL      = 0x0004,      /* Convert absolute to relative? */
  UREL2ABS      = 0x0008       /* Convert relative to absolute? */
};

/* A structure that defines the whereabouts of a URL, i.e. its
   position in an HTML document, etc.  */
typedef struct _urlpos
{
  char *url;            /* Converted URL */
  char *local_name;     /* Local file to which it was saved, not used */
  int pos;		/* Position measured from beginning of the buffer */
  int old_size;		/* Size of the original URL string */
  int new_size;		/* Size of the converted URL string */
  struct _urlpos *next; /* Next struct in list */
} urlpos;

typedef struct
{
  char *formname;
  char *selectname;
} form_select_t;

/* Function declarations */

urlpos *mod_urls_html PARAMS ((const char *buf, accept_info *aip, relay_info *rip));
int get_lendiff PARAMS ((urlpos *));
char *cnvt_links PARAMS ((char *, urlpos *, long));
int insert_base PARAMS ((const char *buf, accept_info *aip, relay_info *rip, char **new_buf));
static int is_first_term PARAMS ((const char*, const char *));
void get_new_location PARAMS ((char *buf, int bufsize, accept_info *aip,
			       relay_info *rip, char **new_location, 
			       int *new_size));
void get_new_url PARAMS ((char *buf, int bufsize, accept_info *aip,
			  relay_info *rip, char **new_location, 
			  int *new_size));
urlpos *mod_js_loc PARAMS ((const char *buf, int bufsize, accept_info *aip, relay_info *rip, form_select_t *[], int*));
urlpos *mod_urls_js PARAMS ((const char *buf, int bufsize, accept_info *aip, relay_info *rip));
urlpos *mod_urls_opt PARAMS ((const char *buf, int bufsize, accept_info *aip, relay_info *rip, form_select_t *[], int));
urlpos *mod_js_event PARAMS ((const char *buf, accept_info *aip, relay_info *rip));
int chop_meta_http PARAMS ((const char *buf, const char *token, char **new_buf));
		     
int skip_url PARAMS ((const char *));
int contains_unsafe PARAMS ((const char *));
void decode_string PARAMS ((char *));
char *encode_string PARAMS ((const char *));

uerr_t urlproto PARAMS ((const char *));
int skip_proto PARAMS ((const char *));
static int has_proto PARAMS ((const char *));
static int get_scheme PARAMS ((const char *, char **));
int skip_uname PARAMS ((const char *));
struct urlinfo *newurl PARAMS ((void));
void freeurl PARAMS ((struct urlinfo *, int));
uerr_t parseurl PARAMS ((const char *, struct urlinfo *, int));
char *path_process PARAMS ((const char *path, char **dir, char **file));
void parse_dir PARAMS ((const char *, char **, char **));
static uerr_t parse_uname PARAMS ((const char *, char **, char **));
static char process_ftp_type PARAMS ((char *));
static char *add_prefix PARAMS ((const char *, int, const char *, int));
void convert_links PARAMS ((const char *, urlpos *));
void free_urlpos PARAMS ((urlpos *));
void print_urlpos PARAMS ((urlpos *));

#endif /* URL_H */
