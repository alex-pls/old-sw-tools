/************************************************************************
WEBRELAY Software -- a multithreaded HTTP relay server
Copyright (C) 1999 Peter Zhang

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

Please address all correspondence concerning the software to 
zhangc@ucalgary.ca
************************************************************************/

#include "html.h"

extern int debug;

#ifndef errno
extern int errno;
#endif

/* Match a string against a null-terminated list of identifiers.  */
static int
idmatch (tag_t *tags, const char *tag, const char *attr)
{
  int i;

  if (tag == NULL || attr == NULL)
    return 0;

  for (i = 0; tags[i].tag != NULL; i++)
    if (!strcasecmp (tags[i].tag, tag) && !strcasecmp (tags[i].attr, attr))
      return 1;
  return 0;
}

/* Parse BUF searching for HTML tags describing URLs to follow.  
   When a tag is encountered, extract its components, and return the
   address and the length of the string.  Return NULL if no URL is
   found.  */
const char *
find_url (const char *buf, int bufsize, int *size, state_t *s)
{
  const char *p, *ph;
  const char *q;
  const char *work;

  /* NULL-terminated list of tags and name of attributes */
  static tag_t html_allow[] = {
    { "a", "href" },
    { "img", "src" },
    { "img", "href" },
    { "body", "background" },
    { "frame", "src" },
    { "iframe", "src" },
    { "fig", "src" },
    { "overlay", "src" },
    { "applet", "code" },
    { "script", "src" },
    { "embed", "src" },
    { "bgsound", "src" },
    { "area", "href" },
    { "img", "lowsrc" },
    { "input", "src" },
    { "form", "action" },
    { "link", "href" },
    /* Strange enough, MS-IIS/4.0 accepts <LINK SRC=...>, instead of
     <LINK HREF=...> */
    { "link", "src" },
    { "table", "background" },
    /* Tags below this line are treated specially.  */
    { "script", "language" },
    { "base", "href" },
    { "meta", "content" },
    { NULL, NULL }
  };

  /* Reset s->is_js_arg to 0 */
  s->is_js_arg = 0;
  /* Reset s->base to NULL */
  FREE_MAYBE(s->base);
  /* Reset s->func_name to NULL */
  FREE_MAYBE(s->func_name);
  /* s->has_js should be initialized to 0 in mod_urls_html only once. */

  while (1) {
    if (bufsize <= 0)
      break;
    /* Let's look for a tag, if we are not already in one.  */
    FREE_MAYBE(s->base);
    if (!s->at_value) {
      /* Find '<'.  */
      if (*buf != '<')
	for (; bufsize && *buf != '<' && *buf != '\0'; ++buf, --bufsize);
      if (bufsize <= 0 || *buf == '\0')
	break;
      /* Skip spaces.  */
      for (++buf, --bufsize; bufsize && ISSPACE (*buf) && 
	     *buf != '>' && *buf != '\0'; ++buf, --bufsize);
      if (bufsize <= 0 || *buf == '\0')
	break;
      p = buf;
      /* Find the tag end.  */
      for (; bufsize && !ISSPACE (*buf) && *buf != '>' && 
	     *buf != '=' && *buf != '\0'; ++buf, --bufsize);
      if (bufsize <= 0 || *buf == '\0')
	break;
      if (*buf == '=') {
	/* <tag=something> is illegal.  Just skip it.  */
	++buf, --bufsize;
	continue;
      }
      if (p == buf) {
	/* *buf == '>'.  */
	++buf, --bufsize;
	continue;
      }

      FREE_MAYBE(s->tag);
      s->tag = strdupdelim (p, buf);

      if (*buf == '>') {
	FREE_MAYBE (s->tag);
	s->tag = NULL;
	++buf, --bufsize;
	continue;
      }
    } else {                     /* s->at_value */
      /* Reset AT_VALUE.  */
      s->at_value = 0;
      /* If in quotes, just skip out of them and continue living.  */
      if (s->in_quote) {
	s->in_quote = 0;
	for (; bufsize && *buf != s->quote_char && *buf != '\0'; 
	     ++buf, --bufsize);
	if (bufsize <= 0 || *buf == '\0' )
	  break;
	++buf, --bufsize;
      }
      if (bufsize <= 0 || *buf == '\0' )
	break;
      if (*buf == '>') {
	FREE_MAYBE (s->tag);
	FREE_MAYBE (s->attr);
	s->tag = s->attr = NULL;
	continue;
      }
    }
    /* Find the attributes.  */
    do {
      FREE_MAYBE (s->attr);
      s->attr = NULL;
      if (bufsize <= 0 || *buf == '\0')
	break;
      /* Skip the spaces if we have them.  We don't have them at
	 places like <img alt="something"src="something-else">.
	 Note:                           ^ no spaces here */
      if (ISSPACE (*buf))
	for (++buf, --bufsize; bufsize && ISSPACE (*buf) && 
	       *buf != '>' && *buf != '\0'; ++buf, --bufsize);
      if (bufsize <= 0 || *buf == '>' || *buf == '\0')
	break;
      if (*buf == '=') {
	/* This is the case of <tag = something>, which is
	   illegal.  Just skip it.  */
	++buf, --bufsize;
	continue;
      }
      p = buf;
      /* Find the attribute end.  */
      for (; bufsize && !ISSPACE (*buf) && *buf != '>' && 
	     *buf != '=' && *buf != '\0'; ++buf, --bufsize);
      if (bufsize <= 0 || *buf == '>' || *buf == '\0')
	break;
      /* Construct the attribute.  */

      FREE_MAYBE(s->attr);
      s->attr = strdupdelim (p, buf);
      /* Now we must skip the spaces to find '='.  */
      if (*buf != '=') {
	for (; bufsize && ISSPACE (*buf) && *buf != '>' && *buf != '\0'; 
	     ++buf, --bufsize);
	if (bufsize <= 0 || *buf == '>' || *buf == '\0')
	  break;
      }
      /* If we still don't have '=', something is amiss.  */
      if (*buf != '=')
	continue;
      /* Find the beginning of attribute value by skipping the
	 spaces.  */
      ++buf, --bufsize;
      for (; bufsize && ISSPACE (*buf) && *buf != '>' &&
	     *buf != '\0'; ++buf, --bufsize);
      if (bufsize <= 0 || *buf == '>' || *buf == '\0')
	break;
      ph = NULL;
      /* The value of an attribute can, but does not have to be
	 quoted.  */
      if (*buf == '\"' || *buf == '\'') {
	s->in_quote = 1;
	s->quote_char = *buf;
	p = buf + 1;
	for (++buf, --bufsize; bufsize && *buf != s->quote_char && 
	       *buf != '\n' && *buf != '\0'; ++buf, --bufsize)
	  if (*buf == '#')
	    ph = buf;
	if (bufsize <= 0 || *buf == '\0') {
	  s->in_quote = 0;
	  break;
	}

      } else {
	p = buf;
	for (; bufsize && !ISSPACE (*buf) && *buf != '>' && 
	       *buf != '\0' && *buf != '\0'; ++buf, --bufsize)
	  if (*buf == '#')
	    ph = buf;
	if (bufsize <= 0 || *buf == '\0')
	  break;
      }
      /* If '#' was found unprotected in a URI, it is probably an
	 HTML marker, or color spec.  */
      *size = ((ph != NULL) ? ph : buf) - p;
      if (*size && idmatch (html_allow, s->tag, s->attr)) {
	if (!strncasecmp(s->tag, "base", 4) && !strncasecmp(s->attr, "href", 4)){
	  /* We want to change this base link too */
	  FREE_MAYBE (s->base);
	  s->base = strdupdelim (p, buf);
	  s->at_value = 1;
	  return p;
	} else if (!strncasecmp (s->tag, "meta", 4) && 
		   !strncasecmp (s->attr, "content", 7)) {
	  /* Some pages use a META tag to specify that the page
	     be refreshed by a new page after a given number of
	     seconds of n.  The general format for this is:                  
	     <META HTTP-EQUIV=Refresh CONTENT="n; URL=index2.html">,
	     where n is a number of second
	  */
	  for (; *size && ISDIGIT (*p); p++, *size -= 1);
	  if (*p == ';') {
	    for (p++, *size -= 1; *size && ISSPACE (*p); p++, *size -= 1);
	    if (!strncasecmp (p, "URL=", 4)) {
	      p += 4, *size -= 4;
	      s->at_value = 1;
	      return p;
	    }
	  } 
	} else if (!strncasecmp(s->tag, "script", 6) &&
		   (!strncasecmp(s->attr, "language", 8) ||
		    !strncasecmp(s->attr, "type", 4))) {
	  if (!strncasecmp (p, "javascript", 10) ||
	      !strncasecmp (p, "text/javascript", 15)) {
	    s->has_js = 1;
	    s->at_value = 1;
	    return p;
	  }
	} else if (s->has_js && !strncasecmp(p, "javascript:", 11)) {
	  int new_size = *size;
	  /* Get the function name first. */
	  work = p + 11;
	  for(--new_size, ++work; new_size && *work != '(' && *work != ')' &&
		*work != '>' && *work != '\0'; --new_size, ++work);
	  if(!new_size || *work == ')' || *work == '>' || *work == '\0') {
	    continue;
	  } else {
	    /* Now we walk back to find '.' or ':'. See, e.g.,
	       <a href=javascript:parent.frames[0].MkUniq("/...")> */
	    p = work;
	    for(--work; *work != '.' && *work != ':'; --work);
	    FREE_MAYBE(s->func_name);
	    s->func_name = strdupdelim(++work, p);
	  }
	  /* Look for starting single or double quote. Double
	   quotes are used when the outside double quotes are
	   omitted -- <a href=javascript:somefunc("/dir1/dir2/file")>
                              ^should have used double quote       ^*/
	  /* Limitations: We only deal with the first function arg */
	  for(--new_size, ++work; new_size && *work != '\'' && 
		*work != '\"' && *work != ')' && *work != '\0';
	      --new_size, ++work);
	  if(!new_size || *work == '\0' || *work == ')') {
	    continue;
	  } else if (((s->in_quote && *work == '\'') ||
		      (s->in_quote == 0 && 
		       (*work == '\'' || *work == '\"'))) &&
		      new_size) {
	    /* Look for ending quote */
	    q = work + 1;
	    for(--new_size, ++work; new_size && *work != '\'' && 
		  *work != '\"' && *work != ')' && *work != '\0';
		--new_size, ++work);
	    if(!new_size || *work == '\0' ||
	       *work == ')') {
	      continue;
	    } else if (((s->in_quote && *work == '\'') ||
			(s->in_quote == 0 && 
			 (*work == '\'' || *work == '\"'))) && 
			new_size) {
	      s->at_value = 1;
	      *size = work - q;
	      p = q;
	      s->is_js_arg = 1;
	      return p;
	    }
	  }
	} else {
	  s->at_value = 1;
	  return p;
	}
      }
      /* Exit from quote.  */
      if (*buf == s->quote_char) {
	s->in_quote = 0;
	++buf, --bufsize;
      }
    } while (*buf != '>');
    FREE_MAYBE (s->tag);
    FREE_MAYBE (s->attr);
    s->tag = s->attr = NULL;
    if (bufsize <= 0 || *buf == '\0')
      break;
  }

  FREE_MAYBE (s->tag);
  FREE_MAYBE (s->attr);
  FREE_MAYBE (s->base);
  FREE_MAYBE (s->func_name);

  return NULL;
}

const char *
find_event_handler (const char *buf, int bufsize, int *size, js_event_t *s)
{
  const char *p;

  /* NULL-terminated list of event_hadlers someone would want to
     follow */
  static char *event_allow[] = { 
    "onClick", "onDragDrop", "onFocus", "onKeyDown",
    "onKeyPress", "onKeyUp", "onMouseDown", "onMouseMove",
    "onMouseOut", "onMouseOver", "onMouseUp", "onMove",
    NULL
  };

  while (1) {
    if (bufsize <= 0)
      break;
    /* Let's look for a tag, if we are not already in one.  */
    if (!s->at_value) {
      /* Find '<'.  */
      if (*buf != '<')
	for (; bufsize && *buf != '<' && *buf != '\0'; ++buf, --bufsize);
      if (bufsize <= 0 || *buf == '\0')
	break;
      /* Skip spaces.  */
      for (++buf, --bufsize; bufsize && ISSPACE (*buf) && 
	     *buf != '>' && *buf != '\0'; ++buf, --bufsize);
      if (bufsize <= 0 || *buf == '\0')
	break;
      p = buf;
      /* Find the tag end.  */
      for (; bufsize && !ISSPACE (*buf) && *buf != '>' && 
	     *buf != '=' && *buf != '\0'; ++buf, --bufsize);
      if (bufsize <= 0 || *buf == '\0')
	break;
      if (*buf == '=') {
	/* <tag=something> is illegal.  Just skip it.  */
	++buf, --bufsize;
	continue;
      }
      if (p == buf) {
	/* *buf == '>'.  */
	++buf, --bufsize;
	continue;
      }

      FREE_MAYBE(s->tag);
      s->tag = strdupdelim (p, buf);
      if (*buf == '>') {
	FREE_MAYBE (s->tag);
	s->tag = NULL;
	++buf, --bufsize;
	continue;
      }
    } else {                     /* s->at_value */
      /* Reset AT_VALUE.  */
      s->at_value = 0;
      /* If in quotes, just skip out of them and continue living.  */
      if (s->in_quote) {
	s->in_quote = 0;
	for (; bufsize && *buf != s->quote_char && *buf != '\0'; 
	     ++buf, --bufsize);
	if (bufsize <= 0 || *buf == '\0')
	  break;
	++buf, --bufsize;
      }
      if (bufsize <= 0 || *buf == '\0')
	break;
      if (*buf == '>') {
	FREE_MAYBE (s->tag);
	FREE_MAYBE (s->event_handler);
	s->tag = s->event_handler = NULL;
	continue;
      }
    }
    /* Find the event_handler.  */
    do {
      FREE_MAYBE (s->event_handler);
      s->event_handler = NULL;
      if (bufsize <= 0)
	break;
      /* Skip the spaces if we have them.  We don't have them at
	 places like <img alt="something"src="something-else">.
	 NB:                             ^ no spaces here */
      if (ISSPACE (*buf))
	for (++buf, --bufsize; bufsize && ISSPACE (*buf) && 
	       *buf != '>' && *buf != '\0'; ++buf, --bufsize);
      if (bufsize <= 0 || *buf == '>' || *buf == '\0')
	break;
      if (*buf == '=') {
	/* This is the case of <tag = something>, which is
	   illegal.  Just skip it.  */
	++buf, --bufsize;
	continue;
      }
      p = buf;
      /* Find the event_handler end.  */
      for (; bufsize && !ISSPACE (*buf) && *buf != '>' && 
	     *buf != '=' && *buf != '\0'; ++buf, --bufsize);
      if (bufsize <= 0 || *buf == '>' || *buf == '\0')
	break;
      /* Construct the event_handler.  */

      FREE_MAYBE(s->event_handler);
      s->event_handler = strdupdelim (p, buf);
      /* Now we must skip the spaces to find '='.  */
      if (*buf != '=') {
	for (; bufsize && ISSPACE (*buf) && *buf != '>' &&
	       *buf != '\0'; ++buf, --bufsize);
	if (bufsize <= 0 || *buf == '>' || *buf == '\0')
	  break;
      }
      /* If we still don't have '=', something is amiss.  */
      if (*buf != '=')
	continue;
      /* Find the beginning of event_handler value by skipping the
	 spaces.  */
      ++buf, --bufsize;
      for (; bufsize && ISSPACE (*buf) && *buf != '>' &&
	     *buf != '\0'; ++buf, --bufsize);
      if (bufsize <= 0 || *buf == '>' || *buf == '\0')
	break;

      /* The value of an event_handler contains a bunch of JavaScript
	 statements. It has to be in double quotes */
      if (*buf == '\"') {
	s->in_quote = 1;
	s->quote_char = *buf;
	p = buf + 1;
	for (++buf, --bufsize; bufsize && *buf != s->quote_char && 
	       *buf != '\n' && *buf != '\0'; ++buf, --bufsize)
	if (bufsize <= 0 || *buf == '\0') {
	  s->in_quote = 0;
	  break;
	}
      } 

      *size = buf - p;
      /* The Event_handler's value is liable to be returned if:
	 1) *size != 0;
	 2) its event_handler is found in event_allow.  */
      if (*size) {
	char **q1;
	for (q1 = event_allow; *q1 != NULL; q1++)
	  if (!strncasecmp (*q1, s->event_handler, strlen (*q1)))
	    break;
	if (*q1 != NULL) {
	  s->at_value = 1;
	  /* Return the start position of the JavaScript statements
	     inside an event_handler */
	  return p;
	}
      }
      /* Exit from quote.  */
      if (*buf == s->quote_char) {
	s->in_quote = 0;
	++buf, --bufsize;
      }
    } while (*buf != '>');
    FREE_MAYBE (s->tag);
    FREE_MAYBE (s->event_handler);
    s->tag = s->event_handler = NULL;
    if (bufsize <= 0 || *buf == '\0')
      break;
  }

  FREE_MAYBE (s->tag);
  FREE_MAYBE (s->event_handler);

  return NULL;
}

