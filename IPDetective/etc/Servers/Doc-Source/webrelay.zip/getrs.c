/************************************************************************
WEBRELAY Software -- a multithreaded HTTP relay server
Copyright (C) 1999 Peter Zhang

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

Please address all correspondence concerning the software to 
zhangc@ucalgary.ca
************************************************************************/

#include "getrs.h"
#define MAXREDIR 10

extern int debug;

/* Get the response header line by line */
int
rs_get_header (int fd, char **hdr)
{
  ssize_t status;
  *hdr = (char *)Smalloc (MAXLINE + 1);

  /* newline is stored like fgets() */
  status = readline(fd, *hdr, MAXLINE);
  if(status == 0)
    return AR_EOF; /* connection closed by the client */
  else if (status < 0)
    return AR_ERROR;
  else if (status > 0) {
    if(debug > 1)
      fprintf(stderr, "ORIG RES HEADER LINE is: %s\n", *hdr);
    return AR_OK;
  }
  return AR_ERROR;
}

/* Parse the STATUS line to get HTTP-Version, Status-Code, and Reason_Phrase. */
int parse_statusline(char *buf, char **http_ver, unsigned *status_code, 
		     char **reason_phrase)
{
  int buflen;
  char *p;
  char *tmp = NULL;
  time_t ct;

  buflen = strlen (buf);

  for(p = buf; *buf != ' ' && *buf != '\0' && buflen > 0; --buflen, ++buf);
  if (*buf == ' ') {
    *http_ver = strdupdelim (p, buf);
  } else {
    time(&ct);
    log_err(ct, NULL, NULL, "Bad first response header line.");
    return -1;
  }

  buf += skip_lws(buf);
  for(p = buf; *buf != ' ' && *buf != '\0' && buflen > 0; --buflen, ++buf);
  if (*buf == ' ') {
    tmp = strdupdelim (p, buf);
    *status_code = atoi(tmp);
    FREE_MAYBE(tmp);
    buf += skip_lws(buf);
    *reason_phrase = xstrdup(buf);
  } else if (*buf == '\0' || buflen == 0) {
    /* Some web servers do not give a reason phrase */
    tmp = strdupdelim (p, buf);
    *status_code = atoi(tmp);
    FREE_MAYBE(tmp);
    *reason_phrase = NULL;
  }
  
  return 0;
}

/* Place the malloc-ed copy of HDR hdr, to the first ';' to ARG. 
 The hdr is Content-Type: media-type; attr=value, we need only the
 media-type part. */
int
http_process_type (const char *hdr, void *arg)
{
  char **result = (char **)arg;
  char *p;

  /*
   *result = xstrdup (hdr);
   */
  p = strrchr (hdr, ';');
  if (p != NULL) {
      int len = p - hdr;
      *result = (char *)Smalloc (len + 1);
      memcpy (*result, hdr, len);
      (*result)[len] = '\0';
  } else
    *result = xstrdup (hdr);
  return 1;
}

/* Read in the message body. Contlen can be either >0 or <=0. Buf is
   not null terminated. */
int
rs_get_body (int fd, char **buf, long *contlen)
{
  int nread, res;
  int bufsize, new_bufsize;

  res = 0;

  if (debug > 2)
    fprintf(stderr, "CONTLEN=%d\n", *contlen);
  /* Now at the beginning of the binary part */
  /* If Content-length: is present */
  if(*contlen > 0) {
    /* Read *contlen bytes from fd */
    *buf = (char *)Smalloc(*contlen + 1); 
    res = readn (fd, *buf, *contlen);
  } else if (*contlen < 0) {
    /* Content-length: not present in response headers. We read until
       reaching the EOF */
    bufsize = BUFFER_SIZE;
    *buf = (char *)Smalloc(bufsize);
    nread = 0;
    new_bufsize = bufsize;
    do {
      res = readn(fd, (*buf + nread), bufsize); 
      if(res < 0)
	break;
      nread += res;
      /* nread cannot be greater than bufsize */
      if (nread >= new_bufsize) {
	new_bufsize <<= 1;
	*buf = (char *)Srealloc(*buf, new_bufsize);
      }
    } while (res > 0);
    *contlen = nread;
  }
  if (res < 0) {
    return -1; /* Error condition */
  } else if (res == 0 && *contlen == 0) {
    return 0; /* No data in the body */
  }
  return 1;
}

void redir_load_err(relay_info *rip)
{
  int len;
  time_t ct;
  char mesg[MAXLINE];

  snprintf(mesg, MAXLINE, 
	   "HTTP/1.0 504 Gateway Timeout\r\nContent-Type: text/html\r\n\r\n");
  len = strlen(mesg);
  snprintf(mesg+len, MAXLINE-len, "<HTML><HEAD><TITLE>AR_RELAY Server Load Failure</TITLE>\r\n<BODY><H1>AR_RELAY Server Load Failure</H1><P>Remote Database Server %s Not Responding.<P></BODY></HTML>", rip->redir_targethost);
  len = strlen(mesg);

  if(writen(rip->sourcefd, mesg, len) != len) {
    time(&ct);
    log_redir_err(ct, NULL, rip, "Error writing to the remote server.");
  }
}

/* Get the response header and see if there is a Location header
   Headers will be completed only after the new_contlen is figured
   out later in the calling routine */
int get_res_headers(accept_info *aip, relay_info *rip, 
		    char **conttype, long *old_contlen, char **headers)
{
  long contlen = -1L;
  char *type = NULL;
  char *cookie = NULL;
  char *loc_url = NULL;

  int hcount;
  int lh;
  int all_length;

  int status; 

  time_t ct;

  /* Header-fetching loop.  */
  hcount = 0;
  all_length = 0;
  while(1) {
    int len;

    /* hdr holds first the original and then modified header line */
    char *hdr = NULL;

    hcount++;
    /* Get the header with \r\n in it. */
    status = rs_get_header (rip->targetfd, &hdr);

    if (status == AR_EOF) {
    /*if (status == AR_EOF && *hdr) {*/
      time(&ct);
      log_err(ct, aip, rip, "End of file while parsing response headers.");
      FREE_MAYBE (hdr);
      return status;
    } else if (status == AR_ERROR) {
      time(&ct);
      log_err (ct, aip, rip, "Read error in response headers.");
      FREE_MAYBE (hdr);
      return status;
    }

    if(debug > 1) {
      fprintf(stderr, "Orig Res Head=%s\n", hdr);
    }
      
    /* Encountered an empty line indicating the end of the header
       section. So let's break the loop. */ 
    if (*hdr == '\r' || *hdr == '\n' || 
	(*hdr == '\r' && *(hdr+1) == '\n')) {
      FREE_MAYBE (hdr);
      break;
    }

    len = strlen(hdr);
    if(hdr[len-1] == '\n')
      hdr[len-1] = '\0';
    if(hdr[len-2] == '\r')
      hdr[len-2] = '\0';

    if(hcount == 1) {
      char *http_ver = NULL;
      char *reason_phrase = NULL;

      /* Parse the first line to get status code */
      if ( parse_statusline(hdr, &http_ver, &rip->rs_status_code, 
			    &reason_phrase) < 0 ) {
        status = AR_ERROR;
        time(&ct);
        log_err(ct, aip, rip, "Bad first response header line.");
        FREE_MAYBE (hdr);
        FREE_MAYBE (http_ver);
        FREE_MAYBE (reason_phrase);
        return status;
      }
    }

    /* If rip->auth_flag == 0 there is no need to deal with cookies here */
    if (rip->auth_flag && !strncasecmp(hdr, "Set-Cookie:", 11)) {
      if (header_process (hdr, "Set-Cookie", &header_strdup, &cookie)) {
	/* We get this response back indicating the session has
	   already established. We can store this cookie into sip
	   of this session. */
	FREE_MAYBE(rip->cookie);
	/* Store raw cookie into rip */
	rip->cookie = xstrdup(cookie);
	/* Multiple cookies are going to be stored in session manager's hash */ 
	status = insert_cookie_sess(rip->seskey, aip, rip);
	/* Free raw cookie to be ready for retrieving cookies from session
	 control data */
	FREE_MAYBE(rip->cookie);
	if (status == SES_OK) {
	  FREE_MAYBE(hdr);
	  hcount--;
	  continue;
	} else if (status == SES_FAIL) {
	  FREE_MAYBE(hdr);
	  time(&ct);
	  log_err(ct, aip, rip, "Session Manager Insert Cookie Failed.");
	  send_sesctl_error(aip, rip);
	  return AR_ERROR;
	} else if (status == SES_CLIENT_ENDS) {
	  FREE_MAYBE(hdr);
	  time(&ct);
	  log_sesend(ct, aip, rip);
	  send_sesend_error(aip, rip);
	  return AR_SES_END;
	}
      }
    }

    /* If rip->auth_flag == 0, we don't need to deal with Location: header */
    if (rip->auth_flag && loc_url == NULL) {
      if (header_process (hdr, "Location", &header_strdup, &loc_url)) {
	struct urlinfo *u;
	char *loc_path = NULL;
	char *loc_db_key = NULL;
	char *loc_seskey = NULL;
	char *raw_path = NULL;
	u = newurl();

	if ( parseurl(loc_url, u, 0) != URLOK ) {
	  /* Bad URL in this database entry, forget it */
	  freeurl (u, 1); 
	  time(&ct);
	  log_err (ct, aip, rip, "Error in getting the redirection url.");
	  status = AR_ERROR;
	  FREE_MAYBE(loc_url);
	  FREE_MAYBE(hdr);
	  return(status);
	}

	/* Set the redirect flag in rip */
	rip->autoredir_now = 1;

	FREE_MAYBE(rip->redir_targethost);
	if(u->host != NULL)
	  rip->redir_targethost = encode_string(u->host);
	else
	  rip->redir_targethost = xstrdup(rip->targethost);
	if(u->port)
	  rip->redir_targetport = u->port;
	else
	  rip->redir_targetport = rip->targetport;

	if(debug > 3)
	  fprintf(stderr, "u->host=%s, u->path=%s\n", u->host, u->path);

	if(u->host != NULL || 
	   ((u->host == NULL) && (*(u->path) == '/')))
	  /* This URL has an absolute PATH. And u->path is not decoded */
	  raw_path = xstrdup(u->path);	
	else if(u->host == NULL && (*(u->path) == '.' || *(u->path) != '/')){
	  len = strlen(rip->targetdir) + 1 + strlen(u->path);
	  raw_path = Smalloc(len + 1);
	  snprintf(raw_path, len+1,
		   "%s/%s", rip->targetdir, u->path);
	}

	FREE_MAYBE(rip->redir_targetpath);
	FREE_MAYBE(rip->redir_targetdir);
	FREE_MAYBE(rip->redir_targetfile);
	rip->redir_targetpath = path_process(raw_path, &rip->redir_targetdir,
					     &rip->redir_targetfile);

	FREE_MAYBE(raw_path);
	FREE_MAYBE(loc_path);
	FREE_MAYBE(loc_db_key);
	FREE_MAYBE(loc_seskey);
	freeurl(u, 1);
	goto done_header;
      }
    }

    if (!strncasecmp(hdr, "Content-Length:", 15)) {
      /* Try getting Content-Length */
      if (contlen < 0L) {
	if (header_process (hdr, "Content-Length", &header_extract_number, 
			    &contlen) == 0)
	  { /* return 0  means no such header line. */
	    contlen = -1L;
	    *old_contlen = contlen;
	  } else {
	    /* returning the old_contlen to the calling routine */
	    *old_contlen = contlen;
	  }
      }
      FREE_MAYBE(hdr);
      hcount--;
      continue;
    }

    /* Try getting content-type.  */
    if (type == NULL)
      if (header_process (hdr, "Content-Type", &http_process_type,
			  &type)) 
	{
	  *conttype = xstrdup(type);
	  goto done_header;
	}
    
  done_header:
    /* We want to change Content-Length: header line only after we get
       all links converted in the entity-body. For now we simply save
       headers in memory */

    /* Add back the \r\n */
    lh = strlen(hdr);
    hdr = (char *)Srealloc(hdr, lh + 3); 
    hdr[lh++] = '\r';
    hdr[lh++] = '\n';
    hdr[lh] = '\0';

    lh = strlen(hdr);

    if(*headers == NULL && all_length == 0)
      *headers = (char *)Smalloc (all_length + lh);
    else
      *headers = (char *)Srealloc (*headers, all_length + lh);
    memcpy (*headers + all_length, hdr, lh);
    all_length += lh;

    FREE_MAYBE(hdr);
  }

  /* An empty line will be added after the new_contlen is figured out
     in the calling routine */ 
  *headers = (char *)Srealloc (*headers, all_length + 1);
  (*headers)[all_length] = '\0';

  if (debug > 2)
    fprintf(stderr, "ALL RES Headers=%s\n", *headers);

  FREE_MAYBE(loc_url);
  FREE_MAYBE(type);
  FREE_MAYBE(cookie);

  return AR_OK;
}


/* AUTOMATIC REDIRECTION */
int do_redirect(accept_info *aip, relay_info *rip)
{
  time_t ct;
  int rq_size, res, status, len;
  char str[MAXNAME];
  char request[3*MAXLINE];
  char first_line[MAXLINE], host_line[MAXNAME];
  char agent_line[MAXNAME], accept_line[MAXNAME], cookie_line[MAXLINE];

  if(rip->targetfd >=0) {
    Sclose(rip->targetfd);
    rip->targetfd = -1;
  }

  /* Open new connection to the redir_targethost on redir_targetport */

  res = 0;

  rip->targetfd = ClientConnect(&res, rip->redir_targethost, 
				rip->redir_targetport);

  if(res < 0) {
    /* If the remote server refuses connection, we quit this thread */
    redir_load_err(rip);
    time(&ct);
    log_redir_err(ct, aip, rip, "The server redirected to by the database vendor refuses connection.");
    if(rip->targetfd >= 0) {
      shutdown(rip->targetfd, SHUT_WR);
      Sclose (rip->targetfd);
      rip->targetfd = -1;
    }
    if(rip)
      deep_free_rip(rip);	
    return AR_ERROR;
  }    

  snprintf(str, MAXNAME, ":%d", rip->redir_targetport);
  snprintf(first_line, MAXLINE, 
	   "GET %s HTTP/1.0\r\n", rip->redir_targetpath);

  if(debug > 3)
    fprintf(stderr, "First_line: %s\n", first_line);

  snprintf(agent_line, MAXNAME, 
	   "User-Agent: Mozilla/4.03 [en] (Win95; I)\r\n");

  if(debug > 3)
    fprintf(stderr, "Agent_line: %s\n", agent_line);

  if(rip->redir_targetport == 80)
    snprintf(host_line, MAXNAME, 
	     "Host: %s\r\n", rip->redir_targethost);
  else
    snprintf(host_line, MAXNAME, 
	     "Host: %s%s\r\n", rip->redir_targethost, str);

  if(debug > 3)
    fprintf(stderr, "Host_line: %s\n", host_line);

  snprintf(accept_line, MAXNAME,
	   "Accept: image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, */*\r\n");

  if(debug > 3)
    fprintf(stderr, "Accept_line: %s\n", accept_line);

  snprintf(request, 3*MAXLINE, "%s%s%s%s", first_line, agent_line,
	    host_line, accept_line);

  if(debug > 3)
    fprintf(stderr, "redir request: %s\n", request);

  /* Add the Cookie: line from the session control data if there is
     one. This cookie is associated with the remote database server
     that issued Set-Cookie: header in its response */
  if (rip->seskey != NULL) {
    status = retrieve_cookie_sess(rip->seskey, aip, rip);

    if(debug > 1) {
      fprintf(stderr, "retr cookie status=%d\n", status);
      fprintf(stderr, "retr cookie=%s\n", rip->cookie);
    }

    if(status == SES_OK && rip->cookie != NULL) {
      snprintf(cookie_line, MAXLINE, "Cookie: %s\r\n", rip->cookie);
      len = strlen(request);
      snprintf(request+len, 3*MAXLINE-len, "%s\r\n", cookie_line);
    } else if (status == SES_OK && rip->cookie == NULL) {
      len = strlen(request);
      snprintf(request+len, 3*MAXLINE-len, "\r\n");
    } else if (status == SES_FAIL) {
      time(&ct);
      log_err(ct, aip, rip, "Session Cookie Retrieval Failed.");
      send_sesctl_error(aip, rip);
      return AR_ERROR;
    } else if (status == SES_CLIENT_ENDS) {
      time(&ct);
      log_sesend(ct, aip, rip);
      send_sesend_error(aip, rip);
      return AR_SES_END;
    }
  } else {
    len = strlen(request);
    snprintf(request+len, 3*MAXLINE-len, "\r\n");
  }

  rq_size = strlen(request);

  if(debug > 1)
    fprintf(stderr, "Redirect REQ header is: %s\n", request);

  /* Pass the new REDIRECT request to the remote server. */

  if(writen(rip->targetfd, request, rq_size) != rq_size) {
    time(&ct);
    log_redir_err(ct, aip, rip, "Error writing to the remote server.");

    if(rip->sourcefd >=0) {
      Sclose (rip->sourcefd);
      rip->sourcefd = -1;
    }
    if(rip->targetfd >= 0) {
      Sclose (rip->targetfd);
      rip->targetfd = -1;
    }
    if(rip)
      deep_free_rip(rip);	
    return AR_ERROR;
  }

  return AR_REDIR_WAIT;
}

/* Modify responses including response header and entity
   body. */ 

int mod_rs(accept_info *aip, relay_info *rip, char **response, int *rs_size)
{
  char *buf; 	/* Buffer to hold header first and then the msg body */

  long new_contlen = -1L; /* New Content-Length specified in the response
			header. */
  long old_contlen = -1L; /* Old Content-Length specified in the response
			header. */
  int i, len;
  char *all_headers = NULL;
  int lh, all_length;
  urlpos *lst;
  char *new_buf = NULL;
  char *contlen_line;
  long new_len = 0; 	/* Length of the modified buffer */
  int	diff;		/* new_len - old_len */

  form_select_t *fselect[MAXNAME];
  int fs_size = 0;

  int counts = 0;  	/* counter preventing infinite loop of redirections*/
  char *type = NULL;

  int n, status; 
  char str[MAXNAME];
  char *p;

  time_t ct;

  for (i = 0; i < MAXNAME; ++i)
    fselect[i] = NULL;

Header:
  /* Get the response headers first */
  status = get_res_headers(aip, rip, &type, 
			   &old_contlen, &all_headers);

  if(debug > 2)
    fprintf(stderr, "ALL_HEADERS=%s\n", all_headers);

  if (status == AR_ERROR) {
    FREE_MAYBE(type);
    FREE_MAYBE(all_headers);
    time(&ct);
    log_err(ct, aip, rip, "Error getting the response header.");
    return status;
  } else if ( status == AR_EOF && all_headers == NULL) {
    FREE_MAYBE(type);
    FREE_MAYBE(all_headers);
    time(&ct);
    log_err(ct, aip, rip, "Our remote server quits.");
    return status;
  }

  /* If Content-Type is NULL, we set it to default of text/html */
  if(type == NULL)
    /* The Grove Art Dictionary site (http://www.groveart.com/) emits
       a response header for the request of /scripts/rwisapi.dll/.....
       which shows no Content-Type: header line at all. This is a 
       Microsoft-IIS/4.0 web server. */
    type = xstrdup("text/html");

  /* There is a Content-Length line but the value is zero, so it is
     truly zero length of body. Or there is no Content-Length line
     and type is none. */
  /* Status code 204 (No Content), 205 (Reset Content) and 304 
     (Not Modified) will have no message-body */
  if (old_contlen == 0L || (old_contlen == -1L && type == NULL) ||
      rip->rs_status_code == 204 || rip->rs_status_code == 205 ||
      rip->rs_status_code == 304) {
    n = 0;
    if(rip->autoredir_now == 1)
      goto Redirect;
    else
      goto done;
  }

  /* The HTTP protocol says that a server may not give a Content-Length:
     Line in the header (Indicated by old_contlen == -1L. Then the end
     of body is determined by EOF */ 

  buf = NULL;

  /* If old_contlen was not given (old_contlen == -1), it will be
     updated */ 

  if(debug > 3)
    fprintf(stderr, "oldcontlen is %d\n", old_contlen);
  n = rs_get_body(rip->targetfd, &buf, &old_contlen);
  if(debug > 3)
    fprintf(stderr, "oldcontlen after getting body is %d\n", old_contlen);

  if( n == -1 ) {
    FREE_MAYBE(buf);
    FREE_MAYBE(type);
    FREE_MAYBE(all_headers);
    time(&ct);
    log_err(ct, aip, rip, "Error getting the response entity body.");
    status = AR_ERROR;
    return status;
    /* zero is still a valid Content-Length */
  } else {
    /* All old_contlen bytes are read in. */
    status = AR_OK;
  }

  /* It is right time now to see if we need redirect */
 Redirect:
  if(rip->autoredir_now == 1) {
    /* Do the redirection now */
    if(debug > 1) {
      fprintf(stderr, "Now we do redirection.\n");
    }
    /* do_redirect will close the current targetfd first then reopen
       a new one */
    status = do_redirect(aip, rip);
    /* Reset the autoredir_now to 0, but redirect_flag to 1 because
     mod_rs will need it. */
    rip->autoredir_now = 0;
    rip->redirect_flag = 1;
    if(status == AR_REDIR_WAIT) {
      counts++;
      if(counts > MAXREDIR) {
	time(&ct);
	log_err(ct, aip, rip, "Error: remote server went infinitely looping.");
	if(n == 0) 
	  FREE_MAYBE(buf);
	FREE_MAYBE(type);
	FREE_MAYBE(all_headers);
	return AR_ERROR;
      }
      if(n == 0)
	FREE_MAYBE(buf);
      FREE_MAYBE(type);
      /* reset all_headers to NULL before calling get_res_headers() */
      FREE_MAYBE(all_headers);
      /* reset old_contlen to -1L before calling get_res_headers() */
      old_contlen = -1L;
      goto Header;
    } else {
      if(n == 0)
	FREE_MAYBE(buf);
      FREE_MAYBE(type);
      FREE_MAYBE(all_headers);
      return AR_ERROR;
    }
  }

  /* Brain-damaged web server gives Content-Type: text/html for a GIF
     image file, which will have terrible effects. Galenet is one of
     them  */
  if (n && old_contlen && !strncasecmp(type, "text/html", 9)) {
    p = buf;
    /*if(*p++ == 'G' && *p++ == 'I' && *p++ == 'F' && *p++ == '8' &&
       *p++ == '9' && *p++ == 'a') {*/
    if(*p++ == 'G' && *p++ == 'I' && *p++ == 'F') {
      FREE_MAYBE(type);
      type = xstrdup("image/gif");
    }
  }

  /* Only text/html file needs modification */
  if (n && old_contlen && 
      (!strncasecmp(type, "text/html", 9) || 
       !strncasecmp(type, "application/x-javascript", 24))) {
    char *tmp_buf = NULL;
    char *token = "meta http-equiv=\"content-type\" content=\"text/html";
    int urlbase_len, tmp_len, tmp1_len, tmp2_len, tmp3_len, tmp4_len;
    int i;
    buf = (char *)Srealloc(buf, old_contlen + 1);
    buf[old_contlen] = '\0';

    if(debug > 3) {
      fprintf(stderr, "Orig RES TEXT:\n%s\n", buf);
    }

    lst = mod_urls_html(buf, aip, rip);

    if(debug > 3)
      fprintf(stderr, "RIP->HAS_JavaScript=%d\n\n", rip->has_js);

    if(rip->has_js) {
      if(lst != NULL) {
	diff = get_lendiff(lst);
	tmp_len = strlen(buf) + diff;
	tmp_buf = cnvt_links(buf, lst, tmp_len);
	free_urlpos (lst);
	FREE_MAYBE(buf);
	buf = xstrdup(tmp_buf);
	FREE_MAYBE(tmp_buf);
      } else 
	tmp_len = strlen(buf);
      
      /* We now have rip->base_url defined. We need insert it into the
	 page if there was originally no base url in that page. */
      if (rip->has_base == 0 && strncasecmp(type, "application/x-javascript", 24)) {
	urlbase_len = insert_base(buf, aip, rip, &tmp_buf);
	if (urlbase_len < 0)
	  return AR_ERROR;
	FREE_MAYBE(buf);
	buf = xstrdup(tmp_buf);
	FREE_MAYBE(tmp_buf);
      }

      tmp1_len = chop_meta_http(buf, token, &tmp_buf);
      FREE_MAYBE(buf);
      buf = xstrdup(tmp_buf);
      FREE_MAYBE(tmp_buf);

      lst = mod_urls_js(buf, tmp1_len, aip, rip);
      if(debug > 3)
	print_urlpos(lst);

      if(lst != NULL) {
	diff = get_lendiff(lst);
	tmp2_len = tmp1_len + diff;
	tmp_buf = cnvt_links(buf, lst, tmp2_len);
	free_urlpos (lst);
	FREE_MAYBE(buf);
	buf = xstrdup(tmp_buf);
	FREE_MAYBE(tmp_buf);
      } else {
	tmp2_len = tmp1_len;
      }

      if(debug > 3) {
	fprintf(stderr, "RES after mod_urls_js:\n%s\n", buf);
      }

      lst = mod_js_loc(buf, tmp2_len, aip, rip, fselect, &fs_size);

      if(debug > 3)
	print_urlpos(lst);

      if(lst != NULL) {
	diff = get_lendiff(lst);
	tmp3_len = tmp2_len + diff;
	tmp_buf = cnvt_links(buf, lst, tmp3_len);
	free_urlpos (lst);
	FREE_MAYBE(buf);
	buf = xstrdup(tmp_buf);
	FREE_MAYBE(tmp_buf);
      } else
	tmp3_len = tmp2_len;

      if(debug > 3) {
	fprintf(stderr, "RES after mod_js_loc:\n%s\n", buf);
      }

      if(fs_size > 0 && rip->fix_opt_value == 1) {
	lst = mod_urls_opt(buf, tmp3_len, aip, rip, fselect, fs_size);
	if(lst != NULL) {
	  diff = get_lendiff(lst);
	  tmp4_len = tmp3_len + diff;
	  tmp_buf = cnvt_links(buf, lst, tmp4_len);
	  free_urlpos (lst);
	  FREE_MAYBE(buf);
	  buf = xstrdup(tmp_buf);
	  FREE_MAYBE(tmp_buf);
	} else
	  tmp4_len = tmp3_len;

	if(debug > 3) {
	  fprintf(stderr, "RES after mod_urls_opt:\n%s\n", buf);
	}

	for(i = 0; i < fs_size; ++i) {
	  FREE_MAYBE(fselect[i]->formname);
	  FREE_MAYBE(fselect[i]->selectname);
	}
      } else
	tmp4_len = tmp3_len;

      lst = mod_js_event(buf, aip, rip);

      if (lst != NULL) {
	diff = get_lendiff(lst);
      	new_len = tmp4_len + diff;
	new_buf = cnvt_links(buf, lst, new_len);
	free_urlpos (lst);
      } else {
	new_buf = xstrdup(buf);
	new_len = strlen(new_buf);
      }

      FREE_MAYBE(buf);

      if(debug > 3) {
	fprintf(stderr, "Modified RES with JavaScript:\n%s\n", new_buf);
      }

    } else {
      if(lst != NULL) {
	diff = get_lendiff(lst);
	tmp_len = strlen(buf) + diff;
	tmp_buf = cnvt_links(buf, lst, tmp_len);
	free_urlpos (lst);
	FREE_MAYBE(buf);
	buf = xstrdup(tmp_buf);
	FREE_MAYBE(tmp_buf);
      } else
	tmp_len = strlen(buf);

      /* We now have rip->base_url defined. We need insert it into the
	 page if there was originally no base url in that page. */
      if (rip->has_base == 0 && strncasecmp(type, "application/x-javascript", 24)) {
	urlbase_len = insert_base(buf, aip, rip, &tmp_buf);
	if (urlbase_len < 0)
	  return AR_ERROR;
	FREE_MAYBE(buf);
	buf = xstrdup(tmp_buf);
	FREE_MAYBE(tmp_buf);
      }

      tmp1_len = chop_meta_http(buf, token, &tmp_buf);
      FREE_MAYBE(buf);
      buf = xstrdup(tmp_buf);
      FREE_MAYBE(tmp_buf);

      if(debug > 3) {
	fprintf(stderr, "after chop meta=\n%s\n", buf);
      }

      lst = mod_js_event(buf, aip, rip);

      if(lst != NULL) {
	diff = get_lendiff(lst);
	new_len = tmp1_len + diff;
	new_buf = cnvt_links(buf, lst, new_len);
	free_urlpos (lst);
      } else {
	new_buf = xstrdup(buf);
	new_len = strlen(new_buf);
      }

      FREE_MAYBE(buf);
    
      if(debug > 3) {
	fprintf(stderr, "Modified RES w/o JavaScript:\n%s\n", new_buf);
      }
    }
  } else if (n && old_contlen 
	     && (strncasecmp(type, "text/html", 9) &&
		 strncasecmp(type, "application/x-javascript", 24))) {
    new_len = old_contlen;
    new_buf = (char *) Smalloc(new_len);
    memcpy(new_buf, buf, new_len);
  } else if (n < 0) {
    FREE_MAYBE(type);
    FREE_MAYBE(buf);
    FREE_MAYBE(all_headers);
    new_len = 0;
    time(&ct);
    log_err(ct, aip, rip, "Error getting the entity body of response.");
    return AR_ERROR;
  } else if (n == 0 && old_contlen == 0) {
    new_len = 0;
  }

  FREE_MAYBE(buf);

done:  
  if(new_len == 0)
    new_contlen = 0L;
  else
    new_contlen = new_len;

  snprintf(str, MAXNAME, "%d", new_contlen);
  if(debug > 3)
    fprintf(stderr, "new_contlen is: %s\n", str);

  if(new_contlen == 0L && type == NULL) {
    contlen_line = xstrdup("\r\n");
  } else {
    len = 15 + 1 + strlen(str) + 4;
    contlen_line = (char *) Smalloc(len + 1);
    snprintf(contlen_line, len+1, "Content-Length: %s\r\n\r\n", str);
  }

  if(debug > 1) {
    fprintf(stderr, "All RES headers NOW is: %s\n", all_headers);
    fprintf(stderr, "ContLEN Line is: %s\n", contlen_line);
  }

  rip->num_bytes = new_contlen;

  lh = strlen(contlen_line);

  all_length = strlen(all_headers);

  all_headers = (char *)Srealloc (all_headers, all_length + lh + 1);
  memcpy(all_headers + all_length, contlen_line, lh);
  all_length += lh;
  all_headers[all_length] = '\0';

  FREE_MAYBE(contlen_line);

  /* Form response from modified headers and body */
  if(new_contlen == 0L) {
    lh = strlen(all_headers);
    *response = (char *)Smalloc(lh + 1);
    memcpy(*response, all_headers, lh);
    (*response)[lh] = '\0';
  } else {
    lh = strlen(all_headers);
    *response = (char *)Smalloc(lh + 1);
    memcpy(*response, all_headers, lh);
    (*response)[lh] = '\0';
    *rs_size = lh + new_contlen;
    if(!strncasecmp(type, "text/html", 9)) {
      *response = (char *)Srealloc(*response, *rs_size + 1);
      memcpy((*response)+lh, new_buf, new_contlen);
      (*response)[*rs_size] = '\0';
    } else {
      *response = (char *)Srealloc(*response, *rs_size + 1);
      memcpy((*response)+lh, new_buf, new_contlen);
    }
  }

  if(debug > 1)
    fprintf(stderr, "New RES is: %s\n", *response);

  FREE_MAYBE(all_headers);
  FREE_MAYBE(new_buf);
  FREE_MAYBE(type);

  status = AR_OK;
  return status;
}

