/************************************************************************
WEBRELAY Software -- a multithreaded HTTP relay server
Copyright (C) 1999 Peter Zhang

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

Please address all correspondence concerning the software to 
zhangc@ucalgary.ca
************************************************************************/

#ifndef GETRQ_H
#define GETRQ_H

#include "mywrap.h"
#include "utils.h"
#include "url.h"
#include "headers.h"
#include "auth.h"
#include "sess_manager.h"
#include "dbtbl.h"
#include "logger.h"


int rq_get_header PARAMS ((int fd, char **hdr));

int parse_firstline PARAMS ((char *line, char **method, char **path,
			     char **proto_vs));

int parse_the_host PARAMS ((char *the_host, char **t_host,
			    unsigned short *t_port));

int parse_the_path PARAMS ((char *the_path, char **db_key, char **seskey,
			    char **redir_url, char **real_path));

int get_first_req_headers PARAMS ((accept_info *aip,
			  relay_info *rip, long *contlen,
			  char **first_rq_headers));

int get_first_req PARAMS ((accept_info *aip, relay_info *rip,
			   char **request, int *rq_size));

void alter_hdr PARAMS ((char *buf, char **new_buf));

void str_chop_body PARAMS ((char *buf, char **new_buf));

int str_chop_token PARAMS ((char *buf, char *token, char **new_buf));

#endif
