/*
** url.c
**
** AR_RELAY Version 1.0.4
**
** Author: Peter Zhang, Aug 31, 1998
**
** Updated: P. Zhang, Oct 28, 1998
** Updated: P. Zhang, Feb 2, 1999
** Updated: P. Zhang, Mar 12, 1999
**   Deals with various issues of JavaScripts.
** Updated: P. Zhang, Apr 21, 1999
**   Make substitutions in dynamic pages more general
*/

#include "url.h"

extern int debug;

/* Default port definitions */
#define DEFAULT_HTTP_PORT 80
#define DEFAULT_FTP_PORT 21

/* URL separator (for findurl) */
#define URL_SEPARATOR "!\"#'(),>`{}|<>"

/* A list of unsafe characters for encoding, as per RFC1738. */

#ifndef WINDOWS
# define URL_UNSAFE " <>\"#%{}|\\^~[]`@:\033"
#else
# define URL_UNSAFE " <>\"%{}|\\^[]`\033"
#endif

/* Is a directory "."?  */
#define DOTP(x) ((*(x) == '.') && (!*(x + 1)))
/* Is a directory ".."?  */
#define DDOTP(x) ((*(x) == '.') && (*(x + 1) == '.') && (!*(x + 2)))

/* NULL-terminated list of strings to be recognized as prototypes (URL
   schemes).  Note that recognized doesn't mean supported -- only HTTP
   is currently supported.

   However, a string that does not match anything in the list will be
   considered a relative URL.  */
static char *protostrings[] =
{
  "cid:",
  "clsid:",
  "file:",
  "finger:",
  "ftp:",
  "gopher:",
  "hdl:",
  "http:",
  "https:",
  "ilu:",
  "ior:",
  "irc:",
  "java:",
  "javascript:",
  "lifn:",
  "mailto:",
  "mid:",
  "news:",
  "nntp:",
  "path:",
  "prospero:",
  "rlogin:",
  "service:",
  "shttp:",
  "snews:",
  "stanf:",
  "telnet:",
  "tn3270:",
  "wais:",
  "whois++:",
  NULL
};

struct proto
{
  char *name;
  uerr_t ind;
  unsigned short port;
};

/* Supported protocols.  */
static struct proto sup_protos[] =
{
  { "http://", URLHTTP, DEFAULT_HTTP_PORT },
  { "ftp://", URLFTP, DEFAULT_FTP_PORT },
  { "file://", URLFILE, DEFAULT_FTP_PORT },
};

/* Returns the number of characters to be skipped if the first thing
   in a URL is URL: (which is 0 or 4+).  The optional spaces after
   URL: are also skipped.  */
int
skip_url (const char *url)
{
  int i;

  if (toupper (url[0]) == 'U' && toupper (url[1]) == 'R'
      && toupper (url[2]) == 'L' && url[3] == ':') {
    /* Skip blanks.  */
    for (i = 4; url[i] && ISSPACE (url[i]); i++);
    return i;
  } else
    return 0;
}

/* Returns 1 if the string contains unsafe characters, 0 otherwise. */
int
contains_unsafe (const char *s)
{
  for (; *s; s++)
    if (strchr (URL_UNSAFE, *s))
      return 1;
  return 0;
}

/* Decodes the forms %xy in a URL to the character whose hex
   code is xy.  If x or y are not hex-digits or `%' precedes `\0', 
   the sequence is inserted literally.  */

void
decode_string (char *s)
{
  char *p = s;

  for (; *s; s++, p++) {
    if (*s != '%')
      *p = *s;
    else {
      /* Do nothing if at the end of the string, or if the chars
	 are not hex-digits.  */
      if (!*(s + 1) || !*(s + 2)
	  || !(ISXDIGIT (*(s + 1)) && ISXDIGIT (*(s + 2)))) {
	*p = *s;
	continue;
      }
      *p = (ASC2HEXD (*(s + 1)) << 4) + ASC2HEXD (*(s + 2));
      s += 2;
    }
  }
  *p = '\0';
}

/* Encodes the unsafe characters (listed in URL_UNSAFE) in a given
   string, returning a %XX encoded string.  */
char *
encode_string (const char *s)
{
  const char *b;
  char *p, *res;
  int i;

  b = s;
  for (i = 0; *s; s++, i++)
    if (strchr (URL_UNSAFE, *s))
      i += 2; /* Two more characters (hex digits) */
  res = (char *)Smalloc (i + 1);
  s = b;
  for (p = res; *s; s++)
    if (strchr (URL_UNSAFE, *s)) {
      const unsigned char c = *s;
      *p++ = '%';
      *p++ = HEXD2ASC (c >> 4);
      *p++ = HEXD2ASC (c & 0xf);
    } else
      *p++ = *s;
  *p = '\0';
  return res;
}

/* Returns the proto-type if URL's protocol is supported, or
   URLUNKNOWN if not.  */
uerr_t
urlproto (const char *url)
{
  int i;

  url += skip_url (url);
  for (i = 0; i < ARRAY_SIZE (sup_protos); i++)
    if (!strncasecmp (url, sup_protos[i].name, 
		      strlen (sup_protos[i].name)))
      return sup_protos[i].ind;
  for (i = 0; url[i] && url[i] != ':' && url[i] != '/'; i++);
  if (url[i] == ':') {
    for (++i; url[i] && url[i] != '/'; i++)
      if (!ISDIGIT (url[i]))
	return URLBADPORT;
    if (url[i - 1] == ':')
      return URLFTP;
    else
      return URLHTTP;
  } else
    return URLHTTP;
}

/* Skip the protocol part of the URL, e.g. `http://'.  If no protocol
   part is found, returns 0.  */
int
skip_proto (const char *url)
{
  char **s;
  int l;

  for (s = protostrings; *s != NULL; s++)
    if (!strncasecmp (*s, url, strlen (*s)))
      break;
  if (*s == NULL)
    return 0;
  l = strlen (*s);
  /* HTTP and FTP protocols are expected to yield exact host names
     (i.e. the `//' part must be skipped, too).  */
  if (!strcmp (*s, "http:") || !strcmp (*s, "ftp:"))
    l += 2;
  return l;
}

/* Returns 1 if the URL begins with a protocol (supported or
   unsupported), 0 otherwise.  */
static int
has_proto (const char *url)
{
  char **s;

  url += skip_url (url);
  for (s = protostrings; *s != NULL; s++)
    if (strncasecmp (url, *s, strlen (*s)) == 0)
      return 1;
  return 0;
}

/* Get the scheme part of a URL */

static int
get_scheme (const char *url, char **scheme)
{
  int i, len;

  url += skip_url (url);
  if((url[0] == '/' && url[1] == '/') || (url[0] == '.' && url[1] == '.') ||
     url[0] == '.' || url[0] == '/') {
    *scheme = xstrdup("http");
    return 0;
  }

  len = strlen(url);
  for (i = 0; i < len && url[i] != ':'; i++);

  if (i == 0 || i == len)
    return -1;
  *scheme = strdupdelim(url, url + i);
  return 0;
}

/* Skip the username and password, if present here.  The function
   should be called *not* with the complete URL, but with the part
   right after the protocol. */
int
skip_uname (const char *url)
{
  const char *p;
  for (p = url; *p && *p != '/'; p++)
    if (*p == '@')
      break;
  /* If a `@' was found before the first occurrence of `/', skip
     it.  */
  if (*p == '@')
    return p - url + 1;
  else
    return 0;
}

/* Allocate a new urlinfo structure, fill it with default values and
   return a pointer to it.  */
struct urlinfo *
newurl (void)
{
  struct urlinfo *u;

  u = (struct urlinfo *)Smalloc (sizeof (struct urlinfo));
  memset (u, 0, sizeof (*u));
  u->proto = URLUNKNOWN;
  return u;
}

/* Perform a "deep" free of the urlinfo structure.  The structure
   should have been created with newurl, but need not have been used.
   If free_pointer is non-0, free the pointer itself.  */
void
freeurl (struct urlinfo *u, int complete)
{
  assert (u != NULL);
  FREE_MAYBE (u->url);
  FREE_MAYBE (u->scheme);
  FREE_MAYBE (u->host);
  FREE_MAYBE (u->path);
  FREE_MAYBE (u->file);
  FREE_MAYBE (u->dir);
  FREE_MAYBE (u->user);
  FREE_MAYBE (u->passwd);
  FREE_MAYBE (u->local);
  FREE_MAYBE (u->referer);
  if (u->proxy != NULL)
    freeurl (u->proxy, 1);
  if (complete)
    free (u);
  return;
}


/* Extract the given URL of the form
   (http:|ftp:)// (user (:password)?@)?hostname (:port)? (/path)?
   No allocation is done.
   If the argument STRICT is set, it recognizes only the canonical
   form.  */
uerr_t
parseurl (const char *url, struct urlinfo *u, int strict)
{
  int i, k, l, abs_ftp;
  int recognizable;            
  uerr_t type;
  int len;
  int flag = 0;

  if(debug > 3)
    fprintf (stderr, "parseurl (\"%s\") ->\n", url);

  url += skip_url (url);
  if(get_scheme(url, &u->scheme) < 0) {
    return URLUNKNOWN;
  }
  recognizable = has_proto (url);
  if (strict && !recognizable)
    return URLUNKNOWN;
  for (i = 0, l = 0; i < ARRAY_SIZE (sup_protos); i++) {
    l = strlen (sup_protos[i].name);
    if (!strncasecmp (sup_protos[i].name, url, l))
      break;
  }
  /* If protocol is recognizable, but unsupported, bail out, else
     suppose unknown.  */
  if (recognizable && sup_protos[i].name == NULL)
    return URLUNKNOWN;
  else if (i == ARRAY_SIZE (sup_protos))
    /*    type = URLUNKNOWN;*/
    if(!strncasecmp(url, "//", 2)) {
      /* There is no "http:" in front of "//" means a relative URI
       and will skip over "//" */
      l = 2;
      recognizable = 1;
      type = URLHTTP;
    } else if(!strncasecmp(url, "..", 2) || *url == '.' || 
	      (*url == '/' && *(url+1) != '/')) {
      l = 0;
      recognizable = 1;
      flag = 1;
      type = URLHTTP;
    } else
      type = URLUNKNOWN;
  else
    u->proto = type = sup_protos[i].ind;

  if (type == URLUNKNOWN)
    l = 0;
  /* Allow a username and password to be specified (i.e. just skip
     them for now).  */
  if (recognizable) /* skip http:// and uname and pwd */
    l += skip_uname (url + l);

  /* We have to deal with URLs w/o host:port */
  if(type == URLHTTP && (!strncasecmp(url, "..", 2) || *url == '.' || 
			 (*url == '/' && *(url+1) != '/'))) {
    u->host = NULL;
    u->port = 0;
    i = l;
    goto Get_path;
  }

  /* Get hostname */
  for (i = l; url[i] && url[i] != ':' && url[i] != '/'; i++);
  if (i == l)
    return URLBADHOST;
  /* Get the hostname.  */
  u->host = strdupdelim (url + l, url + i);

  if(debug > 3)
    fprintf (stderr, "host %s ->\n ", u->host);

  /* Assume no port has been given.  */
  u->port = 0;
  if (url[i] == ':') {
    /* We have a colon delimiting the hostname.  It could mean that
       a port number is following it, or a directory.  */
    if (ISDIGIT (url[++i])) {   /* A port number */
      if (type == URLUNKNOWN)
	u->proto = type = URLHTTP;
      for (; url[i] && url[i] != '/'; i++)
	if (ISDIGIT (url[i]))
	  u->port = 10 * u->port + (url[i] - '0');
	else
	  return URLBADPORT;
      if (!u->port)
	return URLBADPORT;
      if(debug > 3)
	fprintf (stderr, "port %hu ->\n ", u->port);
    } else if (type == URLUNKNOWN) /* or a directory */
      u->proto = type = URLFTP;
    else                      /* or just a misformed port number */
      return URLBADPORT;
  } else if (type == URLUNKNOWN)
    u->proto = type = URLHTTP;

  if (!u->port) {
    for (k = 0; k < ARRAY_SIZE (sup_protos); k++)
      if (sup_protos[k].ind == type)
	break;
    if (k == ARRAY_SIZE (sup_protos))
      return URLUNKNOWN;
    u->port = sup_protos[k].port;
  }
  /* Some delimiter troubles...  */
  if (url[i] == '/' && url[i - 1] != ':')
    ++i;

Get_path:
  if (type == URLHTTP && flag == 0)
    while (url[i] && url[i] == '/')
      ++i;
  len = strlen (url + i) + 8;
  u->path = (char *)Smalloc (len + 1);
  if(flag) 
    /* path starts with a dot or slash in itself */
    snprintf(u->path, len+1, "%s", url + i);
  else
    snprintf(u->path, len+1, "/%s", url + i);
  /*  strcpy (u->path, url + i);*/
  if (type == URLFTP) {
    u->ftp_type = process_ftp_type (u->path);
    /* #### We don't handle type `d' correctly yet.  */
    if (!u->ftp_type || toupper (u->ftp_type) == 'D')
      u->ftp_type = 'I';
  }
  if(debug > 3)
    fprintf (stderr, "opath %s ->\n ", u->path);

  /* Parse the username and password (if existing).  */
  parse_uname (url, &u->user, &u->passwd);
  /* Decode the strings, as per RFC 1738.  */
  if(u->host != NULL)
    decode_string (u->host);
  /*  if(u->path != NULL)
    decode_string (u->path);*/
  if (u->user != NULL)
    decode_string (u->user);
  if (u->passwd != NULL)
    decode_string (u->passwd);
  /* Parse the directory.  */
  parse_dir (u->path, &u->dir, &u->file);

  if(debug > 3)
    fprintf (stderr, "dir %s -> file %s ->\n ", u->dir, u->file);

  /* Simplify the directory.  */
  if(u->dir != NULL)
    decode_string(u->dir);
  path_simplify (u->dir);

  if(debug > 3)
    fprintf (stderr, "ndir %s\n", u->dir);
  /* Strip trailing `/'.  */
  l = strlen (u->dir);
  if (l && u->dir[l - 1] == '/')
    u->dir[l - 1] = '\0';
  /* Re-create the path: */
  abs_ftp = (u->proto == URLFTP && *u->dir == '/');

  u->url = NULL;
  return URLOK;
}

/* Process the path */
char *path_process(const char *path, char **dir, char **file)
{
  char *tmp = NULL;
  char *new_path = NULL;
  int len;

  if(*path == '/' && *(path+1) == '\0')
    *dir = xstrdup("/");
  else
    parse_dir(path, dir, file);
  decode_string(*dir);
  /* path_simplify defined in utils.h to get rid of unnecessary
     stuff. But it also removes the trailing slash. We do need the
     trailing slash if it is a directory not with a file */
  len = strlen(path);
  if(path[len-1] == '/' && len != 1 && (*file) == NULL) {
    path_simplify(*dir);
    len = strlen(*dir);
    tmp = Smalloc(len + 1 + 1);
    memcpy(tmp, *dir, len);
    tmp[len] = '/';
    tmp[len+1] = '\0';
    new_path = encode_string(tmp);
  } else if (*path == '/' && *(path+1) == '\0') {
    new_path = xstrdup("/");
  } else {
    path_simplify(*dir);
    tmp = encode_string(*dir);
    if(*tmp == '/' && *(tmp+1) == '\0') {
      len = 1 + strlen(*file);
      new_path = Smalloc(len + 1);
      snprintf(new_path, len+1, "/%s", *file);
    } else {
      len = strlen(tmp) + 1 + strlen(*file);
      new_path = Smalloc(len + 1);
      snprintf(new_path, len+1, "%s/%s", tmp, *file);
    }
  }
  FREE_MAYBE(tmp);
  return new_path;
}

/* Parse the path to get the directory and filename components. */
void
parse_dir (const char *path, char **dir, char **file)
{
  int i, j, k, l;

  for (i = l = strlen (path); i && path[i] != '/'; i--);
  if (!i && *path != '/') {  /* Just filename */
    if (DOTP (path) || DDOTP (path)) {
      *dir = xstrdup (path);
      *file = xstrdup ("");
    } else {
      *dir = xstrdup ("");     
      *file = xstrdup (path);
    }
  } else if (!i && *path == '/') {
    /* This is a filename or a query string w/o slashes, with a
       leading slash */ 
    if (DOTP (path + 1) || DDOTP (path + 1)) {
      *dir = xstrdup (path);
      *file = xstrdup ("");
    } else {
      *dir = xstrdup ("/");
      if(*(path+1) != '\0')
	*file = xstrdup (path + 1);
    }
  } else { 
    /* Nonempty directory with or without a filename or that slash was
       found in the middle of a query string as query arguments */
    for (j = i; j && path[j] != '?'; j--);
    if (j) { 
      /* There is a query string which has arguments that may have
	 a slash in it. We now search for a slash again */
      for (k = j; k && path[k] != '/'; k--);
      if (!k && *path != '/') {  /* Just query string */
	*dir = xstrdup ("");
	*file = xstrdup (path);
      } else if (!k && *path == '/') {  /* /querystring */
	*dir = xstrdup ("/");
	*file = xstrdup (path + 1);
      } else if (k) {
	*dir = strdupdelim (path, path + k);
	*file = strdupdelim (path + k + 1, path + l + 1);
      }
    } else {
      /* There is no '?' found, so the '/' found before was a
	 separator between dir and file */
      if (DOTP (path + i + 1) || DDOTP (path + i + 1)) {
	*dir = xstrdup (path);
	*file = xstrdup ("");
      } else {
	*dir = strdupdelim (path, path + i);
	*file = strdupdelim (path + i + 1, path + l + 1);
      }
    }
  }
}

/* Find the optional username and password within the URL, as per
   RFC1738.  The returned user and passwd char pointers are
   malloc-ed.  */
static uerr_t
parse_uname (const char *url, char **user, char **passwd)
{
  int l;
  const char *p, *col;
  char **where;

  *user = NULL;
  *passwd = NULL;
  url += skip_url (url);
  /* Look for end of protocol string.  */
  l = skip_proto (url);
  if (!l)
    return URLUNKNOWN;
  /* Add protocol offset.  */
  url += l;
  /* Is there an `@' character?  */
  for (p = url; *p && *p != '/'; p++)
    if (*p == '@')
      break;
  /* If not, return.  */
  if (*p != '@')
    return URLOK;
  /* Else find the username and password.  */
  for (p = col = url; *p != '@'; p++) {
    if (*p == ':' && !*user) {
      *user = (char *)Smalloc (p - url + 1);
      memcpy (*user, url, p - url);
      (*user)[p - url] = '\0';
      col = p + 1;
    }
  }
  /* Decide whether you have only the username or both.  */
  where = *user ? passwd : user;
  *where = (char *)Smalloc (p - col + 1);
  memcpy (*where, col, p - col);
  (*where)[p - col] = '\0';
  return URLOK;
}

/* If PATH ends with `;type=X', return the character X.  */
static char
process_ftp_type (char *path)
{
  int len = strlen (path);

  if (len >= 7
      && !memcmp (path + len - 7, ";type=", 6)) {
    path[len - 7] = '\0';
    return path[len - 1];
  } else
    return '\0';
}

/* BUF is scanned with find_url(). mod_urls_html() modifies both absolute  
   URLs and PATH. If the base is the same as that of the destination 
   "targethost" of the targeted database server, Replace the target URL 
   with the relay server, i.e., 

               http://relayhost:port/Session_Key/

   In the case of redirection, use

               http://relayhost:port/
	       Session_Key=redir_targethost:redir_targetport/redir_targetpath/

   If an absolute link points to a hostname other than the target
   hostname and there is no "Location:" header in the responses
   headers, replace it with

               http://relayhost:port/Session_Key=newhostname:newport/newpath

   where newhostname has nothing to do with the originally designated
   target host of the vendor.

   Only absolute PATHs in a relative links are modified with ar_prefix
   (If there is no <BASE href="..."> defined) or ar_base_prefix (The
   base URL in the HTML <BASE href="..."> tag has a higher precedence).

   However, a filename in <meta http-equiv="refresh" content="0; URL=...">
   is treated differently, because apparently, the BASE URL has little effects
   on it. So we add targetdir in front of it. (See the site of the
   Grove Art Dictionary, which uses a MS-IIS/4.0 web server)

   The modified links are stored in a linked list of urlpos, which will
   be used later by cnvt_links to actually convert the hmtl buffer
   */

urlpos *
mod_urls_html (const char *buf, accept_info *aip, relay_info *rip)
{
  state_t *s;		/* local in this function, not a global */

  char *ar_prefix = NULL;	/* Prefix for absolute path */
  char *ar_rel_prefix = NULL;	/* Prefix for relative path */
  char *ar_base_prefix = NULL; 	/* When BASE URL exists */
  char *ar_base_rel_prefix = NULL; 	/* When BASE URL exists */

  int has_base = 0;	/* Flag for having BASE URL */
  const char *pbuf;	/* Current cursor position in the buf */
  int size = 0;		/* Size of the original links */
  int len_myhost;	/* strlen of my host */
  urlpos *first, *current, *old; /* Pointers to urlpos */

  long orig_len;		/* Length of the original buffer */

  int sizeofs;
  struct urlinfo *u;
  char str[MAXNAME], str1[MAXNAME];

  int len;

  first = current = old = NULL;	  /* Initialize pointers the list */
  orig_len = strlen(buf);

  sizeofs = sizeof(state_t);

  s = (state_t *)Smalloc(sizeofs);
  memset(s, 0, sizeofs);

  /* ar_prefix is a base of the relay server URL address. We intend to
     add this to relative links and to replace the targethost with
     it. */ 
  snprintf(str, MAXNAME, "%d", aip->relay_port);
  snprintf(str1, MAXNAME, "%d", rip->redir_targetport);

  len_myhost = strlen(aip->relay_hostname);

  if(rip->redirect_flag && rip->redir_targethost != NULL && 
     rip->redir_targetpath != NULL) {

    /* After authentication, there must be a rip->seskey non-NULL */
    len = 7 + len_myhost + 1 + strlen(str) + 1 + strlen(rip->seskey) + 1 + 
      strlen(rip->redir_targethost) + 1 + strlen(str1) + 1;
    ar_prefix = (char *) Smalloc(len + 1);
    snprintf(ar_prefix, len+1, "http://%s:%s/%s=%s:%s/", aip->relay_hostname, 
	     str, rip->seskey, rip->redir_targethost, str1);
    /* the targetdir has a leading slash. */
    ar_rel_prefix = add_prefix(ar_prefix, len, rip->redir_targetdir,
			       strlen(rip->redir_targetdir));
    len = strlen(ar_rel_prefix);
    if(ar_rel_prefix[len - 1] != '/') {
      ar_rel_prefix = Srealloc(ar_rel_prefix, len + 1 + 1);
      snprintf(ar_rel_prefix + len, len+2, "/");
    } 
 
    /* If there was originally a base URL in the <HEAD> section, this
       rip->base_url should be overwritten */
    len = strlen(ar_rel_prefix) + 
      ((rip->redir_targetfile != NULL) ? strlen(rip->redir_targetfile) : 0);
    if(rip->redir_targetfile != NULL) {
      rip->base_url = Smalloc(len + 1);
      snprintf(rip->base_url, len+1, "%s%s", ar_rel_prefix, 
	       rip->redir_targetfile);
    } else
      rip->base_url = xstrdup(ar_rel_prefix);
  } else {
    /* After authentication, there must be a rip->seskey non-NULL */
    len = 7 + len_myhost + 1 + strlen(str) + 1 + strlen(rip->seskey) + 1;
    ar_prefix = (char *) Smalloc(len + 1);
    snprintf(ar_prefix, len+1, "http://%s:%s/%s/", aip->relay_hostname, str, 
	    rip->seskey);
    /* the targetdir has a leading slash, and a trailing slash too, if a
       filename was followed. */
    ar_rel_prefix = add_prefix(ar_prefix, len, 
			       rip->targetdir, strlen(rip->targetdir));
    len = strlen(ar_rel_prefix);
    if(ar_rel_prefix[len - 1] != '/') {
      ar_rel_prefix = Srealloc(ar_rel_prefix, len + 1 + 1);
      snprintf(ar_rel_prefix + len, len+2, "/");
    } 
    /* If there was originally a base URL in the <HEAD> section, this
       rip->base_url should be overwritten */
    len = strlen(ar_rel_prefix) + 
      ((rip->targetfile != NULL) ? strlen(rip->targetfile) : 0);
    if(rip->targetfile != NULL) {
      rip->base_url = Smalloc(len + 1);
      snprintf(rip->base_url, len+1, "%s%s", ar_rel_prefix, rip->targetfile);
    } else
      rip->base_url = xstrdup(ar_rel_prefix);
  }

  /* Iterate over the links in BUF, picked by htmlfindurl().  */
  for (pbuf=buf; (pbuf=find_url(pbuf, orig_len - (pbuf - buf), &size, s)) != NULL;
       pbuf += size) {
    int i, no_proto = 0, skip_blanks;
    char *old_url = NULL;	/* Original URL */
    char *constr = NULL; 	/* Newly Constructed URL */

    /* This is a simple mechanism for brain-damaged pages that refer
       to URI-s as <a href="<spaces>URI">.  If the URI is absolute,
       the spaces will be silently skipped.  Otherwise, the spaces
       will still be taken for a legal part of a relative URI.  Note
       that you can still write <a href = any_URI> without spaces
       having any special meaning.  Thanks to Hrvoje Lacko
       <hlacko@fly.cc.fer.hr>.  */
    for (skip_blanks = 0; ISSPACE (pbuf[skip_blanks]) && 
	   skip_blanks < size; skip_blanks++);

    if(debug > 3) {
      fprintf(stderr, "Mod_urls_html: S->HAS_JS=%d\n\n", s->has_js);
      fprintf(stderr, "Mod_urls_html: no_proto=%d\n\n", no_proto);
    }

    if(debug > 3)
      fprintf(stderr, "S->Tag=%s, S->Attr=%s, S->Base=%s\n", s->tag,  s->attr, s->base);

    if(s->has_js && !strncasecmp(s->tag, "script", 6) && 
       (!strncasecmp(s->attr, "language", 8) ||
	!strncasecmp(s->attr, "type", 8))) {

      old_url = strdupdelim (pbuf, pbuf + size);

      if(debug > 3)
	fprintf(stderr, "Script Language=%s\n", old_url);

      if(!strncasecmp(old_url, "javascript", 10) ||
	 !strncasecmp(old_url, "text/javascript", 15))
	rip->has_js = 1;

      if(debug > 3) {
	fprintf(stderr, "See if rip->has_js updated?\n");
	fprintf(stderr, "RIP->Has_js=%d\n", rip->has_js);
      }
      
      goto End;
    }

    for (i = 0; protostrings[i] != NULL; i++) {
      if (!strncasecmp (protostrings[i], pbuf + skip_blanks,
			MINVAL (strlen (protostrings[i]),
				size - skip_blanks)))
	break;
    }
    /* The second part of the check is provided for bad pages
       refering to http:URL.  See below for details.  */
    if (protostrings[i] != NULL
	&& !(strncasecmp (pbuf + skip_blanks, "http:", 5) == 0
	     && strncasecmp (pbuf + skip_blanks, "http://", 7) != 0)) {
      no_proto = 0;
    } else if ( (!protostrings[i]) && (!strncasecmp(pbuf + skip_blanks,
						    "//", 2)) ) {
      /* "//erl.lib...../path/...", assume http: */
      no_proto = 0;
    } else {
      no_proto = 1;
      /* This is for extremely brain-damaged pages that refer to
	 relative links as <a href="http:URL">.  Just strip off the
	 silly leading "http:" (as well as any leading blanks
	 before it).  */
      if ((size > skip_blanks + 5) &&
	  !strncasecmp ("http:", pbuf + skip_blanks, 5)) {
	pbuf += skip_blanks + 5;
	size -= skip_blanks + 5;
      }
    }
    if (!no_proto && skip_blanks) {
      pbuf += skip_blanks;
      size -= skip_blanks;
    }
    if (!no_proto) {
      for (i = 0; i < ARRAY_SIZE (sup_protos); i++) {
	if (!strncasecmp (sup_protos[i].name, pbuf,
			  MINVAL (strlen (sup_protos[i].name), size)))
	  break;
      }
      /* Do *not* accept a non-supported protocol.  */
      if (i == ARRAY_SIZE (sup_protos) && strncasecmp(pbuf, "//", 2) )
	goto End;
    }

    /* s->base must be absolute URL with a protocol part */
    if (!no_proto && s->base != NULL && !strncasecmp(s->tag, "base", 4)) {
      char *base_url = NULL;
      char *path = NULL;
      
      has_base = 1;
      rip->has_base = 1;
      base_url = strdupdelim(pbuf, pbuf + size);
      u = newurl ();
      if ( parseurl(base_url, u, 0) != URLOK ) {
	/* Bad URL in this link, forget it */
	freeurl (u, 1); 
	goto End;
      }
      snprintf(str1, MAXNAME, "%d", u->port);
      len = 7 + len_myhost + 1 + strlen(str) + 1 + strlen(rip->seskey) + 
	1 + strlen(u->host) + 1 + strlen(str1) + 1;
      ar_base_prefix = (char *) Smalloc(len + 1);
      snprintf(ar_base_prefix, len+1, "http://%s:%s/%s=%s:%s/",
	       aip->relay_hostname, str, rip->seskey, u->host, str1);
      ar_base_rel_prefix = add_prefix(ar_base_prefix, len, u->dir,
				      strlen(u->dir));
      len = strlen(ar_base_rel_prefix);
      if(ar_base_rel_prefix[len - 1] != '/') {
	ar_base_rel_prefix = Srealloc(ar_base_rel_prefix, len + 1 + 1);
	snprintf(ar_base_rel_prefix + len, len+2, "/");
      } 

      for (i = 0; u->path[i] && u->path[i] == '/'; i++);
      /* Make a copy of u->path w/o a leading slash. */
      path = xstrdup(u->path + i);

      if(*path == '\0') {
	constr = xstrdup(ar_base_prefix);
      } else {
	constr = add_prefix(ar_base_prefix, strlen(ar_base_prefix), 
			    path, strlen(path));
      }
      /* Replace the previously defined rip->base_url at the beginning 
	 of this function with our new base, not used but just in case:
	 We DON'T need insert this base!!! */
      FREE_MAYBE(rip->base_url);
      rip->base_url = xstrdup(constr);

      freeurl (u, 1);
      FREE_MAYBE(base_url);
      FREE_MAYBE(path);
      goto Done;
    }

    if (no_proto) {
      /* If a relative link starts with a "#", then the link is
	 relative within the current page. We don't need any
	 modifications in this case. */
      if(*pbuf == '#') {
	goto End;
      } 
      if (!s->is_js_arg) { 
	/* This is a relative URL */
	old_url = strdupdelim(pbuf, pbuf + size);
	if(has_base) {
	  if(old_url[0] == '/') 
	    /* This is an absolute path, so add our relay prefix to it. We 
	       define ar_base_prefix and ar_prefix having a trailing slash.
	       Add_prefix handles both cases of with and without slash.*/
	    constr = add_prefix(ar_base_prefix, strlen(ar_base_prefix), 
				old_url, size);
	  else {
	    if(strncasecmp(s->tag, "meta", 4))
	      goto End;
	    else
	      /* URL inside <META http-eqiv="refresh" content="0; URL=...">
		 i.e., s->tag is "META", special attention is needed. */
	      constr = add_prefix(ar_base_rel_prefix, strlen(ar_base_rel_prefix),
				old_url, size);
	  }
	} else {
	  if(old_url[0] == '/') 
	    constr = add_prefix (ar_prefix, strlen(ar_prefix), old_url, size);
	  else {
	    if(strncasecmp(s->tag, "meta", 4))
	      goto End;
	    else
	      /* URL inside <META http-eqiv="refresh" content="0; URL=...">
		 i.e., s->tag is "META", special attention is needed.
	      See, e.g., Groveart.com */
	      constr = add_prefix (ar_rel_prefix, strlen(ar_rel_prefix), 
				 old_url, size);
	  }
	}
      } else if (s->is_js_arg && s->func_name != NULL) {
	int is_frst_term = 0;
	/* We are dealing with the first arg of a javascript function call.
	 It can be an absolute URL (then no_proto should be 1), 
	 a relative URL (an absolute path or a relative path),
	 or even simply a plain text string */
	/* E.g., CPIQ now decides inside a JavaScript statement they
	   do the following (in a function of bkmURL(pathinfo, namedloc):
	   location.href = "/itw/sesssion/../../" + pathinfo + ...;
	   when calling this function, they use
	   javascript:bkmURL('/6!xrn_1_0_1_9922093','')
	   so that we SHOULD NOT add ar_prefix to pathinfo! */

	/* If the arg starts with a "/" (meaning an absolute path)
	   we may want to change it to have our
	   ar_prefix in front of it, otherwise do nothing */
	/* Warning: There is no way to be 100% sure we got the right thing */
	is_frst_term = is_first_term(buf, s->func_name);
	/* Only if the arg is the first term on the rhs we need
	   to do substitution */

	if(debug > 4)
	  fprintf(stderr, "Is_First_Term = %d, Func_name = %s\n", 
		  is_frst_term, s->func_name);

	if(is_frst_term != 1)
	  goto End;
	old_url = strdupdelim(pbuf, pbuf + size);
	if(has_base) {
	  if(old_url[0] == '/') {
	    /* It is an absolute path, not a plain text string */
	    constr = add_prefix(ar_base_prefix, strlen(ar_base_prefix), 
				old_url, size);
	 } else {
	    /* Hard to tell if it is a relative path or simply a plain 
	       text string. The relative path is now taken care of
	       by the <BASE> URL, so we need not do anything */
	    /*	  constr = add_prefix(ar_base_rel_prefix, 
		  strlen(ar_base_rel_prefix), 
		  old_url, size);	*/
	    goto End;
	  }
	} else {
	  if(old_url[0] == '/') {
	    /* It is more probably a relative URL, not a plain text string */
	    constr = add_prefix(ar_prefix, strlen(ar_prefix),
				old_url, size); 
	  } else {
	    /* Hard to tell if it is a relative path or simply a plain 
	       text string. The relative path is now taken care of
	       by the inserted <BASE> URL, so we need not do anything */
	    /*	  constr = add_prefix (ar_rel_prefix, strlen(ar_rel_prefix), 
		  old_url, size);	*/
	    goto End;
	  }
	}
      }
    } else {
      /* has proto and must be absolute link */
      /* Even if s->is_js_arg == 1, we know this kind of absolute URL
	 must be substituted with our relay URL. See, e.g. Library
	 Home Page big jumbo javascript. */ 
      /* Because it is an absolute link, the meta info BASE will have
	 no effect on it */ 
	
      old_url = strdupdelim(pbuf, pbuf + size);
	  
      /* Parse old_url and put useful info into urlinfo struct */
      u = newurl ();
      if ( parseurl(old_url, u, 0) != URLOK ) {
	/* Bad URL in this link, forget it */
	freeurl (u, 1); 
	goto End;
      }

      if(debug > 3)
	fprintf(stderr, "What hostname is=%s\n", u->host);
      /* hostname in the hyperlink identical to targethost */
      if(!strncasecmp(u->host, rip->targethost, strlen(u->host)) &&
	 (u->port == rip->targetport)) {
	/* This is an absolute link to the target host the client
	   wants to access, so translate it to point to our relay
	   host */
	char *path;
	  
	/* Skip over any leading slashes */
	for (i = 0; u->path[i] && u->path[i] == '/'; i++);
	 
	/* Make a copy of u->path without a leading slash */
	path = xstrdup(u->path + i);
	
	/* Form a new link from ar_prefix and path. */

	if ( *path == '\0' ) {
	  len = strlen(ar_prefix);
	  constr = (char *)Smalloc(len + 1);
	  snprintf(constr, len+1, "%s", ar_prefix);
	} else {
	  constr = add_prefix(ar_prefix, strlen(ar_prefix),
			      path, strlen(path));
			      /*len = strlen(ar_prefix) + strlen(path);
	  constr = (char *)Smalloc(len + 1);
	  snprintf(constr, len+1, "%s%s", ar_prefix, path);*/
	}
	FREE_MAYBE (path);
	freeurl (u, 1);
      } else {
	/* Vendors frequently change their server host and/or use
	   multiple servers, all of them require IP checking. 
	   Sometimes they might intentionally include some sideline
	   servers which do not require IP checking. We will always
	   redirect the requests to them */
	char *path, *ar_other_prefix;
	  
	snprintf(str1, MAXNAME, "%d", u->port);
	len = 7 + len_myhost + 1 + strlen(str) + 1 + 
	  strlen(rip->seskey) + 
	  1 + strlen(u->host) + 1 + strlen(str1) + 1;
	ar_other_prefix = (char *) Smalloc(len + 1);
	snprintf(ar_other_prefix, len+1, "http://%s:%s/%s=%s:%s/",
		aip->relay_hostname, str, rip->seskey,
		u->host, str1);
	/* Skip over any leading slashes */
	for (i = 0; u->path[i] && u->path[i] == '/'; i++);
	
	/* Make a copy of u->path without a leading slash */
	path = xstrdup(u->path + i);
	
	/* Form a new link from ar_other_prefix and path. */
	
	if ( *path == '\0' ) {
	  len = strlen(ar_other_prefix);
	  constr = (char *)Smalloc(len + 1);
	  snprintf(constr, len+1, "%s", ar_other_prefix);
	} else {
	  constr = add_prefix(ar_other_prefix, strlen(ar_other_prefix),
			      path, strlen(path));
	}
	FREE_MAYBE (path);
	FREE_MAYBE (ar_other_prefix);
	freeurl (u, 1);
      }
    }

  Done:
    /* Allocate the space.  */
    old = current;
    current = (urlpos *)Smalloc (sizeof (urlpos));
    if (old != NULL)
      old->next = current;
    if (first == NULL)
      first = current;
    /* Fill the values.  */
    memset (current, 0, sizeof (urlpos));
    current->next = NULL;
    current->url = xstrdup(constr); 	/* This is converted URL */
    current->old_size = size;
    current->new_size = strlen(constr);
    current->pos = pbuf - buf;

    if(debug > 3) {
      fprintf(stderr, "current->url=%s, size=%d\n", 
	      constr, current->new_size);
    }

  End:
    /* reset s->is_js_arg to zero */
    s->is_js_arg = 0;
    FREE_MAYBE(old_url);
    FREE_MAYBE(constr);
  }

  /* Free memory of  here.......free (s); */

  FREE_MAYBE(ar_prefix);
  FREE_MAYBE(ar_rel_prefix);
  FREE_MAYBE(ar_base_prefix);
  FREE_MAYBE(ar_base_rel_prefix);
  FREE_MAYBE(s->tag);
  FREE_MAYBE(s->attr);
  FREE_MAYBE(s->base);
  FREE_MAYBE(s->func_name);
  FREE_MAYBE(s);

  /* Return the linked list of all the hyperlinks */
  return first;
}

/* Insert a base hyperlink in the HEAD section of a homepage. It
   returns a new Content-Length on success, otherwise returns -1 */
int insert_base(const char *buf, accept_info *aip, relay_info *rip, char **new_buf)
{
  int len;
  const
  char *p, *q, *p1, *p2;
  char *base_str = NULL;
  char *head, *tail;

  time_t ct;

  p = find_first_token(buf, "<HEAD>");
  q = find_first_token(buf, "<HTML>");
  p1 = find_first_token(buf, "<BODY");
  if (p != NULL) {
    len = 13 + strlen(rip->base_url) + 3;
    base_str = Smalloc(len + 1);
    snprintf(base_str, len+1, "\n<BASE href=\"%s\">\n", rip->base_url);

    tail = xstrdup(p + 6);
    head = strdupdelim(buf, p + 6);

    len = strlen(head) + strlen(base_str) + strlen(tail);

    *new_buf = Smalloc(len + 1);
    memcpy(*new_buf, head, strlen(head));
    memcpy(*new_buf + strlen(head), base_str, strlen(base_str));
    memcpy(*new_buf + strlen(head) + strlen(base_str), tail, strlen(tail));
    (*new_buf)[len] = '\0';
    FREE_MAYBE(head);
    FREE_MAYBE(tail);
    FREE_MAYBE(base_str);
    len = strlen(*new_buf);
    return len;
  } else if (q != NULL && p == NULL) {
    len = 19 + strlen(rip->base_url) + 10;
    base_str = Smalloc(len + 1);
    snprintf(base_str, len+1, "<HEAD>\n<BASE href=\"%s\"></HEAD>\n", 
	     rip->base_url);
    tail = xstrdup(p + 6);
    head = strdupdelim(buf, p + 6);

    len = strlen(head) + strlen(base_str) + strlen(tail);

    *new_buf = Smalloc(len + 1);
    memcpy(*new_buf, head, strlen(head));
    memcpy(*new_buf + strlen(head), base_str, strlen(base_str));
    memcpy(*new_buf + strlen(head) + strlen(base_str), tail, strlen(tail));
    (*new_buf)[len] = '\0';
    FREE_MAYBE(head);
    FREE_MAYBE(tail);
    FREE_MAYBE(base_str);
    len = strlen(*new_buf);
    return len;
  } else if (p1 != NULL && q == NULL & p == NULL) {
    /* This is really a broken page. But there are such broken pages out
       there, e.g., the UofC Library's /library/whatsnew/digitized.html
       file, which does not have a <HTML>, nor <HEAD>, nor </BODY ...>,
       nor </HEAD>, nor </HTML>.... It simply starts with a <BODY> and ends
       with no other ending tags at all. */
    len = 25 + strlen(rip->base_url) + 10;
    base_str = Smalloc(len + 1);
    snprintf(base_str, len+1, "<HTML><HEAD>\n<BASE href=\"%s\"></HEAD>\n", 
	     rip->base_url);

    len = strlen(base_str) + strlen(buf);

    *new_buf = Smalloc(len + 1);
    memcpy(*new_buf, base_str, strlen(base_str));
    memcpy(*new_buf + strlen(base_str), buf, strlen(buf));
    FREE_MAYBE(base_str);
    *new_buf = Srealloc(*new_buf, len + 8 + 1);
    memcpy(*new_buf+len, "</HTML>\n", 8);
    (*new_buf)[len+8] = '\0';    
    len = strlen(*new_buf);
    return len;
  } else {
    /* There are other pages out there: E.g., cpxweb.ei.org's
       first page consists of only one single line of
  
       <meta http-equiv=refresh content="0; 
       url=http://hood2.ei.org/eivill/plsql/switch.main">

    */
    len = 32 + strlen(rip->base_url) + 10;
    base_str = Smalloc(len + 1);
    snprintf(base_str, len+1, "<HTML><HEAD>\n<BASE href=\"%s\"></HEAD>\n<BODY>\n", 
	     rip->base_url);

    len = strlen(base_str) + strlen(buf);

    *new_buf = Smalloc(len + 1);
    memcpy(*new_buf, base_str, strlen(base_str));
    memcpy(*new_buf + strlen(base_str), buf, strlen(buf));
    FREE_MAYBE(base_str);
    *new_buf = Srealloc(*new_buf, len + 15 + 1);
    memcpy(*new_buf+len, "</BODY></HTML>\n", 15);
    (*new_buf)[len+15] = '\0';    
    len = strlen(*new_buf);
    time(&ct);
    log_err(ct, aip, rip, "Missing <HTML> and <HEAD> in the html file.");
    return len;
  }
}

static int
is_first_term(const char *buf, const char *func_name)
{
  char *p, *t_buf, *q, *arg_name;
  /* Assume that a function must be defined before it can be invoked
   so that the first function name encountered is a definition. */
  if((p = strstr(buf, func_name)) != NULL) {
    /* Search for the first arg in the arg list */
    t_buf = p + strlen(func_name);
    for (; *t_buf != '(' && *t_buf != '\0'; ++t_buf);
    if(*t_buf == '\0')
      return -1;
    if(*t_buf == '(') {
      t_buf += skip_lws(t_buf);
      for (p = t_buf; *p != ')' && *p != ',' && *p != '\0'; ++p);
      if (*p == '\0')
	return -1;
      else
	arg_name = strdupdelim(++t_buf, p);
    }
    /* looking for the starting curly bracket and entering the 
     function definition block */
    t_buf = p;
    for (; *t_buf != '{' && *t_buf != '\0'; ++t_buf);
    if (*t_buf == '\0')
      return -1;
    while ((p = strstr(t_buf, arg_name)) != NULL) {
      /* Is the arg_name followed immediately after a "=" sign?
       We walk backwards now */
      for(q = --p; *q != '+' && *q != '=' && 
	    *q != ';' && *q != '{' && *q != '['; --q);
      if (*q == '+')
	/* the arg_name is not the first term */
	return 0;
      else if(*q == '=') 
	/* It is the first term following the "=" sign */
	return 1;
      else {
	/* The arg_name may be a lvalue? We skip it over */
	t_buf += strlen(arg_name);
	continue;
      }
    }
  }
}

/* BUF is scanned for LOCATION and LOCATION.HREF objects inside any
   blocks between <SCRIPT LANGUAGE="JavaScript"> and </SCRIPT>.
   Add PREFIX to the PATH on the right-hand side of the assignment 
   statement.*/
urlpos *
mod_js_loc(const char *buf, int bufsize, accept_info *aip, relay_info *rip,
	   form_select_t *fselect[], int *fs_size)
{
  int i = 0;
  const char *buf_start = buf;
  const char *p1, *p2, *p, *q;
  urlpos *first, *current, *old;

  first = current = old = NULL;

  /* A page can contain multiple <SCRIPT></SCRIPT> pairs */
  while ((p1 = find_first_token(buf, "<SCRIPT")) != NULL) {
    /* Skip over <script language="JavaScript"> */
    bufsize -= (p1 - buf + 29);
    buf = p1 + 29;
    q = find_first_token(buf, "</SCRIPT>");
    if (q != NULL) {
      /* server = "http://host" was seen in STOREcology site */
      while (((p2 = strstr(buf, "window.location")) != NULL ||
	      (p2 = strstr(buf, "window.open")) != NULL ||
	      (p2 = strstr(buf, "parent.open")) != NULL ||
	      (p2 = strstr(buf, "location")) != NULL ||
	      (p2 = strstr(buf, "this.href")) != NULL ||
	      (p2 = strstr(buf, "new Option")) != NULL)
	     && p2 < q && bufsize) {
	char *value = NULL;
	char *new_location = NULL;
	int size, new_size;
	if(*p2 == 'l' || *p2 == 't') {
	  /* Get a "location" or "this.href". Go over it */
	  if(*p2 == 'l') {
	    bufsize -= (p2 - buf + 8);
	    buf = p2 + 8;
	  } else if(*p2 == 't') {
	    bufsize -= (p2 - buf + 9);
	    buf = p2 + 9;
	  }
	  /* Look for the "=" first, make sure location is on left-hand side */
	  for (p=buf; bufsize && *buf != '=' && *buf != ';' && *buf != '\0' &&
		 *buf != '+' && *buf != '}' && *buf != ','; buf++, bufsize--);
	  if(*buf != '=' || !bufsize || *buf == '\0') {
	    /* The location is on the right hand side of the equal sign */
	    continue;
	  }
	  if(*buf == '=') {
	    /* Got the "=" sign. Look for the ';', ',', the end of the
	       statement */
	    /*for (p = ++buf; bufsize && *buf != ';' && *buf != '}' &&
		   *buf != ')' && *buf != ',' && *buf != '\0'; 
		   Look for ')' is not good, e.g., in 
		location = "http:" + ... + escape(Bterm) + ... ;   */

	    /* Make sure it is not in a conditional statement */
	    
	    if( (*(buf-1) == '!' && *(buf) == '=') || 
		(*(buf) == '=' && *(buf+1) == '=')) {
	      continue;
	    }

	    for (p = ++buf; bufsize && *buf != ';' && *buf != '}' &&
		   *buf != ',' && *buf != '\0'; 
		 buf++, bufsize--);
	    if(!bufsize || *buf == '\0')
	      continue;
	    if(*buf == ',') {
	      /* ',' means we have a list of arguments inside window.open()*/
	      continue;
	    }
	    /* A JavaScript statement in a block may miss a ';' sign. This
	       kind of feature is seen in Swetscan's JavaScripts. */
	    p += skip_lws(p);
	    value = strdupdelim(p, buf);
	    size = buf - p;

	    /* Is there something like in Human Molecular Genetics?

	       location = document.FORMname.SELECTname.options[index].value;
	    */
	    if(!strncasecmp(value, "document.", 9) && 
	       strstr(value, ".options[") != NULL &&
	       strstr(value, "].value") != NULL && *p2 == 'l') {
	      rip->fix_opt_value = 1;
	      fselect[i] = Smalloc(sizeof(form_select_t));
	      memset(fselect[i], 0, sizeof(form_select_t));
	      for(p = value + 9; *value != '\0' && *value != '.'; ++value);
	      if(*value == '.') {
		fselect[i]->formname = strdupdelim(p, value);
		for(p = value + 1; *value != '[' && *value != '\0' && 
		      *value != '.'; ++value);
		if(*value == '.') 
		  fselect[i]->selectname = strdupdelim(p, value);
		else {
		  rip->fix_opt_value = 0;
		  FREE_MAYBE(fselect[i]->formname);
		  FREE_MAYBE(fselect[i]->selectname);
		  FREE_MAYBE(fselect[i]);
		  continue;
		}
		++i;
		continue;
	      } else {
		rip->fix_opt_value = 0;
		FREE_MAYBE(fselect[i]->formname);
		FREE_MAYBE(fselect[i]->selectname);
		FREE_MAYBE(fselect[i]);
		continue;
	      }
	    }
	  } else {
	    continue;
	  }
	} else if (*p2 == 'n') {
	  /* Am Imago: some var = new Option("name", "value");
	     where value can be a URL */
	  bufsize -= (p2 - buf + 10);
	  buf = p2 + 10;
	  /* Look for "(" */
	  for (; bufsize && *buf != '(' && *buf != '\0'; buf++, bufsize--);
	  if(*buf == '(') {
	    /* Got the "(" sign. */
	    /* Look for the first '\"' or '\'' */
	    for (; bufsize && *buf != '\"' && *buf != '\'' && *buf != ')' &&
		   *buf != '\0'; buf++, bufsize--);
	    if(*buf == '\"') {
	      /* Look for the 2nd quote */
	      for (buf++; bufsize && *buf != '\"' && *buf != ')' &&
		     *buf != '\0'; buf++, bufsize--);
	      if(*buf == '\"') {
		/* There must be a comma */
		for (; bufsize && *buf != ',' && *buf != ')' &&
		       *buf != '\0'; buf++, bufsize--);
		if(*buf == ',') {
		  /* Get the second arg in new Option(arg1, arg2)
		   */
		  for (p = ++buf; bufsize && *buf != ')'
			 && *buf != '\0'; buf++, bufsize--);
		  if(!bufsize || *buf == '\0')
		    continue;
		  p += skip_lws(p);
		  value = strdupdelim(p, buf);
		  size = buf - p; 
		} else
		  continue;
	      } else if (*buf == '\'') {
		/* Look for the 2nd quote */
		for (buf++; bufsize && *buf != '\'' && *buf != ')' &&
		       *buf != '\0'; buf++, bufsize--);
		/* There must be a comma */
		for (; bufsize && *buf != ',' && *buf != ')' &&
		       *buf != '\0'; buf++, bufsize--);
		if(*buf == ',') {
		  /* Get the second arg in new Option(arg1, arg2)
		   */
		  for (p = ++buf; bufsize && *buf != ')'
			 && *buf != '\0'; buf++, bufsize--);
		  if(!bufsize || *buf == '\0')
		    continue;
		  p += skip_lws(p);
		  value = strdupdelim(p, buf);
		  size = buf - p; 
		} else
		  continue;
	      } else 
		continue;
	    } else
	      continue;
	  } else
	    continue;
	} else if (*p2 == 'w' || *p2 == 'p') {
	  if(*(p2+7) == 'o') {
	    bufsize -= (p2 - buf + 11);
	    buf = p2 + 11;
	  } else if (*(p2+7) == 'l') {
	    bufsize -= (p2 - buf + 15);
	    buf = p2 + 15;
	  }
	  /* Look for "(" or "=" which ever appears first */
	  for (; bufsize && *buf != '(' && *buf != '=' && 
		 *buf != '\0'; buf++, bufsize--);
	  if(*buf == '(') {
	    /* Got the "(" sign. Look for ")" */
	    for (p = ++buf; bufsize && *buf != ')' && *buf != '\0';
		 buf++, bufsize--);
	    if(!bufsize || *buf == '\0')
	      continue;
	    p += skip_lws(p);
	    value = strdupdelim(p, buf);
	    size = buf - p; 
	  } else if (*buf == '=') {
	    /* See, e.g., in American Imago:
	       window.location = "indexold.html" */
	    if( (*(buf-1) == '!' && *(buf) == '=') || 
		(*(buf) == '=' && *(buf+1) == '=')) {
	      continue;
	    }

	    for (p = ++buf; bufsize && *buf != ';' && *buf != '}' &&
		   *buf != ',' && *buf != '\0'; 
		 buf++, bufsize--);
	    if(!bufsize || *buf == '\0')
	      continue;
	    if(*buf == ',') {
	      /* ',' means we have a list of arguments inside window.open()*/
	      continue;
	    }
	    /* A JavaScript statement in a block may miss a ';' sign. This
	       kind of feature is seen in Swetscan's JavaScripts. */
	    p += skip_lws(p);
	    value = strdupdelim(p, buf);
	    size = buf - p; 	    
	  } else {
	    continue;
	  }
	}
	if(debug > 3)
	  fprintf(stderr, "Original Location Obj=%s\n", value);
	get_new_location(value, size, aip, rip, 
			 &new_location, &new_size);
	if(debug > 3)
	  fprintf(stderr, "\nNew Location Obj=%s\n", new_location);
	old = current;
	current = (urlpos *)Smalloc(sizeof(urlpos));
	if (old != NULL)
	  old->next = current;
	if(first == NULL)
	  first = current;
	memset(current, 0, sizeof(urlpos));
	current->next = NULL;
	current->url = xstrdup(new_location);
	current->old_size = size;
	current->new_size = new_size;
	current->pos = p - buf_start;
	FREE_MAYBE(value);
	FREE_MAYBE(new_location);
      }
    }
  }
  if(rip->fix_opt_value == 1 && i > 0)
    *fs_size = i;
  else
    *fs_size = 0;
  return first;
}

/* BUF is scanned for a lvalue inside any blocks between <SCRIPT LANGUAGE=
   "JavaScript"> and </SCRIPT>, which does not contain any LOCATION and 
   LOCATION.HREF objects. If that lvalue is assigned a
   value on the r.h.s, which is an absolute URL or an absolute path, we
   substitute them. */
urlpos *
mod_urls_js(const char *obuf, int bufsize, accept_info *aip, relay_info *rip)
{
  const char *buf = obuf;
  const char *p1, *p2, *p3, *p4, *q;
  char *var1, *var;
  char *value = NULL;
  char *new_url = NULL;
  int size, new_size;

  urlpos *first, *current, *old;

  first = current = old = NULL;

  /* A page can contain multiple <SCRIPT></SCRIPT> pairs */


  while ((p1 = find_first_token(buf, "<SCRIPT")) != NULL) {
    /* Skip over <script language="JavaScript" */
    bufsize -= (p1 - buf + 28);
    buf = p1 + 28;
    /* There must be a ">" */
    for (++buf; *buf != '>' && *buf != '\0' && *buf != '<' && bufsize > 0;
	 --bufsize, ++buf);
    if(*buf == '<' || *buf == '\0' || bufsize <= 0)
      break;

    q = find_first_token(buf, "</SCRIPT>");

    if(q != NULL) {
      if(debug > 3)
	fprintf(stderr, "Initial p1=%x, Buf=%x, q=%x\n", p1, buf, q);

      while ((buf < q) && bufsize > 0) {
	/* Search for "http://......" or "/....." */
	for (; *buf != '\"' && *buf != '\'' && buf < q && bufsize > 0;
	     --bufsize, ++buf);
	if(*buf == '\"' || *buf == '\'') {
	  /* See if there are "http://......" or "/....." at the 
	     start of this quoted string */
	  p2 = buf; /* Recording the start quote */
	  ++buf;
	  if(strncasecmp(buf, "http://", 7) && *buf != '/') {
	    if (*p2 == '\"') {
	      for (; *buf != '\"' && buf < q && bufsize > 0;
		   --bufsize, ++buf);
	      if(*buf != '\"')
		/* Quotes are not paired properly. */
		break;
	      else {
		++buf;
		--bufsize;
		continue;
	      }
	    } else  if (*p2 == '\'') {
	      for (; *buf != '\'' && buf < q && bufsize > 0;
		   --bufsize, ++buf);
	      if(*buf != '\'')
		/* Quotes are not paired properly. */
		break;
	      else {
		++buf;
		--bufsize;
		continue;
	      }
	    }
	  } else {
	    /* Get the ending quote */
	    if(*p2 == '\"')
	      for (++buf; *buf != '\"' && *buf != ';' && 
		     *buf != '}' && *buf != ')' && buf < q && bufsize > 0;
		   --bufsize, ++buf);
	    else if(*p2 == '\'')
	      for (++buf; *buf != '\'' && *buf != ';' && 
		     *buf != '}' && *buf != ')' && buf < q && bufsize > 0;
		   --bufsize, ++buf);
	    if((*p2 == '\"' && *buf == '\"') || (*p2 == '\'' && *buf == '\'')){
	      /* Got the ending quote. p4 stores starting position of 
		 the old URL */
	      p4 = p2 + 1;
	      p4 += skip_lws(p4);

	      if(debug > 3)
		fprintf(stderr, "Buf=%x, q=%x\n", buf, q);

	      value = strdupdelim(p4, buf);
	      size = strlen(value);
	      ++buf;
	      --bufsize;
	    } else {
	      ++buf;
	      --bufsize;
	      continue;
	    }
	    /* Walk backwards to grab the l.h.s. var. p2 still at
	     the starting quote of the URL value, while buf remains
	     pointing to the ending quote. p3 will point to p2 */

	    /* Find the first legitimate "=" sign, otherwise, skip it over.
	     If we get a "+" sign before "=", that means this is not
	     the first term, and we should skip it too. */
	    for(p3=p2; *p2 != '=' && *p2 != '+' && *p2 != ';' && 
		  *p2 != '{' && *p2 != '(' && *p2 != ')' && *p2 != '>' && 
		  *p2 != '<' && *p2 != '\n' && p2 != p1; --p2);
	    if(*p2 != '=')
	      continue;

	    /* Make sure it is not in a conditional statement */
	    if( (*(p2-1) == '!' && *(p2) == '=') || 
		(*(p2-1) == '=' && *(p2) == '=') ||
		(*(p2-1) == '<' && *(p2) == '=') ||
		(*(p2-1) == '>' && *(p2) == '='))
	      continue;

	    /* looking for the lvalue var on the l.h.s. A variable can only 
	       contain letters, digits, _, and $ */
	    for(p3=p2, --p2; *p2 != '_' && *p2 != '$' && !ISDIGIT(*p2) && 
		!ISALPHA(*p2) && *p2 != ';' && *p2 != '{' && 
		*p2 != '(' && *p2 != '>' && *p2 != '<' && *p2 != '\n' && 
		p2 != p1; --p2);
	    if(*p2 != '_' && *p2 != '$' && !ISDIGIT(*p2) && !ISALPHA(*p2))
	      /* Not found legitimate var */
	      continue;
	    for(--p2; *p2 != ' ' && *p2 != ';' && *p2 != '{' &&
		  *p2 != '(' && *p2 != '>' && *p2 != '\n' && p2 != p1; --p2);
	    if(p2 == p1)
	      continue;
	    var1 = strdupdelim(p2 + 1, p3);
	    var1 += skip_lws(var1);
	    /* get rid of trailing white space */ 
	    for(p2 = var1, p3 = var1; *p3 != ' ' && *p3 != '\t' 
		  && *p3 != '\0'; ++p3);
	    var = strdupdelim(p2, p3);
	    FREE_MAYBE(var1);
	    if(((p2 = strstr(var, "window.location")) != NULL ||
		(p2 = strstr(var, "window.open")) != NULL ||
		(p2 = strstr(var, "location")) != NULL ||
		(p2 = strstr(var, "this.href")) != NULL))
	      /* These objects are delt with in mod_js_loc() */
	      continue;
	    else {
	      if(debug > 3)
		fprintf(stderr, "Original URL=%s\n", value);
	      get_new_url(value, size, aip, rip, 
			  &new_url, &new_size);
	      if(debug > 3)
		fprintf(stderr, "\nNew URL=%s\n", new_url);
	      old = current;
	      current = (urlpos *)Smalloc(sizeof(urlpos));
	      if (old != NULL)
		old->next = current;
	      if(first == NULL)
		first = current;
	      memset(current, 0, sizeof(urlpos));
	      current->next = NULL;
	      current->url = xstrdup(new_url);
	      current->old_size = size;
	      current->new_size = new_size;
	      current->pos = p4 - obuf;
	      FREE_MAYBE(value);
	      FREE_MAYBE(new_url);
	    }
	  }
	} else { /* no quotes are found */
	  ++buf;
	  --bufsize;
	  continue;
	}
      } /* while (buf < q) */
    } else {
      /* There is no </script> to end the <script language="JavaScript"> */
      break;
    }
  }
  return first;
}

/* BUF is scanned for <FORM><SELECT><OPTION VALUE="..." and values are
   substituted, if rip->fix_opt_value is set to 1.*/
urlpos *
mod_urls_opt(const char *buf, int bufsize, accept_info *aip, relay_info *rip,
	     form_select_t *fselect[], int fs_size)
{
  const char *p, *q, *obuf = buf;
  int i;
  char *formname = NULL;
  char *selectname = NULL;
  char *value = NULL;
  char *new_url = NULL;
  int size, new_size;

  urlpos *first, *current, *old;

  first = current = old = NULL;

  while ((p = find_first_token(buf, "<FORM ")) != NULL) {
    p += 6;
    /* Look for 'n' or 'N' in "name" or "NAME" */
    for(buf = p; *buf != 'n' && *buf != 'N' && *buf != '>' &&
          *buf != '\n' && *buf != '\0'; ++buf);
    if(*buf == 'n' || *buf == 'N') {
      if(!strncasecmp(p, "name", 4)) {
        p += 4;
        /* Look for '=' */
        for(buf = p; *buf != '=' && *buf != '\"' &&
              *buf != '\'' && *buf != ',' && *buf != '>' &&
              *buf != '\n' && *buf != '\0'; ++buf);
        if(*buf == '=') {
          /* Look for leading quote for formname */
          for(buf = p; *buf != '\"' && *buf != '\'' &&
                *buf != ',' && *buf != '>' &&
                *buf != '\n' && *buf != '\0'; ++buf);
          if(*buf == '\"' || *buf == '\'') {
            p = buf;
            /* Look for ending quote for formname */
            for(buf = p + 1; *buf != '\"' && *buf != '\'' &&
                  *buf != ',' && *buf != '>' &&
                  *buf != '\n' && *buf != '\0'; ++buf);
            if(*buf == '\"' && *p == '\"' ||
               *buf == '\'' && *p == '\'') {
              FREE_MAYBE(formname);
              formname = strdupdelim(p + 1, buf);
              for(i = 0; i < fs_size; ++i)
                if(!strncasecmp(formname, fselect[i]->formname,
                                 strlen(fselect[i]->formname)))
                  break;
              if(i < fs_size) {
                FREE_MAYBE(selectname);
                /* Look for <select and </select pair */
                while((p=find_first_token(buf, "<SELECT ")) != NULL) {
                  p += 8;
                  /* Look for 'n' or 'N' in "name" or "NAME" */
                  for(buf = p; *buf != 'n' && *buf != 'N' && *buf != '>' &&
                        *buf != '\n' && *buf != '\0'; ++buf);
                  if(*buf == 'n' || *buf == 'N') {
                    if(!strncasecmp(buf, "name", 4)) {
                      /* Look for '=' */
                      for(buf += 4; *buf != '=' && *buf != '\"' &&
                            *buf != '\'' && *buf != ',' && *buf != '>' &&
                            *buf != '\n' && *buf != '\0'; ++buf);
                      if(*buf == '=') {
                        /* Look for starting quote for selectname */
                        for(buf += 1; *buf != '\"' && *buf != '\'' &&
                              *buf != ',' && *buf != '>' &&
                              *buf != '\n' && *buf != '\0'; ++buf);
                        if(*buf == '\"' || *buf == '\'') {
			  p = buf;
                          /* Look for ending quote for selectname */
                          for(buf = p + 1; *buf != '\"' && *buf != '\'' &&
                                *buf != ',' && *buf != '>' &&
                                *buf != '\n' && *buf != '\0'; ++buf);
                          if(*buf == '\"' && *p == '\"' ||
                             *buf == '\'' && *p == '\'') {
                            selectname = strdupdelim(p + 1, buf);
                            if(strncasecmp(selectname, fselect[i]->selectname,
                                           strlen(fselect[i]->selectname))) {
                              FREE_MAYBE(formname);
                              FREE_MAYBE(selectname);
                              break;
			    }
                            FREE_MAYBE(formname);
                            FREE_MAYBE(selectname);
			    q = find_first_token(buf, "</SELECT>");
                            if(q != NULL) {
			    SELECTOPTION:
                              while((p=find_first_token(buf, "<OPTION VALUE")) != NULL && p < q) {
                                /* Look for '=' */
                                for(buf += 13; *buf != '=' && *buf != '\"' &&
                                      *buf != '\'' && *buf != ',' && 
				      *buf != '>' &&
                                      *buf != '\n' && *buf != '\0'; ++buf);
                                if(*buf == '=') {
                                  /* Look for starting quote for value */
                                  for(buf += 1; *buf != '\"' && *buf != '\'' &&
                                        *buf != ',' && *buf != '>' &&
                                        *buf != '\n' && *buf != '\0'; ++buf);
                                  if(*buf == '\"' || *buf == '\'') {
                                    p = buf;
                                    /* Look for ending quote for value */
                                    for(buf = p + 1; *buf != '\"' && 
					  *buf != '\'' &&
                                          *buf != ',' && *buf != '>' &&
                                          *buf != '\n' && *buf != '\0'; ++buf);
                                    if(*buf == '\"' && *p == '\"' ||
                                       *buf == '\'' && *p == '\'') {
                                      p += 1;
                                      size = buf - p;
                                      if(size > 0) {
					p += skip_lws(p);
					value = strdupdelim(p, buf);
					if(debug > 3)
					  fprintf(stderr, "\nOld optURL=%s\n", value);
					
					get_new_url(value, size, aip, rip, 
						    &new_url, &new_size);
					if(debug > 3)
					  fprintf(stderr, "\nNew OptURL=%s\n", new_url);
					old = current;
					current = (urlpos *)Smalloc(sizeof(urlpos));
					if (old != NULL)
					  old->next = current;
					if(first == NULL)
					  first = current;
					memset(current, 0, sizeof(urlpos));
					current->next = NULL;
					current->url = xstrdup(new_url);
					current->old_size = size;
					current->new_size = new_size;
					current->pos = p - obuf;
					FREE_MAYBE(value);
					FREE_MAYBE(new_url);
				      } else
					continue;
                                    } else
				      continue;
                                  } else
                                    continue;
                                } else
                                  continue;
                              }
                            } else
                              /* <select> is not paired with </select> */
                              break;
                          } else
                            /* Quotes are not paired */
			    break;
                        } else
                          /* No leading quote */
                          break;
                      } else
                        /* No '=' sign for name */
			break;
                    } else
                      /* No select name */
		      break;
		  } else
		    /* No select name */
		    continue;
		} /* while(...<SELECT... */
	      } else
		/* This form doesn't match any FORM NAME, look for the next for\
m */
		continue;
	    } else
	      /* Quotes are not paired */
	      break;
	  } else
	    /* No leading quote */
	    break;
	} else
	  /* No '=' sign for name */
	  break;
      } else
	/* No name field for this form, look for the next form */
	continue;
    } else
      /* No name field for this form, look for the next form */
      continue;
  } /* Gone through all the FORMs */
  return first;
}


/* BUF is scanned for LOCATION, LOCATION.HREF, THIS.HREF objects inside any
   block of JavaScript statements of an event_handler.
   Add PREFIX to the PATH on the right-hand side of the assignment 
   statement, for things like, location... = ..., this.href = ..., 
   and window.open(..., ...) */
urlpos *
mod_js_event(const char *buf, accept_info *aip, relay_info *rip)
{
  js_event_t *s;
  const char *pbuf;
  int buflen;
  int size = 0;
  urlpos *first, *current, *old;
  /*time_t ct;*/
  
  s = (js_event_t *)Smalloc(sizeof(js_event_t));
  memset(s, 0, sizeof(js_event_t));

  first = current = old = NULL;

  buflen = strlen(buf);

  /* Iterate over the event_handlers in BUF, 
     picked by find_event_handler(). */
  for (pbuf = buf; (pbuf = 
		    find_event_handler(pbuf, buflen - (pbuf - buf), 
				       &size, s)) != NULL; 
       pbuf += size) {
    int skip_blanks;
    const char *p, *q;
    int ssize = size;

    /* Set a boundary at the end of the event_handler block */
    q = pbuf + size - 1;

    for (skip_blanks = 0; ISSPACE (pbuf[skip_blanks]) && skip_blanks < size;
	 skip_blanks++);

    ssize -= skip_blanks;

    /* An event_handler can contain "location" etc. where we have to 
       remap them to our relay server */
    while ((((p = strstr(pbuf, "window.location")) != NULL) ||
	   ((p = strstr(pbuf, "window.open")) != NULL) ||
	   ((p = strstr(pbuf, "location")) != NULL) ||
	   ((p = strstr(pbuf, "this.href")) != NULL)) &&
	   p < q && ssize) {
      char *value = NULL;
      char *new_location = NULL;
      int old_size, new_size;

      if(*p == 'l' || *p == 't') {
	/* Get a "location" or "this.href". Go over it */
	if(*p == 'l') {
	  ssize -= (p - pbuf + 8);
	  pbuf = p + 8;
	} else if(*p == 't') {
	  ssize -= (p - pbuf + 9);
	  pbuf = p + 9;
	}
	/* Look for the "=" first, make sure location is on left-hand side.
	   '\"', ';', and possibly '}' are the end of a statement */
	for (; ssize && *pbuf != '=' && *pbuf != ',' && *pbuf != '\0' &&
	       *pbuf != '\"' && *pbuf != '\'' && *pbuf != ';' && 
	       *pbuf != '}'; pbuf++, ssize--);
	if(*pbuf == '\"' || *pbuf == ';' || *pbuf == '}' || *pbuf == ','
	   || *pbuf == '\'' || *pbuf == '\0' || !ssize) {
	  /* The location is on the right hand side of the equal sign */
	  continue;
	}
	if(*pbuf == '=') {
	  /* Got the "=" sign. Look for ''' */
	  /* Got the "=" sign. Look for ';', and other end of the
	     statement sign */
	  for (p = ++pbuf; ssize && *pbuf != '\"' && *pbuf != ',' &&
		 *pbuf != ';' && *pbuf != '\0' && *pbuf != '}'; 
	       pbuf++, ssize--);
	  if(!ssize || *pbuf == ',' || *pbuf == '\0')
	    continue;
	  /* A JavaScript statement in a block may miss a ';' sign. This
	     kind of feature is seen in Swetscan's JavaScripts. */
	  value = strdupdelim(p, pbuf);
	  old_size = pbuf - p; 
	} else {
	  continue;
	}
      } else if (*p == 'w') {
	ssize -= (p - pbuf + 11);
	pbuf = p + 11;
	/* Look for "(" first */
	for (; ssize && *pbuf != '(' && *pbuf != '\0'; pbuf++, ssize--);
	if(*pbuf == '(') {
	  /* Got the "(" sign. Look for ")" */
	  for (p = ++pbuf; ssize && *pbuf != ')' && *pbuf != '\0';
	       pbuf++, ssize--);
	  if(!ssize || *pbuf == '\0')
	    continue;
	  value = strdupdelim(p, pbuf);
	  old_size = pbuf - p; 
	} else {
	  continue;
	}
      }
      get_new_location(value, old_size, aip, rip, 
		       &new_location, &new_size);
      old = current;
      current = (urlpos *)Smalloc(sizeof(urlpos));
      if (old != NULL)
	old->next = current;
      if(first == NULL)
	first = current;
      memset(current, 0, sizeof(urlpos));
      current->next = NULL;
      current->url = xstrdup(new_location);
      current->old_size = old_size;
      current->new_size = new_size;
      current->pos = p - buf;
      FREE_MAYBE(value);
      FREE_MAYBE(new_location);
    }
  }
  FREE_MAYBE(s->tag);
  FREE_MAYBE(s->event_handler);
  FREE_MAYBE(s);

  return first;
}

/* Add ar_prefix to the old relative URL (usually an absolute PATH)
 * The BUF is the old URL and bufsize is the length of that URL
 */
void get_new_url(char *buf, int size,  accept_info *aip, 
		 relay_info *rip, char **new_url, int *new_size)
{
  int len, len_myhost;
  char portstr1[MAXNAME], portstr2[MAXNAME];
  struct urlinfo *u;
  char str[MAXNAME];
  char *ar_prefix, *ar_rel_prefix;
  time_t ct;

  /* ar_prefix is a base of the relay server URL address. We intend to
     add this to relative URLs with a leading slash,
     and to replace the targethost with it. */ 
  snprintf(portstr1, MAXNAME, "%d", aip->relay_port);
  snprintf(portstr2, MAXNAME, "%d", rip->redir_targetport);

  len_myhost = strlen(aip->relay_hostname);

  if(rip->redirect_flag && rip->redir_targethost != NULL && 
     rip->redir_targetpath != NULL) {

    /* After authentication, there must be a rip->seskey non-NULL */
    len = 7 + len_myhost + 1 + strlen(portstr1) + 1 + 
      strlen(rip->seskey) + 1 + strlen(rip->redir_targethost) + 1 +
      strlen(portstr2) + 1;
    ar_prefix = (char *) Smalloc(len + 1);
    snprintf(ar_prefix, len+1, "http://%s:%s/%s=%s:%s/", 
	     aip->relay_hostname, portstr1,
	     rip->seskey, rip->redir_targethost, portstr2);
    /* the targetdir has a leading slash */
    ar_rel_prefix = add_prefix(ar_prefix, len, rip->redir_targetdir,
			       strlen(rip->redir_targetdir));
    len = strlen(ar_rel_prefix);
    if(ar_rel_prefix[len - 1] != '/') {
      ar_rel_prefix = Srealloc(ar_rel_prefix, len + 1 + 1);
      snprintf(ar_rel_prefix + len, len+2, "/");
    } 
  } else {
    /* BASE URL has higher precedence over others. Especially true when
     the original page does have a <BASE href=".."> included. */
    if(rip->has_base > 0 && rip->base_url != NULL) {
      /* Parse base_url and put useful info into urlinfo struct */
      u = newurl ();
      if ( parseurl(rip->base_url, u, 0) != URLOK ) {
	/* Bad URL in this link, forget it */
	freeurl (u, 1); 
	time(&ct);
	log_err(ct, aip, rip, "Base URL is BAD.");
	return;
      }

      snprintf(str, MAXNAME, "%d", u->port);
      len = 7 + len_myhost + 1 + strlen(portstr1) + 1 + 
	strlen(rip->seskey) + 
	1 + strlen(u->host) + 1 + strlen(str) + 1;
      ar_prefix = (char *) Smalloc(len + 1);
      snprintf(ar_prefix, len+1, "http://%s:%s/%s=%s:%s/",
	       aip->relay_hostname, portstr1, rip->seskey,
	       u->host, str);
      /* the u->dir has a leading slash */
      ar_rel_prefix = add_prefix(ar_prefix, len, u->dir,
				 strlen(u->dir));
      len = strlen(ar_rel_prefix);
      if(ar_rel_prefix[len - 1] != '/') {
	ar_rel_prefix = Srealloc(ar_rel_prefix, len + 1 + 1);
	snprintf(ar_rel_prefix + len, len+2, "/");
      }
      freeurl(u, 1);
    } else { 
      /* This block may not be needed, because rip->base_url is always
	 available after mod_urls_html() call. */
      len = 7 + len_myhost + 1 + strlen(portstr1) + 1 + 
	strlen(rip->seskey) + 1;
      ar_prefix = (char *) Smalloc(len + 1);
      snprintf(ar_prefix, len+1, "http://%s:%s/%s/", aip->relay_hostname, 
	       portstr1, rip->seskey);
      /* the targetdir has a leading slash */
      ar_rel_prefix = add_prefix(ar_prefix, len, rip->targetdir,
				 strlen(rip->targetdir));
      len = strlen(ar_rel_prefix);
      if(ar_rel_prefix[len - 1] != '/') {
	ar_rel_prefix = Srealloc(ar_rel_prefix, len + 1 + 1);
	snprintf(ar_rel_prefix + len, len+2, "/");
      }
    }
  }
  
  if(!strncasecmp(buf, "http://", 7)) {
    int i;
    char *ar_other_prefix, *path;
    /* This is an absolute URL */

    u = newurl ();
    if ( parseurl(buf, u, 0) != URLOK ) {
      freeurl (u, 1); 
      if(buf[7] != '\0' || strlen(buf) > 7) {
	time(&ct);
	log_err(ct, aip, rip, "URL is BAD.");
      }
      /* URL may not contain even a host, because it is simply a prefix
	 followed by other javascript var or string literals, e.g., in
	 Literature Online site we see:

	 location.href = "http://" + somehost + ":" + ......
	 We should retain the old URL. */
      *new_url = xstrdup(buf);
      *new_size = strlen(*new_url);
      return;
    }
    /* If u->host and u->port point to our relay host and port, we should
       not do substitution. This can happen when using writeln statements
       inside <SCRIPT></SCRIPT> pair like in AmImago site, because the
       URLs are already been substituted in the previous run. */
    if(!strncasecmp(u->host, aip->relay_hostname, len_myhost) &&
       u->port == aip->relay_port) {
      *new_url = xstrdup(buf);
      *new_size = strlen(*new_url);
      return;
    }

    snprintf(str, MAXNAME, "%d", u->port);
    len = 7 + len_myhost + 1 + strlen(portstr1) + 1 + 
      strlen(rip->seskey) + 
      1 + strlen(u->host) + 1 + strlen(str) + 1;
    ar_other_prefix = (char *) Smalloc(len + 1);
    snprintf(ar_other_prefix, len+1, "http://%s:%s/%s=%s:%s/",
	     aip->relay_hostname, portstr1, rip->seskey,
	     u->host, str);
    /* Skip over any leading slashes */
    for (i = 0; u->path[i] && u->path[i] == '/'; i++);
	
    /* Make a copy of u->path without a leading slash */
    path = xstrdup(u->path + i);
	
    /* Form a new link from ar_other_prefix and path. */
	
    if ( *path == '\0' ) {
      len = strlen(ar_other_prefix);
      *new_url = (char *)Smalloc(len + 1);
      snprintf(*new_url, len+1, "%s", ar_other_prefix);
    } else {
      *new_url = add_prefix(ar_other_prefix, strlen(ar_other_prefix),
			  path, strlen(path));
    }
    FREE_MAYBE (path);
    FREE_MAYBE (ar_other_prefix);
    freeurl (u, 1);
  } else if (*buf == '/') {
    *new_url = add_prefix(ar_prefix, strlen(ar_prefix),
			  buf, strlen(buf));
  } else
    return;
  *new_size = strlen(*new_url);
  return;
}

/* Add ar_prefix to the old relative URL (usually an absolute PATH)
 * The BUF is the old URL and bufsize is the length of that URL
 */
void get_new_location(char *buf, int bufsize, accept_info *aip,
		      relay_info *rip, char **new_location, 
		      int *new_size)
{
  char *p, *q, *buf_start = buf;
  int len, len_myhost, n_iterate;
  char portstr1[MAXNAME], portstr2[MAXNAME];
  struct urlinfo *u;
  char str[MAXNAME];
  char *ar_prefix, *ar_rel_prefix;
  time_t ct;

  /* ar_prefix is a base of the relay server URL address. We intend to
     add this to relative URLs with a leading slash,
     and to replace the targethost with it. */ 
  snprintf(portstr1, MAXNAME, "%d", aip->relay_port);
  snprintf(portstr2, MAXNAME, "%d", rip->redir_targetport);

  len_myhost = strlen(aip->relay_hostname);

  if(rip->redirect_flag && rip->redir_targethost != NULL && 
     rip->redir_targetpath != NULL) {

    /* After authentication, there must be a rip->seskey non-NULL */
    len = 7 + len_myhost + 1 + strlen(portstr1) + 1 + 
      strlen(rip->seskey) + 1 + strlen(rip->redir_targethost) + 1 +
      strlen(portstr2) + 1;
    ar_prefix = (char *) Smalloc(len + 1);
    snprintf(ar_prefix, len+1, "http://%s:%s/%s=%s:%s/", 
	     aip->relay_hostname, portstr1,
	     rip->seskey, rip->redir_targethost, portstr2);
    /* the targetdir has a leading slash */
    ar_rel_prefix = add_prefix(ar_prefix, len, rip->redir_targetdir,
			       strlen(rip->redir_targetdir));
    len = strlen(ar_rel_prefix);
    if(ar_rel_prefix[len - 1] != '/') {
      ar_rel_prefix = Srealloc(ar_rel_prefix, len + 1 + 1);
      snprintf(ar_rel_prefix + len, len+2, "/");
    } 
  } else {
    /* BASE URL has higher precedence over others. Especially true when
     the original page does have a <BASE href=".."> included. */
    if(rip->has_base > 0 && rip->base_url != NULL) {
      /* Parse base_url and put useful info into urlinfo struct */
      u = newurl ();
      if ( parseurl(rip->base_url, u, 0) != URLOK ) {
	/* Bad URL in this link, forget it */
	freeurl (u, 1); 
	time(&ct);
	log_err(ct, aip, rip, "Base URL is BAD.");
	return;
      }

      snprintf(str, MAXNAME, "%d", u->port);
      len = 7 + len_myhost + 1 + strlen(portstr1) + 1 + 
	strlen(rip->seskey) + 
	1 + strlen(u->host) + 1 + strlen(str) + 1;
      ar_prefix = (char *) Smalloc(len + 1);
      snprintf(ar_prefix, len+1, "http://%s:%s/%s=%s:%s/",
	       aip->relay_hostname, portstr1, rip->seskey,
	       u->host, str);
      /* the u->dir has a leading slash */
      ar_rel_prefix = add_prefix(ar_prefix, len, u->dir,
				 strlen(u->dir));
      len = strlen(ar_rel_prefix);
      if(ar_rel_prefix[len - 1] != '/') {
	ar_rel_prefix = Srealloc(ar_rel_prefix, len + 1 + 1);
	snprintf(ar_rel_prefix + len, len+2, "/");
      }
      freeurl(u, 1);
    } else { 
      /* This block may not be needed, because rip->base_url is always
	 available after mod_urls_html() call. */
      len = 7 + len_myhost + 1 + strlen(portstr1) + 1 + 
	strlen(rip->seskey) + 1;
      ar_prefix = (char *) Smalloc(len + 1);
      snprintf(ar_prefix, len+1, "http://%s:%s/%s/", aip->relay_hostname, 
	       portstr1, rip->seskey);
      /* the targetdir has a leading slash */
      ar_rel_prefix = add_prefix(ar_prefix, len, rip->targetdir,
				 strlen(rip->targetdir));
      len = strlen(ar_rel_prefix);
      if(ar_rel_prefix[len - 1] != '/') {
	ar_rel_prefix = Srealloc(ar_rel_prefix, len + 1 + 1);
	snprintf(ar_rel_prefix + len, len+2, "/");
      }
    } 
  }

  /* skip over leading linear white spaces */
  buf += skip_lws(buf);

  /* If the buf refers to "self.location" we have to change it to
     point to our relay server */
  if(!strncasecmp(buf, "self.location", 13) ||
     !strncasecmp(buf, "location.href", 13)) {
    len = 1 + strlen(ar_rel_prefix) + 1;
    *new_location = Smalloc(len + 1);
    snprintf(*new_location, len+1, "\"%s\"", ar_rel_prefix);
    *new_size = strlen(*new_location);
    FREE_MAYBE(ar_prefix);
    FREE_MAYBE(ar_rel_prefix);
    return;
  }

  /* We may not have to do much about other variables in front of the
     FIRST URL path definition that is bracketed by a pair of quotes. If the
     remote database server decides to do redirection to
     another host, they don't USUALLY have to use a
     JavaScript. A JavaScript is USUALLY used to reset a potion of
     the path in the current location.href object. But if there is only one
     variable on the r.h.s, and it is location.href, or self.location
     we will replace it. If that only var is passed from the calling
     page, its value is taken care of in mod_urls_html */
  n_iterate = 0;
Start:
  for (p = buf; bufsize && *buf != '\"' && *buf != '\'' && 
	 *buf != ',' && *buf != '\0'; buf++, bufsize--);
  if(*buf == '\0' || !bufsize) {
    if(!strncasecmp(p, "self.location", 13) ||
       !strncasecmp(p, "location.href", 13)) {
      len = 1 + strlen(ar_rel_prefix) + 1;
      *new_location = Smalloc(len + 1);
      snprintf(*new_location, len+1, "\"%s\"", ar_rel_prefix);
    } else {
      *new_location = xstrdup(buf_start);
    }
    *new_size = strlen(*new_location);
    FREE_MAYBE(ar_prefix);
    FREE_MAYBE(ar_rel_prefix);
    return;
  }
  if(*buf == ',') {
    /* This is a list of arguments inside window.open() */
    *new_location = xstrdup(buf_start);
    *new_size = strlen(*new_location);
    FREE_MAYBE(ar_prefix);
    FREE_MAYBE(ar_rel_prefix);
    return;
  }
  if(*buf == '\"' || *buf == '\'') {
    /* Got the starting quote. Mark the beginning of the value */
    q = buf;
    p = ++buf;
    /* Look for the ending quote. */
    for (; bufsize && *buf != '\"' && *buf != '\'' && 
	   *buf != '+' && *buf != '\0'; buf++, bufsize--);
    if(*buf == '+' || *buf == '\0') {
      /* Ending quote is missing */
      time(&ct);
      log_err(ct, aip, rip, "Quotes are not paird in JavaScript.");
      /* Can we tolerate this behavior?? */
      FREE_MAYBE(ar_prefix);
      FREE_MAYBE(ar_rel_prefix);
      *new_location = xstrdup(buf_start);
      *new_size = bufsize;
      return;
    }
    if((*q == '\"' && *buf == '\"') || (*q == '\'' && *buf == '\'')) {
      /* Got the ending quote */
      char *tail;
      int len1, len2, len3;
      char *old_first_path;

      old_first_path = strdupdelim(p, buf);
      tail = xstrdup(++buf);
      len2 = strlen(old_first_path);
      len3 = strlen(tail);
      old_first_path += skip_lws(old_first_path);
      if(*old_first_path == '/' && *(old_first_path + 1) != '/') {
	char *constr;
	constr = add_prefix (ar_prefix, strlen(ar_prefix), 
			     old_first_path, len2);
	len1 = strlen(constr);
	len = 1 + len1 + 1 + len3;
	*new_location = Smalloc(len + 1);
	if(*q == '\"') 
	  snprintf(*new_location, len+1, "\"%s\"%s", constr, tail); 
	else if(*q == '\'')
	  snprintf(*new_location, len+1, "\'%s\'%s", constr, tail); 
	*new_size = strlen(*new_location);
	FREE_MAYBE(constr);
	FREE_MAYBE(tail);
	FREE_MAYBE(ar_prefix);
	FREE_MAYBE(ar_rel_prefix);
	FREE_MAYBE(old_first_path);
	return;
	/* It is hard to predict that the string w/o a leading slash
	   is a path or a fragment of a path. But since it is
	   bracketed by a pair of double quotes, it cannot be a
	   variable, instead it must be a string constant. We assume this
	   string constant is a relative path at the very beginning */
      }
      if ( n_iterate == 0 && !strncasecmp(old_first_path, "//", 2) ) {
	/* Likely having something like:
	   window.opener.location.protocol+'//'
	   +window.opener.location.host+'/somedir/somefile'+res; 
	   The '//' part should be skipped over till we see the next
	   quoted string. */
	++n_iterate;
	FREE_MAYBE(old_first_path);
	goto Start;
      }
      if( strncasecmp(old_first_path, "http:", 5) &&
	  *old_first_path != ':' && *old_first_path != '/' ) {
	/*char *constr;*/
	/* This is a relative path, not a protocol. Substutite it
	   or not would not make a difference. */
	/*constr = add_prefix (ar_rel_prefix, strlen(ar_rel_prefix), 
			     old_first_path, len2);
	len1 = strlen(constr);
	len = 1 + len1 + 1 + len3;
	*new_location = Smalloc(len + 1);
	if(*q == '\"')
	  snprintf(*new_location, len+1, "\"%s\"%s", constr, tail);
	else if (*q == '\'')
	  snprintf(*new_location, len+1, "\'%s\'%s", constr, tail);*/
	len1 = strlen(old_first_path);
	len = 1 + len1 + 1 + len3;
	*new_location = Smalloc(len + 1);
	if(*q == '\"')
	  snprintf(*new_location, len+1, "\"%s\"%s", old_first_path, tail);
	else if (*q == '\'')
	  snprintf(*new_location, len+1, "\'%s\'%s", old_first_path, tail);
	*new_size = strlen(*new_location);
	/*FREE_MAYBE(constr);*/
	FREE_MAYBE(tail);
	FREE_MAYBE(ar_prefix);
	FREE_MAYBE(ar_rel_prefix);
	FREE_MAYBE(old_first_path);
	return;
      } 
      if( !strncasecmp(old_first_path, "http://", 7) &&
	  strlen(old_first_path) == 7 ) {
	/* "http://" + location.hostname + ":" + location.port + var ...
	   "http://" + location.hostname + var ...
	   or "http://" + location.host + "/path"...,
	   or "http://" + this.location.host + "/path"...
	   must be replaced with ar_prefix and get rid of + location.hostname 
	   ":" + location.port, or location.host, altogether */
	/* Look for next '+' */
	buf += skip_lws(buf);
	for(p=buf; bufsize && *buf != '\0' && *buf != '+'; buf++, bufsize--);
	/* There must be a '+' */
	if(*buf == '+') {
	  buf++;
	  buf += skip_lws(buf);
	  if(!strncasecmp(buf, "location.hostname", 17)) {
	    for(p=buf; bufsize && *buf != '\0' && *buf != '+'; 
		buf++, bufsize--);
	    if(*buf == '+') {
	      p = buf;
	      buf++;
	      buf += skip_lws(buf);
	      if(!strncasecmp(buf, "\":\"", 3)) {
		for(p=buf; bufsize && *buf != '\0' && *buf != '+'; 
		    buf++, bufsize--);
		if(*buf == '+') {
		  buf++;
		  buf += skip_lws(buf);
		  if(!strncasecmp(buf, "location.port", 13)) {
		    for(p=buf; bufsize && *buf != '\0' && *buf != '+'; 
			buf++, bufsize--);
		    if(*buf == '+') {
		      FREE_MAYBE(tail);
		      tail = xstrdup(buf);
		      len3 = strlen(tail);
		      len1 = strlen(ar_prefix);
		      len = 1 + len1 + 1 + len3;
		      *new_location = Smalloc(len + 1);
		      snprintf(*new_location, len+1, "\"%s\"%s", 
			       ar_prefix, tail);
		      *new_size = strlen(*new_location);
		      FREE_MAYBE(tail);
		      FREE_MAYBE(ar_prefix);
		      FREE_MAYBE(ar_rel_prefix);
		      FREE_MAYBE(old_first_path);
		      return;
		    }
		  } else { 
		    /* there is no location.port but another var like
		     in "http://" + location.hostname + var.... */
		    FREE_MAYBE(tail);
		    tail = xstrdup(buf);
		    len3 = strlen(tail);
		    len1 = strlen(ar_prefix);
		    len = 1 + len1 + 1 + len3;
		    *new_location = Smalloc(len + 1);
		    snprintf(*new_location, len+1, "\"%s\"%s", 
			     ar_prefix, tail);
		    *new_size = strlen(*new_location);
		    FREE_MAYBE(tail);
		    FREE_MAYBE(ar_prefix);
		    FREE_MAYBE(ar_rel_prefix);
		    FREE_MAYBE(old_first_path);
		    return;
		  }
		}
	      } else {
		/* "http://" + location.hostname + var ... */
		FREE_MAYBE(tail);
		tail = xstrdup(p);
		len3 = strlen(tail);
		len1 = strlen(ar_prefix);
		len = 1 + len1 + 1 + len3;
		*new_location = Smalloc(len + 1);
		snprintf(*new_location, len+1, "\"%s\"%s", 
			 ar_prefix, tail);
		*new_size = strlen(*new_location);
		FREE_MAYBE(tail);
		FREE_MAYBE(ar_prefix);
		FREE_MAYBE(ar_rel_prefix);
		FREE_MAYBE(old_first_path);
		return;		
	      }
	    }
	  } else if (!strncasecmp(buf, "location.host", 13)||
		     !strncasecmp(buf, "this.location.host", 18)) {
	    for(p=buf; bufsize && *buf != '\0' && *buf != '+'; 
		buf++, bufsize--);
	    if(*buf == '+') {
	      FREE_MAYBE(tail);
	      tail = xstrdup(buf);
	      len3 = strlen(tail);
	      len1 = strlen(ar_prefix);
	      len = 1 + len1 + 1 + len3;
	      *new_location = Smalloc(len + 1);
	      snprintf(*new_location, len+1, "\"%s\"%s", ar_prefix, tail);
	      *new_size = strlen(*new_location);
	      if(debug > 3)
		fprintf(stderr, "http://+location.host =>%s\n", *new_location);
	      FREE_MAYBE(tail);
	      FREE_MAYBE(ar_prefix);
	      FREE_MAYBE(ar_rel_prefix);
	      FREE_MAYBE(old_first_path);
	      return;
	    }
	  }
	}
      } else if ( !strncasecmp(old_first_path, "http://", 7) &&
		  strlen(old_first_path) > 7 ) {
	/* old_first_path is an absolute URL */
	struct urlinfo *u;
	char str[MAXNAME], str1[MAXNAME];
	char *constr;
	char *ar_other_prefix;
	char *path;
	int i, len1;
	u = newurl ();
	if ( parseurl(old_first_path, u, 0) != URLOK ) {
	  /* Bad URL in this link, forget it */
	  *new_location = xstrdup(buf_start);
	  *new_size = strlen(*new_location);
	  freeurl (u, 1); 
	  return;
	}
	snprintf(str1, MAXNAME, "%d", u->port);
	snprintf(str, MAXNAME, "%d", aip->relay_port);
	len1 = 7 + len_myhost + 1 + strlen(str) + 1 + strlen(rip->seskey) + 
	  1 + strlen(u->host) + 1 + strlen(str1) + 1;
	ar_other_prefix = (char *) Smalloc(len1 + 1);
	snprintf(ar_other_prefix, len1+1, "http://%s:%s/%s=%s:%s/",
		 aip->relay_hostname, str, rip->seskey, u->host, str1);

	for (i = 0; u->path[i] && u->path[i] == '/'; i++);
	/* Make a copy of u->path w/o a leading slash. */
	path = xstrdup(u->path + i);

	if(*path == '\0') {
	  constr = xstrdup(ar_other_prefix);
	} else {
	  constr = add_prefix(ar_other_prefix, strlen(ar_other_prefix), 
			      path, strlen(path));
	}
	freeurl (u, 1);
	len1 = strlen(constr);
	len = 1 + len1 + 1 + len3;
	*new_location = Smalloc(len + 1);
	if(*q == '\"')
	  snprintf(*new_location, len+1, "\"%s\"%s", constr, tail);
	else if (*q == '\'')
	  snprintf(*new_location, len+1, "\'%s\'%s", constr, tail);
	*new_size = strlen(*new_location);
	FREE_MAYBE(constr);
	FREE_MAYBE(tail);
	FREE_MAYBE(ar_prefix);
	FREE_MAYBE(ar_rel_prefix);
	FREE_MAYBE(ar_other_prefix);
	FREE_MAYBE(path);
	FREE_MAYBE(old_first_path);
	return;
      }
    }
  }
}

/* Chops a <string> from a buf, based on the token. E.g., for removing
   the <meta http-equiv="Content-Type" content="text/html...>.
   This meta tag will cause Netscape 3.x to ask users to repost form data,
   which is annoying. So get rid of it.
   Returns a new Content-Length.*/
int chop_meta_http(const char *buf, const char *token, char **new_buf)
{
  int len, len1, len2;
  int len_work, len_eup, len_elp;
  const char *work = buf; 
  const char *p, *q, *rtoken;
  const char *tail;

  char *eup, *elp;
  const char *headu = "</HEAD>";
  const char *headl = "</head>";

  eup = strstr(buf, headu);
  elp = strstr(buf, headl);
  if(eup != NULL)
    len_eup = strlen(eup);
  else 
    len_eup = 0;

  if(elp != NULL)
    len_elp = strlen(elp);
  else 
    len_elp = 0;

  len = strlen(buf);

  if (eup == NULL && elp == NULL) {
    (*new_buf) = xstrdup(buf);
    return strlen(*new_buf);
  }

  len_work = strlen(work);
  while ((p = strchr(work, '<')) != NULL && len_work >= len_eup &&
	 len_work > len_elp && *work != '\0') {
    rtoken = token;
    q = p + 1; 
    while (*token && (tolower (*token) == tolower (*q)))
      ++q, ++token;
    if (*token) {
      token = rtoken;
      work = q;
      continue;
    }
    work = p;
    len1 = work - buf;
    for(; *q != '>' && *q != '\0'; q++);
    tail = q + 1;
    break;
  }
  if(*work == '<' && *work != '\0') {
    len2 = strlen(tail);
    len = len1 + len2;
    *new_buf = Smalloc(len + 1);
    memcpy(*new_buf, buf, len1);
    memcpy((*new_buf)+len1, tail, len2);
    (*new_buf)[len] = '\0';
  } else {
    (*new_buf) = xstrdup(buf);
  }
    
  return strlen(*new_buf);
}
 
/* Construct an absolute URL, given a relative URL, which can be
   either a absolute path or a relative path. */   
static char *
add_prefix (const char *prefix, int len_prefix, const char *rel, int len_rel)
{
  char *constr;
  int len;

  if (rel == NULL) {
    constr = xstrdup(prefix);
    return constr;
  }
  if (*rel != '/') {
    /* This is a relative path or an absolute path but with its leading
     slash being removed. */
    len = len_prefix + len_rel;
    constr = (char *)Smalloc (len + 1);
    snprintf(constr, len+1, "%s%s", prefix, rel);
  } else {
    /* *rel == `/'. This is an absolute path */
    char *t = (char *)Smalloc(len_rel);
    /* removing the leading slash because the prefix has a trailing
       slash */ 
    memcpy(t, rel+1, len_rel - 1);
    t[len_rel - 1] = '\0';
    len = len_prefix + strlen(t);
    constr = (char *)Smalloc (len + 1);
    snprintf(constr, len+1, "%s%s", prefix, t);
    FREE_MAYBE(t);
  } /* *rel == `/' */
  return constr;
}

/* Get the length of the new buffer with modified links */
int get_lendiff (urlpos *list)
{
  long sum1, sum2;	/* running sums for old_size and new_size */
  int diff;		/* new_len - old_len */

  /* Figure out the length of the new buffer */
  for(sum1 = 0, sum2 = 0; list != NULL; list = list->next) {
    sum1 += list->old_size;
    sum2 += list->new_size;
  }

  diff = sum2 - sum1;
  return diff;
}

/* Change the links in a buffer of response message body, using positions
   and sizes all the links stored in urlpos linked list. New buffer
   containing converted links is returned. urlpos->new_size is stored
   there for figuring out the Content-Length */

/* Remember to call free_urlpos in the calling routine after this
   function returns */ 
char *
cnvt_links (char *old_buf, urlpos *l, long new_len)
{
  char *new_buf; 	/* Buffer now has converted links */
  char *p1, *p2;	/* Two cursors in the old_buf */
  int len1, len2;	/* Lengths of dynamically updated strings */
  long old_len;		/* Length of the original buffer */

  /* Initialize the new_buf */
  old_len = strlen (old_buf);

  if(l == NULL && new_len == old_len) {
    new_buf = xstrdup(old_buf);
    return new_buf;
  }
  
  new_buf = (char *)Smalloc (new_len + 1L);
  memset(new_buf, 0, new_len);
  new_buf[new_len] = '\0';

  len1 = 0;
  len2 = 0;
  for (p1 = old_buf; l != NULL; l = l->next) {
    if (old_len <= l->pos) {
      time_t ct;
      time(&ct);
      log_err(ct, NULL, NULL, "Something strange is going on.  Please investigate.");
      break;
    }
    /* p1 points to the beginning of the segment following the
       previous hyperlink, while p2 points to the beginning of the
       next hyperlink. They both are relative to the old_buf */
    p2 = old_buf + l->pos;

    /* len2 is the length of the text segment between two
       consecutive hyperlinks */
    len2 = p2 - p1;

    /* Update the current new_buf */
    memcpy(new_buf + len1, p1, len2);

    /* len1 is the current length of the new_buf */
    len1 += len2;
    memcpy(new_buf + len1, l->url, l->new_size);
    len1 += l->new_size;
    /* Update the p1 */
    p1 = p2 + l->old_size;
  }

  /* Concatenate the remainder of the old_buf to new_buf*/
  if ( (p1 - old_buf) < strlen(old_buf)) {
    p2 = old_buf + strlen(old_buf);
    len2 = p2 - p1;
    memcpy(new_buf + len1, p1, len2);
  }

  new_buf[new_len] = '\0';

  return new_buf;
}

/* Print out the linked list of urlpos.  */
void
print_urlpos (urlpos *l)
{
  while (l != NULL)
    {
      urlpos *next = l->next;
      fprintf (stderr, "new URL is %s\n", l->url);
      l = next;
    }
}

/* Free the linked list of urlpos.  */
void
free_urlpos (urlpos *l)
{
  while (l != NULL) {
    urlpos *next = l->next;
    FREE_MAYBE (l->url);
    FREE_MAYBE (l->local_name);
    FREE_MAYBE (l);
    l = next;
  }
}

