/************************************************************************
WEBRELAY Software -- a multithreaded HTTP relay server
Copyright (C) 1999 Peter Zhang

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

Please address all correspondence concerning the software to 
zhangc@ucalgary.ca
************************************************************************/

#include "utils.h"

extern int debug;
extern int daemon_proc;

static int base64_initialized = 0;
int base64_value[256];
const char base64_code[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

void print_aip(accept_info *aip)
{
  if(aip != NULL) {
    fprintf(stderr, "RELAY_HOSTNAME=%s\n", 
	    (aip->relay_hostname != NULL) ? aip->relay_hostname : "-");
    fprintf(stderr, "RELAY PORT=%d\n", aip->relay_port);
    fprintf(stderr, "CLIADDR_LEN=%d\n", aip->clilen);
    fprintf(stderr, "CLIENT_FD=%d\n", aip->clifd);
    fprintf(stderr, "AUTH_TYPE=%s\n", 
	    (aip->auth_type != NULL) ? aip->auth_type : "-");
    fprintf(stderr, "CLIENTHOST=%s\n", 
	    (aip->ClientHostname != NULL) ? aip->ClientHostname : "-");
  }
  return;
}


/* Deep free of aip structure */
void deep_free_aip (accept_info *aip)
{
    FREE_MAYBE(aip->relay_hostname);
    aip->relay_port = AR_RELAY_PORT;
    FREE_MAYBE(aip->cliaddr);
    aip->clilen = 0;
    aip->clifd = -1;
    FREE_MAYBE(aip->auth_type);
    FREE_MAYBE(aip->ClientHostname);
}

void print_rip(relay_info *rip)
{
  fprintf(stderr, "DB_KEY=%s\n", 
	  (rip->db_key != NULL) ? rip->db_key : "-");
  fprintf(stderr, "DB_OFFICIAL_NAME=%s\n", 
	  (rip->db_official_name != NULL) ? rip->db_official_name : "-");
  fprintf(stderr, "SESKEY=%s\n", 
	  (rip->seskey != NULL) ? rip->seskey : "-");
  fprintf(stderr, "COOKIE=%s\n", 
	  (rip->cookie != NULL) ? rip->cookie : "-");
  fprintf(stderr, "CLIENT_AUTH=%s\n", 
	  (rip->client_auth != NULL) ? rip->client_auth : "-");
  fprintf(stderr, "CLIENT_PROTO_VS=%s\n", 
	  (rip->client_proto_vs != NULL) ? rip->client_proto_vs : "-");
  fprintf(stderr, "CLIENT_USER_AGENT=%s\n", 
	  (rip->client_user_agent != NULL) ? rip->client_user_agent : "-");
  fprintf(stderr, "PERSIST_FLAG=%d\n", rip->persist_flag);
  fprintf(stderr, "TARGETHOST=%s\n",
	  (rip->targethost != NULL) ?  rip->targethost : "-");
  fprintf(stderr, "TARGETPATH=%s\n", 
	  (rip->targetpath != NULL) ? rip->targetpath : "-");
  fprintf(stderr, "TARGETDIR=%s\n", 
	  (rip->targetdir != NULL) ? rip->targetdir : "-");
  fprintf(stderr, "TARGETFILE=%s\n", 
	  (rip->targetfile != NULL) ? rip->targetfile : "-");
  fprintf(stderr, "AUTOREDIR_NOW=%d\n", rip->autoredir_now);
  fprintf(stderr, "REDIRECT_FLAG=%d\n", rip->redirect_flag);
  fprintf(stderr, "REDIR_TARGETHOST=%s\n", 
	  (rip->redir_targethost != NULL) ? rip->redir_targethost : "-");
  fprintf(stderr, "REDIR_TARGETPORT=%d\n", rip->redir_targetport);
  fprintf(stderr, "REDIR_TARGETPATH=%s\n", 
	  (rip->redir_targetpath != NULL) ? rip->redir_targetpath : "-");
  fprintf(stderr, "REDIR_TARGETDIR=%s\n", 
	  (rip->redir_targetdir != NULL) ? rip->redir_targetdir : "-");
  fprintf(stderr, "REDIR_TARGETFILE=%s\n", 
	  (rip->redir_targetfile != NULL) ? rip->redir_targetfile : "-");
  fprintf(stderr, "SRCFD=%d\n", rip->sourcefd);  
  fprintf(stderr, "TGTFD=%d\n", rip->targetfd);  
  fprintf(stderr, "HAS_JavaScript=%d\n", rip->has_js);
  fprintf(stderr, "HAS_BASE=%d\n", rip->has_base);
  fprintf(stderr, "BASE_URL=%s\n", 
	  (rip->base_url != NULL) ? rip->base_url : "-");
  fprintf(stderr, "Auth_flag=%d\n", rip->auth_flag);
  fprintf(stderr, "Fix_Opt_Value=%d\n", rip->fix_opt_value);
  fprintf(stderr, "NBYTE=%d\n", rip->num_bytes);
  fprintf(stderr, "STATUS CODE=%d\n", rip->rs_status_code);
}


/* Deep free of rip structure */
void deep_free_rip (relay_info *rip)
{
  FREE_MAYBE(rip->db_key);
  FREE_MAYBE(rip->db_official_name);
  FREE_MAYBE(rip->targethost);
  rip->targethost_size = 0;
  rip->targetport = 80;
  FREE_MAYBE(rip->targetpath);
  FREE_MAYBE(rip->targetdir);
  FREE_MAYBE(rip->targetfile);
  rip->autoredir_now = 0;
  rip->redirect_flag = 0;
  FREE_MAYBE(rip->redir_targethost);
  rip->redir_targetport = 80;
  FREE_MAYBE(rip->redir_targetpath);
  FREE_MAYBE(rip->redir_targetdir);
  FREE_MAYBE(rip->redir_targetfile);
  rip->sourcefd = -1;
  rip->targetfd = -1;
  FREE_MAYBE(rip->client_auth);
  FREE_MAYBE(rip->seskey);
  FREE_MAYBE(rip->client_proto_vs);
  FREE_MAYBE(rip->client_user_agent);
  rip->persist_flag = 0;
  FREE_MAYBE(rip->cookie);
  rip->persist_flag = 0;
  rip->has_js = 0;
  rip->has_base = 0;
  FREE_MAYBE(rip->base_url);
  rip->auth_flag = 0;
  rip->num_bytes = 0;
  rip->rs_status_code = 200;
}


char *
xstrdup (const char *s)
{
#ifndef HAVE_STRDUP
  int l;
  char *s1;
  if(s != NULL) {
    l = strlen (s);
    s1 = Smalloc (l + 1);
    memcpy (s1, s, l);
    s1[l] = '\0';
  } else {
    s1 = Smalloc(1);
    s1[0] = '\0';
  }
  return s1;
#else  /* HAVE_STRDUP */
  char *s1 = strdup (s);
  if (s1 == NULL)
    err_sys("strdup");
  return s1;
#endif /* HAVE_STRDUP */
}

/* Copy the string formed by two pointers (one on the beginning, other
   on the char after the last char) to a new, malloc-ed location.
   0-terminate it. End must be greater than or equal to beg.  */
char *
strdupdelim (const char *beg, const char *end)
{
  char *res;
  if(end >= beg) {
    res = (char *)Smalloc (end - beg + 1);
    memcpy (res, beg, end - beg);
    res[end - beg] = '\0';
  } else {
    res = NULL;
  }
  return res;
}

/* Find either upper or lower case of a string whichever appears first */
char * 
find_first_token(const char *buf, const char *token)
{
  const char *p1, *p2;
  char *p;
  char *token1;
  int i, len;
  
  len = strlen(token);
  token1 = Smalloc(len + 1);
  for (i = 0; i < len; ++i) {
    if (isupper(token[i]))
      token1[i] = tolower(token[i]);
    else if(islower(token[i]))
      token1[i] = toupper(token[i]);
    else /* Could be a space or '<' or whatever */
      token1[i] = token[i];
  }
    
  token1[len] = '\0';

  p1 = strstr(buf, token);
  p2 = strstr(buf, token1);
  if(p1 != NULL && p2 != NULL) 
    p = (char *) ((p1 < p2) ? p1 : p2);
  else if (p1 != NULL && p2 == NULL) 
    p = (char *)p1;
  else if (p1 == NULL && p2 != NULL)
    p = (char *)p2;
  else
    p = NULL;

  FREE_MAYBE(token1);
  return p;
}


void
daemon_init(const char *pname, int facility)
{
  int status, errno_save;
  pid_t	pid;
  struct syslog_data syslogdata = SYSLOG_DATA_INIT;
  char strerrbuf[MAXNAME];

  pid = fork();

  if(pid == -1)
    err_sys ("fork error");

  if (pid > 0)
    exit(0);			/* parent terminates */

  /* 1st child continues */
  setsid();				/* become session leader */

  signal(SIGHUP, SIG_IGN);

  pid = fork();

  if(pid == -1)
    err_sys ("fork error");

  if ( pid > 0)
    exit(0);	 	/* 1st child terminates */

  /* 2nd child continues */
  daemon_proc = 1;		/* for our err_XXX() functions */

  chdir("/");			/* change working directory */

  umask(0);			/* clear our file mode creation mask */

  /* Close out the standard fle descriptors */
  if (freopen("/dev/null", "r", stdin) == NULL) {
    errno_save = errno;
    status = strerror_r(errno_save, strerrbuf, sizeof(strerrbuf));
    if(status == 0)
      fprintf(stderr, "WEBRELAY: unable to replace stdin with /dev/null: %s\n", strerrbuf);
    /* continue anyhow -- note we can't close out descriptor 0 because we 
     * have nothing to replace it with, and if we did not have a descriptor
     * 0 the next file would be created with that value... leading to havoc.
     */
  }
  if(freopen("/dev/null", "w", stdout) == NULL) {
    errno_save = errno;
    status = strerror_r(errno_save, strerrbuf, sizeof(strerrbuf));
    if(status == 0)
      fprintf(stderr, "WEBRELAY: unable to replace stdout with /dev/null: %s\n", strerrbuf);
  }
  /* stderr is a tricky one. We really want it to be the error_log,
   * but we have not opened that yet. So leave it alone for now, and
   * it will be reopned a moment later 
   */

  /* ID is our progname, LogOpt using PID always */
  
  openlog_r(pname, LOG_PID, facility, &syslogdata);
}

void stderr_open(const char *path)
{
  int fd;

  if (debug > 0 && daemon_proc == 0)
    return;
    
  if (path == NULL)
    path = "/dev/null";

  fd = Sopen(path, O_WRONLY+O_APPEND+O_CREAT, 0644);
  if (fd < 0) {
    struct syslog_data syslogdata;
    syslog_r(LOG_DEBUG, &syslogdata, "stderr_init(): %s: %m", path);
  } else if (fd != 2) {
    dup2(fd, 2);
    Sclose(fd);
  }
}

/* 
 * Get uid and gid
 */

int uidgid_get(const char *user, const char *group, uid_t *uid, 
	       gid_t *gid) 
{
  struct passwd pwb, *pw = NULL;
  struct group grb, *gp = NULL;
  char workbuf[MAXLINE];
  int status;

  if (user != NULL) {
    if (ISDIGIT(user[0])) {
      *uid = atoi(user);
      pw = Sgetpwuid_r(*uid, &pwb, workbuf, sizeof(workbuf));
      if(pw != NULL) {
	*uid = pw->pw_uid;
	*gid = pw->pw_gid;
      } else
	return AR_ERROR;
    } else {
      pw = Sgetpwnam_r(user, &pwb, workbuf, sizeof(workbuf));
      if(pw != NULL) {
	*uid = pw->pw_uid;
	*gid = pw->pw_gid;
      } else
	return AR_ERROR;
    }
  }

  if (group != NULL) {
    if (ISDIGIT(group[0]))
      *gid = atol(group);
    else {
      gp = Sgetgrnam_r(group, &grb, workbuf, sizeof(workbuf));
      if (gp != NULL)
	*gid = gp->gr_gid;	
      else
	return AR_ERROR;
    }
  }

  return 0;
}


int setup_uidgid(char *server_user, uid_t server_uid, gid_t server_gid)
{
  struct syslog_data syslogdata;
  /* Reads in defined group membership of the specified user, sets the
     supplemental group ID of the current process to that value */ 
  if ( initgroups(server_user, server_gid) < 0 ) {
    syslog_r(LOG_DEBUG, &syslogdata, "initgroups(\"%s\", %d) failed: %m",
	       server_user, server_gid);
    return -1;
  }

  if (server_gid != -1L) {
    if (setegid(server_gid) < 0) {
      syslog_r(LOG_DEBUG, &syslogdata, "setegid(%d) failed: %m", server_gid);
      return -1;
    }
  }
    
  if (server_uid != -1L) {
    /*seteuid The process effective user ID is reset if the UID
     * parameter is equal to either the current real or saved user IDs
     * or if the effective user ID of the process is the root user.
     */

    /* If the root runs this program we now change it to server_uid
       which is nobody */

    if (seteuid(server_uid) < 0) {
      syslog_r(LOG_DEBUG, &syslogdata, "seteuid(%d) failed: %m", server_uid);
      return -1;
    }
  }

  return 0;
}

/* Canonicalize PATH, and return a new path. */ 
void
path_simplify (char *path)
{
  register int i, start, ddot;
  char stub_char;

  if (!*path)
    return;

  /*stub_char = (*path == '/') ? '/' : '.';*/
  stub_char = '/';

  /* Addition: Remove all `./'-s preceding the string.  If `../'-s
     precede, put `/' in front and remove them too.  */
  i = 0;
  ddot = 0;
  while (1) {
    if (path[i] == '.' && path[i + 1] == '/')
      i += 2;
    else if (path[i] == '.' && path[i + 1] == '.' && path[i + 2] == '/') {
      i += 3;
      ddot = 1;
    } else
      break;
  }
  if (i)
    strcpy (path, path + i - ddot);

  /* Replace single `.' or `..' with `/'.  */
  if ((path[0] == '.' && path[1] == '\0')
      || (path[0] == '.' && path[1] == '.' && path[2] == '\0')) {
    path[0] = stub_char;
    path[1] = '\0';
    return;
  }
  /* Walk along PATH looking for things to compact.  */
  i = 0;
  while (1) {
    if (!path[i])
      break;

    while (path[i] && path[i] != '/')
      i++;

    start = i++;

    /* If we didn't find any slashes, then there is nothing left to do.  */
    if (!path[start])
      break;

    /* Handle multiple `/'s in a row.  */
    while (path[i] == '/')
      i++;

    if ((start + 1) != i) {
      strcpy (path + start + 1, path + i);
      i = start + 1;
    }

    /* Check for trailing `/'.  */
    if (start && !path[i]) {
    zero_last:
      path[--i] = '\0';
      break;
    }

    /* Check for `../', `./' or trailing `.' by itself.  */
    if (path[i] == '.') {
      /* Handle trailing `.' by itself.  */
      if (!path[i + 1])
	goto zero_last;

      /* Handle `./'.  */
      if (path[i + 1] == '/') {
	strcpy (path + i, path + i + 1);
	i = (start < 0) ? 0 : start;
	continue;
      }

      /* Handle `../' or trailing `..' by itself.  */
      if (path[i + 1] == '.' &&
	  (path[i + 2] == '/' || !path[i + 2])) {
	while (--start > -1 && path[start] != '/');
	strcpy (path + start + 1, path + i + 2);
	i = (start < 0) ? 0 : start;
	continue;
      }
    }	/* path == '.' */
  } /* while */

  if (!*path)
    {
      *path = stub_char;
      path[1] = '\0';
    }
}

static void
base64_init(void)
{
    int i;

    for (i = 0; i < 256; i++)
	base64_value[i] = -1;

    for (i = 0; i < 64; i++)
	base64_value[(int) base64_code[i]] = i;
    /* Padding is '=' */
    base64_value['='] = 0;

    base64_initialized = 1;
}

char *
base64_decode(const char *p)
{
    static char result[2048];
    int c;
    long val;
    int i;
    char *d;

    if (p == NULL)
	return NULL;

    if (!base64_initialized)
	base64_init();

    val = c = 0;
    d = result;
    while (*p) {
      /* get the index value in a 6-bit chunk. */
	i = base64_value[(int) *p++];
	/* convert it to a base64 number */
	if (i >= 0) {
	    val = val * 64 + i;
	    c++;
	}
	if (c == 4) {  /* One quantum of four encoding characters/24 bit */
	    *d++ = val >> 16;	/* High 8 bits */
	    *d++ = (val >> 8) & 0xff;	/* Mid 8 bits */
	    *d++ = val & 0xff;	/* Low 8 bits */
	    val = c = 0;
	}
    }
    *d = 0;
    return *result ? result : NULL;
}


static const char *const weekday[] =
{
    "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"
};

static const char *const month[] =
{
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
};

/* Reentrant function to get time string */
int http_time_r(const time_t *btp, char **buf)
{
    struct tm tpb;

    if (gmtime_r(btp, &tpb) == NULL)
	return -1;

    *buf = Smalloc(MAXNAME + 1);
    snprintf(*buf, MAXNAME+1, "%s, %02d %s %d %02d:%02d:%02d GMT",
	    weekday[tpb.tm_wday],
	    tpb.tm_mday,
	    month[tpb.tm_mon],
	    tpb.tm_year + 1900,
	    tpb.tm_hour,
	    tpb.tm_min,
 	    tpb.tm_sec);

    return 0;
}

/* Reentrant safe version */
int log_time_r(const time_t btp, char **logtimestamp) 
{
  struct tm tmtime, *ret; 
  /* tmtime must have memory space allocated already */  
  ret = localtime_r(&btp, &tmtime);
  if (ret == NULL)
    return -1;

  *logtimestamp = Smalloc(MAXNAME + 1);
	
  snprintf(*logtimestamp, MAXNAME+1, "%s, %02d %s %d %02d:%02d:%02d - ",
	  weekday[tmtime.tm_wday],
	  tmtime.tm_mday,
	  month[tmtime.tm_mon],
	  tmtime.tm_year + 1900,
	  tmtime.tm_hour,
	  tmtime.tm_min,
	  tmtime.tm_sec);
  return 0;                           
}

/* Reentrant safe version */
int datetime(const time_t btp, char **timestamp) 
{
  struct tm tmtime, *ret; 
  /* tmtime must have memory space allocated already */  
  ret = localtime_r(&btp, &tmtime);
  if (ret == NULL)
    return -1;

  *timestamp = Smalloc(MAXNAME + 1);
	
  snprintf(*timestamp, MAXNAME+1, "%04d%02d%02d%02d%02d%02d",
	  tmtime.tm_year+1900,
	  tmtime.tm_mon+1,
	  tmtime.tm_mday,
	  tmtime.tm_hour,
	  tmtime.tm_min,
	  tmtime.tm_sec);
  return 0; 
}

/*
** This is based on Robert Stevens' Book
*/

/*
 * Throughout the book I use snprintf() because it's safer than sprintf().
 * But as of the time of this writing, not all systems provide this
 * function.  The function below should only be built on those systems
 * that do not provide a real snprintf().
 * The function below just acts like sprintf(); it is not safe, but it
 * tries to detect overflow.
 */

int
snprintf(char *buf, size_t size, const char *fmt, ...)
{
  int n;
  va_list ap;
  time_t ct;
  char *logtimestmp = NULL;

  va_start(ap, fmt);
  vsprintf(buf, fmt, ap);  /* Sigh, some vsprintf's return ptr, not length */
  n = strlen(buf);
  va_end(ap);
  if (n >= size) {
    /*err_quit("snprintf: '%s' overflowed array", fmt);*/
    /* We did not make sure it is thread-safe because we know the program
       will exit abnormally anyway in this case. */
    time(&ct);
    log_time_r(ct, &logtimestmp);
    fprintf(stderr, "%s snprintf: '%s' overflowed array\n", 
	    logtimestmp, fmt);
    exit(1);
  }
  return n;
}

