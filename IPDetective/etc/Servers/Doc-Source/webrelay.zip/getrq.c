/************************************************************************
WEBRELAY Software -- a multithreaded HTTP relay server
Copyright (C) 1999 Peter Zhang

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

Please address all correspondence concerning the software to 
zhangc@ucalgary.ca
************************************************************************/

#include "getrq.h"

extern int debug;

/* Get the request header line by line */
int
rq_get_header (int fd, char **hdr)
{
  ssize_t status;
  *hdr = (char *)Smalloc (MAXLINE + 1);

  /* newline is stored like fgets() */
  status = readline(fd, *hdr, MAXLINE);
  if(status == 0)
    return AR_EOF; /* connection closed by the client */
  else if(status < 0)
    return AR_ERROR;
  else if (status > 0) {
    if(debug > 1)
      fprintf(stderr, "ORIG REQ HEADER LINE is: %s\n", *hdr);
    return AR_OK;
  }
  return AR_ERROR;
}

/* Parse the first line to get METHOD, PATH, and PROTO_VS. */
int parse_firstline(char *buf, char **method, char **path, char **proto_vs)
{
  int buflen;
  char *p;
  time_t ct;

  buflen = strlen (buf);
  
  for(p = buf; *buf != ' ' && *buf != '\0' && buflen > 0; --buflen, ++buf);
  if (*buf == ' ') {
    *method = strdupdelim (p, buf);
  } else {
    time(&ct);
    log_err(ct, NULL, NULL, "Bad first request header line.");
    return -1;
  }

  buf += skip_lws(buf);
  for(p = buf; *buf != ' ' && *buf != '\0' && buflen > 0; --buflen, ++buf);
  if (*buf == ' ') {
    *path = strdupdelim (p, buf);
    buf += skip_lws(buf);
    *proto_vs = xstrdup(buf);
  } else if (*buf == '\0' || buflen == 0) {
    /* Assume a default proto_vs of HTTP/1.0 */
    *path = strdupdelim (p, buf);
    *proto_vs = xstrdup("HTTP/1.0");
  }

  if(debug > 1)
    fprintf(stderr, "The Top Path is: %s\n", *path);

  return 0;
}

/* Parse the_host (buf) found in the Host: line into t_host and t_port */
int parse_the_host (char *buf, char **t_host, unsigned short *t_port)
{
  int i, buflen;
  char *p, *work = NULL;
  time_t ct;

  unsigned short port;

  buflen = strlen (buf);
  
  for(p = buf; *buf != ':' && *buf != '\0' && 
	buflen > 0; --buflen, ++buf);

  if (*buf == '\0' || buflen == 0) {
    /* There is no port field so take the default */
    *t_port = 80;
    *t_host = xstrdup(p);
  }

  if (*buf == ':') {
    *t_host = strdupdelim (p, buf);
    buf += skip_lws(buf);
    buf++;
    work = xstrdup(buf);
    buflen = strlen(work);
    port = 0;
    for (i = 0; i < buflen && work[i] != '\0'; i++) {
      if(ISDIGIT(work[i]))
	port = 10 * (port) + (work[i] - '0');
      else {
	time(&ct);
	log_err(ct, NULL, NULL, "Bad port number in request Host: line.");
	return -1;
      }
    }
    *t_port = port;
    FREE_MAYBE(work);
  } 
  return 0;
}  

/* Parse the_path into db_key or seskey and real_path. They are not decoded */
int parse_the_path(char *the_path, char **db_key, char **seskey, 
                   char **redir_url, char **real_path)
{
  int i, len;
  char *p, *work;

  len = strlen (the_path);
  
  /* Find the second slash which separates the db_key from path. We
     start from i=1, because the leading slash is always there */
  for (i = 1; i < len && the_path[i] != '/'; i++);

  /* Strdupdelim is defined in utils.h which makes a new string out of
     the original one from the position of the first arg up to the 
     position of the second arg */
  work = strdupdelim (the_path + 1, the_path + i);
  work += skip_lws (work);

  if(!strncasecmp(work, "DB=", 3) ||
     !strncasecmp(work, "DB%3D", 5) ) {
    /* This is a DB_KEY */
    p = strchr(work, '=');
    if (p != NULL) {
      p++;
      *db_key = xstrdup(p); 
    }
  } else {
    /* Not a DB_KEY, but a SESKEY plus possible redir_url */
    p = strchr(work, '=');
    if(p != NULL) {
      *seskey = strdupdelim(work, p);
      p++;
      *redir_url = xstrdup(p);
    } else 
      *seskey = xstrdup(work);
  }

  /* real_path will have a leading slash */

  if ( i == len ) {
    /* This is a request of /DBKEY or SESKEY without anything else
     following it. We define "/" as its real_path */
    *real_path = Smalloc(1 + 1);
    memcpy(*real_path, "/", 1);
    (*real_path)[1] = '\0';
  } else 
    /* leading "/" is now included */
    *real_path = xstrdup(the_path + i);
  FREE_MAYBE(work);
  return 0;
}

/* Call this function when a client is connected to us for the first
   time. We will get db_key, session key and other information here for
   deciding if we would grant them access to the target server */

int get_first_req_headers(accept_info *aip, relay_info *rip, 
			  long *contlen, char **first_rq_headers)
{
  int hcount;
  int len, lh, all_length;
  int status;
  int fd;
  time_t ct;

  char *the_host = NULL;
  char *cookie = NULL;
  char *if_modified_since = NULL;
  char *ref_url = NULL;
  char *user_agent = NULL;
  char *keepalive = NULL;

  /* Initialize */
  all_length = 0;

  /* Header-fetching loop.  */

  fd = rip->sourcefd;
  hcount = 0;
  while(1) {
    /* hdr holds first original and then modified header line */
    char *hdr = NULL; 

    /* various vars used for checking on the Referer: line. (not used) */

    hcount++;
    /* Get the header.  Not allow continuation lines. All special
       chars in the header are decoded now  */
    status = rq_get_header (fd, &hdr);
    /*if (status == AR_EOF && *hdr) {*/
    if (status == AR_EOF) {
      time(&ct);
      log_err(ct, aip, rip, "End of file while parsing headers.");  
      FREE_MAYBE (hdr);
      return status;
    } else if (status == AR_ERROR) {
      time(&ct);
      log_err(ct, aip, rip, "Read error in request headers.");
      FREE_MAYBE (hdr);
      return status;
    }

    if(debug > 1)
      fprintf(stderr, "The OLD REQ line is: %s\n", hdr);

    /* Encountered an empty line indicating the end of the header
       section. So let's break the loop. */ 
    if (*hdr == '\r' || *hdr == '\n' || 
	(*hdr == '\r' && *(hdr+1) == '\n')) {
      FREE_MAYBE (hdr);
      break;
    }
      
    len = strlen(hdr);
    if(hdr[len-1] == '\n')
      hdr[len-1] = '\0';
    if(hdr[len-2] == '\r')
      hdr[len-2] = '\0';

    /* First header line of the first request contains the DB_KEY 
       used for subsequent processing. Subsequest requests should
       try to match this field first in the PATH */
    if(hcount == 1) {
      /* various temporary vars used for changing the first and Host:
	 header lines */ 
      char *method = NULL;
      char *the_path = NULL;
      char *proto_vs = NULL;
      char *redir_url = NULL;
      char *real_toppath = NULL;
      char *db_url = NULL;
      
      char *UCIP = "136.159.0.0";
      char *UCMASK = "255.255.0.0";
      in_addr_t uc_ip, uc_mask;

      struct urlinfo *u;

      /* Parse the first line to get method, the_path and proto_vs.*/
      if ( parse_firstline(hdr, &method, &the_path, &proto_vs) < 0 ) {
	status = AR_ERROR;
	time(&ct);
	log_err(ct, aip, rip, "Bad first request header line.");
	FREE_MAYBE (hdr);
	FREE_MAYBE (method);
	FREE_MAYBE (the_path);
	FREE_MAYBE (proto_vs);
	return status;
      }

      FREE_MAYBE(rip->client_proto_vs);
      rip->client_proto_vs = xstrdup(proto_vs);

      /* Get DB_KEY and TARGETHOST. */

      if(debug > 1)
	fprintf(stderr, "The_path is: %s\n", the_path);

      /* Leading slash is there in the real_path */
      FREE_MAYBE(rip->db_key);
      FREE_MAYBE(rip->seskey);
      if (parse_the_path(the_path, &rip->db_key, &rip->seskey, 
			 &redir_url, &real_toppath) != 0) {
	time(&ct);
	log_err(ct, aip, rip, "Error in getting the db_key or seskey.");
	FREE_MAYBE (hdr);
	FREE_MAYBE(the_path);
	FREE_MAYBE(redir_url);
	FREE_MAYBE(real_toppath);
	status = AR_ERROR;
	return status;
      }

      if(debug > 1) {
	fprintf(stderr, "Real_toppath is: %s\n", real_toppath);
	fprintf(stderr, "Redir_URL is: %s\n", redir_url);
      }
      
      /* Get DB_URL from DB_KEY or SESKEY */
      /* We retain db_key, targethost and targetport for all
	 subsequent requests. E.g., for replacing the Host:
	 field.	 */ 

      /* If it is the first request, there is a DB_KEY */
      if(rip->db_key != NULL) {
	hentry_t *hep;
	dbinfo_t *dbip;

	hep = (hentry_t *)dburl_lookup(rip->db_key, 0);
	if (hep != NULL){
	  Spthread_mutex_lock(&hep->lock);
	  dbip = (dbinfo_t *) (hep->data);
	  db_url = xstrdup(dbip->db_url);
	  if(dbip->auth_mandated)
	    rip->auth_flag = 1;
	  else {
	    /* following two pieces of info can be used for us to check the
	       source IP address to see if we need to authenticate the source
	       user with other methods. */
	    /* Compare IP address only. If checking hostname then call
	       gethostbyaddr_r to do reverse DNS lookup */
	    uc_ip = inet_addr(UCIP);
	    uc_mask = inet_addr(UCMASK);
	    if( (aip->cliaddr->sin_addr.s_addr ^ uc_ip) & uc_mask)
	      /* This is a non-UofC IP address */
	      rip->auth_flag = 1;
	    else
	      rip->auth_flag = 0;
	  }

	  /*test auth so set auth_flag = 1 */
	  /*rip->auth_flag = 1;*/

	  FREE_MAYBE(rip->db_official_name);	    
	  rip->db_official_name = xstrdup(dbip->db_official_name);
	  Spthread_mutex_unlock(&hep->lock);
	  ht_release(hep);

	  if(debug > 3) {
	    fprintf(stderr, "RIP after getting first req line is \n");
	    print_rip(rip);
	  }
	} else {
	  FREE_MAYBE(hdr);
	  FREE_MAYBE(method);
	  FREE_MAYBE(the_path);
	  FREE_MAYBE(real_toppath);
	  FREE_MAYBE(proto_vs);
	  FREE_MAYBE(db_url);
	  FREE_MAYBE(redir_url);
	  time(&ct);
	  log_err(ct, aip, rip, "No such database.");
	  return AR_ERROR;
	}
      } else if (rip->seskey != NULL) {
	/* must be a SESKEY. We find db_key from session manager lookup and update
	   timer */
	chain_node_t *cnp;
	sess_info_t *sip;
	hentry_t *hep;
	cnp = sess_manager_find(rip->seskey, 0);
	if(cnp != NULL) {
	  Spthread_mutex_lock(&cnp->lock);
	  sip = (sess_info_t *) (cnp->data);
	  rip->auth_flag = sip->auth_flag;
	  FREE_MAYBE(rip->db_key);
	  rip->db_key = xstrdup(sip->db_key);
	  if(debug > 2)
	    fprintf(stderr, "sip->dbkey=%s\n", sip->db_key);
          hep = (hentry_t *)dburl_lookup(sip->db_key, 0);
	  if (hep != NULL) {
	    dbinfo_t *dbip;
	    Spthread_mutex_lock(&hep->lock);
	    dbip = (dbinfo_t *) (hep->data);
	    if (dbip != NULL && redir_url == NULL) {
	      db_url = xstrdup(dbip->db_url);
	      FREE_MAYBE(rip->db_official_name);
	      rip->db_official_name = xstrdup(dbip->db_official_name);
	    }
	    Spthread_mutex_unlock(&hep->lock);
	    ht_release(hep);

	    if(debug > 3) {
	      fprintf(stderr, "RIP after getting first req line is \n");
	      print_rip(rip);
	    }

	  } else {
	    FREE_MAYBE(hdr);
	    FREE_MAYBE(method);
	    FREE_MAYBE(the_path);
	    FREE_MAYBE(real_toppath);
	    FREE_MAYBE(proto_vs);
	    FREE_MAYBE(db_url);
	    FREE_MAYBE(redir_url);
	    time(&ct);
	    log_err(ct, aip, rip, "No such database.");
	    return AR_ERROR;
	  }
	  Spthread_mutex_unlock(&cnp->lock);
	  chain_hash_release(cnp);
	  status = update_timer_sess(rip->seskey, aip, rip);
	  if(status == SES_OK) {
	    ;
	  } else if (status == SES_FAIL) {
	    FREE_MAYBE(hdr);
	    FREE_MAYBE(method);
	    FREE_MAYBE(the_path);
	    FREE_MAYBE(real_toppath);
	    FREE_MAYBE(proto_vs);
	    FREE_MAYBE(db_url);
	    FREE_MAYBE(redir_url);
	    time(&ct);
	    log_err(ct, aip, rip, "Session Manager data Update Failed.");
	    send_sesctl_error(aip, rip);
	    return AR_ERROR;
	  } else if (status == SES_CLIENT_ENDS) {
	    FREE_MAYBE(hdr);
	    FREE_MAYBE(method);
	    FREE_MAYBE(the_path);
	    FREE_MAYBE(real_toppath);
	    FREE_MAYBE(proto_vs);
	    FREE_MAYBE(db_url);
	    FREE_MAYBE(redir_url);
	    time(&ct);
	    log_sesend(ct, aip, rip);
	    send_sesend_error(aip, rip);
	    return AR_SES_END;
	  }
	} else {
	  /* This session has been ended */
	  FREE_MAYBE(hdr);
	  FREE_MAYBE(method);
	  FREE_MAYBE(the_path);
	  FREE_MAYBE(real_toppath);
	  FREE_MAYBE(proto_vs);
	  FREE_MAYBE(db_url);
	  FREE_MAYBE(redir_url);
	  time(&ct);
	  log_sesend(ct, aip, rip);
	  send_sesend_error(aip, rip);
	  return AR_SES_END;
	}
      }

      if(debug > 1)
	fprintf(stderr, "DB_URL=%s\n", db_url);

      if(redir_url == NULL) {
	/* Get DB info using DB_URL. We retain db_key, targethost and
	   targetport for all subsequent requests. E.g., for replacing
	   the Host: field.	 */ 
	rip->redirect_flag = 0;
	u = newurl();
	if ( parseurl(db_url, u, 0) != URLOK ) {
	  /* Bad URL in this database entry, forget it */
	  freeurl (u, 1); 
	  FREE_MAYBE(hdr);
	  FREE_MAYBE(method);
	  FREE_MAYBE(the_path);
	  FREE_MAYBE(real_toppath);
	  FREE_MAYBE(proto_vs);
	  FREE_MAYBE(db_url);
	  FREE_MAYBE(redir_url);
	  time(&ct);
	  log_err(ct, aip, rip, "Error in getting the db_url.");
	  status = AR_ERROR;
	  return status;
	}
	/* u->host is malloc'ed inside parseurl. */
	/* Always encode the string for sending out request */
	FREE_MAYBE(rip->targethost);
	rip->targethost = encode_string(u->host);
	rip->targetport = u->port;
	rip->targethost_size = strlen(rip->targethost);

	if(rip->db_key != NULL && rip->seskey == NULL && 
	   *real_toppath == '/' && *(real_toppath+1) == '\0') {
	  /* We come freshly at the very beginning, so the targetpath
	     must come from db_url in the configuration file, instead
	     of from request header */
	  FREE_MAYBE(rip->targetpath);
	  FREE_MAYBE(rip->targetdir);
	  FREE_MAYBE(rip->targetfile);
	  rip->targetpath = path_process(u->path, &rip->targetdir,
					 &rip->targetfile);
	} else {
	  /* Session has been started, so we get path from request
	     header */
	  FREE_MAYBE(rip->targetpath);
	  FREE_MAYBE(rip->targetdir);
	  FREE_MAYBE(rip->targetfile);
	  rip->targetpath = path_process(real_toppath, &rip->targetdir,
					 &rip->targetfile);
	}
	if(u != NULL)
	  freeurl(u, 1);
      } else {
	char *p;
	char *raw_host = NULL;
	/* This is a redirected request, then host, path info must be
	   from the request header itself */
	rip->redirect_flag = 1;
	p = strchr(redir_url, ':');
	if (p != NULL) {
	  raw_host = strdupdelim(redir_url, p);
	  p++;
	  rip->redir_targetport = atoi(p);
	} else
	  raw_host = xstrdup(redir_url);
	FREE_MAYBE(rip->redir_targethost);
	rip->redir_targethost = encode_string(raw_host);
	FREE_MAYBE(rip->redir_targetpath);
	FREE_MAYBE(rip->redir_targetdir);
	FREE_MAYBE(rip->redir_targetfile);
	rip->redir_targetpath = path_process(real_toppath,
					     &rip->redir_targetdir,
					     &rip->redir_targetfile);
	FREE_MAYBE(raw_host);
	/* In case Location: header only gives PATH w/o hostname 
	   and port, we retain the targethost from redir_targethost. */
	FREE_MAYBE(rip->targethost);
	rip->targethost = xstrdup(rip->redir_targethost);
	rip->targetport = rip->redir_targetport;
	FREE_MAYBE(rip->targetpath);
	rip->targetpath = xstrdup(rip->redir_targetpath);
	FREE_MAYBE(rip->targetdir);
	rip->targetdir = xstrdup(rip->redir_targetdir);
	FREE_MAYBE(rip->targetfile);
	rip->targetfile = xstrdup(rip->redir_targetfile);
      } 

      if( (rip->auth_flag) == 0) {
	FREE_MAYBE(hdr);
	return AR_OK;
      }
	
      /* Free the original hdr now and reconstruct a new header line
	 based on method, top level path and proto_vs. */

      FREE_MAYBE(hdr);

      /* We alter client's protocol version to be always HTTP/1.0 */
      if(rip->auth_flag && rip->redirect_flag == 1 && redir_url != NULL) {
	/*len = strlen(method) + strlen(rip->redir_targetpath) + 
	  strlen(rip->client_proto_vs) + 4;*/
	len = strlen(method) + strlen(rip->redir_targetpath) + 8 + 4;
	hdr = Smalloc(len + 1);
	/*snprintf(hdr, len+1, "%s %s %s\r\n", method, rip->redir_targetpath, 
		rip->client_proto_vs); */
	snprintf(hdr, len+1, "%s %s HTTP/1.0\r\n", 
		 method, rip->redir_targetpath);
      } else {
	/*len = strlen(method) + strlen(rip->targetpath) + 
	  strlen(rip->client_proto_vs) + 4;*/
	len = strlen(method) + strlen(rip->targetpath) + 8 + 4;
	hdr = Smalloc(len + 1);
	snprintf(hdr, len+1, "%s %s HTTP/1.0\r\n", method, rip->targetpath);
      }

      if(debug > 1)
	fprintf(stderr, "The new first REQ line is: %s\n", hdr);

      FREE_MAYBE(method);
      FREE_MAYBE(the_path);
      FREE_MAYBE(real_toppath);
      FREE_MAYBE(proto_vs);
      FREE_MAYBE(db_url);
      FREE_MAYBE(redir_url);
      
      goto done_header;
    }

    /* Process rest of the request header lines. */
    if (hcount > 1) {

      /* Get the_host (hostname:port) and replace it with remote
	 targethost */
      /* hostname:port. */
      char *t_host = NULL;
      unsigned short t_port;
      char portstr[MAXNAME]; /* Hoding the ":targetport" part */

      /* POST request may have an entity body, then Content-Length is
	 needed */

      if (the_host == NULL) {
	if (header_process (hdr, "Host", &header_strdup, &the_host))
	  {
	    parse_the_host (the_host, &t_host, &t_port);
	    /* aip->relay_hostname and aip->relay_port are initialized
	       at the very top of the thread */
	    /* if(strlen(aip->relay_hostname) != strlen(t_host) ||
	       strcmp(aip->relay_hostname, t_host) ||
	       t_port != aip->relay_port) {
	      FREE_MAYBE(hdr);
	      FREE_MAYBE(the_host);
	      FREE_MAYBE(t_host);
	      time(&ct);
	      log_err(ct, aip, rip, "Bad Host: line."); 
	      status = AR_ERROR;
	      return status;
	    }
	    */
	    /* Free the original hdr now and reconstruct a new Host:
	       line */  

	    FREE_MAYBE(hdr);

	    if(rip->auth_flag && rip->redirect_flag == 1 
	       && rip->redir_targethost != NULL) {
	      snprintf(portstr, MAXNAME, ":%d", rip->redir_targetport);
	      len = 6 + strlen(rip->redir_targethost) + strlen(portstr) + 2;
	      hdr = Smalloc(len + 1);
	      if(rip->redir_targetport == 80)
		snprintf(hdr, len+1, "Host: %s\r\n", 
			 rip->redir_targethost);
	      else
		snprintf(hdr, len+1, "Host: %s%s\r\n", 
			 rip->redir_targethost, portstr);
	    } else {
	      snprintf(portstr, MAXNAME, ":%d", rip->targetport);
	      len = 6 + strlen(rip->targethost) + strlen(portstr) + 2;
	      hdr = Smalloc(len + 1);
	      if(rip->targetport == 80)
		snprintf(hdr, len+1, "Host: %s\r\n", 
			 rip->targethost);
	      else
		snprintf(hdr, len+1, "Host: %s%s\r\n", 
			 rip->targethost, portstr);
	    }

	    FREE_MAYBE(t_host);
	    goto done_header;
	  }
      }

      /* If rip->auth_flag == 0, we should not do anything about Connection
       This is, however, no longer important */
      if (rip->auth_flag && keepalive == NULL) {
	if (header_process (hdr, "Connection", &header_strdup, &keepalive))
	  {
	    if (((strncasecmp(keepalive, "Keep-Alive", 10) == 0) &&
		(strncasecmp(rip->client_proto_vs, "HTTP/1.0", 8) == 0)) ||
		((strncasecmp(keepalive, "close", 5) != 0) &&
		 (strncasecmp(rip->client_proto_vs, "HTTP/1.1", 8) == 0)))
	      rip->persist_flag = 1;
	    else
	      rip->persist_flag = 0;
	    goto add_newline;
	  }
      }

      if (rip->auth_flag && user_agent == NULL) {
	if (header_process (hdr, "User-Agent", &header_strdup, &user_agent))
	  {
	    rip->client_user_agent = xstrdup(user_agent);
	    goto add_newline;
	  }
      }

      /* If rip->auth_flag == 0, we must not chop off the Cookie line --
       This is, however, no longer important. */
      if (rip->auth_flag && cookie == NULL) {
	if (header_process (hdr, "Cookie", &header_strdup, &cookie)) {
	  /* We don't need this cookie associated with our relay server,
	     instead we need to add a cookie line which has been
	     stored in the session manager hash and was set by 
	     the remote database server's Set-Cookie: header */
	  FREE_MAYBE(hdr);
	  hcount--;
	  continue;
	}
      }

      /* If rip->auth_flag == 0, we must not chop off the If-Modified-Since
	 line --.  This is, however, no longer important. */
      if (rip->auth_flag && if_modified_since == NULL) {
	if (header_process (hdr, "If-Modified-Since", &header_strdup, 
			    &if_modified_since)) {
	  /* Always get a fresh copy */
	  FREE_MAYBE(hdr);
	  hcount--;
	  continue;
	}
      }

      if (!strncasecmp(hdr, "Content-Length:", 15)) {
	/* Try getting Content-Length */
	if (*contlen < 0L) {
	  if (header_process (hdr, "Content-Length", 
			      &header_extract_number, 
			      contlen) == 0)
	    { /* returning code 0 means no such header line. */
	      *contlen = -1L;
	    }
	}
	goto add_newline;
      } 

      if (ref_url == NULL) {
	if (header_process (hdr, "Referer", &header_strdup, &ref_url)) {
	  struct urlinfo *u;
	  char *ref_host = NULL;
	  char *ref_path = NULL;
	  char *ref_db_key = NULL;
	  char *ref_seskey = NULL;
	  char *ref_real_path = NULL;
	  char *redir_url = NULL;

	  u = newurl();
	  if ( parseurl(ref_url, u, 0) != URLOK ) {
	    /* Bad URL in this database entry, forget it */
	    freeurl (u, 1); 
	    FREE_MAYBE(hdr);
	    FREE_MAYBE(ref_url);
	    time(&ct);
	    log_err (ct, aip, rip, "Error in getting the db_url.");
	    status = AR_ERROR;
	    return status;
	  }
	  ref_host = encode_string(u->host);
	  /* Now u-path is not decoded */
	  ref_path = xstrdup(u->path);

	  if (parse_the_path(ref_path, &ref_db_key, &ref_seskey, 
			     &redir_url, &ref_real_path) != 0) {
	    FREE_MAYBE(hdr);
	    FREE_MAYBE(ref_url);
	    FREE_MAYBE(ref_path);
	    FREE_MAYBE(ref_db_key);
	    FREE_MAYBE(ref_seskey);
	    FREE_MAYBE(ref_real_path);
	    FREE_MAYBE(redir_url);
	    time(&ct);
	    log_err (ct, aip, rip, "Error in getting the ref_db_key.");
	    status = AR_ERROR;
	    return status;
	  }

          if (rip->auth_flag && rip->targethost != NULL && 
	      rip->redirect_flag == 0 &&
	      strncmp(rip->targethost, ref_host, strlen(rip->targethost))) {
	    /* Free the original hdr now and reconstruct a new Referer:
	       line. The referer is used by some servers to generate
	       a link back to the table of contents page */  
	    FREE_MAYBE(hdr);
	    snprintf(portstr, MAXNAME, ":%d", rip->targetport);
	    len = 9 + strlen(u->scheme) + 3 + strlen(rip->targethost) + 
	      strlen(portstr) +  strlen(ref_real_path)+ 2; 
	    hdr = Smalloc(len + 1);
	    /* ref_real_path has a leading slash */
	    snprintf(hdr, len+1, "Referer: %s://%s%s%s\r\n", u->scheme, 
		    rip->targethost, portstr, ref_real_path);
	    FREE_MAYBE(ref_seskey);
	    FREE_MAYBE(redir_url);
	    FREE_MAYBE(ref_host);
	    FREE_MAYBE(ref_path);
	    FREE_MAYBE(ref_db_key);
	    FREE_MAYBE(ref_real_path);
	    freeurl(u, 1);
	    goto done_header;
	  } else if (rip->auth_flag && rip->redir_targethost != NULL && 
		     rip->redirect_flag == 1 &&
		     strncmp(rip->redir_targethost,
			     ref_host, strlen(ref_host))) {
	    FREE_MAYBE(hdr);
	    snprintf(portstr, MAXNAME, ":%d", rip->redir_targetport);
	    len = 9 + strlen(u->scheme) + 3 + 
	      strlen(rip->redir_targethost) + 
	      strlen(portstr) + strlen(ref_real_path)+ 2; 
	    hdr = Smalloc(len + 1);
	    /* ref_real_path has a leading slash */
	    snprintf(hdr, len+1, "Referer: %s://%s%s%s\r\n", u->scheme, 
		    rip->redir_targethost, portstr, ref_real_path);
	    FREE_MAYBE(ref_seskey);
	    FREE_MAYBE(redir_url);
	    FREE_MAYBE(ref_host);
	    FREE_MAYBE(ref_path);
	    FREE_MAYBE(ref_db_key);
	    FREE_MAYBE(ref_real_path);
	    freeurl(u, 1);
	    goto done_header;
	  }
	} else {
	  goto add_newline;
	}
      }

      if (rip->auth_flag && !strncasecmp(aip->auth_type, "basic", 5) &&
	  !strncasecmp(hdr, "Authorization:", 14) &&
	  (rip->client_auth == NULL)) {
	char *buf = NULL;
	if (header_process (hdr, "Authorization", 
			    &header_strdup, &buf) <= 0)
	  {
	    FREE_MAYBE(buf);
	    rip->client_auth = NULL;
	    time(&ct);
	    log_err(ct, aip, rip, "Bad Authorization Header.");
	  } else {
	    char *p;
	    p = strchr(buf, ' ');
	    rip->client_auth = xstrdup(p + 1);
	  }
	/* This header is for relay server itself to digest. It never
	   goes to the target server */
	FREE_MAYBE(buf);
	FREE_MAYBE(hdr);
	hcount--;
	continue;
      }

      /* Other header lines are not touched except for the "\r\n" */
    add_newline:
      len = strlen(hdr);
      hdr = Srealloc(hdr, len + 3);
      hdr[len++] = '\r';
      hdr[len++] = '\n';
      hdr[len] = '\0';

      goto done_header;
    }

  done_header:
    /* Save new headers into memory */   
    
    lh = strlen (hdr);
    
    if(*first_rq_headers == NULL && !all_length)
      *first_rq_headers = (char *)Smalloc(all_length + lh);
    else
      *first_rq_headers = (char *)Srealloc (*first_rq_headers, all_length 
					    + lh);
    memcpy ((*first_rq_headers) + all_length, hdr, lh);
    all_length += lh;

    FREE_MAYBE(hdr);
  }

  FREE_MAYBE(the_host);
  FREE_MAYBE(keepalive);
  FREE_MAYBE(ref_url);
  FREE_MAYBE(cookie);
  FREE_MAYBE(if_modified_since);
  FREE_MAYBE(user_agent);
  

  /* Add the Cookie: line from the session control manager if there is
     one. This cookie is associated with the remote database server
     that issued Set-Cookie: header in its response */
  if (rip->auth_flag && rip->seskey != NULL) {
    status = retrieve_cookie_sess(rip->seskey, aip, rip);

    if(debug > 1) {
      fprintf(stderr, "retr cookie status=%d\n", status);
      fprintf(stderr, "retr cookie=%s\n", rip->cookie);
    }

    if(status == SES_OK && rip->cookie != NULL) {
      char *hdr = NULL;
      len = strlen(rip->cookie) + 8 + 2;
      hdr = Smalloc(len + 1);
      snprintf(hdr, len+1, "Cookie: %s\r\n", rip->cookie);
      lh = strlen(hdr);

      *first_rq_headers = (char *)Srealloc (*first_rq_headers, all_length 
					    + lh);
      memcpy ((*first_rq_headers) + all_length, hdr, lh);
      all_length += lh;
      FREE_MAYBE(hdr);
    } else if (status == SES_OK && rip->cookie == NULL) {
      ;
    } else if (status == SES_FAIL) {
      time(&ct);
      log_err(ct, aip, rip, "Session Cookie Retrieval Failed.");
      send_sesctl_error(aip, rip);
      return AR_ERROR;
    } else if (status == SES_CLIENT_ENDS) {
      time(&ct);
      log_sesend(ct, aip, rip);
      send_sesend_error(aip, rip);
      return AR_SES_END;
    }
  }

  /* We need an empty line to separate the header from the body */

  *first_rq_headers = (char *)Srealloc (*first_rq_headers, 
					all_length + 2 + 1);  
  memcpy(*first_rq_headers + all_length, "\r\n\0", 3);

  status = AR_OK;
  return status;
}

int get_first_req(accept_info *aip, relay_info *rip, 
		  char **request, int *rq_size)
{
  char *headers;
  char *body;

  int len;

  /* Content-Length of the original request entity body */
  long contlen = -1;

  int n, status, form_status, ses_status;
  int fd;

  auth_info_t *auip;
  chain_node_t *cnp;

  time_t ct;

  auip = (auth_info_t *)Smalloc(sizeof(auth_info_t));
  memset(auip, 0, sizeof(auth_info_t));

  fd = rip->sourcefd;

  /* Initialize memory for strings before passing to subroutines */
  headers = NULL;
  body = NULL;

  status = get_first_req_headers(aip, rip, &contlen, &headers);

  if(rip->auth_flag == 0 && status == AR_OK) {
    status = send_redirect(aip, rip);
    if(status != AR_REDIR_SENT) {
      time(&ct);
      log_redir_err(ct, aip, rip, "Error telling on-campus clients to redirect");
    } else {
      time(&ct);
      log_pass(ct, aip, rip);
    }

    /* This thread has finished its task. The client should be
       able to access the target database directly */
    FREE_MAYBE(headers);
    if(rip->sourcefd >=0) {
      Sclose(rip->sourcefd);
      rip->sourcefd = -1;
    }
    if(rip != NULL)
      deep_free_rip(rip);
    if(aip != NULL)
      deep_free_aip(aip);
    pthread_exit(NULL);
  }

  if(debug > 1) {
    fprintf(stderr, "The NEW REQ headers are: %s\n", headers);
  }

  if (status == AR_ERROR) {
    FREE_MAYBE(headers);
    time(&ct);
    log_err(ct, aip, rip, "Error getting the first request header.");
    return status;
  } else if ( status == AR_EOF && headers == NULL) {
    FREE_MAYBE(headers);
    time(&ct);
    log_err(ct, aip, rip, "Our client quits.");
    return status;
  } else if (status == AR_SES_END) {
    FREE_MAYBE(headers);
    time(&ct);
    log_sesend(ct, aip, rip);
    return status;
  }
  /* Content-Length: must be present for POST request */
  if (contlen < 0L || contlen == 0L) {
    status = AR_OK;
    n = 0;
    goto auth;
  }

  /* request POST message may not contain a binary body */
  n = rs_get_body(fd, &body, &contlen);
  if( n < 0) {
    FREE_MAYBE(headers);
    FREE_MAYBE(body);
    time(&ct);
    log_err(ct, aip, rip, "Error getting subsequent entity body of request.");
    status = AR_ERROR;
    return status;
  } else if(n == 0 && body == NULL) {
    FREE_MAYBE(headers);
    FREE_MAYBE(body);
    time(&ct);
    log_err(ct, aip, rip, "Our client quits.");
    return AR_EOF;
  } else {
    body = Srealloc(body, contlen + 1);
    body[contlen] = '\0';
    status = AR_OK;
  }

auth:

  if(rip->auth_flag == 0)
    goto done;

  /* First request must HAVE db_key. but NOT seskey */
  if (!strncasecmp(aip->auth_type, "basic", 5) &&
      rip->client_auth == NULL && rip->db_key != NULL &&
      rip->seskey == NULL ) {
    status = send_challenge(aip->auth_type, aip, rip);
    FREE_MAYBE(headers);
    FREE_MAYBE(body);
    if(status > 0) {
      return AR_AUTH_WAIT;
    } else
      return AR_ERROR;
  }
  
  /* Now the username and password is always coming along */
  if (!strncasecmp(aip->auth_type, "basic", 5) &&
      rip->client_auth != NULL) {
    len = strlen(rip->client_auth);
    auip->data = Smalloc(len + 1);
    memcpy(auip->data, rip->client_auth, len);
    auip->data[len] = '\0';
    if(basic_get_credential(rip, auip) != BASIC_CRED_OK) {
      FREE_MAYBE(headers);
      FREE_MAYBE(body);
      if(auip != NULL)
	auth_free(aip, auip);
      time(&ct);
      log_err(ct, aip, rip, "Client failed authentication.");
      return AR_ERROR;
    }
    /* But this is still the first request where DB_KEY is in the
       first header line, but no seskey. A new session starts here */
    if(rip->db_key != NULL && rip->seskey == NULL) {
      ses_status = sess_start(aip, rip, auip);
      if(ses_status == SES_OK) {
	status = AR_OK;
	time(&ct);
	log_sesstart(ct, aip, rip);
	goto done;
      } else if (ses_status == SES_FAIL) {
	FREE_MAYBE(headers);
	FREE_MAYBE(body);
	if(auip != NULL)
	  auth_free(aip, auip);
	*request = NULL;
	return AR_ERROR;
      } else if (ses_status == SES_CLIENT_ENDS) {
	FREE_MAYBE(headers);
	FREE_MAYBE(body);
	if(auip != NULL)
	  auth_free(aip, auip);
	time(&ct);
	log_sesend(ct, aip, rip);
	send_sesend_error(aip, rip);
	return AR_SES_END;
      }
    }

    /* Subsequent requests MUST have SESKEY but NOT DB_KEY */
    if(!strncasecmp(aip->auth_type, "basic", 5) &&
       rip->db_key == NULL && rip->seskey != NULL) {
      ses_status = basic_check_sess(rip->seskey, auip, aip, rip);
      if (ses_status == SES_FAIL) {
	time(&ct);
	log_err(ct, aip, rip, "Client failed authentication.");
	send_sesctl_error(aip, rip);
	FREE_MAYBE(headers);
	FREE_MAYBE(body);
	if(auip != NULL)
	  auth_free(aip, auip);
	return AR_ERROR;
      } else if (ses_status == SES_TIMEOUT || ses_status == SES_CLIENT_ENDS) {
	time(&ct);
	log_sesend(ct, aip, rip);
	send_sesend_error(aip, rip);
	FREE_MAYBE(headers);
	FREE_MAYBE(body);
	if(auip != NULL)
	  auth_free(aip, auip);
	cnp = sess_manager_find(rip->seskey, 0);
	if (cnp != NULL) {
	  if (sess_manager_delete(cnp) != 0) {
	    time(&ct);
	    log_err(ct, aip, rip, "Session Control Manager data delete failed.");
	    return AR_ERROR;
	  } 
	  chain_hash_release(cnp);
	}
	return AR_SES_END;
      } else if (ses_status == SES_OK) {
	status = AR_OK;
	goto done;
      }
    }
  }

  if(!strncasecmp(aip->auth_type, "custom", 6) &&
     rip->db_key != NULL && rip->seskey == NULL) {
    if (contlen < 0 || body == NULL) {
      /* No form data received yet */
      if(send_challenge(aip->auth_type, aip, rip)) {
	FREE_MAYBE(headers);
	FREE_MAYBE(body);
	if(auip != NULL)
	  auth_free(aip, auip);
	return AR_AUTH_WAIT;
      } else {
	FREE_MAYBE(headers);
	FREE_MAYBE(body);
	if(auip != NULL)
	  auth_free(aip, auip);
	time(&ct);
	log_err(ct, aip, rip, "Error sending Sign-On form.");
	return AR_ERROR;
      }
    } else {
      if((form_status = form_get_credential(body, contlen, aip, rip, auip)) !=
	 FORM_CRED_OK) {
	FREE_MAYBE(headers);
	FREE_MAYBE(body);
	if(auip != NULL)
	  auth_free(aip, auip);
	time(&ct);
	if(form_status == FORM_CRED_TIMEOUT)
	  log_err(ct, aip, rip, "Logon form timedout.");
	else
	  log_err(ct, aip, rip, "Error getting credentials from form.");
	return AR_ERROR;
      } else {
	/* Start a new session here */
	ses_status = sess_start(aip, rip, auip);
	if(ses_status == SES_OK) {
	  time(&ct);
	  log_sesstart(ct, aip, rip);
	  alter_hdr(headers, request);
	  status = AR_OK;
	  goto end;
	} else if (ses_status == SES_FAIL) {
	  FREE_MAYBE(headers);
	  FREE_MAYBE(body);
	  if(auip != NULL)
	    auth_free(aip, auip);
	  *request = NULL;
	  return AR_ERROR;
	} else if (ses_status == SES_CLIENT_ENDS) {
	  FREE_MAYBE(headers);
	  FREE_MAYBE(body);
	  if(auip != NULL)
	    auth_free(aip, auip);
	  time(&ct);
	  log_sesend(ct, aip, rip);
	  send_sesend_error(aip, rip);
	  return AR_SES_END;
        }
      }
    }	  
  }
      
  if(!strncasecmp(aip->auth_type, "custom", 6) &&
     rip->seskey != NULL) {
    ses_status = custom_check_sess(rip->seskey, auip, aip, rip);
    if (ses_status == SES_FAIL) {
      time(&ct);
      log_err(ct, aip, rip, "Client failed authentication.");
      send_sesctl_error(aip, rip);
      FREE_MAYBE(headers);
      FREE_MAYBE(body);
      if(auip != NULL)
	auth_free(aip, auip);
      return AR_ERROR;
    } else if (ses_status == SES_TIMEOUT || ses_status == SES_CLIENT_ENDS) {
      FREE_MAYBE(headers);
      FREE_MAYBE(body);
      if(auip != NULL)
	auth_free(aip, auip);
      time(&ct);
      log_sesend(ct, aip, rip);
      send_sesend_error(aip, rip);
      cnp = sess_manager_find(rip->seskey, 0);
      if (cnp != NULL) {
	if (sess_manager_delete(cnp) != 0) {
          time(&ct);
	  log_err(ct, aip, rip, "Session manager data delete failed.");
	  return AR_ERROR;
	}
	chain_hash_release(cnp);
      }
      return AR_SES_END;
    } else if (ses_status == SES_OK) {
      rip->auth_flag = 1;
      status = AR_OK;
      goto done;
    }
  }

done:
  /* Form the request message including headers and body */
  if (n == 0) {
    len = strlen(headers);
    *request = (char *)Smalloc(len + 1);
    memcpy(*request, headers, len);
    (*request)[len] = '\0';
  } else {
    len = strlen(headers) + contlen;
    *request = (char *)Smalloc(len + 1);
    memcpy(*request, headers, strlen(headers));
    memcpy((*request)+strlen(headers), body, contlen);
    (*request)[len] = '\0';
  }

end:
  *rq_size = strlen(*request);

  if(debug > 1)
    fprintf(stderr, "New REQ HEADER AND BODY is: %s\n", *request);

  FREE_MAYBE(headers);
  FREE_MAYBE(body);
  /* auip becomes a dangling pointer 
    if(auip != NULL)
    auth_free(aip, auip);*/
  return status;
}
  
void alter_hdr(char *buf, char **new_buf)
{
  int len;
  char *p, *tail, *work;
  char *tmp1 = NULL, *tmp2 = NULL, *tmp3 = NULL, *tmp4 = NULL, *tmp5 = NULL;
  char *conttype = "Content-Type";
  char *contlen = "Content-Length";
  char *ifmod = "If-Modified-Since";
  char *cookie = "Cookie";
  /* Get rid of the Referer: line for the first request */
  char *referer = "Referer";

  if ((p=strstr(buf, "POST")) != NULL || (p = strstr(buf, "post")) != NULL) {
    tail = xstrdup(p + 4);
    *(p + 6) = '\0';
    len = 3 + strlen(tail);

    work = Smalloc(len + 1);
    memcpy(work, "GET", 3);
    memcpy(work+3, tail, strlen(tail));
    work[len] = '\0';
  } else
    work = xstrdup(buf);

  str_chop_body(work, &tmp1);
  len = str_chop_token(tmp1, conttype, &tmp2);
  len = str_chop_token(tmp2, contlen, &tmp3);
  /* get rid of the cookie associated with the relay server */
  len = str_chop_token(tmp3, cookie, &tmp4);
  len = str_chop_token(tmp4, ifmod, &tmp5);
  len = str_chop_token(tmp5, referer, new_buf);

  FREE_MAYBE(work);
  FREE_MAYBE(tail);
  FREE_MAYBE(tmp1);
  FREE_MAYBE(tmp2);
  FREE_MAYBE(tmp3);
  FREE_MAYBE(tmp4);
  FREE_MAYBE(tmp5);
}

/* Chop the entity body */
void str_chop_body(char *buf, char **new_buf)
{
  char *work = buf; 
  char *p;

  while ((p = strchr(work, '\n')) != NULL) {
    if( *(p + 1) != '\0' && (*(p + 1) == '\r' || *(p + 1) == '\n')) {
      /* we got the empty line now, the entity body follows */
      if(*++p == '\r') {
	/* Must have a \n following, so skip over the newline */
	p = p + 2;
	*p = '\0';
	break;
      }
      if(*++p == '\n') {
	p++;
	*p = '\0';
	break;
      }
    } else if (*(p + 1) != '\0' && *(p + 1) != '\r' && *(p + 1) != '\n') {
      work = p + 1;
      continue;
    }
  }
  
  *new_buf = xstrdup(buf);
}

/* Chop a header line based on the token. Return length of the new
   headers. This is done after the entity body was chopped off */
int str_chop_token(char *buf, char *token, char **new_buf)
{
  int len, len1, len2;
  char *work = buf; 
  char *p, *q, *tail, *rtoken;

  len = strlen(buf);

  while ((p = strchr(work, '\n')) != NULL) {
    if( *(p + 1)!= '\0' && *(p + 1) != '\r' && *(p + 1) != '\n') {
      work = p + 1;
      tail = work;
      rtoken = token;
      while (*token && (tolower (*token) == tolower (*tail)))
	++tail, ++token;
      if (*token || *tail++ != ':') {
	token = rtoken;
	continue;
      }
      if ((q = strchr(work, '\n')) != NULL) {
	len1 = work - buf;
	tail = q + 1;
	*(p + 1) = '\0';
	len2 = strlen(tail);
	len = len1 + len2;
	*new_buf = Smalloc(len + 1);
	memcpy(*new_buf, buf, len1);
	memcpy((*new_buf)+len1, tail, len2);
	(*new_buf)[len] = '\0';
      } else {
	(*new_buf) = xstrdup(buf);
	break;
      }
    } else {
      (*new_buf) = xstrdup(buf);
      break;
    }
  }
    
  return strlen(*new_buf);
}
