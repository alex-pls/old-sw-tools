/************************************************************************
WEBRELAY Software -- a multithreaded HTTP relay server
Copyright (C) 1999 Peter Zhang

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

Please address all correspondence concerning the software to 
zhangc@ucalgary.ca
************************************************************************/

#include "auth.h"

extern int debug;
extern int sess_manager_refresh;
extern int sess_manager_ttl;

/* Send a redirection response back to our client */
int send_redirect(accept_info *aip, relay_info *rip)
{
  const char *myserver = "AR_Server/1.0.4";
  int status, len, len1;
  char str[MAXNAME];
  char *response = NULL;
  time_t ct;
  char *buf = NULL;
  char *location_line = NULL, *serv_line = NULL, *date_line = NULL;
  char *targeturl = NULL, *moved_line = NULL, *cont_type_line = NULL;
    
  time(&ct);

  if (http_time_r(&ct, &buf) <0)
    log_err(ct, aip, rip, "HTTP Date line: error");
  len = 32;
  moved_line = (char *)Smalloc(len + 1);

  /* We have to pretend to be version 1.0, because we don't deal with
     HTTP/1.1 Connection headers */
  snprintf(moved_line, len+1, "HTTP/1.0 301 Moved Permanently\r\n");
  len = 8 + strlen(myserver) + 2;
  serv_line = (char *)Smalloc(len + 1);
  snprintf(serv_line, len+1, "Server: %s\r\n", myserver);
  len = 6 + strlen(buf) + 2;
  date_line = (char *)Smalloc(len + 1);
  snprintf(date_line, len+1,  "Date: %s\r\n", buf);
  len = 25;
  cont_type_line = (char *)Smalloc(len + 1);
  snprintf(cont_type_line, len+1, "Content-type: text/html\r\n");

  FREE_MAYBE(buf);

  snprintf(str, MAXNAME, "%d", rip->targetport);
  len = 7 + strlen(rip->targethost) + 1 + strlen(str) + 
			      strlen(rip->targetpath);
  targeturl = (char *)Smalloc(len + 1);
  if(rip->targetport == 80)
    snprintf(targeturl, len+1, "http://%s%s", 
	     rip->targethost, rip->targetpath);
  else
    snprintf(targeturl, len+1, "http://%s:%s%s", 
	     rip->targethost, str, rip->targetpath);
  len = 10 + strlen(targeturl) + 2;
  location_line = (char *)Smalloc(len + 1);
  snprintf(location_line, len+1, "Location: %s\r\n", targeturl);
  len = strlen(moved_line) + strlen(serv_line) + strlen(date_line) + 
    strlen(location_line) + strlen(cont_type_line) + 2;
  response = (char *)Smalloc(len + 1);
  snprintf(response, len+1, "%s%s%s%s%s\r\n", moved_line, serv_line,
	    date_line, location_line, cont_type_line);

  len1 = len + strlen(targeturl) + MAXLINE;
  response = (char *)Srealloc(response, len1 + 1);
  snprintf(response+len, len1+1-len, "<HTML><HEAD><TITLE>Moved Permanently</TITLE></HEAD><BODY><H1>Moved Permanently</H1>This database (%s) can be directly accessed from any on-campus IP address. You received this message because your browser does not perform automatic redirection for you.</BODY></HTML>\r\n", targeturl);

  len = strlen(response);

  if(writen(rip->sourcefd, response, len) != len) {
    status = AR_ERROR;
  } else {
    status = AR_REDIR_SENT;
  }

  FREE_MAYBE(location_line);
  FREE_MAYBE(serv_line);
  FREE_MAYBE(date_line);
  FREE_MAYBE(targeturl);
  FREE_MAYBE(moved_line);
  FREE_MAYBE(cont_type_line);
  FREE_MAYBE(response);

  return status;
}

/* Send a redirection response back to our client */
int redir_to_autherrhtml(accept_info *aip, relay_info *rip)
{
  const char *myserver = "AR_Server/1.0.4";
  int status, len;
  char *response;
  time_t ct;
  char *buf = NULL;
  char *location_line = NULL, *serv_line = NULL, *date_line = NULL;
  char *targeturl = NULL, *moved_line = NULL, *cont_type_line = NULL;
  char *err_html_url="http://www.ucalgary.ca/library/gateway/invalid.html";

  time(&ct);

  if (http_time_r(&ct, &buf) <0)
    log_err(ct, aip, rip, "HTTP Date line: error");
  len = 32;
  moved_line = (char *)Smalloc(len + 1);

  /* We have to pretend to be version 1.0, because we don't deal with
     HTTP/1.1 Connection headers */

  snprintf(moved_line, len+1, "HTTP/1.0 301 Moved Permanently\r\n");
  len = 8 + strlen(myserver) + 2;
  serv_line = (char *)Smalloc(len + 1);
  snprintf(serv_line, len+1, "Server: %s\r\n", myserver);
  len = 6 + strlen(buf) + 2;
  date_line = (char *)Smalloc(len + 1);
  snprintf(date_line, len+1, "Date: %s\r\n", buf);
  len = 25;
  cont_type_line = (char *)Smalloc(len + 1);
  snprintf(cont_type_line, len+1, "Content-type: text/html\r\n");

  FREE_MAYBE(buf);

  len = 10 + strlen(err_html_url) + 2;
  location_line = (char *)Smalloc(len + 1);
  snprintf(location_line, len+1, "Location: %s\r\n", err_html_url);

  len = strlen(moved_line) + strlen(serv_line) + strlen(date_line) + 
    strlen(location_line) + strlen(cont_type_line) + 2;
  response = (char *)Smalloc(len + 1);
  snprintf(response, len+1, "%s%s%s%s%s\r\n", moved_line, serv_line,
	    date_line, location_line, cont_type_line);

  if(writen(rip->sourcefd, response, len) != len) {
    status = AR_ERROR;
  } else {
    status = AR_REDIR_SENT;
  }

  FREE_MAYBE(location_line);
  FREE_MAYBE(serv_line);
  FREE_MAYBE(date_line);
  FREE_MAYBE(targeturl);
  FREE_MAYBE(moved_line);
  FREE_MAYBE(cont_type_line);
  FREE_MAYBE(response);
  return status;
}

/* Send a timeout meesage to the client when he/she gets back to that
   logon form about 5 minutes after the session has started. */
int send_form_ttl(accept_info *aip, relay_info *rip)
{
  const char *myserver = "AR_Server/1.0.4";
  int status, len;
  char response[2*MAXLINE];
  time_t ct;
  char *buf = NULL;
  char serv_line[MAXNAME], date_line[MAXNAME];
  char bad_line[MAXNAME], cont_type_line[MAXNAME];
    
  time(&ct);

  if (http_time_r(&ct, &buf) <0)
    log_err(ct, aip, rip, "HTTP Date line: error");

  /* We have to pretend to be version 1.0, because we don't deal with
     HTTP/1.1 Connection headers */

  snprintf(bad_line, MAXNAME, "HTTP/1.0 400 Bad Request\r\n");
  snprintf(serv_line, MAXNAME, "Server: %s\r\n", myserver);
  snprintf(date_line, MAXNAME, "Date: %s\r\n", buf);

  FREE_MAYBE(buf);

  snprintf(cont_type_line, MAXNAME, "Content-type: text/html\r\n");

  snprintf(response, 2*MAXLINE, "%s%s%s%s\r\n", bad_line, serv_line,
	    date_line, cont_type_line);

  len = strlen(response);

  snprintf(response+len, 2*MAXLINE-len, "<HTML><HEAD><TITLE>Bad Request</TITLE></HEAD><BODY><H1>Logon Form Timedout</H1>You cannot come back to this logon page for the database of <EM>%s</EM> after you had started a session. This is to prevent other people from being able to use your legitimate session without your attendance. You can always start a freshly new session from the Library's top page to logon again. Thanks.</BODY></HTML>\r\n", rip->db_official_name);

  len = strlen(response);

  if(writen(rip->sourcefd, response, len) != len) {
    status = AR_ERROR;
  } else {
    status = AR_OK;
  }
  return status;
}

    
/* Send out challenge to the client */
int send_challenge(const char *type, accept_info *aip, relay_info *rip)
{
  const char *myserver = "AR_Server/1.0.4";
  int status, len;
  char response[3*MAXLINE];
  time_t ct;
  char *buf = NULL;

  time(&ct);

  if (strncasecmp(aip->auth_type, "basic", 5) == 0) {
    char unauth_line[MAXNAME], serv_line[MAXNAME], date_line[MAXNAME];
    char www_auth_line[MAXNAME], cont_type_line[MAXNAME];
    char realm[MAXNAME];
    
    if (http_time_r(&ct, &buf) <0)
      log_err(ct, aip, rip, "HTTP Date line: error");

    /* We have to pretend to be version 1.0, because we don't deal with
       HTTP/1.1 Connection headers */

    snprintf(unauth_line, MAXNAME, "HTTP/1.0 401 Unauthorized\r\n");
    snprintf(serv_line, MAXNAME, "Server: %s\r\n", myserver);
    snprintf(date_line, MAXNAME, "Date: %s\r\n", buf);

    FREE_MAYBE(buf);

    snprintf(realm, MAXNAME, "realm=\"%s\"\r\n", rip->db_key);
    snprintf(www_auth_line, MAXNAME, "WWW-authenticate: %s %s", type, realm);
    snprintf(cont_type_line, MAXNAME, "Content-type: text/html\r\n");

    snprintf(response, 3*MAXLINE, "%s%s%s%s%s\r\n", unauth_line, serv_line,
	    date_line, www_auth_line, cont_type_line);

    len = strlen(response);

    if(writen(rip->sourcefd, response, len) != len) {
      status = AR_ERROR;
    } else
      status = AR_OK;
  } else if (strncasecmp(aip->auth_type, "custom", 6) == 0) {
    char OK_line[MAXNAME], serv_line[MAXNAME], date_line[MAXNAME];
    char cont_type_line[MAXNAME];
    char str[MAXNAME];
    char tmstmp[MAXNAME];
    char *format1 = "<html><head><title>User Authentication for Database %s, University of Calgary Library</title><!-- For anyone who is using the banner image as the top of a web page for the Library web pages, you must copy everything below this line up to the comment at the bottom of the page and paste it into your web page. -->\n <SCRIPT LANGUAGE=\"JavaScript\" TYPE=\"text/javascript\"><!--\nif(document.images) {\n nav01on = new Image;\n nav01on.src =\"http://www.ucalgary.ca/library/gfx/cofatopon.gif\";\n nav02on = new Image;\n nav02on.src = \"http://www.ucalgary.ca/library/gfx/libon.gif\";\n nav04on = new Image;\n nav04on.src = \"http://www.ucalgary.ca/library/gfx/helpon.gif\";\n nav05on = new Image;\n nav05on.src = \"http://www.ucalgary.ca/library/gfx/searchon.gif\";\n nav06on = new Image;\n nav06on.src = \"http://www.ucalgary.ca/library/gfx/catalon.gif\";\n nav07on = new Image;\n nav07on.src = \"http://www.ucalgary.ca/library/gfx/artindon.gif\";\n nav01off = new Image;\n nav01off.src = \"http://www.ucalgary.ca/library/gfx/cofatopoff.gif\";\n nav02off = new Image;\n nav02off.src = \"http://www.ucalgary.ca/library/gfx/liboff.gif\";\n nav04off = new Image;\n nav04off.src = \"http://www.ucalgary.ca/library/gfx/helpoff.gif\";\n nav05off = new Image;\n nav05off.src = \"http://www.ucalgary.ca/library/gfx/searchoff.gif\";\n nav06off = new Image;\n nav06off.src = \"http://www.ucalgary.ca/library/gfx/cataloff.gif\"; nav07off = new Image;\n nav07off.src = \"http://www.ucalgary.ca/library/gfx/artindoff.gif\";\n}\n function img_act(imgName) {\n if (document.images) {\n imgOn = eval(imgName + \"on.src\");\n document [imgName].src = imgOn;\n }\n}\n function img_inact(imgName) {\n if (document.images) {\n imgOff = eval(imgName + \"off.src\");\n document [imgName].src = imgOff;\n }\n}\n// -->\n</SCRIPT>\n</HEAD>\n<BODY BGCOLOR=\"#FFFFFF\">\n<TABLE BORDER=\"0\" CELLPADDING=\"0\" CELLSPACING=\"0\" align=\"center\">\n<TR><TD ALIGN=\"LEFT\" VALIGN=\"TOP\" COLSPAN=\"2\"><A HREF=\"http://www.ucalgary.ca/\" target=\"_top\" onMouseOver=\"img_act(\'nav01\');return true;\" onMouseout=\"img_inact(\'nav01\');return true;\"><IMG SRC=\"http://www.ucalgary.ca/library/gfx/cofatopoff.gif\" WIDTH=223 HEIGHT=51 ALT=\"University of Calgary Home Page\" BORDER=\"0\" name=\"nav01\"></A></TD>\n <td align=\"left\" valign=\"top\" colspan=\"3\"><a href=\"http://www.ucalgary.ca/library/\" onMouseOver=\"img_act(\'nav02\');return true;\" onMouseout=\"img_inact(\'nav02\');return true;\"><img src=\"http://www.ucalgary.ca/library/gfx/liboff.gif\" width=197 height=51 alt=\"University of Calgary Library Home Page\" border=\"0\" name=\"nav02\"></a></td>\n <td align=\"right\" valign=\"top\" colspan=\"2\"><img src=\"http://www.ucalgary.ca/library/gfx/connect.gif\" width=200 height=51 ></td></TR><TR>\n <TD ALIGN=\"LEFT\" VALIGN=\"TOP\"><A HREF=\"http://www.ucalgary.ca/\" TARGET=\"_top\" onMouseOver=\"img_act(\'nav01\');return true;\" onMouseout=\"img_inact(\'nav01\');return true;\"><IMG SRC=\"http://www.ucalgary.ca/library/gfx/cofabottom.gif\" WIDTH=119 HEIGHT=37 ALT=\"University of Calgary Home Page\" BORDER=\"0\"></A></TD>\n<TD align=\"left\" valign=\"top\"><IMG SRC=\"http://www.ucalgary.ca/library/gfx/bar.gif\" WIDTH=104 HEIGHT=37 ALT=\"\" BORDER=\"0\"></TD>\n<TD align=\"left\" valign=\"top\"><IMG SRC=\"http://www.ucalgary.ca/library/gfx/bar.gif\" WIDTH=75 HEIGHT=37 ALT=\"\" BORDER=\"0\"></TD>\n<TD><A HREF=\"http://www.ucalgary.ca/library/linc/help.html\" onMouseOver=\"img_act(\'nav04\');return true;\" onMouseout=\"img_inact(\'nav04\');return true;\"  ><IMG SRC=\"http://www.ucalgary.ca/library/gfx/helpoff.gif\" WIDTH=54 HEIGHT=37 ALT=\"Library Help\" BORDER=\"0\" name=\"nav04\"></A></TD>\n<TD><A HREF=\"http://www.ucalgary.ca/library/search.html\" onMouseOver=\"img_act(\'nav05\');return true;\" onMouseout=\"img_inact(\'nav05\');return true;\" ><IMG SRC=\"http://www.ucalgary.ca/library/gfx/searchoff.gif\" WIDTH=68 HEIGHT=37 ALT=\"Search Library Information\" BORDER=\"0\" name=\"nav05\"></A></TD>\n<TD><A HREF=\"http://clavis.ucalgary.ca/\" onMouseOver=\"img_act(\'nav06\');return true;\" onMouseout=\"img_inact(\'nav06\');return true;\" ><IMG SRC=\"http://www.ucalgary.ca/library/gfx/cataloff.gif\" WIDTH=86 HEIGHT=37 ALT=\"Library Catalogue\" BORDER=\"0\" name=\"nav06\"></A></TD>\n<TD><A HREF=\"http://www.ucalgary.ca/library/gateway/indabs.html\" onMouseOver=\"img_act(\'nav07\');return true;\" onMouseout=\"img_inact(\'nav07\');return true;\" ><IMG SRC=\"http://www.ucalgary.ca/library/gfx/artindoff.gif\" WIDTH=114 HEIGHT=37 ALT=\"Article Index List\" BORDER=\"0\" name=\"nav07\"></A></TD>\n</TR></TABLE>\n<!-- Copy and paste everything from the top comment down to this comment line into your page in order to have the Library banner at the top. -->\n<center><h2>User Authentication for <BR><EM>%s</EM></h2></center>\n<center><img src=\"http://www.ucalgary.ca/library/images/longred.gif\" alt=\"\" width=300 height=2></center><BR>\n<form method=\"POST\" action=\"http://%s:%s/DB=%s%s\">\n<center><TABLE><tr><td align=\"right\">  user ID:</td><td align=\"left\"><input type=\"text\" name=\"User_ID\" size=\"20\" maxlength=\"20\" value=\"\"></td><td align=\"right\">  PIN:</td><td align=\"left\"><input type=\"password\" name=\"Pin\" size=10 maxlength=10 value=\"\"></td><td align=\"right\"></td><td align=\"left\"><input type=\"submit\" value=\"Access Database\"></td></tr></table></center><input type=\"hidden\" name=\"tmstmp\" value=\"%s\"></form>\n<P>Access to this electronic product is limited to University of Calgary students, faculty and staff.  This use is for educational and non-profit research purposes.  Users with Internet Service Providers other than the University of Calgary are directed to this user authentication procedure, and for a few databases, all users are directed to this procedure. <P>Before you can progress any further, you must identify yourself by (1) your Library User ID, which is the first nine digits of the barcode number on the back of your campus card, and (2) your PIN, which is the number on the front of your campus card (unless you have changed your PIN to a new number).<P><font color=\"red\">This information is collected under the <i>Freedom of Information and Protection of Privacy Act</i>. It is required to verify the identification of the researcher and to authorize access to the database. If you have any questions about the collection or use of this information, please contact <a href=\"http://www.acs.ucalgary.ca/cgi-bin/library/mailform.cgi?username=tull&actual_name=Eric+Tull<br>Public+Service+Systems+Librarian\">Public Services Systems Librarian</a>, MacKimmie Library Tower 405, (403)-220-5650.</font><P><center><img src=\"http://www.ucalgary.ca/library/images/longred.gif\" alt=\"\" width=580 height=2></center><p align=\"right\"><EM>University Computing Services</P>";

    if (http_time_r(&ct, &buf) <0)
      log_err(ct, aip, rip, "HTTP Date line: error");

    snprintf(tmstmp, MAXNAME, "%u", ct);

    /* We have to pretend to be version 1.0, because we don't deal with
       HTTP/1.1 Connection headers */

    snprintf(OK_line, MAXNAME, "HTTP/1.0 200 OK\r\n");
    snprintf(serv_line, MAXNAME, "Server: %s\r\n", myserver);
    snprintf(date_line, MAXNAME, "Date: %s\r\n", buf);

    FREE_MAYBE(buf);

    snprintf(cont_type_line, MAXNAME, "Content-type: text/html\r\n");

    snprintf(response, 2*MAXLINE, "%s%s%s%s\r\n", OK_line, serv_line,
	    date_line, cont_type_line);

    snprintf(str, MAXNAME, "%d", aip->relay_port);

    len = strlen(response);

    snprintf(response+len, 3*MAXLINE-len, format1, rip->db_key, rip->db_official_name, aip->relay_hostname, str, rip->db_key, rip->targetpath, tmstmp);
  
    len = strlen(response);

    snprintf(response+len, 3*MAXLINE-len, "</body></html>");

    len = strlen(response);

    if(writen(rip->sourcefd, response, len) != len) {
      status = AR_ERROR;
    } else
      status = AR_OK;
  }
    return status;
}

/* Send out AuthError page to the client */
int send_auth_error(accept_info *aip, relay_info *rip, char *msg)
{
  const char *myserver = "AR_Server/1.0.4";
  int status, len;
  char response[MAXLINE];
  time_t ct;
  char *buf = NULL;
  char forbid_line[MAXNAME], serv_line[MAXNAME], date_line[MAXNAME];
  char www_auth_line[MAXNAME], cont_type_line[MAXNAME];
  char realm[MAXNAME];
    
  time(&ct);

  if (http_time_r(&ct, &buf) <0)
    log_err(ct, aip, rip, "HTTP Date line: error");

  /* We have to pretend to be HTTP/1.0 */
  snprintf(forbid_line, MAXNAME, "HTTP/1.0 403 Forbidden\r\n");
  snprintf(serv_line, MAXNAME, "Server: %s\r\n", myserver);
  snprintf(date_line, MAXNAME, "Date: %s\r\n", buf);

  FREE_MAYBE(buf);

  snprintf(cont_type_line, MAXNAME, "Content-type: text/html\r\n");

  snprintf(response, MAXLINE, "%s%s%s%s\r\n", forbid_line, serv_line,
	  date_line, cont_type_line);

  len = strlen(response);
  snprintf(response+len, MAXLINE-len, "<HTML><HEAD><TITLE>Forbidden</TITLE></HEAD><BODY><H1>Error 403 Forbidden</H1>Proper authorization is required for this database %s when accessed from an off-campus IP address. <P><B>%s</B></BODY></HTML>\r\n", rip->db_official_name, msg);

  len = strlen(response);

  if(writen(rip->sourcefd, response, len) != len) {
    status = AR_ERROR;
  } else
    status = AR_OK;

  return status;
}

/* Send out Session Ends page to the client */
int send_sesend_error(accept_info *aip, relay_info *rip)
{
  const char *myserver = "AR_Server/1.0.4";
  int status, len;
  char response[MAXLINE];
  time_t ct;
  char *buf = NULL;
  char forbid_line[MAXNAME], serv_line[MAXNAME], date_line[MAXNAME];
  char www_auth_line[MAXNAME], cont_type_line[MAXNAME];
  char realm[MAXNAME];
    
  time(&ct);

  if (http_time_r(&ct, &buf) <0)
    log_err(ct, aip, rip, "HTTP Date line: error");
  /* We have to pretend to be HTTP/1.0 for now */
  snprintf(forbid_line, MAXNAME, "HTTP/1.0 403 Forbidden\r\n");
  snprintf(serv_line, MAXNAME, "Server: %s\r\n", myserver);
  snprintf(date_line, MAXNAME, "Date: %s\r\n", buf);

  FREE_MAYBE(buf);

  snprintf(cont_type_line, MAXNAME, "Content-type: text/html\r\n");

  snprintf(response, MAXLINE, "%s%s%s%s\r\n", forbid_line, serv_line,
	  date_line, cont_type_line);

  len = strlen(response);
  snprintf(response+len, MAXLINE-len, "<HTML><HEAD><TITLE>Session Ends</TITLE></HEAD><BODY><H1>Session Ends</H1>Your session has been ended. The maximum idle time of a session is currently limited to a predefined period of time.\n You may go back to the library top homepage</a> to logon again for the database <EM>%s</EM> that you wanted to access.</BODY></HTML>\r\n", rip->db_official_name);

  len = strlen(response);

  if(writen(rip->sourcefd, response, len) != len) {
    status = AR_ERROR;
  } else
    status = AR_OK;

  return status;
}

/* Send out Session Control Failure page to the client */
int send_sesctl_error(accept_info *aip, relay_info *rip)
{
  const char *myserver = "AR_Server/1.0.4";
  int status, len;
  char response[MAXLINE];
  time_t ct;
  char *buf = NULL;
  char forbid_line[MAXNAME], serv_line[MAXNAME], date_line[MAXNAME];
  char www_auth_line[MAXNAME], cont_type_line[MAXNAME];
  char realm[MAXNAME];
    
  time(&ct);

  if (http_time_r(&ct, &buf) <0)
    log_err(ct, aip, rip, "HTTP Date line: error");

  /* We pretend to be HTTP/1.0 for now */
  snprintf(forbid_line, MAXNAME, "HTTP/1.0 500 Internal Server Error\r\n");
  snprintf(serv_line, MAXNAME, "Server: %s\r\n", myserver);
  snprintf(date_line, MAXNAME, "Date: %s\r\n", buf);

  FREE_MAYBE(buf);

  snprintf(cont_type_line, MAXNAME, "Content-type: text/html\r\n");

  snprintf(response, MAXLINE, "%s%s%s%s\r\n", forbid_line, serv_line,
	  date_line, cont_type_line);

  len = strlen(response);
  snprintf(response+len, MAXLINE-len, "<HTML><HEAD><TITLE>Session Control Failure</TITLE></HEAD><BODY><H1>Session Control Failure</H1>Sorry for the server session control failure for the database of <EM>%s</EM> you wanted to access.</BODY></HTML>\r\n", rip->db_official_name);

  len = strlen(response);

  if(writen(rip->sourcefd, response, len) != len) {
    status = AR_ERROR;
  } else
    status = AR_OK;

  return status;
}


int basic_get_credential(relay_info *rip, auth_info_t *auip)
{
  char *buf = NULL;

  buf = base64_decode(auip->data);
  if(buf[0] == '\0')
    return AUTH_FAIL;
  FREE_MAYBE(auip->username);
  FREE_MAYBE(auip->password);
  auip->username = buf;
  auip->password = strchr(buf, ':');
  if (auip->password != NULL)
    *(auip->password)++ = '\0';

  FREE_MAYBE(auip->db_key);
  auip->db_key = xstrdup(rip->db_key);
  return BASIC_CRED_OK;
}

int form_get_credential(char *body, long contlen, accept_info *aip,
			  relay_info *rip, auth_info_t *auip)
{
  char **name, **value;
  int i, nvcount;
  time_t ct, start_time;

  name = Smalloc(sizeof(char *) * (contlen/4 + 1));
  value = Smalloc(sizeof(char *) * (contlen/4 + 1));

  if(body == NULL)
    return AUTH_FAIL;

  nvcount = qstr2nv(body, name, value);
  if(nvcount != 3)
    return AUTH_FAIL;

  for (i = 0; i < nvcount; i++) {
    decode_string(name[i]);
    decode_string(value[i]);
  }

  time(&ct);
  start_time = atol(value[2]);

  if(debug > 2)
    fprintf(stderr, "Form starts at %u and Now is %u\n", start_time, ct);

  if(difftime(ct, start_time) >= FORM_TTL) {
    send_form_ttl(aip, rip);
    return FORM_CRED_TIMEOUT;
  }

  /*  auip->db_key = xstrdup(value[0]);*/
  FREE_MAYBE(auip->username);
  FREE_MAYBE(auip->password);
  FREE_MAYBE(auip->db_key);
  auip->username = xstrdup(value[0]);
  auip->password = xstrdup(value[1]);
  auip->db_key = xstrdup(rip->db_key);

  return FORM_CRED_OK;
}

/* Take a query string and get the name and value pairs. Name and
   value must have already been allocated. maxnumber of pairs is
   contlen/4 (min number of chars in a pair is 4)
   It returns the number of pairs processed on success. */
int qstr2nv(char *qstr, char **name, char**value)
{
  int in_name;	/* reading a name? (boolean) */
  int i;	/* index into qstr */
  int len;	/* length of the query string */
  int nvcount;	/* count of pairs processed */
  char *nstr;	/* pointer to substring under consideration */

  len = strlen(qstr);
  in_name = 1;
  nvcount = 0;
  nstr = qstr;
  for (i = 0; i < len; i++) {
    if(in_name) {
      if(qstr[i] == '=') {
	name[nvcount] = nstr;
	qstr[i] = '\0';
	nstr = qstr + i + 1;
	in_name = 0;
      }
    } else {
      if (qstr[i] == '&') {
	value[nvcount] = nstr;
	qstr[i] = '\0';
	nstr = qstr + i + 1;
	in_name = 1;
	nvcount++;
      }
    }
  }
  value[nvcount] = nstr;
  nvcount++;

  return nvcount;
}

/* Check against session manager data */
int basic_check_sess(char *seskey, auth_info_t *auip,
		     accept_info *aip, relay_info *rip)
{
  int i;
  chain_node_t *cnp;
  sess_info_t *sip;

  int status;

  /* Must have got username=password from Base64 decoded string in the
     request header as reply to our challenge */
  if(auip == NULL || auip->username == NULL || auip->password == NULL ||
     auip->username[0] == '\0' || auip->password[0] == '\0')

    return SES_CLIENT_ENDS;
  
  /* seskey is a search key if the user has been checked against
     our sirsi databse. Session will end if we find any discrepancies
     in our sess_manager */ 

  cnp = sess_manager_find(seskey, 0);
  if(cnp != NULL) {
    Spthread_mutex_lock(&cnp->lock);
    sip = cnp->data;
    if(sip != NULL && sip->username != NULL && sip->password != NULL && 
       sip->ClientIPAddr && cnp->LastUpdated) {
      if (!strncmp(auip->username, sip->username, strlen(sip->username)) &&
	  !strncmp(auip->password, sip->password, strlen(sip->password)) &&
	  (aip->cliaddr->sin_addr.s_addr == sip->ClientIPAddr) ) {
	time_t ct;
	time(&ct);
	if ( difftime(ct, cnp->LastUpdated) <= sess_manager_ttl ) {
	  rip->auth_flag = sip->auth_flag;
	  status = SES_OK;
	} else {
	  status = SES_TIMEOUT;
	}
      } else
	status = SES_CLIENT_ENDS;
    } else 
      status = SES_CLIENT_ENDS;
    Spthread_mutex_unlock(&cnp->lock);
    chain_hash_release(cnp);
  } else
    status = SES_CLIENT_ENDS;
  return status;
}

/* Custom check against session manager data */
int custom_check_sess(char *seskey, auth_info_t *auip,
		     accept_info *aip, relay_info *rip)
{
  chain_node_t *cnp;
  sess_info_t *sip;
  int status;

  cnp = sess_manager_find(seskey, 0);
  if(cnp != NULL) {
    Spthread_mutex_lock(&cnp->lock);
    sip = cnp->data;
    if(sip != NULL && sip->ClientIPAddr && cnp->LastUpdated) {
      if ((aip->cliaddr->sin_addr.s_addr == sip->ClientIPAddr)) {
	time_t ct;
	time(&ct);
	if ( difftime(ct, cnp->LastUpdated) <= sess_manager_ttl ) {
	  rip->auth_flag = sip->auth_flag;
	  if(debug > 3) 
	    fprintf(stderr, "SesCheck: UserName=%s, PWD=%s, DBKEY[0]=%s, InsCOOKIENAME=%s, SesStart=%u, LastUpd=%u\n", 
	      sip->username ? sip->username : "-", 
	      sip->password ? sip->password : "-",
	      sip->db_key ? sip->db_key : "-", 
	      sip->cookie_name[0] ? sip->cookie_name[0] : "-",
	      cnp->SesStart, cnp->LastUpdated);

	  status = SES_OK;
	} else {
	  status = SES_TIMEOUT;
	}
      } else
	status = SES_CLIENT_ENDS;
    } else 
      status = SES_CLIENT_ENDS;
    Spthread_mutex_unlock(&cnp->lock);
    chain_hash_release(cnp);
  } else
    status = SES_CLIENT_ENDS;
  return status;
}


/* Insert new cookie into session manager data */
int insert_cookie_sess(char *seskey, accept_info *aip, relay_info *rip)
{
  int status;

  status = sess_manager_update_cookie(seskey, 0, aip, rip);

  return status;
}

/* Retrieve cookie from session manager data */
int retrieve_cookie_sess(char *seskey, accept_info *aip, relay_info *rip)
{
  int status;

  status = sess_manager_retrieve_cookie(seskey, 0, aip, rip);

  return status;
}


/* Update the timer in the session manager data */
int update_timer_sess(char *seskey, accept_info *aip, relay_info *rip)
{
  int status;

  status = sess_manager_update_timer(seskey, 0, aip);

  return status;
}

/* Make a session key */
int make_seskey(char **seskey, accept_info *aip)
{
  char *timestamp = NULL;
  char str[MAXNAME];
  time_t ct;
  int len;

  time(&ct);

  if(datetime(ct, &timestamp) < 0)
    return -1;
  snprintf(str, MAXNAME, "%08x", aip->cliaddr->sin_addr.s_addr);
  len = strlen(timestamp) + strlen(str);
  *seskey = Smalloc(len + 1);
  snprintf(*seskey, len+1, "%s%s", timestamp, str);
  return 0;
}

/* Start a session */
int sess_start(accept_info *aip, relay_info *rip, auth_info_t *auip)
{
  int status;
  sess_info_t *sip;
  chain_node_t *cnp;

  time_t ct;

  /*status = libuser(auip->username, auip->password, aip, rip);*/

  status = libuser_test(auip->username, auip->password, aip, rip);

  if(status == 0) {
    /* library_user() returns 0 when OK*/
    /* set up session key etc. */
    if(make_seskey(&rip->seskey, aip) < 0) {
      time(&ct);
      log_err(ct, aip, rip, "Cannot get current time and seskey");
    }
	
    /* Session just started, there is no cookie set by the remote
       database server yet. SesStart and LastUpdated are set to
       current time */ 
    sip = sess_info_init(auip->username, auip->password, auip->db_key, 
			aip->cliaddr->sin_addr.s_addr, 
			aip->ClientHostname, rip->auth_flag);
    cnp = sess_manager_insert(rip->seskey, 0, sip, 0);
    if(cnp == NULL) {
      time(&ct);
      log_err(ct, aip, rip, "Session Cache insert failed");
      send_sesctl_error(aip, rip);
      auth_free(aip, auip);
      status = SES_FAIL;
    } else {
      auth_free(aip, auip);

      if(debug > 3) 
	fprintf(stderr, "UserName=%s, PWD=%s, DBKEY=%s, COOKIEname=%s, SesStart=%u, LastUpd=%u, AUTH_FLAG=%d\n", 
		sip->username ? sip->username : "-", 
		sip->password ? sip->password : "-",
		sip->db_key ? sip->db_key : "-", 
		sip->cookie_name[0] ? sip->cookie_name[0] : "-",
		cnp->SesStart, cnp->LastUpdated,
		sip->auth_flag);

      chain_hash_release(cnp);
      status = SES_OK;
    }
  } else {
    /* An error page sent back to user and an entry was logged
       in log.ar_errlog from the libuser() function */
    if(auip != NULL)
      auth_free(aip, auip);
    status = SES_FAIL;
  }
  return status;
}

/* Release an auth_info structure */
void auth_free(accept_info *aip, auth_info_t *auip)
{
    if (auip == NULL)
	return;

    if (aip->auth_type != NULL) {
      FREE_MAYBE(auip->data);
      FREE_MAYBE(auip->username);
      FREE_MAYBE(auip->password);
      FREE_MAYBE(auip->db_key);
    }
    FREE_MAYBE(auip);
}

/* Get Cookie. This is only for the "old" cookie specification of
   Netscape. For RFC2109 version "1" cookies, one need to have
   $Version="1", $Path=pathvalue and $Domain=domainvalue... */
char *parse_cookie(char *cookie, char **cookie_path, char **cookie_domain)
{
  char *cookie_cookie = NULL;
  char *p, *buf;
  /* Search first occurence of ; to get the NAME=VALUE which is the cookie */
  p = cookie;
  for(; *cookie != ';' && *cookie != '\0'; ++cookie);
  if(cookie > p) {
    /* Got the NAME=VALUE field */
    cookie_cookie = strdupdelim(p, cookie);
    if(*cookie == ';') {
      /* There are more fields than the NAME=VALUE field. We first get
       the PATH=path field. Default path is "/" */
      p = find_first_token(cookie, "PATH=");
      if(p != NULL) {
        buf = p + 5;
        for(p = buf; *buf != ';' && *buf != '\0'; ++buf);
        if(buf > p)
          *cookie_path = strdupdelim(p, buf);
        else
          *cookie_path = xstrdup("/");
      } else 
        *cookie_path = xstrdup("/");

      /* Then get the DOMAIN=domain field. Default domain is NULL, meaning
       using the current domain */
      p = find_first_token(cookie, "DOMAIN=");
      if(p != NULL) {
        buf = p + 7;
        for(p = buf; *buf != ';' && *buf != '\0'; ++buf);
        if(buf > p)
          *cookie_domain = strdupdelim(p, buf);
      }
    } else
      *cookie_path = xstrdup("/");
  } 
  return cookie_cookie;
}

/* This is only for testing */
int libuser_test(char *username, char *password, accept_info *aip, 
		 relay_info *rip)
{
  time_t ct;
  char *msg = NULL;
  int len;

  if(strcasecmp(username, password) == 0)
    return 0;
  else {
    time(&ct);
    len = 22;
    msg = Smalloc(len + 1);
    snprintf(msg, len+1, "Authentication failed.");
    log_err(ct, aip, rip, msg);
    send_auth_error(aip, rip, msg);
    FREE_MAYBE(msg);
    return 1;
  }
}

