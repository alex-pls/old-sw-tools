/************************************************************************
WEBRELAY Software -- a multithreaded HTTP relay server
Copyright (C) 1999 Peter Zhang

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

Please address all correspondence concerning the software to 
zhangc@ucalgary.ca
************************************************************************/

#include "mywrap.h"

#include "getrq.h"
#include "getrs.h"
#include "chainhash.h"
#include "sess_manager.h"
#include "hashtbl.h"
#include "dbtbl.h"
#include "utils.h"
#include "logger.h"

char *server_root = DEFAULT_SERVER_ROOT;
char *server_log = DEFAULT_SERVER_LOG;
char *server_user = DEFAULT_SERVER_USER;
char *server_group = DEFAULT_SERVER_GROUP;

int debug = 0;
int daemon_proc = 0;

int sess_manager_refresh = DEFAULT_SESS_MANAGER_REFRESH;
int sess_manager_ttl = DEFAULT_SESS_MANAGER_TTL;

void *server_thread (void *);
int rs_process (accept_info *, relay_info *);
int load_err (relay_info *rip);

void usage(char *progname) 
{
  fprintf(stderr, "Usage: %s [-a [basic | custom]] [-p port] [-d debug_level] [-r server_root] [-l server_log] [-u server_user] [-g server_group] [-i session_idletime] [-s session_length] [-?] [-h]\n", progname);
}

int main(int argc, char **argv)
{
  char *optionargument;
  int currentoption;
  int optionindex;
  int stringindex;
  int returnedoption;

  int  listenfd;		/* relay server's listen socket */

  char *progname;
  extern int optind;
  extern char *optarg;
  char *auth_type = DEFAULT_AUTH_TYPE;

  uid_t server_uid;
  gid_t server_gid;

  char dburls_path[FILENAME_MAX];
  char accpath[FILENAME_MAX];
  char errpath[FILENAME_MAX];
  char cnt_path[FILENAME_MAX];

  void sig_int(int);

  char *my_hostname = NULL;
  unsigned short relay_port = 32888;

  pthread_t  srv_tid;
  pthread_attr_t attr;

  progname = basename(argv[0]);

  returnedoption = optionindex = stringindex = 0;
  getopt_r(argc, argv, "a:p:d:r:l:u:g:i:s?h", &currentoption, &optionargument, 
	   &optionindex, 0, &stringindex, &returnedoption);

  while(returnedoption != -1) {
    switch (returnedoption) {
    case 'a':
      auth_type = optionargument;
      break;
    case 'p':
      relay_port = atoi(optionargument);
      break;
    case 'd':
      debug = atoi(optionargument);
      break;
    case 'r':
      server_root = optionargument;
      break;
    case 'l':
      server_log = optionargument;
      break;
    case 'u':
      server_user = optionargument;
      break;
    case 'g':
      server_group = optionargument;
      break;
    case 'i':
      sess_manager_refresh = atoi(optionargument);
      break;
    case 's':
      sess_manager_ttl = atoi(optionargument);
      break;
    case '?': 
      usage(progname);
      break;
    default:
      usage(progname);
      break;
    }
    getopt_r(argc, argv, "a:p:d:r:l:u:g:i:s:?h", &currentoption, &optionargument,
	     &optionindex, 0, & stringindex, &returnedoption);
  }

  snprintf(dburls_path, FILENAME_MAX, "%s%s", server_root, 
	  DEFAULT_DBURLS_FILE);
  snprintf(accpath, FILENAME_MAX, "%s%s", server_log, DEFAULT_ACCLOG_FILE);
  snprintf(errpath, FILENAME_MAX, "%s%s", server_log, DEFAULT_ERRLOG_FILE);
  snprintf(cnt_path,FILENAME_MAX, "%s%s", server_log, DEFAULT_CNTLOG_FILE);

 if (uidgid_get(server_user, server_group, &server_uid, &server_gid) <0) {
   /* syslogopen_r() has not been called until daemon_init() */ 
   /*struct syslog_data syslogdata;

    fprintf(stderr, "AR_RELAY: uidgid_get() failed\n");
    syslog_r(LOG_DEBUG, &syslogdata, "uidgid_get(\"%s\", \"%s\") failed",
	   server_user != NULL ? server_user : "",
	   server_group != NULL ? server_group : "");*/
    exit(1);
  }

  if (debug < 0)
    debug = 0;

  if (debug > 0) {
    daemon_proc = 0;
  } else {
    daemon_proc = 1;
    daemon_init(progname, LOG_LOCAL6);
  }

  Ssignal(SIGPIPE, SIG_IGN);
  Ssignal(SIGHUP, SIG_IGN);
  Ssignal(SIGINT, SIG_IGN);

  stderr_open(errpath);

  log_init(accpath, errpath, NULL);

  /* Initiate DB_TABLE */
  if( init_dburls(dburls_path) == -1 ) {
    fprintf(stderr, "Configuration file error\n");
    exit(1);
  }

  /* Initialize session control manager */
  sess_manager_init();

  /* relay_hostname can be obtained from gethostname() call
   */
  my_hostname = Smalloc(MAXNAME + 1);
  gethostname(my_hostname, MAXNAME);

  if(strncasecmp(auth_type, "basic", 5) &&
     strncasecmp(auth_type, "custom", 6)) {
    if (debug > 1)
      fprintf(stderr, "Authentication Method Not Supported.");
    exit(1);
  }

  /* SO_REUSERADDR socket option is set up here */
  listenfd = ServerConnect (relay_port);
 
  /* Now we don't need root access any more, because the server is 
     already created to listen on the server port.  */
  if (getuid() == 0) {
    if (setup_uidgid(server_user, server_uid, server_gid) < 0) {
      fprintf(stderr, "webrelay: setup_uidgid() failed\n");
      exit(1);
    }
  }

  /* It appears that the default state (AIX system) is undetached 
     For this daemon-like thread, we set it to be detached.*/
  Spthread_attr_init( &attr );
  Spthread_attr_setdetachstate( &attr, PTHREAD_CREATE_DETACHED );

  for ( ; ; ) {
    int clifd;	
    struct sockaddr_in cliaddr;  	/* client's address, each thread gets one */
    socklen_t  clilen;			/* length of cliaddr */
    accept_info *acceptinfo = NULL;

    /* cliaddr is a value-result arg */
    clilen = sizeof(struct sockaddr);

    acceptinfo = (accept_info *)Smalloc(sizeof(accept_info));
    memset(acceptinfo, 0, sizeof(accept_info));

    acceptinfo->relay_hostname = xstrdup(my_hostname);
    acceptinfo->relay_port = relay_port;

    clifd = Saccept(listenfd, (struct sockaddr *) &cliaddr, &clilen);

    acceptinfo->clifd = clifd;

    acceptinfo->cliaddr = (struct sockaddr_in *)Smalloc(sizeof(struct sockaddr_in));
    memcpy(acceptinfo->cliaddr, &cliaddr, sizeof(struct sockaddr_in));

    acceptinfo->clilen = clilen;

    if(auth_type == NULL) {
      acceptinfo->auth_type = (char *)Smalloc(6 + 1);
      memcpy(acceptinfo->auth_type, "custom", 6);
      acceptinfo->auth_type[6] = '\0';
    } else {
      acceptinfo->auth_type = xstrdup(auth_type);
    }
    /* For future use */
    acceptinfo->ClientHostname = NULL;

    Spthread_create(&srv_tid, &attr, &server_thread, (void *)acceptinfo);
  }

  /* Shuts down the hashtable of db_table */
  dburl_destroy();
  /* Never reach here */
  return (0);
}

void *
server_thread(void *arg)
{
  int res, status;
  accept_info *aip;
  relay_info *rip;

  char *request = NULL;
  int rq_size = 0;
  size_t rqsize;
  ssize_t n;
  time_t ct;

  aip = (accept_info *)Smalloc(sizeof(accept_info));
  memset(aip, 0, sizeof(accept_info));  

  aip->auth_type = xstrdup(((accept_info *)arg)->auth_type);
  aip->relay_port = ((accept_info *)arg)->relay_port;
  aip->relay_hostname = xstrdup(((accept_info *)arg)->relay_hostname);
  aip->clilen = ((accept_info *)arg)->clilen;
  aip->cliaddr = (struct sockaddr_in *)Smalloc(sizeof(struct sockaddr_in));
  /* clilen is the size of struct sockaddr, not sockaddr_in ! */
  /*aip->cliaddr = ((accept_info *)arg)->cliaddr;*/
  memcpy(aip->cliaddr, ((accept_info *)arg)->cliaddr, sizeof(struct sockaddr_in));
  aip->clifd = ((accept_info *)arg)->clifd;
  aip->ClientHostname = NULL;

  /* Free memory of arg */
  if(arg != NULL) {
    deep_free_aip(arg);
  }

  rip = (relay_info *) Smalloc(sizeof(relay_info));
  rip->sourcefd = (aip->clifd);

Keepalive:
  
  /* Initialize rip */
  rip->db_key = NULL;
  rip->db_official_name = NULL;
  rip->seskey = NULL;
  rip->targethost = NULL;
  rip->targethost_size = 0;
  rip->targetpath = NULL;
  rip->targetdir = NULL;
  rip->targetfile = NULL;
  rip->targetport = 80; /* default to 80 */
  rip->autoredir_now = 0;  /* Not auto redirection yet */
  rip->redirect_flag = 0;  /* default is not redirect */
  rip->redir_targethost = NULL;
  rip->redir_targetport = 80; /* default to 80 */
  rip->redir_targetpath = NULL;
  rip->redir_targetdir = NULL;
  rip->redir_targetfile = NULL;
  rip->client_auth = NULL;
  rip->cookie = NULL;
  rip->client_proto_vs = NULL;
  rip->client_user_agent = NULL;
  rip->persist_flag = 0;
  rip->has_js = 0;
  rip->has_base = 0;
  rip->base_url = NULL;
  rip->auth_flag = 0;
  rip->fix_opt_value = 0;
  rip->num_bytes = 0;
  rip->rs_status_code = 200;

  rip->targetfd = -1;

  /* Get the first request from client to see if we need check
     authentication and to get database info and form a new request on
     behalf of the client to be sent to the remote server. */

  status = get_first_req(aip, rip, &request, &rq_size);

  if ( status == AR_ERROR ) {
    time(&ct);
    log_err(ct, aip, rip, "Error getting first request.");
    if(rip->sourcefd >= 0) {
      Sclose(rip->sourcefd);
      rip->sourcefd = -1;
    }
    FREE_MAYBE(request);
    goto End;
  } else if( (status == AR_EOF && request == NULL) ||
	     (status == AR_SES_END && request == NULL) ) {
    if(rip->sourcefd >= 0) {
      Sclose(rip->sourcefd);
      rip->sourcefd = -1;
    }
    goto End;
  } else if (status == AR_REDIR_SENT && request == NULL) {
    /* On-Campus addresses, so let it bypass our relay */
    if(rip->sourcefd >= 0) {
      Sclose(rip->sourcefd);
      rip->sourcefd = -1;
    }
    goto End;
  } else if (status == AR_AUTH_WAIT && request == NULL) {
    if(rip->sourcefd >= 0) {
      Sclose(rip->sourcefd);
      rip->sourcefd = -1;
    }
    goto End;
  }    

  /* Open connection to the target host on targetport */

  res = 0;

  if(debug > 3)
    print_rip(rip);

  if(rip->redirect_flag == 1 && rip->redir_targethost != NULL)
    rip->targetfd = ClientConnect(&res, rip->redir_targethost, 
				    rip->redir_targetport);
  else 
    rip->targetfd = ClientConnect(&res, rip->targethost, 
				  rip->targetport);

  if(res < 0) {
    /* If the remote server refuses connection, we quit this thread */
    FREE_MAYBE(request);
    load_err(rip);
    time(&ct);
    log_err(ct, aip, rip, "Remote server refuses connection.");
    if(rip->sourcefd >= 0) {
      Sclose(rip->sourcefd);
      rip->sourcefd = -1;
    }
    if(rip->targetfd >= 0) {
      Sclose(rip->targetfd);
      rip->targetfd = -1;
    }
    goto End;
  }    

  /* Pass the translated first request to the remote server. */
  n = writen(rip->targetfd, request, (size_t)rq_size);
  rqsize = (ssize_t)rq_size;

  if(n != rqsize) {
    time(&ct);
    log_err(ct, aip, rip, "Error writing to the remote server.");
    FREE_MAYBE(request);
    if(rip->sourcefd >= 0) {
      Sclose(rip->sourcefd);
      rip->sourcefd = -1;
    }
    if(rip->targetfd >= 0) {
      Sclose(rip->targetfd);
      rip->targetfd = -1;
    }
    goto End;
  } else {
    status = AR_OK;
    FREE_MAYBE(request);
  }    

  /*  while(status == AR_OK) {*/
    /* Data flow from remote server back to client */
    status = rs_process(aip, rip);
    if (status == AR_ERROR || status == AR_EOF) {
      time(&ct);
      log_err(ct, aip, rip, "Error to get back responses.");
      if(rip->targetfd >= 0) {
	Sclose(rip->targetfd);
	rip->targetfd = -1;
      }
      if(rip->sourcefd >= 0) {
	Sclose(rip->sourcefd);
	rip->sourcefd = -1;
      }
      goto End;
    } else if (status == AR_OK) {
      if(rip->targetfd >= 0) {
	Sclose(rip->targetfd);
	rip->targetfd = -1;
      }
      /* Send a FIN to client: no more writes to it. */
      if(rip->sourcefd >= 0) {
	Sclose(rip->sourcefd);
	rip->sourcefd = -1;
      }
      if(debug > 2) {
	print_rip(rip);
      }
      goto End;
    }

  if(rip->targetfd >= 0) {
    Sclose(rip->targetfd);
    rip->targetfd = -1;
  }
  if(rip->sourcefd >= 0) {
    Sclose(rip->sourcefd);
    rip->sourcefd = -1;
  }

End:

  if (rip != NULL) {
    deep_free_rip(rip);
  }
  if (aip != NULL) {
    deep_free_aip(aip);
  }
  pthread_exit (NULL);

  return( NULL );
}

int rs_process(accept_info *aip, relay_info *rip)
{
  int status;
  char *response = NULL;
  int rs_size = 0;
  ssize_t n, rssize;
  time_t ct;

  /* Get data from targetfd and put the modified data to rip->response
   */

  signal(SIGPIPE, SIG_IGN);
  status = mod_rs(aip, rip, &response, &rs_size);
  if (debug > 2)
    fprintf(stderr, "Res from DB=%s\n", response);

  if ( status == AR_ERROR ) {
    FREE_MAYBE(response);
    return (status); 	/* connection closed by the remote server */
  } 

  if(debug > 3)
    fprintf(stderr, "sourcefd=%d\n", rip->sourcefd);

  n = writen(rip->sourcefd, response, (size_t)rs_size);
  rssize = (ssize_t)rs_size;
  
  if(n != rssize) {
    FREE_MAYBE(response);
    status = AR_ERROR;
    return status;
  }

  if(debug > 3) {
    fprintf(stderr, "Targethost=%s\n", rip->targethost);
    fprintf(stderr, "DB_KEY=%s\n", rip->db_key);
    fprintf(stderr, "SESKEY=%s\n", rip->seskey);
    fprintf(stderr, "Res TEXT=%s\n", response);
  }

  time(&ct);
  log_conn(ct, aip, rip);

  FREE_MAYBE(response);
  return (status);
}

int load_err(relay_info *rip)
{
  int status;
  size_t len;
  char mesg[MAXLINE];
  ssize_t n;

  status = AR_OK;
  snprintf(mesg, MAXLINE, 
	   "HTTP/1.0 504 Gateway Timeout\r\nContent-Type: text/html\r\n\r\n");

  len = strlen(mesg);
  snprintf(mesg+len, MAXLINE-len, "<HTML><HEAD><TITLE>AR_RELAY Server Load Failure</TITLE>\r\n<BODY><H1>AR_RELAY Server Load Failure</H1><P>Remote Database Server %s Not Responding.<P></BODY></HTML>", ((rip->targethost != NULL) ?
	   rip->targethost : rip->redir_targethost));
  len = strlen(mesg);

  n = writen(rip->sourcefd, mesg, len);
  if(n != (ssize_t)len) {
    status = AR_ERROR;
    return status;
  }

  return status;
}
