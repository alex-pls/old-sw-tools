/************************************************************************
WEBRELAY Software -- a multithreaded HTTP relay server
Copyright (C) 1999 Peter Zhang

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

Please address all correspondence concerning the software to 
zhangc@ucalgary.ca
************************************************************************/

#include "mywrap.h"

extern int debug;

/* Wrapper for getpwuid_r */
struct passwd *Sgetpwuid_r (const uid_t uid, struct passwd *pwent,
			    char *buffer, int buflen)
{
#if defined (AIX4_3)
  struct passwd *result;
  int status;
  status = getpwuid_r (uid, pwent, buffer, buflen, &result);
  if (status != 0) {
    errno = status;
    result = NULL;
  }
  return result;
#elif defined (AIX4_1) || defined (AIX4_2)
  if (getpwuid_r (uid, pwent, buffer, buflen) == -1)
    return NULL;
  else
    return pwent;
#endif
}

/* Wrapper for getpwnam_r */
struct passwd *Sgetpwnam_r (const char *name, struct passwd *pwent,
			    char *buffer, int buflen)
{
#if defined (AIX4_3)
  struct passwd *result;
  int status;
  status = getpwnam_r (name, pwent, buffer, buflen, &result);
  if (status != 0) {
    errno = status;
    result = NULL;
  }
  return result;
#elif defined (AIX4_1) || defined (AIX4_2)
  if (getpwnam_r (name, pwent, buffer, buflen) == -1)
    return NULL;
  else
    return pwent;
#endif
}
/* Wrapper for getgrnam_r */
struct group *Sgetgrnam_r (const char *name, struct group *grent,
			    char *buffer, int buflen)
{
#if defined (AIX4_3)
  struct group *result;
  int status;
  status = getgrnam_r (name, grent, buffer, buflen, &result);
  if (status != 0) {
    errno = status;
    result = NULL;
  }
  return result;
#elif defined (AIX4_1) || defined (AIX4_2)
  if (getgrnam_r (name, grent, buffer, buflen) == -1)
    return NULL;
  else
    return grent;
#endif
}

/* Signal function from R. Stevens. This is for backward
 compatibility of POSIX sigaction with old signal function */
Sigfunc *Ssignal(int signo, Sigfunc *func)
{
  struct sigaction act, oact;
  /* Set the handler to be our signal handler func */
  act.sa_handler = func;
  /* Empty mask set means no additional signals are blocked 
     while our signal handler is running */
  sigemptyset(&act.sa_mask);
  act.sa_flags = 0;
  if (signo == SIGALRM) {
#ifdef SA_INTERRUPT
    act.sa_flags |= SA_INTERRUPT; /*sunOS 4.x */
#endif
  } else {
#ifdef SA_RESTART
    act.sa_flags |= SA_RESTART;  /* S5V4; 4.4BSD */
#endif
  }
  if(sigaction(signo, &act, &oact) < 0)
    return (SIG_ERR);
  return (oact.sa_handler);
}

/* Pthread functions return positive errno indicating error, and 0
   for success. */
void Spthread_create(pthread_t *tid, const pthread_attr_t *attr, void *(*func)(void *), void *arg) 
{
  if (pthread_create(tid, attr, func, arg) != 0)
    err_sys("pthread_create %s", tid);
}

void Spthread_attr_init(pthread_attr_t *attr)
{
  if (pthread_attr_init(attr) != 0)
    err_sys("pthread_attr_init");
}

void Spthread_attr_setdetachstate(pthread_attr_t *attr, int detachstate)
{
  if (pthread_attr_setdetachstate(attr, detachstate) != 0)
    err_sys("pthread_attr_setdetachstate");
}

void Spthread_attr_setscope(pthread_attr_t *attr, int contentionscope)
{
  if (pthread_attr_setscope(attr, contentionscope) == 0)
    return;
  err_sys("pthread_attr_setscope");
}

void Spthread_detach(pthread_t tid)
{
  if (pthread_detach(tid) == 0)
    return;
  err_sys("pthread_detach");
}

void Spthread_mutex_init(pthread_mutex_t *mptr, pthread_mutexattr_t *attr)
{
  if (pthread_mutex_init(mptr, attr) == 0)
    return;
  err_sys("pthread_mutex_init");
}

void Spthread_mutex_lock(pthread_mutex_t *mptr)
{
  if (pthread_mutex_lock(mptr) == 0)
    return;
  err_sys("pthread_mutex_lock");
}


void Spthread_mutex_trylock(pthread_mutex_t *mptr)
{
  int n;

  if ((n = pthread_mutex_trylock(mptr)) == 0 || n == EBUSY)
    return;
  err_sys("pthread_mutex_trylock");
}

void Spthread_mutex_unlock(pthread_mutex_t *mptr)
{
  if (pthread_mutex_unlock(mptr) == 0)
    return;
  err_sys("pthread_mutex_unlock");
}

void Spthread_mutex_destroy(pthread_mutex_t *mptr)
{
  if (pthread_mutex_destroy(mptr) == 0)
    return;
  err_sys("pthread_mutex_destroy");
}

void Spthread_cond_init (pthread_cond_t *condition, pthread_condattr_t *attr)
{
  if (pthread_cond_init(condition, attr) == 0)
    return;
  err_sys("pthread_cond_init");
}

void Spthread_cond_timedwait (pthread_cond_t *condition, 
			      pthread_mutex_t *mutex, 
			      const struct timespec *timeout)

{
  if (pthread_cond_timedwait(condition, mutex, timeout) == 0)
    return;
  err_sys("pthread_cond_timedwait");
}

int Saccept(int fd, struct sockaddr *sa, socklen_t *salen)
{
  int n;

Loop:
  n = accept(fd, sa, salen);

  if ( n < 0 ) {
    if (errno != EINTR) {
      err_ret("Accept");
      sleep(10);
    }
    goto Loop;
  }
  return(n);
}

void Sbind(int fd, struct sockaddr *sa, socklen_t salen)
{
  int n;

  n = bind(fd, sa, salen);
  
  if (n < 0) 
    err_sys("bind");
}


int Sconnect(int fd, struct sockaddr *sa, socklen_t salen)
{
  int s;

  while ((s = connect(fd, sa, salen)) < 0 && errno == EINTR)
    ;

  return s;
}

void Slisten(int fd, int backlog)
{
  if (listen(fd, backlog) < 0) {
    err_sys("listen");
  }
}

void Ssetsockopt(int fd, int level, int optname, const void *optval, 
		 socklen_t optlen)
{
  if (setsockopt(fd, level, optname, optval, optlen) < 0) {
    err_sys("setsockopt");
  }
}

int Ssocket(int family, int type, int protocol)
{
  int n;

  if ( (n = socket(family, type, protocol)) < 0) {
    err_sys("socket");
  }
  return (n);
}

void Sfclose(FILE *fp)
{
  if (fclose(fp) != 0) {
    err_sys("fclose");
    pthread_exit(NULL);
  }
}

void Sclose(int fd)
{
  if (close(fd) != 0) {
    err_sys("close");
    pthread_exit(NULL);
  }
}

FILE *Sfdopen(int fd, const char *type)
{
  FILE	*fp;
  
  if ( (fp = fdopen(fd, type)) == NULL) {
    err_sys("fdopen");
    pthread_exit(NULL);
  }

  return(fp);
}

char *Sfgets(char *ptr, int n, FILE *fp)
{
  char	*rptr;

  if ( (rptr = fgets(ptr, n, fp)) == NULL && ferror(fp)) {
    err_sys("fgets");
    pthread_exit(NULL);
  }
    return rptr;
}

FILE *Sfopen(const char *filename, const char *mode)
{
  FILE	*fp;

  if ( (fp = fopen(filename, mode)) == NULL) {
    err_sys("fopen");
    pthread_exit(NULL);
  }

  return fp;
}

void Sfputs(const char *ptr, FILE *fp)
{
  if (fputs(ptr, fp) == EOF) {
    err_sys("fputs");
    pthread_exit(NULL);
  }
}

void * Scalloc(int n, size_t size)
{
  void	*ptr;

  if ( (ptr = calloc(n, size)) == NULL) {
    err_dump("calloc");
  }
  return ptr;
}

void * Smalloc(size_t size)
{
  void	*ptr;

  ptr = malloc(size);
  if ( ptr == NULL ) {
    err_dump("malloc");
  }
  return ptr;
}

void * Srealloc(void *loc, size_t size)
{
  void	*ptr;

  if ( (ptr = realloc(loc, size)) == NULL) {
    err_dump("realloc");
  }
  return ptr;
}

int Sopen(const char *pathname, int oflag, unsigned long mode)
{
  int fd;

  if ( (fd = open(pathname, oflag, mode)) == -1) {
    err_sys("open");
    pthread_exit(NULL);
  }
  return fd;
}


/* We use gethostbyname_r which is said to be reentrant on AIX.*/
void Sgethostbyname(const char *host, struct hostent **hptr)
{
  int status;
  struct hostent_data *he_data;

  *hptr = (struct hostent *) Smalloc(sizeof(struct hostent));
  he_data = (struct hostent_data *)Smalloc(sizeof(struct hostent_data));
  memset(he_data, 0, sizeof(struct hostent_data));

  status = gethostbyname_r(host, *hptr, he_data);
  if ( status < 0) {
    err_sys_thr("gethostbyname_r");
  }

  FREE_MAYBE(he_data);
}

void Sgethostbyaddr(char *addr, struct hostent **hptr)
{
  int status;
  struct hostent_data *he_data;

  *hptr = (struct hostent *) Smalloc(sizeof(struct hostent));
  he_data = (struct hostent_data *)Smalloc(sizeof(struct hostent_data));
  memset(he_data, 0, sizeof(struct hostent_data));

  status = gethostbyaddr_r(addr, strlen(addr), AF_INET, *hptr, he_data);
  if ( status < 0) {
    err_sys_thr("gethostbyaddr_r");
  }

  FREE_MAYBE(he_data);
}

int FileCopy(FILE *to, FILE *from)
{
  int c;

  while ( (c = fgetc(from) ) != EOF )
    if ( fputc(c, to) == EOF)
      return 0;

  if ( ferror(to) )
    return 0;

  return 1;
}

int
iread (int fd, char *buf, int len)
{
  int res;

  do
    {
      res = read (fd, buf, len);
    }
  while (res == -1 && errno == EINTR);

  return res;
}


/* Read "n" bytes from a descriptor. */
ssize_t	readn(int fd, void *vptr, size_t n)
{
  size_t nleft;
  /* ssize_t is a shorthand for signed int type. */
  ssize_t nread;
  char	*ptr;

  ptr = vptr;
  nleft = n;
  while (nleft > 0) {
    if ( (nread = read(fd, ptr, nleft)) < 0) {
      if (errno == EINTR)
	nread = 0;	/* and call read() again */
      else
	return -1;
    } else if (nread == 0)
      break;		/* EOF */
    
    nleft -= nread;
    ptr   += nread;
  }
  return(n - nleft);	/* return >= 0 */
}
/* end readn */

ssize_t Readn(int fd, void *ptr, size_t nbytes)
{
  ssize_t n;

  if ( (n = readn(fd, ptr, nbytes)) < 0)
    err_sys("readn error");
  return n;
}

/* Write "n" bytes to a descriptor. */
ssize_t	writen(int fd, const void *vptr, size_t n)
{
  size_t nleft;
  ssize_t nwritten;
  const char *ptr;
  
  ptr = vptr;
  nleft = n;
  while (nleft > 0) {
    if ( (nwritten = write(fd, ptr, nleft)) <= 0) {
      if (errno == EINTR)
	nwritten = 0;	/* and call write() again */
      else
	return -1;	/* error */
    }
    
    nleft -= nwritten;
    ptr   += nwritten;
  }
  return n;
}	
/* end writen */

void Writen(int fd, void *ptr, size_t nbytes)
{
  if (writen(fd, ptr, nbytes) != nbytes)
    err_sys("writen error");
}

/* Read a line from stream socket to a buffer. The \n is stored in
 * the buffer along with a terminator \0.
*/
ssize_t readline(register int fd, register char *buf, register int maxlen)
{
  ssize_t n, rc;
  char c;

  for (n = 1; n < maxlen; n++) {
  Again:
    if( (rc = read(fd, &c, 1)) == 1) {
      *buf++ = c;
      if(c == '\n')
	break;			/* newline is stored as fgets() */
    } else if (rc == 0) {
      if (n == 1) 
	return 0; /*EOF, no data read */
      else
	break; /*EOF, some data was read.*/
    } else {
      if (errno == EINTR)
	goto Again;
      return -1; /* error */
    }
  }
  *buf = 0;	/* Null terminated like fgets() */
  return n;
}



/* bind server to a port and listen */
int ServerConnect(const unsigned short port) 
{
  struct sockaddr_in sin;
  const int one = 1;
  int sock_fd;

  /* use standard socket functions */
  sock_fd = Ssocket(AF_INET, SOCK_STREAM, 0);
  bzero(&sin, sizeof(struct sockaddr_in));
  sin.sin_family = AF_INET;
  sin.sin_port = htons(port);
  sin.sin_addr.s_addr = htonl(INADDR_ANY);

/* make the port resuable for the server, this is necessary */
  Ssetsockopt(sock_fd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));

  Ssetsockopt(sock_fd, SOL_SOCKET, SO_KEEPALIVE,
		(char *)&one, sizeof(one));

  Sbind(sock_fd, (struct sockaddr *) &sin, sizeof(struct sockaddr));

  Slisten(sock_fd, BACKLOG);

  return sock_fd;
}

/* establish connection between client and server */
int ClientConnect(int *res, const char *host, const int port)
{
  struct sockaddr_in sin;
  struct in_addr iaddr;
  int sock_fd;
  int one = 1;
  int status;

/* handle both name address and x.x.x.x IP address */
  /* inet_addr is deprecated, should use inet_aton */
  /*  iaddr.s_addr = inet_addr(host);*/
  status = inet_aton(host, &iaddr);
  /*  if ( iaddr.s_addr == INADDR_NONE ) { */
  if(status == 0) {
    /* inet_aton fails so we call gethostbyname_r */
    struct hostent *hptr;
    struct hostent_data *he_data;

    hptr = (struct hostent *) Smalloc(sizeof (struct hostent));
    he_data = (struct hostent_data *) Smalloc(sizeof (struct hostent_data));

    memset(he_data, 0, sizeof(struct hostent_data));

    if ( gethostbyname_r(host, hptr, he_data) < 0) {
      if (debug > 1)
	fprintf(stderr, "gethostbyname_r: Error! for %s\n", host);
      *res = -1;
      FREE_MAYBE(he_data);
      FREE_MAYBE(hptr);
      return -1;
    }

    if(hptr == NULL) {
      if (debug > 1)
	fprintf(stderr, "gethostbyname_r: Error! for %s\n", host);
      *res = -1;
      FREE_MAYBE(he_data);
      return -1;
    }

    /*memcpy(&iaddr, hptr->h_addr_list[0], sizeof(struct in_addr);*/
    memcpy(&iaddr, hptr->h_addr_list[0], hptr->h_length);
    FREE_MAYBE(he_data);
    FREE_MAYBE(hptr);
  }

  /* standard socket functions */
  sock_fd = Ssocket(AF_INET, SOCK_STREAM, 0);
  bzero(&sin, sizeof(struct sockaddr_in));
  sin.sin_family = AF_INET;
  sin.sin_port = htons(port);
  sin.sin_addr = iaddr;

  Ssetsockopt(sock_fd, SOL_SOCKET, SO_KEEPALIVE,
		(char *)&one, sizeof(one));

  *res = Sconnect(sock_fd, (struct sockaddr *)&sin, sizeof(struct sockaddr));

  return sock_fd;
}

