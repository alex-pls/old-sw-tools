/************************************************************************
WEBRELAY Software -- a multithreaded HTTP relay server
Copyright (C) 1999 Peter Zhang

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

Please address all correspondence concerning the software to 
zhangc@ucalgary.ca
************************************************************************/

#ifndef DBTBL_H
#define DBTBL_H

#include "hashtbl.h"
#include "utils.h"
#include "headers.h"

typedef struct dbinfo_s
{
    char *db_url;
    int auth_mandated;
    char *db_official_name;
} dbinfo_t;

int init_dburls PARAMS ((char *dburls_path));

int dburl_foreach PARAMS ((int (*foreach_funn)(hentry_t *hep, void *misc), void *misc));

hentry_t *dburl_lookup PARAMS ((const void *key, unsigned keylen));

void dburl_destroy PARAMS ((void));

static ssize_t read_line PARAMS ((int fd, char *buf, int size));

static ssize_t get_line PARAMS ((int fd, char **buf));

static int load_dburls PARAMS ((char *dburls_path));

static void dburl_free PARAMS ((void *));

#endif
