/************************************************************************
WEBRELAY Software -- a multithreaded HTTP relay server
Copyright (C) 1999 Peter Zhang

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

Please address all correspondence concerning the software to 
zhangc@ucalgary.ca
************************************************************************/

#ifndef HASHTBL_H
#define HASHTBL_H

#include "mywrap.h"

#define HTF_REPLACE	0x0001
#define HTF_NOINSERT	0x0002

typedef struct hentry_s
{
    pthread_mutex_t lock;
    int h_count;
    void *key;
    unsigned int keylen;
    void *data;
    struct hentry_s *next;
    void (*release_func)(void *data);
} hentry_t;


typedef struct htable_s
{
    unsigned int size;
    unsigned int (*hash_func)(const void *key,
			     unsigned int keylen,
			     unsigned int size);
    void (*release_func)(void *data);
    hentry_t *table;
} htable_t;

static unsigned int hash PARAMS ((const void *key,
				  unsigned int keylen,
				  unsigned int hashsize));

void ht_init PARAMS ((htable_t *htp,
		      unsigned int hashsize,
		      unsigned int (*hash_func)(const void *key,
						unsigned int keylen,
						unsigned int hashsize),
		      void (*release_func)(void *data)));

int ht_clean PARAMS ((htable_t *htp));
void ht_destroy PARAMS ((htable_t *htp));

hentry_t *ht_lookup PARAMS ((htable_t *htp,
			     const void *key,
			     unsigned int keylen));

void ht_release PARAMS ((hentry_t *hep));

void ht_free PARAMS ((hentry_t *hep));

hentry_t *ht_insert PARAMS ((htable_t *htp,
			     const void *key,
			     unsigned int keylen,
			     void *data,
			     unsigned int flags,
			     void (*release_func)(void *data)));

int ht_delete PARAMS ((htable_t *htp, hentry_t *hep));

int ht_foreach PARAMS ((htable_t *htp,
			int (*foreach_func)(hentry_t *hep,
					    void *misc),
			void *misc));

#endif
