/************************************************************************
WEBRELAY Software -- a multithreaded HTTP relay server
Copyright (C) 1999 Peter Zhang

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

Please address all correspondence concerning the software to 
zhangc@ucalgary.ca
************************************************************************/

#ifndef CHAINHASH_H
#define CHAINHASH_H

#include "mywrap.h"
#include "utils.h"

typedef struct chain_node_s
{
    pthread_mutex_t lock;
    int ref_count;
    /* Initialization time or Session start time */
    time_t SesStart;
    /* Last Updated time */
    time_t LastUpdated;
			 
    void (*release_func)(void *data);
    
    void *key;
    unsigned int keylen;
    void *data;
    
    struct chain_node_s *next;
} chain_node_t;

typedef struct chain_hash_s
{
    unsigned int size;
    unsigned int (*hash_func)(const void *key,
			     unsigned int keylen,
			     unsigned int size);
    void (*release_func)(void *data);
    int refresh;
    int ttl;
    int gc_sleep;
    chain_node_t *table;
} chain_hash_t;

#define CF_REPLACE	0x0001
#define CF_NOINSERT	0x0010

static unsigned int c_hash PARAMS ((const void *key,
			 unsigned int keylen,
			 unsigned int hashsize));

static void *gc_thrd PARAMS ((void *arg));

static chain_node_t *chain_node_alloc PARAMS((void *key,
				  unsigned int keylen,
				  void *data,
				  void (*release_func)(void *data)));

void chain_hash_init PARAMS ((chain_hash_t *chp,
			 int refresh,
			 int ttl,
			 int gc_sleep,
			 unsigned int hashsize,
			 unsigned int (*hash_func)(const void *key,
						   unsigned int keylen,
						   unsigned int hashsize),
			 void (*release_func)(void *data)));

chain_node_t *chain_hash_find PARAMS ((chain_hash_t *chp,
			      void *key,
			      unsigned int keylen));


chain_node_t *chain_hash_insert PARAMS ((chain_hash_t *chp, void *key,
				unsigned int keylen,
				void *data, unsigned int flags,
				void (*release_func)(void *data)));

void chain_hash_release PARAMS ((chain_node_t *cnp));

int chain_hash_delete PARAMS ((chain_hash_t *chp, chain_node_t *cnp));

int chain_hash_foreach PARAMS ((chain_hash_t *chp,
			   int (*foreach_func)(chain_node_t *cnp, void *misc),
			   void *misc));

#endif
